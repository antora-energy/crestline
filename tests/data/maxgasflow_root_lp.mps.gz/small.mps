NAME        bad
ROWS
 N  Obj     
 L  r0      
 L  r11     
 L  r12     
 L  r15     
 L  r16     
 L  r20     
 L  r23     
 L  r32     
 L  r36     
 L  r39     
 L  r42     
 L  r43     
 L  r45     
 L  r46     
 L  r47     
 L  r48     
 L  r49     
 L  r50     
 L  r52     
 L  r58     
 L  r60     
 L  r61     
 L  r64     
 L  r65     
 L  r81     
 L  r82     
 L  r88     
 L  r89     
 L  r90     
 L  r91     
 L  r92     
 L  r101    
 L  r102    
 L  r103    
 L  r104    
 L  r105    
 L  r106    
 L  r107    
 L  r112    
 L  r114    
 L  r115    
 L  r116    
 L  r117    
 L  r118    
 L  r119    
 L  r120    
 L  r121    
 L  r122    
 L  r123    
 L  r124    
 L  r125    
 L  r126    
 L  r127    
 L  r128    
 L  r129    
 L  r130    
 L  r131    
 L  r133    
 L  r134    
 L  r136    
 L  r137    
 L  r138    
 L  r139    
 L  r142    
 L  r147    
 L  r148    
 L  r158    
 L  r161    
 L  r162    
 L  r163    
 L  r164    
 L  r166    
 L  r168    
 L  r169    
 L  r170    
 L  r172    
 L  r179    
 L  r189    
 L  r190    
 L  r191    
 L  r192    
 L  r193    
 L  r194    
 L  r195    
 L  r196    
 L  r197    
 L  r198    
 L  r199    
 L  r202    
 L  r205    
 L  r206    
 L  r209    
 L  r210    
 L  r211    
 L  r212    
 L  r214    
 L  r215    
 L  r218    
 L  r219    
 L  r220    
 L  r221    
 L  r222    
 L  r225    
 L  r227    
 L  r229    
 L  r230    
 L  r232    
 L  r233    
 L  r235    
 L  r236    
 L  r239    
 L  r243    
 L  r244    
 L  r246    
 L  r247    
 L  r248    
 L  r249    
 L  r250    
 L  r251    
 L  r252    
 L  r253    
 L  r255    
 L  r256    
 L  r258    
 L  r261    
 L  r265    
 L  r267    
 L  r268    
 L  r269    
 L  r270    
 L  r272    
 L  r274    
 L  r275    
 L  r276    
 L  r277    
 L  r278    
 L  r279    
 L  r280    
 L  r281    
 L  r282    
 L  r283    
 L  r284    
 L  r285    
 L  r287    
 L  r292    
 L  r293    
 L  r295    
 L  r298    
 L  r299    
 L  r300    
 L  r301    
 L  r303    
 L  r304    
 L  r305    
 L  r307    
 L  r309    
 L  r310    
 L  r313    
 L  r322    
 L  r323    
 L  r325    
 L  r327    
 L  r330    
 L  r331    
 L  r333    
 L  r335    
 L  r337    
 L  r338    
 L  r340    
 L  r341    
 L  r342    
 L  r345    
 L  r347    
 L  r349    
 L  r350    
 L  r360    
 L  r361    
 L  r362    
 L  r365    
 L  r366    
 L  r368    
 L  r369    
 L  r370    
 L  r371    
 L  r383    
 L  r392    
 L  r394    
 L  r397    
 L  r398    
 L  r399    
 L  r400    
 L  r401    
 L  r403    
 L  r405    
 L  r406    
 L  r407    
 L  r408    
 L  r411    
 L  r412    
 L  r414    
 L  r415    
 L  r416    
 L  r417    
 L  r418    
 L  r419    
 L  r420    
 L  r421    
 L  r422    
 L  r423    
 L  r424    
 L  r425    
 L  r426    
 L  r427    
 L  r428    
 L  r429    
 L  r430    
 L  r431    
 L  r432    
 L  r433    
 L  r434    
 L  r435    
 L  r436    
 L  r437    
 L  r438    
 L  r439    
 L  r440    
 L  r441    
 L  r442    
 L  r443    
 L  r444    
 L  r446    
 L  r447    
 L  r448    
 L  r449    
 L  r461    
 L  r462    
 L  r463    
 L  r468    
 L  r470    
 L  r474    
 L  r476    
 L  r477    
 L  r479    
 L  r480    
 L  r481    
 L  r482    
 L  r483    
 L  r484    
 L  r485    
 L  r488    
 L  r489    
 L  r490    
 L  r493    
 L  r494    
 L  r495    
 L  r496    
 L  r497    
 L  r498    
 L  r499    
 L  r500    
 L  r501    
 L  r502    
 L  r504    
 L  r505    
 L  r510    
 L  r513    
 L  r514    
 L  r516    
 L  r519    
 L  r520    
 L  r521    
 L  r522    
 L  r523    
 L  r525    
 L  r527    
 L  r530    
 L  r531    
 L  r534    
 L  r537    
 L  r538    
 L  r540    
 L  r544    
 L  r545    
 L  r546    
 L  r547    
 L  r548    
 L  r550    
 L  r551    
 L  r552    
 L  r553    
 L  r559    
 L  r560    
 L  r561    
 L  r562    
 L  r563    
 L  r564    
 L  r566    
 L  r567    
 L  r568    
 L  r574    
 L  r575    
 L  r576    
 L  r577    
 L  r583    
 L  r584    
 L  r585    
 L  r586    
 L  r587    
 L  r593    
 L  r600    
 L  r601    
 L  r603    
 L  r604    
 L  r605    
 L  r606    
 L  r607    
 L  r614    
 L  r615    
 L  r616    
 L  r622    
 L  r623    
 L  r625    
 L  r627    
 L  r628    
 L  r630    
 L  r631    
 L  r632    
 L  r636    
 L  r640    
 L  r641    
 L  r642    
 L  r643    
 L  r645    
 L  r646    
 L  r647    
 L  r649    
 L  r650    
 L  r651    
 L  r652    
 L  r653    
 L  r654    
 L  r655    
 L  r657    
 L  r658    
 L  r659    
 L  r660    
 L  r661    
 L  r662    
 L  r664    
 L  r665    
 L  r666    
 L  r668    
 L  r669    
 L  r671    
 L  r673    
 L  r674    
 L  r675    
 L  r676    
 L  r677    
 L  r678    
 L  r679    
 L  r681    
 L  r684    
 L  r685    
 L  r688    
 L  r689    
 L  r691    
 L  r692    
 L  r693    
 L  r694    
 L  r695    
 L  r697    
 L  r699    
 L  r703    
 L  r705    
 L  r706    
 L  r707    
 L  r708    
 L  r709    
 L  r710    
 L  r711    
 L  r713    
 L  r718    
 L  r719    
 L  r720    
 L  r723    
 L  r726    
 L  r727    
 L  r728    
 L  r729    
 L  r730    
 L  r731    
 L  r732    
 L  r733    
 L  r734    
 L  r735    
 L  r736    
 L  r738    
 L  r739    
 L  r740    
 L  r742    
 L  r743    
 L  r744    
 L  r746    
 L  r747    
 L  r748    
 L  r749    
 L  r750    
 L  r754    
 L  r756    
 L  r757    
 L  r758    
 L  r759    
 L  r760    
 L  r761    
 L  r762    
 L  r765    
 L  r767    
 L  r768    
 L  r769    
 L  r770    
 L  r772    
 L  r775    
 L  r776    
 L  r778    
 L  r779    
 L  r780    
 L  r781    
 L  r782    
 L  r783    
 L  r784    
 L  r785    
 L  r786    
 L  r787    
 L  r788    
 L  r792    
 L  r794    
 L  r797    
 L  r800    
 L  r801    
 L  r804    
 L  r805    
 L  r806    
 L  r808    
 L  r809    
 L  r815    
 L  r818    
 L  r821    
 L  r823    
 L  r824    
 L  r825    
 L  r826    
 L  r829    
 L  r858    
 L  r859    
 L  r863    
 L  r867    
 L  r870    
 L  r871    
 L  r873    
 L  r875    
 L  r876    
 L  r880    
 L  r881    
 L  r884    
 L  r889    
 L  r890    
 L  r892    
 L  r895    
 L  r896    
 L  r898    
 L  r899    
 L  r906    
 L  r909    
 L  r910    
 L  r911    
 L  r912    
 L  r913    
 L  r914    
 L  r915    
 L  r917    
 L  r922    
 L  r923    
 L  r924    
 L  r925    
 L  r926    
 L  r928    
 L  r929    
 L  r930    
 L  r933    
 L  r934    
 L  r941    
 L  r942    
 L  r949    
 L  r950    
 L  r951    
 L  r953    
 L  r955    
 L  r956    
 L  r957    
 L  r958    
 L  r959    
 L  r960    
 L  r961    
 L  r962    
 L  r963    
 L  r964    
 L  r965    
 L  r966    
 L  r967    
 L  r971    
 L  r972    
 L  r974    
 L  r975    
 L  r977    
 L  r978    
 L  r979    
 L  r980    
 L  r985    
 L  r986    
 L  r987    
 L  r988    
 L  r989    
 L  r990    
 L  r991    
 L  r993    
 L  r994    
 L  r995    
 L  r996    
 L  r998    
 L  r999    
 L  r1000   
 L  r1001   
 L  r1002   
 L  r1003   
 L  r1005   
 L  r1006   
 L  r1007   
 L  r1008   
 L  r1009   
 L  r1010   
 L  r1011   
 L  r1015   
 L  r1016   
 L  r1024   
 L  r1028   
 L  r1031   
 L  r1032   
 L  r1033   
 L  r1037   
 L  r1040   
 L  r1041   
 L  r1051   
 L  r1061   
 L  r1062   
 L  r1063   
 L  r1064   
 L  r1067   
 L  r1070   
 L  r1071   
 L  r1072   
 L  r1075   
 L  r1077   
 L  r1078   
 L  r1079   
 L  r1080   
 L  r1081   
 L  r1082   
 L  r1085   
 L  r1087   
 L  r1088   
 L  r1091   
 L  r1092   
 L  r1093   
 L  r1094   
 L  r1095   
 L  r1098   
 L  r1100   
 L  r1101   
 L  r1102   
 L  r1103   
 L  r1104   
 L  r1107   
 L  r1108   
 L  r1109   
 L  r1111   
 L  r1114   
 L  r1115   
 L  r1116   
 L  r1117   
 L  r1118   
 L  r1120   
 L  r1121   
 L  r1122   
 L  r1125   
 L  r1128   
 L  r1129   
 L  r1130   
 L  r1131   
 L  r1132   
 L  r1133   
 L  r1135   
 L  r1136   
 L  r1138   
 L  r1139   
 L  r1148   
 L  r1151   
 L  r1152   
 L  r1157   
 L  r1158   
 L  r1165   
 L  r1171   
 L  r1172   
 L  r1176   
 L  r1178   
 L  r1182   
 L  r1187   
 L  r1190   
 L  r1192   
 L  r1193   
 L  r1195   
 L  r1196   
 L  r1197   
 L  r1201   
 L  r1202   
 L  r1208   
 L  r1211   
 L  r1212   
 L  r1214   
 L  r1215   
 L  r1218   
 L  r1219   
 L  r1221   
 L  r1223   
 L  r1225   
 L  r1226   
 L  r1227   
 L  r1229   
 L  r1230   
 L  r1231   
 L  r1233   
 L  r1242   
 L  r1248   
 L  r1250   
 L  r1252   
 L  r1254   
 L  r1257   
 L  r1261   
 L  r1263   
 L  r1264   
 L  r1266   
 L  r1274   
 L  r1275   
 L  r1276   
 L  r1277   
 L  r1282   
 L  r1283   
 L  r1288   
 L  r1289   
 L  r1290   
 L  r1293   
 L  r1296   
 L  r1297   
 L  r1299   
 L  r1300   
 L  r1302   
 L  r1303   
 L  r1304   
 L  r1305   
 L  r1306   
 L  r1307   
 L  r1309   
 L  r1318   
 L  r1319   
 L  r1320   
 L  r1321   
 L  r1322   
 L  r1327   
 L  r1331   
 L  r1332   
 L  r1338   
 L  r1339   
 L  r1340   
 L  r1342   
 L  r1343   
 L  r1348   
 L  r1349   
 L  r1353   
 L  r1357   
 L  r1361   
 L  r1367   
 L  r1368   
 L  r1369   
 L  r1370   
 L  r1371   
 L  r1374   
 L  r1378   
 L  r1383   
 L  r1384   
 L  r1389   
 L  r1390   
 L  r1395   
 L  r1397   
 L  r1399   
 L  r1400   
 L  r1403   
 L  r1414   
 L  r1419   
 L  r1420   
 L  r1427   
 L  r1428   
 L  r1432   
 L  r1433   
 L  r1437   
 L  r1438   
 L  r1450   
 L  r1452   
 L  r1454   
 L  r1456   
 L  r1457   
 L  r1458   
 L  r1460   
 L  r1466   
 L  r1467   
 L  r1468   
 L  r1471   
 L  r1474   
 L  r1475   
 L  r1476   
 L  r1477   
 L  r1478   
 L  r1480   
 L  r1483   
 L  r1485   
 L  r1492   
 L  r1493   
 L  r1494   
 L  r1496   
 L  r1508   
 L  r1512   
 L  r1513   
 L  r1514   
 L  r1515   
 L  r1518   
 L  r1519   
 L  r1525   
 L  r1531   
 L  r1540   
 L  r1541   
 L  r1542   
 L  r1543   
 L  r1544   
 L  r1545   
 L  r1546   
 L  r1549   
 L  r1550   
 L  r1552   
 L  r1553   
 L  r1554   
 L  r1556   
 L  r1557   
 L  r1559   
 L  r1564   
 L  r1568   
 L  r1569   
 L  r1572   
 L  r1573   
 L  r1574   
 L  r1575   
 L  r1576   
 L  r1577   
 L  r1578   
 L  r1579   
 L  r1583   
 L  r1588   
 L  r1589   
 L  r1590   
 L  r1599   
 L  r1600   
 L  r1601   
 L  r1602   
 L  r1603   
 L  r1604   
 L  r1605   
 L  r1612   
 L  r1613   
 L  r1614   
 L  r1615   
 L  r1616   
 L  r1617   
 L  r1618   
 L  r1619   
 L  r1620   
 L  r1621   
 L  r1622   
 L  r1623   
 L  r1624   
 L  r1626   
 L  r1627   
 L  r1628   
 L  r1629   
 L  r1635   
 L  r1636   
 L  r1640   
 L  r1646   
 L  r1649   
 L  r1651   
 L  r1656   
 L  r1661   
 L  r1667   
 L  r1671   
 L  r1672   
 L  r1676   
 L  r1687   
 L  r1688   
 L  r1689   
 L  r1690   
 L  r1692   
 L  r1694   
 L  r1695   
 L  r1696   
 L  r1698   
 L  r1699   
 L  r1703   
 L  r1708   
 L  r1709   
 L  r1710   
 L  r1712   
 L  r1713   
 L  r1714   
 L  r1716   
 L  r1717   
 L  r1719   
 L  r1720   
 L  r1721   
 L  r1722   
 L  r1723   
 L  r1727   
 L  r1728   
 L  r1730   
 L  r1732   
 L  r1733   
 L  r1734   
 L  r1735   
 L  r1737   
 L  r1739   
 L  r1742   
 L  r1745   
 L  r1746   
 L  r1747   
 L  r1748   
 L  r1749   
 L  r1750   
 L  r1752   
 L  r1753   
 L  r1754   
 L  r1756   
 L  r1760   
 L  r1762   
 L  r1763   
 L  r1765   
 L  r1766   
 L  r1768   
 L  r1771   
 L  r1772   
 L  r1773   
 L  r1774   
 L  r1775   
 L  r1776   
 L  r1778   
 L  r1779   
 L  r1780   
 L  r1782   
 L  r1783   
 L  r1785   
 L  r1787   
 L  r1788   
 L  r1792   
 L  r1795   
 L  r1796   
 L  r1799   
 L  r1809   
 L  r1814   
 L  r1816   
 L  r1818   
 L  r1822   
 L  r1829   
 L  r1830   
 L  r1833   
 L  r1835   
 L  r1840   
 L  r1842   
 L  r1844   
 L  r1845   
 L  r1847   
 L  r1848   
 L  r1849   
 L  r1850   
 L  r1851   
 L  r1853   
 L  r1854   
 L  r1855   
 L  r1856   
 L  r1858   
 L  r1859   
 L  r1862   
 L  r1863   
 L  r1864   
 L  r1866   
 L  r1867   
 L  r1868   
 L  r1869   
 L  r1871   
 L  r1872   
 L  r1873   
 L  r1874   
 L  r1875   
 L  r1876   
 L  r1877   
 L  r1879   
 L  r1880   
 L  r1881   
 L  r1882   
 L  r1883   
 L  r1884   
 L  r1885   
 L  r1886   
 L  r1887   
 L  r1888   
 L  r1889   
 L  r1892   
 L  r1896   
 L  r1897   
 L  r1898   
 L  r1899   
 L  r1901   
 L  r1904   
 L  r1905   
 L  r1906   
 L  r1909   
 L  r1912   
 L  r1913   
 L  r1914   
 L  r1915   
 L  r1916   
 L  r1917   
 L  r1918   
 L  r1919   
 L  r1920   
 L  r1921   
 L  r1922   
 L  r1923   
 L  r1925   
 L  r1926   
 L  r1927   
 L  r1928   
 L  r1929   
 L  r1930   
 L  r1931   
 L  r1935   
 L  r1936   
 L  r1937   
 L  r1938   
 L  r1939   
 L  r1940   
 L  r1941   
 L  r1942   
 L  r1954   
 L  r1961   
 L  r1964   
 L  r1966   
 L  r1971   
 L  r1976   
 L  r1978   
 L  r1979   
 L  r1982   
 L  r1985   
 L  r1986   
 L  r1991   
 L  r1994   
 L  r1995   
 L  r1998   
 L  r2002   
 L  r2012   
 L  r2017   
 L  r2021   
 L  r2032   
 L  r2033   
 L  r2034   
 L  r2035   
 L  r2036   
 L  r2037   
 L  r2039   
 L  r2041   
 L  r2043   
 L  r2045   
 L  r2046   
 L  r2048   
 L  r2056   
 L  r2057   
 L  r2058   
 L  r2059   
 L  r2060   
 L  r2061   
 L  r2062   
 L  r2063   
 L  r2064   
 L  r2065   
 L  r2066   
 L  r2067   
 L  r2068   
 L  r2069   
 L  r2071   
 L  r2072   
 L  r2073   
 L  r2074   
 L  r2075   
 L  r2076   
 L  r2080   
 L  r2081   
 L  r2082   
 L  r2083   
 L  r2084   
 L  r2085   
 L  r2088   
 L  r2089   
 L  r2090   
 L  r2095   
 L  r2096   
 L  r2098   
 L  r2101   
 L  r2102   
 L  r2103   
 L  r2105   
 L  r2106   
 L  r2108   
 L  r2112   
 L  r2113   
 L  r2116   
 L  r2119   
 L  r2123   
 L  r2125   
 L  r2129   
 L  r2135   
 L  r2138   
 L  r2139   
 L  r2140   
 L  r2141   
 L  r2144   
 L  r2145   
 L  r2147   
 L  r2149   
 L  r2150   
 L  r2151   
 L  r2152   
 L  r2153   
 L  r2157   
 L  r2159   
 L  r2162   
 L  r2163   
 L  r2164   
 L  r2166   
 L  r2167   
 L  r2169   
 L  r2175   
 L  r2177   
 L  r2178   
 L  r2179   
 L  r2182   
 L  r2183   
 L  r2184   
 L  r2186   
 L  r2189   
 L  r2192   
 L  r2193   
 L  r2201   
 L  r2203   
 L  r2205   
 L  r2208   
 L  r2209   
 L  r2210   
 L  r2211   
 L  r2219   
 L  r2220   
 L  r2221   
 L  r2225   
 L  r2226   
 L  r2227   
 L  r2229   
 L  r2230   
 L  r2231   
 L  r2234   
 L  r2238   
 L  r2239   
 L  r2240   
 L  r2242   
 L  r2244   
 L  r2246   
 L  r2247   
 L  r2248   
 L  r2259   
 L  r2260   
 L  r2265   
 L  r2266   
 L  r2267   
 L  r2269   
 L  r2270   
 L  r2271   
 L  r2275   
 L  r2276   
 L  r2277   
 L  r2278   
 L  r2279   
 L  r2280   
 L  r2281   
 L  r2282   
 L  r2283   
 L  r2284   
 L  r2285   
 L  r2289   
 L  r2290   
 L  r2296   
 L  r2298   
 L  r2299   
 L  r2300   
 L  r2302   
 L  r2303   
 L  r2306   
 L  r2307   
 L  r2308   
 L  r2317   
 L  r2321   
 L  r2324   
 L  r2325   
 L  r2326   
 L  r2327   
 L  r2328   
 L  r2330   
 L  r2332   
 L  r2334   
 L  r2335   
 L  r2343   
 L  r2348   
 L  r2349   
 L  r2352   
 L  r2353   
 L  r2354   
 L  r2355   
 L  r2359   
 L  r2367   
 L  r2379   
 L  r2384   
 L  r2396   
 L  r2404   
 L  r2406   
 L  r2407   
 L  r2410   
 L  r2411   
 L  r2413   
 L  r2415   
 L  r2422   
 L  r2423   
 L  r2425   
 L  r2427   
 L  r2432   
 L  r2435   
 L  r2442   
 L  r2443   
 L  r2448   
 L  r2449   
 L  r2450   
 L  r2451   
 L  r2453   
 L  r2454   
 L  r2455   
 L  r2458   
 L  r2459   
 L  r2460   
 L  r2461   
 L  r2462   
 L  r2463   
 L  r2464   
 L  r2465   
 L  r2473   
 L  r2476   
 L  r2477   
 L  r2478   
 L  r2486   
 L  r2487   
 L  r2488   
 L  r2489   
 L  r2517   
 L  r2523   
 L  r2528   
 L  r2542   
 L  r2563   
 L  r2582   
 L  r2677   
 L  r2782   
 L  r2815   
 L  r2816   
 L  r2830   
 L  r2859   
 L  r2860   
 L  r2864   
 L  r2884   
 L  r2901   
 L  r2903   
 L  r2912   
 L  r2913   
 L  r2914   
 L  r2915   
 L  r2916   
 L  r2917   
 L  r2918   
 L  r2919   
 L  r2920   
 L  r2921   
 L  r2922   
 L  r2923   
 L  r2924   
 L  r2925   
 L  r2926   
 L  r2927   
 L  r2928   
 L  r2929   
 L  r2930   
 L  r2931   
 L  r2932   
 L  r2933   
 L  r2934   
 L  r2935   
 L  r2936   
 L  r2937   
 L  r2941   
 L  r2987   
 E  r2996   
 E  r2997   
 E  r2998   
 E  r2999   
 E  r3000   
 E  r3001   
 E  r3002   
 E  r3003   
 E  r3004   
 E  r3005   
 E  r3006   
 E  r3007   
 E  r3008   
 E  r3009   
 E  r3010   
 E  r3011   
 E  r3012   
 E  r3013   
 E  r3014   
 E  r3015   
 E  r3016   
 E  r3017   
 E  r3018   
 E  r3019   
 E  r3020   
 E  r3021   
 E  r3022   
 E  r3023   
 E  r3024   
 E  r3025   
 E  r3026   
 E  r3027   
 E  r3028   
 E  r3029   
 E  r3030   
 E  r3031   
 E  r3032   
 E  r3033   
 E  r3034   
 E  r3035   
 E  r3036   
 E  r3037   
 E  r3038   
 E  r3039   
 E  r3040   
 E  r3041   
 E  r3042   
 E  r3043   
 E  r3044   
 E  r3045   
 E  r3046   
 E  r3047   
 E  r3048   
 E  r3049   
 E  r3050   
 E  r3051   
 E  r3052   
 E  r3053   
 E  r3054   
 E  r3055   
 E  r3056   
 E  r3057   
 E  r3058   
 E  r3059   
 E  r3060   
 E  r3061   
 E  r3062   
 E  r3063   
 E  r3064   
 E  r3065   
 E  r3066   
 E  r3067   
 E  r3068   
 E  r3069   
 E  r3070   
 E  r3071   
 E  r3072   
 E  r3073   
 E  r3074   
 E  r3075   
 E  r3076   
 E  r3077   
 E  r3078   
 E  r3079   
 E  r3080   
 E  r3081   
 E  r3082   
 E  r3083   
 E  r3084   
 E  r3085   
 E  r3086   
 E  r3087   
 E  r3088   
 E  r3089   
 E  r3090   
 E  r3091   
 E  r3092   
 E  r3093   
 E  r3094   
 E  r3095   
 E  r3096   
 E  r3097   
 E  r3098   
 E  r3099   
 E  r3100   
 E  r3101   
 E  r3102   
 E  r3103   
 E  r3104   
 E  r3105   
 E  r3106   
 E  r3107   
 E  r3108   
 E  r3109   
 E  r3110   
 E  r3111   
 E  r3112   
 E  r3113   
 E  r3114   
 E  r3115   
 E  r3116   
 E  r3117   
 E  r3118   
 E  r3119   
 E  r3120   
 E  r3121   
 E  r3122   
 E  r3123   
 E  r3124   
 E  r3125   
 E  r3126   
 E  r3127   
 E  r3128   
 E  r3129   
 E  r3130   
 E  r3131   
 E  r3132   
 E  r3133   
 E  r3134   
 E  r3135   
 E  r3136   
 E  r3137   
 E  r3138   
 E  r3139   
 E  r3140   
 E  r3141   
 E  r3142   
 E  r3143   
 E  r3144   
 E  r3145   
 E  r3146   
 E  r3147   
 E  r3148   
 E  r3149   
 E  r3150   
 E  r3151   
 E  r3152   
 E  r3153   
 E  r3154   
 E  r3155   
 E  r3156   
 E  r3157   
 E  r3158   
 E  r3159   
 E  r3160   
 E  r3161   
 E  r3162   
 E  r3163   
 E  r3164   
 E  r3165   
 E  r3166   
 E  r3167   
 E  r3168   
 E  r3169   
 E  r3170   
 E  r3171   
 E  r3172   
 E  r3173   
 E  r3174   
 E  r3175   
 E  r3176   
 E  r3177   
 E  r3178   
 E  r3179   
 E  r3180   
 E  r3181   
 E  r3182   
 E  r3183   
 E  r3184   
 E  r3185   
 E  r3186   
 E  r3187   
 E  r3188   
 E  r3189   
 E  r3190   
 E  r3191   
 E  r3192   
 E  r3193   
 E  r3194   
 E  r3195   
 E  r3196   
 E  r3197   
 E  r3198   
 E  r3199   
 E  r3200   
 E  r3201   
 E  r3202   
 E  r3203   
 E  r3204   
 E  r3205   
 E  r3206   
 E  r3207   
 E  r3208   
 E  r3209   
 E  r3210   
 E  r3211   
 E  r3212   
 E  r3213   
 E  r3214   
 E  r3215   
 E  r3216   
 E  r3217   
 E  r3218   
 E  r3219   
 E  r3220   
 E  r3221   
 E  r3222   
 E  r3223   
 E  r3224   
 E  r3225   
 E  r3226   
 E  r3227   
 E  r3228   
 E  r3229   
 E  r3230   
 E  r3231   
 E  r3232   
 E  r3233   
 E  r3234   
 E  r3235   
 E  r3236   
 E  r3237   
 E  r3238   
 E  r3239   
 E  r3240   
 E  r3241   
 E  r3242   
 E  r3243   
 E  r3244   
 E  r3245   
 E  r3246   
 E  r3247   
 E  r3248   
 E  r3249   
 E  r3250   
 E  r3251   
 E  r3252   
 E  r3253   
 E  r3254   
 E  r3255   
 E  r3256   
 E  r3257   
 E  r3258   
 E  r3259   
 E  r3260   
 E  r3261   
 E  r3262   
 E  r3263   
 E  r3264   
 E  r3265   
 E  r3266   
 E  r3267   
 E  r3268   
 E  r3269   
 E  r3270   
 E  r3271   
 E  r3272   
 E  r3273   
 E  r3274   
 E  r3275   
 E  r3276   
 E  r3277   
 E  r3278   
 E  r3279   
 E  r3280   
 E  r3281   
 E  r3282   
 E  r3283   
 E  r3284   
 E  r3285   
 E  r3286   
 E  r3287   
 E  r3288   
 E  r3289   
 E  r3290   
 E  r3291   
 E  r3292   
 E  r3293   
 E  r3294   
 E  r3295   
 E  r3296   
 E  r3297   
 E  r3298   
 E  r3299   
 E  r3300   
 E  r3301   
 E  r3302   
 E  r3303   
 E  r3304   
 E  r3305   
 E  r3306   
 E  r3307   
 E  r3308   
 E  r3309   
 E  r3310   
 E  r3311   
 E  r3312   
 E  r3313   
 E  r3314   
 E  r3315   
 E  r3316   
 E  r3317   
 E  r3318   
 E  r3319   
 E  r3320   
 E  r3321   
 E  r3322   
 E  r3323   
 E  r3324   
 E  r3325   
 E  r3326   
 E  r3327   
 E  r3328   
 E  r3329   
 E  r3330   
 E  r3331   
 E  r3332   
 E  r3333   
 E  r3334   
 E  r3335   
 E  r3336   
 E  r3337   
 E  r3338   
 E  r3339   
 E  r3340   
 E  r3341   
 E  r3342   
 E  r3343   
 E  r3344   
 E  r3345   
 E  r3346   
 E  r3347   
 E  r3348   
 E  r3349   
 E  r3350   
 E  r3351   
 E  r3352   
 E  r3353   
 E  r3354   
 E  r3355   
 E  r3356   
 E  r3357   
 E  r3358   
 E  r3359   
 E  r3360   
 E  r3361   
 E  r3362   
 E  r3363   
 E  r3364   
 E  r3365   
 E  r3366   
 E  r3367   
 E  r3368   
 E  r3369   
 E  r3370   
 E  r3371   
 E  r3372   
 E  r3373   
 E  r3374   
 E  r3375   
 E  r3376   
 E  r3377   
 E  r3378   
 E  r3379   
 E  r3380   
 E  r3381   
 E  r3382   
 E  r3383   
 E  r3384   
 E  r3385   
 E  r3386   
 E  r3387   
 E  r3388   
 E  r3389   
 E  r3390   
 E  r3391   
 E  r3392   
 E  r3393   
 E  r3394   
 E  r3395   
 E  r3396   
 E  r3397   
 E  r3398   
 E  r3399   
 E  r3400   
 E  r3401   
 E  r3402   
 E  r3403   
 E  r3404   
 E  r3405   
 E  r3406   
 E  r3407   
 E  r3408   
 E  r3409   
 E  r3410   
 E  r3411   
 E  r3412   
 E  r3413   
 E  r3414   
 E  r3415   
 E  r3416   
 E  r3417   
 E  r3418   
 E  r3419   
 E  r3420   
 E  r3421   
 E  r3422   
 E  r3423   
 E  r3424   
 E  r3425   
 E  r3426   
 E  r3427   
 E  r3428   
 E  r3429   
 E  r3430   
 E  r3431   
 E  r3432   
 E  r3433   
 E  r3434   
 E  r3435   
 E  r3436   
 E  r3437   
 E  r3438   
 E  r3439   
 E  r3440   
 E  r3441   
 E  r3442   
 E  r3443   
 E  r3444   
 E  r3445   
 E  r3446   
 E  r3447   
 E  r3448   
 E  r3449   
 E  r3450   
 E  r3451   
 E  r3452   
 E  r3453   
 E  r3454   
 E  r3455   
 E  r3456   
 E  r3457   
 E  r3458   
 E  r3459   
 E  r3460   
 E  r3461   
 E  r3462   
 E  r3463   
 E  r3464   
 E  r3465   
 E  r3466   
 E  r3467   
 E  r3468   
 E  r3469   
 E  r3470   
 E  r3471   
 E  r3472   
 E  r3473   
 E  r3474   
 E  r3475   
 E  r3476   
 E  r3477   
 E  r3478   
 E  r3479   
 E  r3480   
 E  r3481   
 E  r3482   
 E  r3483   
 E  r3484   
 E  r3485   
 E  r3486   
 E  r3487   
 E  r3488   
 E  r3489   
 E  r3490   
 E  r3491   
 E  r3492   
 E  r3493   
 E  r3494   
 E  r3495   
 E  r3496   
 E  r3497   
 E  r3498   
 E  r3499   
 E  r3500   
 E  r3501   
 E  r3502   
 E  r3503   
 E  r3504   
 E  r3505   
 E  r3506   
 E  r3507   
 E  r3508   
 E  r3509   
 E  r3510   
 E  r3511   
 E  r3512   
 E  r3513   
 E  r3514   
 E  r3515   
 E  r3516   
 E  r3517   
 E  r3518   
 E  r3519   
 E  r3520   
 E  r3521   
 E  r3522   
 E  r3523   
 E  r3524   
 E  r3525   
 E  r3526   
 E  r3527   
 E  r3528   
 E  r3529   
 E  r3530   
 E  r3531   
 E  r3532   
 E  r3533   
 E  r3534   
 E  r3535   
 E  r3536   
 E  r3537   
 E  r3538   
 E  r3539   
 E  r3540   
 E  r3541   
 E  r3542   
 E  r3543   
 E  r3544   
 E  r3545   
 E  r3546   
 E  r3547   
 E  r3548   
 E  r3549   
 E  r3550   
 E  r3551   
 E  r3552   
 E  r3553   
 E  r3554   
 E  r3555   
 E  r3556   
 E  r3557   
 E  r3558   
 E  r3559   
 E  r3560   
 E  r3561   
 E  r3562   
 E  r3563   
 E  r3564   
 E  r3565   
 E  r3566   
 E  r3567   
 E  r3568   
 E  r3569   
 E  r3570   
 E  r3571   
 E  r3572   
 E  r3573   
 E  r3574   
 E  r3575   
 E  r3576   
 E  r3577   
 E  r3578   
 E  r3579   
 E  r3580   
 E  r3581   
 E  r3582   
 E  r3583   
 E  r3584   
 E  r3585   
 E  r3586   
 E  r3587   
 E  r3588   
 E  r3589   
 E  r3590   
 E  r3591   
 E  r3592   
 E  r3593   
 E  r3594   
 E  r3595   
 E  r3596   
 E  r3597   
 E  r3598   
 E  r3599   
 E  r3600   
 E  r3601   
 E  r3602   
 E  r3603   
 E  r3604   
 E  r3605   
 E  r3606   
 E  r3607   
 E  r3608   
 E  r3609   
 E  r3610   
 E  r3611   
 E  r3612   
 E  r3613   
 E  r3614   
 E  r3615   
 E  r3616   
 E  r3617   
 E  r3618   
 E  r3619   
 E  r3620   
 E  r3621   
 E  r3622   
 E  r3623   
 E  r3624   
 E  r3625   
 E  r3626   
 E  r3627   
 E  r3628   
 E  r3629   
 E  r3630   
 E  r3631   
 E  r3632   
 E  r3633   
 E  r3634   
 E  r3635   
 E  r3636   
 E  r3637   
 E  r3638   
 E  r3639   
 E  r3640   
 E  r3641   
 E  r3642   
 E  r3643   
 E  r3644   
 E  r3645   
 E  r3646   
 E  r3647   
 E  r3648   
 E  r3649   
 E  r3650   
 E  r3651   
 E  r3652   
 E  r3653   
 E  r3654   
 E  r3655   
 E  r3656   
 E  r3657   
 E  r3658   
 E  r3659   
 E  r3660   
 E  r3661   
 E  r3662   
 E  r3663   
 E  r3664   
 E  r3665   
 E  r3666   
 E  r3667   
 E  r3668   
 E  r3669   
 E  r3670   
 E  r3671   
 E  r3672   
 E  r3673   
 E  r3674   
 E  r3675   
 E  r3676   
 E  r3677   
 E  r3678   
 E  r3679   
 E  r3680   
 E  r3681   
 E  r3682   
 E  r3683   
 E  r3684   
 E  r3685   
 E  r3686   
 E  r3687   
 E  r3688   
 E  r3689   
 E  r3690   
 E  r3691   
 E  r3692   
 E  r3693   
 E  r3694   
 E  r3695   
 E  r3696   
 E  r3697   
 E  r3698   
 E  r3699   
 E  r3700   
 E  r3701   
 E  r3702   
 E  r3703   
 E  r3704   
 E  r3705   
 E  r3706   
 E  r3707   
 E  r3708   
 E  r3709   
 E  r3710   
 E  r3711   
 E  r3712   
 E  r3713   
 E  r3714   
 E  r3715   
 E  r3716   
 E  r3717   
 E  r3718   
 E  r3719   
 E  r3720   
 E  r3721   
 E  r3722   
 E  r3723   
 E  r3724   
 E  r3725   
 E  r3726   
 E  r3727   
 E  r3728   
 E  r3729   
 E  r3730   
 E  r3731   
 E  r3732   
 E  r3733   
 E  r3734   
 E  r3735   
 E  r3736   
 E  r3737   
 E  r3738   
 E  r3739   
 E  r3740   
 E  r3741   
 E  r3742   
 E  r3743   
 E  r3744   
 E  r3745   
 E  r3746   
 E  r3747   
 E  r3748   
 E  r3749   
 E  r3750   
 E  r3751   
 E  r3752   
 E  r3753   
 E  r3754   
 E  r3755   
 E  r3756   
 E  r3757   
 E  r3758   
 E  r3759   
 E  r3760   
 E  r3761   
 E  r3762   
 E  r3763   
 E  r3764   
 E  r3765   
 E  r3766   
 E  r3767   
 E  r3768   
 E  r3769   
 E  r3770   
 E  r3771   
 E  r3772   
 E  r3773   
 E  r3774   
 E  r3775   
 E  r3776   
 E  r3777   
 E  r3778   
 E  r3779   
 E  r3780   
 E  r3781   
 E  r3782   
 E  r3783   
 E  r3784   
 E  r3785   
 E  r3786   
 E  r3787   
 E  r3788   
 E  r3789   
 E  r3790   
 E  r3791   
 E  r3792   
 E  r3793   
 E  r3794   
 E  r3795   
 E  r3796   
 E  r3797   
 E  r3798   
 E  r3799   
 E  r3800   
 E  r3801   
 E  r3802   
 E  r3803   
 E  r3804   
 E  r3805   
 E  r3806   
 E  r3807   
 E  r3808   
 E  r3809   
 E  r3810   
 E  r3811   
 E  r3812   
 E  r3813   
 E  r3814   
 E  r3815   
 E  r3816   
 E  r3817   
 E  r3818   
 E  r3819   
 E  r3820   
 E  r3821   
 E  r3822   
 E  r3823   
 E  r3824   
 E  r3825   
 E  r3826   
 E  r3827   
 E  r3828   
 E  r3829   
 E  r3830   
 E  r3831   
 E  r3832   
 E  r3833   
 E  r3834   
 E  r3835   
 E  r3836   
 E  r3837   
 E  r3838   
 E  r3839   
 E  r3840   
 E  r3841   
 E  r3842   
 E  r3843   
 E  r3844   
 E  r3845   
 E  r3846   
 E  r3847   
 E  r3848   
 E  r3849   
 E  r3850   
 E  r3851   
 E  r3852   
 E  r3853   
 E  r3854   
 E  r3855   
 E  r3856   
 E  r3857   
 E  r3858   
 E  r3859   
 E  r3860   
 E  r3861   
 E  r3862   
 E  r3863   
 E  r3864   
 E  r3865   
 E  r3866   
 E  r3867   
 E  r3868   
 E  r3869   
 E  r3870   
 E  r3871   
 E  r3872   
 E  r3873   
 E  r3874   
 E  r3875   
 E  r3876   
 E  r3877   
 E  r3878   
 E  r3879   
 E  r3880   
 E  r3881   
 E  r3882   
 E  r3883   
 E  r3884   
 E  r3885   
 E  r3886   
 E  r3887   
 E  r3888   
 E  r3889   
 E  r3890   
 E  r3891   
 E  r3892   
 E  r3893   
 E  r3894   
 E  r3895   
 E  r3896   
 E  r3897   
 E  r3898   
 E  r3899   
 E  r3900   
 E  r3901   
 E  r3902   
 E  r3903   
 E  r3904   
 E  r3905   
 E  r3906   
 E  r3907   
 E  r3908   
 E  r3909   
 E  r3910   
 E  r3911   
 E  r3912   
 E  r3913   
 E  r3914   
 E  r3915   
 E  r3916   
 E  r3917   
 E  r3918   
 E  r3919   
 E  r3920   
 E  r3921   
 E  r3922   
 E  r3923   
 E  r3924   
 E  r3925   
 E  r3926   
 E  r3927   
 E  r3928   
 E  r3929   
 E  r3930   
 E  r3931   
 E  r3932   
 E  r3933   
 E  r3934   
 E  r3935   
 E  r3936   
 E  r3937   
 E  r3938   
 E  r3939   
 E  r3940   
 E  r3941   
 E  r3942   
 E  r3943   
 E  r3944   
 E  r3945   
 E  r3946   
 E  r3947   
 E  r3948   
 E  r3949   
 E  r3950   
 E  r3951   
 E  r3952   
 E  r3953   
 E  r3954   
 E  r3955   
 E  r3956   
 E  r3957   
 E  r3958   
 E  r3959   
 E  r3960   
 E  r3961   
 E  r3962   
 E  r3963   
 E  r3964   
 E  r3965   
 E  r3966   
 E  r3967   
 E  r3968   
 E  r3969   
 E  r3970   
 E  r3971   
 E  r3972   
 E  r3973   
 E  r3974   
 E  r3975   
 E  r3976   
 E  r3977   
 E  r3978   
 E  r3979   
 E  r3980   
 E  r3981   
 E  r3982   
 E  r3983   
 E  r3984   
 E  r3985   
 E  r3986   
 E  r3987   
 E  r3988   
 E  r3989   
 E  r3990   
 E  r3991   
 E  r3992   
 E  r3993   
 E  r3994   
 E  r3995   
 E  r3996   
 E  r3997   
 E  r3998   
 E  r3999   
 E  r4000   
 E  r4001   
 E  r4002   
 E  r4003   
 E  r4004   
 E  r4005   
 E  r4006   
 E  r4007   
 E  r4008   
 E  r4009   
 E  r4010   
 E  r4011   
 E  r4012   
 E  r4013   
 E  r4014   
 E  r4015   
 E  r4016   
 E  r4017   
 E  r4018   
 E  r4019   
 E  r4020   
 E  r4021   
 E  r4022   
 E  r4023   
 E  r4024   
 E  r4025   
 E  r4026   
 E  r4027   
 E  r4028   
 E  r4029   
 E  r4030   
 E  r4031   
 E  r4032   
 E  r4033   
 E  r4034   
 E  r4035   
 E  r4036   
 E  r4037   
 E  r4038   
 E  r4039   
 E  r4040   
 E  r4041   
 E  r4042   
 E  r4043   
 E  r4044   
 E  r4045   
 E  r4046   
 E  r4047   
 E  r4048   
 E  r4049   
 E  r4050   
 E  r4051   
 E  r4052   
 E  r4053   
 E  r4054   
 E  r4055   
 E  r4056   
 E  r4057   
 E  r4058   
 E  r4059   
 E  r4060   
 E  r4061   
 E  r4062   
 E  r4063   
 E  r4064   
 E  r4065   
 E  r4066   
 E  r4067   
 E  r4068   
 E  r4069   
 E  r4070   
 E  r4071   
 E  r4072   
 E  r4073   
 E  r4074   
 E  r4075   
 E  r4076   
 E  r4077   
 E  r4078   
 E  r4079   
 E  r4080   
 E  r4081   
 E  r4082   
 E  r4083   
 E  r4084   
 E  r4085   
 E  r4086   
 E  r4087   
 E  r4088   
 E  r4089   
 E  r4090   
 E  r4091   
 E  r4092   
 E  r4093   
 E  r4094   
 E  r4095   
 E  r4096   
 E  r4097   
 E  r4098   
 E  r4099   
 E  r4100   
 E  r4101   
 E  r4102   
 E  r4103   
 E  r4104   
 E  r4105   
 E  r4106   
 E  r4107   
 E  r4108   
 E  r4109   
 E  r4110   
 E  r4111   
 E  r4112   
 E  r4113   
 E  r4114   
 E  r4115   
 E  r4116   
 E  r4117   
 E  r4118   
 E  r4119   
 E  r4120   
 E  r4121   
 E  r4122   
 E  r4123   
 E  r4124   
 E  r4125   
 E  r4126   
 E  r4127   
 E  r4128   
 E  r4129   
 E  r4130   
 E  r4131   
 E  r4132   
 E  r4133   
 E  r4134   
 E  r4135   
 E  r4136   
 E  r4137   
 E  r4138   
 E  r4139   
 E  r4140   
 E  r4141   
 E  r4142   
 E  r4143   
 E  r4144   
 E  r4145   
 E  r4146   
 E  r4147   
 E  r4148   
 E  r4149   
 E  r4150   
 E  r4151   
 E  r4152   
 E  r4153   
 E  r4154   
 E  r4155   
 E  r4156   
 E  r4157   
 E  r4158   
 E  r4159   
 E  r4160   
 E  r4161   
 E  r4162   
 E  r4163   
 E  r4164   
 E  r4165   
 E  r4166   
 E  r4167   
 E  r4168   
 E  r4169   
 E  r4170   
 E  r4171   
 E  r4172   
 E  r4173   
 E  r4174   
 E  r4175   
 E  r4176   
 E  r4177   
 E  r4178   
 E  r4179   
 E  r4180   
 E  r4181   
 E  r4182   
 E  r4183   
 E  r4184   
 E  r4185   
 E  r4186   
 E  r4187   
 E  r4188   
 E  r4189   
 E  r4190   
 E  r4191   
 E  r4192   
 E  r4193   
 E  r4194   
 E  r4195   
 E  r4196   
 E  r4197   
 E  r4198   
 E  r4199   
 E  r4200   
 E  r4201   
 E  r4202   
 E  r4203   
 E  r4204   
 E  r4205   
 E  r4206   
 E  r4207   
 E  r4208   
 E  r4209   
 E  r4210   
 E  r4211   
 E  r4212   
 E  r4213   
 E  r4214   
 E  r4215   
 E  r4216   
 E  r4217   
 E  r4218   
 E  r4219   
 E  r4220   
 E  r4221   
 E  r4222   
 E  r4223   
 E  r4224   
 E  r4225   
 E  r4226   
 E  r4227   
 E  r4228   
 E  r4229   
 E  r4230   
 E  r4231   
 E  r4232   
 E  r4233   
 E  r4234   
 E  r4235   
 E  r4236   
 E  r4237   
 E  r4238   
 E  r4239   
 E  r4240   
 E  r4241   
 E  r4242   
 E  r4243   
 E  r4244   
 E  r4245   
 E  r4246   
 E  r4247   
 E  r4248   
 E  r4249   
 E  r4250   
 E  r4251   
 E  r4252   
 E  r4253   
 E  r4254   
 E  r4255   
 E  r4256   
 E  r4257   
 E  r4258   
 E  r4259   
 E  r4260   
 E  r4261   
 E  r4262   
 E  r4263   
 E  r4264   
 E  r4265   
 E  r4266   
 E  r4267   
 E  r4268   
 E  r4269   
 E  r4270   
 E  r4271   
 E  r4272   
 E  r4273   
 E  r4274   
 E  r4275   
 E  r4276   
 E  r4277   
 E  r4278   
 E  r4279   
 E  r4280   
 E  r4281   
 E  r4282   
 E  r4283   
 L  r4284   
 L  r4285   
 L  r4286   
 L  r4287   
 L  r4288   
 L  r4289   
 L  r4290   
 L  r4291   
 L  r4292   
 L  r4293   
 L  r4294   
 L  r4295   
 L  r4296   
 L  r4297   
 L  r4298   
 L  r4299   
 L  r4300   
 L  r4301   
 L  r4302   
 L  r4303   
 L  r4304   
 L  r4305   
 L  r4306   
 L  r4307   
 L  r4308   
 L  r4310   
 L  r4311   
 L  r4312   
 L  r4313   
 L  r4314   
 L  r4316   
 L  r4317   
 L  r4318   
 L  r4319   
 L  r4320   
 L  r4321   
 L  r4322   
 L  r4323   
 L  r4324   
 L  r4325   
 L  r4326   
 L  r4327   
 L  r4330   
 L  r4331   
 L  r4332   
 L  r4333   
 L  r4334   
 L  r4335   
 L  r4336   
 L  r4337   
 L  r4338   
 L  r4340   
 L  r4341   
 L  r4342   
 L  r4343   
 L  r4344   
 L  r4345   
 L  r4346   
 L  r4347   
 L  r4348   
 L  r4349   
 L  r4350   
 L  r4351   
 L  r4352   
 L  r4353   
 L  r4354   
 L  r4355   
 L  r4356   
 L  r4357   
 L  r4358   
 L  r4359   
 L  r4361   
 L  r4362   
 L  r4363   
 L  r4364   
 L  r4366   
 L  r4367   
 L  r4368   
 L  r4369   
 L  r4370   
 L  r4371   
 L  r4372   
 L  r4373   
 L  r4374   
 L  r4375   
 L  r4376   
 L  r4377   
 L  r4378   
 L  r4379   
 L  r4380   
 L  r4381   
 L  r4382   
 L  r4384   
 L  r4385   
 L  r4386   
 L  r4387   
 L  r4388   
 L  r4389   
 L  r4390   
 L  r4391   
 L  r4392   
 L  r4393   
 L  r4394   
 L  r4395   
 L  r4396   
 L  r4397   
 L  r4398   
 L  r4399   
 L  r4400   
 L  r4401   
 L  r4402   
 L  r4403   
 L  r4404   
 L  r4405   
 L  r4406   
 L  r4407   
 L  r4408   
 L  r4409   
 L  r4410   
 L  r4411   
 L  r4412   
 L  r4413   
 L  r4415   
 L  r4416   
 L  r4417   
 L  r4418   
 L  r4419   
 L  r4420   
 L  r4421   
 L  r4423   
 L  r4424   
 L  r4425   
 L  r4426   
 L  r4427   
 L  r4428   
 L  r4430   
 L  r4431   
 L  r4432   
 L  r4433   
 L  r4434   
 L  r4435   
 L  r4436   
 L  r4438   
 L  r4439   
 L  r4440   
 L  r4442   
 L  r4443   
 L  r4445   
 L  r4446   
 L  r4447   
 L  r4448   
 L  r4449   
 L  r4450   
 L  r4451   
 L  r4452   
 L  r4453   
 L  r4454   
 L  r4455   
 L  r4456   
 L  r4457   
 L  r4458   
 L  r4459   
 L  r4460   
 L  r4461   
 L  r4462   
 L  r4464   
 L  r4465   
 L  r4466   
 L  r4467   
 L  r4468   
 L  r4470   
 L  r4471   
 L  r4472   
 L  r4473   
 L  r4474   
 L  r4475   
 L  r4476   
 L  r4478   
 L  r4479   
 L  r4481   
 L  r4482   
 L  r4483   
 L  r4484   
 L  r4485   
 L  r4486   
 L  r4487   
 L  r4488   
 L  r4489   
 L  r4490   
 L  r4491   
 L  r4492   
 L  r4493   
 L  r4494   
 L  r4495   
 L  r4497   
 L  r4498   
 L  r4499   
 L  r4500   
 L  r4502   
 L  r4505   
 L  r4507   
 L  r4508   
 L  r4509   
 L  r4510   
 L  r4511   
 L  r4512   
 L  r4513   
 L  r4514   
 L  r4515   
 L  r4516   
 L  r4517   
 L  r4518   
 L  r4519   
 L  r4520   
 L  r4521   
 L  r4522   
 L  r4523   
 L  r4524   
 L  r4525   
 L  r4526   
 L  r4527   
 L  r4528   
 L  r4529   
 L  r4530   
 L  r4534   
 L  r4535   
 L  r4536   
 L  r4537   
 L  r4538   
 L  r4539   
 L  r4540   
 L  r4541   
 L  r4542   
 L  r4543   
 L  r4544   
 L  r4545   
 L  r4546   
 L  r4547   
 L  r4548   
 L  r4549   
 L  r4550   
 L  r4551   
 L  r4552   
 L  r4553   
 L  r4554   
 L  r4555   
 L  r4556   
 L  r4557   
 L  r4558   
 L  r4559   
 L  r4560   
 L  r4561   
 L  r4562   
 L  r4563   
 L  r4564   
 L  r4565   
 L  r4567   
 L  r4568   
 L  r4570   
 L  r4571   
 L  r4572   
 L  r4573   
 L  r4574   
 L  r4575   
 L  r4576   
 L  r4577   
 L  r4578   
 L  r4579   
 L  r4581   
 L  r4583   
 L  r4584   
 L  r4586   
 L  r4587   
 L  r4588   
 L  r4589   
 L  r4590   
 L  r4591   
 L  r4592   
 L  r4593   
 L  r4594   
 L  r4595   
 L  r4596   
 L  r4597   
 L  r4598   
 L  r4599   
 L  r4600   
 L  r4601   
 L  r4602   
 L  r4604   
 L  r4605   
 L  r4606   
 L  r4607   
 L  r4608   
 L  r4609   
 L  r4610   
 L  r4611   
 L  r4612   
 L  r4613   
 L  r4614   
 L  r4615   
 L  r4616   
 L  r4617   
 L  r4618   
 L  r4619   
 L  r4620   
 L  r4621   
 L  r4623   
 L  r4625   
 L  r4626   
 L  r4627   
 L  r4628   
 L  r4629   
 L  r4630   
 L  r4631   
 L  r4632   
 L  r4633   
 L  r4634   
 L  r4635   
 L  r4636   
 L  r4637   
 L  r4638   
 L  r4639   
 L  r4640   
 L  r4641   
 L  r4642   
 L  r4643   
 L  r4644   
 L  r4645   
 L  r4646   
 L  r4647   
 L  r4648   
 L  r4649   
 L  r4650   
 L  r4651   
 L  r4653   
 L  r4655   
 L  r4656   
 L  r4657   
 L  r4658   
 L  r4659   
 L  r4660   
 L  r4661   
 L  r4662   
 L  r4663   
 L  r4664   
 L  r4665   
 L  r4667   
 L  r4668   
 L  r4669   
 L  r4670   
 L  r4671   
 L  r4672   
 L  r4673   
 L  r4674   
 L  r4675   
 L  r4676   
 L  r4680   
 L  r4681   
 L  r4682   
 L  r4683   
 L  r4684   
 L  r4685   
 L  r4686   
 L  r4689   
 L  r4690   
 L  r4692   
 L  r4694   
 L  r4696   
 L  r4697   
 L  r4699   
 L  r4701   
 L  r4702   
 L  r4703   
 L  r4704   
 L  r4705   
 L  r4706   
 L  r4707   
 L  r4708   
 L  r4709   
 L  r4711   
 L  r4712   
 L  r4713   
 L  r4714   
 L  r4715   
 L  r4716   
 L  r4717   
 L  r4718   
 L  r4719   
 L  r4720   
 L  r4721   
 L  r4722   
 L  r4724   
 L  r4725   
 L  r4726   
 L  r4727   
 L  r4728   
 L  r4729   
 L  r4730   
 L  r4732   
 L  r4733   
 L  r4734   
 L  r4736   
 L  r4737   
 L  r4738   
 L  r4741   
 L  r4742   
 L  r4743   
 L  r4745   
 L  r4747   
 L  r4748   
 L  r4749   
 L  r4750   
 L  r4751   
 L  r4752   
 L  r4753   
 L  r4754   
 L  r4756   
 L  r4757   
 L  r4759   
 L  r4762   
 L  r4764   
 L  r4765   
 L  r4766   
 L  r4767   
 L  r4768   
 L  r4769   
 L  r4770   
 L  r4773   
 L  r4774   
 L  r4775   
 L  r4776   
 L  r4778   
 L  r4780   
 L  r4782   
 L  r4783   
 L  r4784   
 L  r4785   
 L  r4786   
 L  r4788   
 L  r4789   
 L  r4790   
 L  r4791   
 L  r4792   
 L  r4793   
 L  r4794   
 L  r4795   
 L  r4796   
 L  r4797   
 L  r4798   
 L  r4800   
 L  r4801   
 L  r4802   
 L  r4803   
 L  r4804   
 L  r4805   
 L  r4807   
 L  r4808   
 L  r4809   
 L  r4810   
 L  r4811   
 L  r4812   
 L  r4816   
 L  r4817   
 L  r4818   
 L  r4819   
 L  r4820   
 L  r4821   
 L  r4822   
 L  r4823   
 L  r4825   
 L  r4827   
 L  r4828   
 L  r4829   
 L  r4830   
 L  r4831   
 L  r4832   
 L  r4833   
 L  r4834   
 L  r4836   
 L  r4837   
 L  r4838   
 L  r4839   
 L  r4840   
 L  r4841   
 L  r4842   
 L  r4845   
 L  r4847   
 L  r4848   
 L  r4849   
 L  r4850   
 L  r4851   
 L  r4854   
 L  r4857   
 L  r4859   
 L  r4860   
 L  r4862   
 L  r4863   
 L  r4864   
 L  r4865   
 L  r4867   
 L  r4868   
 L  r4870   
 L  r4871   
 L  r4872   
 L  r4873   
 L  r4875   
 L  r4877   
 L  r4878   
 L  r4879   
 L  r4880   
 L  r4881   
 L  r4882   
 L  r4885   
 L  r4887   
 L  r4888   
 L  r4889   
 L  r4890   
 L  r4891   
 L  r4893   
 L  r4894   
 L  r4895   
 L  r4897   
 L  r4901   
 L  r4903   
 L  r4904   
 L  r4905   
 L  r4906   
 L  r4911   
 L  r4914   
 L  r4915   
 L  r4917   
 L  r4918   
 L  r4919   
 L  r4920   
 L  r4921   
 L  r4922   
 L  r4924   
 L  r4925   
 L  r4926   
 L  r4927   
 L  r4928   
 L  r4930   
 L  r4931   
 L  r4932   
 L  r4933   
 L  r4934   
 L  r4935   
 L  r4937   
 L  r4939   
 L  r4941   
 L  r4942   
 L  r4943   
 L  r4944   
 L  r4945   
 L  r4947   
 L  r4948   
 L  r4949   
 L  r4950   
 L  r4951   
 L  r4953   
 L  r4954   
 L  r4955   
 L  r4956   
 L  r4957   
 L  r4959   
 L  r4960   
 L  r4961   
 L  r4962   
 L  r4963   
 L  r4967   
 L  r4968   
 L  r4970   
 L  r4971   
 L  r4972   
 L  r4975   
 L  r4976   
 L  r4977   
 L  r4978   
 L  r4979   
 L  r4980   
 L  r4981   
 L  r4982   
 L  r4983   
 L  r4984   
 L  r4986   
 L  r4990   
 L  r4992   
 L  r4993   
 L  r4994   
 L  r4995   
 L  r4997   
 L  r4998   
 L  r4999   
 L  r5000   
 L  r5002   
 L  r5003   
 L  r5004   
 L  r5005   
 L  r5007   
 L  r5008   
 L  r5009   
 L  r5010   
 L  r5011   
 L  r5014   
 L  r5015   
 L  r5017   
 L  r5019   
 L  r5020   
 L  r5021   
 L  r5022   
 L  r5023   
 L  r5024   
 L  r5025   
 L  r5028   
 L  r5029   
 L  r5030   
 L  r5032   
 L  r5033   
 L  r5034   
 L  r5035   
 L  r5038   
 L  r5039   
 L  r5040   
 L  r5041   
 L  r5042   
 L  r5043   
 L  r5044   
 L  r5045   
 L  r5046   
 L  r5047   
 L  r5049   
 L  r5050   
 L  r5051   
 L  r5052   
 L  r5053   
 L  r5055   
 L  r5056   
 L  r5057   
 L  r5058   
 L  r5059   
 L  r5060   
 L  r5061   
 L  r5062   
 L  r5063   
 L  r5064   
 L  r5065   
 L  r5066   
 L  r5067   
 L  r5068   
 L  r5069   
 L  r5070   
 L  r5071   
 L  r5072   
 L  r5073   
 L  r5074   
 L  r5075   
 L  r5076   
 L  r5077   
 L  r5078   
 L  r5079   
 L  r5080   
 L  r5081   
 L  r5082   
 L  r5083   
 L  r5084   
 L  r5085   
 L  r5086   
 L  r5087   
 L  r5088   
 L  r5089   
 L  r5090   
 L  r5091   
 L  r5092   
 L  r5093   
 L  r5094   
 L  r5095   
 L  r5096   
 L  r5097   
 L  r5098   
 L  r5099   
 L  r5100   
 L  r5101   
 L  r5102   
 L  r5103   
 L  r5104   
 L  r5105   
 L  r5106   
 L  r5107   
 L  r5108   
 L  r5109   
 L  r5110   
 L  r5111   
 L  r5112   
 L  r5113   
 L  r5114   
 L  r5115   
 L  r5116   
 L  r5117   
 L  r5118   
 L  r5119   
 L  r5120   
 L  r5121   
 L  r5122   
 L  r5123   
 L  r5124   
 L  r5125   
 L  r5126   
 L  r5127   
 L  r5128   
 L  r5129   
 L  r5130   
 L  r5131   
 L  r5132   
 L  r5133   
 L  r5134   
 L  r5135   
 L  r5136   
 L  r5137   
 L  r5138   
 L  r5141   
 L  r5143   
 L  r5144   
 L  r5148   
 L  r5150   
 L  r5151   
 L  r5152   
 L  r5153   
 L  r5154   
 L  r5155   
 L  r5158   
 L  r5159   
 L  r5162   
 L  r5163   
 L  r5164   
 L  r5165   
 L  r5168   
 L  r5169   
 L  r5170   
 L  r5172   
 L  r5174   
 L  r5175   
 L  r5177   
 L  r5178   
 L  r5180   
 L  r5181   
 L  r5183   
 L  r5186   
 L  r5187   
 L  r5189   
 L  r5190   
 L  r5191   
 L  r5192   
 L  r5194   
 L  r5195   
 L  r5198   
 L  r5201   
 L  r5202   
 L  r5203   
 L  r5204   
 L  r5206   
 L  r5208   
 L  r5210   
 L  r5211   
 L  r5214   
 L  r5215   
 L  r5216   
 L  r5217   
 L  r5218   
 L  r5219   
 L  r5221   
 L  r5222   
 L  r5224   
 L  r5231   
 L  r5234   
 L  r5239   
 L  r5240   
 L  r5242   
 L  r5245   
 L  r5248   
 L  r5251   
 L  r5252   
 L  r5254   
 L  r5255   
 L  r5258   
 L  r5260   
 L  r5262   
 L  r5263   
 L  r5264   
 L  r5265   
 L  r5267   
 L  r5268   
 L  r5269   
 L  r5270   
 L  r5271   
 L  r5272   
 L  r5274   
 L  r5275   
 L  r5277   
 L  r5278   
 L  r5279   
 L  r5280   
 L  r5282   
 L  r5283   
 L  r5285   
 L  r5287   
 L  r5291   
 L  r5292   
 L  r5293   
 L  r5294   
 L  r5296   
 L  r5297   
 L  r5299   
 L  r5300   
 L  r5302   
 L  r5304   
 L  r5308   
 L  r5309   
 L  r5314   
 L  r5316   
 L  r5317   
 L  r5319   
 L  r5320   
 L  r5321   
 L  r5322   
 L  r5323   
 L  r5325   
 L  r5329   
 L  r5337   
 L  r5338   
 L  r5339   
 L  r5340   
 L  r5341   
 L  r5343   
 L  r5344   
 L  r5345   
 L  r5349   
 L  r5350   
 L  r5352   
 L  r5353   
 L  r5354   
 L  r5357   
 L  r5361   
 L  r5362   
 L  r5363   
 L  r5367   
 L  r5369   
 L  r5371   
 L  r5374   
 L  r5376   
 L  r5378   
 L  r5379   
 L  r5383   
 L  r5384   
 L  r5385   
 L  r5386   
 L  r5388   
 L  r5393   
 L  r5394   
 L  r5395   
 L  r5396   
 L  r5398   
 L  r5399   
 L  r5401   
 L  r5402   
 L  r5403   
 L  r5404   
 L  r5405   
 L  r5407   
 L  r5408   
 L  r5415   
 L  r5416   
 L  r5417   
 L  r5418   
 L  r5419   
 L  r5420   
 L  r5421   
 L  r5422   
 L  r5425   
 L  r5426   
 L  r5431   
 L  r5436   
 L  r5439   
 L  r5441   
 L  r5442   
 L  r5443   
 L  r5445   
 L  r5447   
 L  r5449   
 L  r5450   
 L  r5453   
 L  r5456   
 L  r5457   
 L  r5458   
 L  r5459   
 L  r5462   
 L  r5463   
 L  r5468   
 L  r5469   
 L  r5473   
 L  r5475   
 L  r5478   
 L  r5480   
 L  r5482   
 L  r5483   
 L  r5485   
 L  r5487   
 L  r5488   
 L  r5490   
 L  r5491   
 L  r5492   
 L  r5493   
 L  r5494   
 L  r5497   
 L  r5498   
 L  r5499   
 L  r5501   
 L  r5507   
 L  r5510   
 L  r5512   
 L  r5516   
 L  r5517   
 L  r5519   
 L  r5520   
 L  r5522   
 L  r5524   
 L  r5532   
 L  r5533   
 L  r5534   
 L  r5536   
 L  r5537   
 L  r5538   
 L  r5539   
 L  r5540   
 L  r5544   
 L  r5546   
 L  r5550   
 L  r5558   
 L  r5561   
 L  r5562   
 L  r5563   
 L  r5565   
 L  r5566   
 L  r5570   
 L  r5571   
 L  r5572   
 L  r5574   
 L  r5575   
 L  r5576   
 L  r5577   
 L  r5578   
 L  r5580   
 L  r5582   
 L  r5583   
 L  r5584   
 L  r5585   
 L  r5587   
 L  r5588   
 L  r5595   
 L  r5596   
 L  r5598   
 L  r5599   
 L  r5600   
 L  r5601   
 L  r5603   
 L  r5604   
 L  r5610   
 L  r5613   
 L  r5617   
 L  r5618   
 L  r5627   
 L  r5628   
 L  r5631   
 L  r5633   
 L  r5637   
 L  r5639   
 L  r5640   
 L  r5642   
 L  r5643   
 L  r5645   
 L  r5646   
 L  r5647   
 L  r5648   
 L  r5649   
 L  r5652   
 L  r5654   
 L  r5655   
 L  r5656   
 L  r5657   
 L  r5662   
 L  r5664   
 L  r5665   
 L  r5666   
 L  r5668   
 L  r5674   
 L  r5676   
 L  r5677   
 L  r5680   
 L  r5683   
 L  r5686   
 L  r5687   
 L  r5688   
 L  r5692   
 L  r5693   
 L  r5694   
 L  r5696   
 L  r5699   
 L  r5702   
 L  r5704   
 L  r5706   
 L  r5708   
 L  r5714   
 L  r5718   
 L  r5725   
 L  r5726   
 L  r5729   
 L  r5731   
 L  r5733   
 L  r5734   
 L  r5736   
 L  r5739   
 L  r5741   
 L  r5744   
 L  r5745   
 L  r5748   
 L  r5750   
 L  r5759   
 L  r5786   
 L  r5787   
 L  r5795   
 L  r5797   
 L  r5799   
 L  r5801   
 L  r5802   
 L  r5805   
 L  r5808   
 L  r5811   
 L  r5813   
 L  r5814   
 L  r5821   
 L  r5824   
 L  r5826   
 L  r5831   
 L  r5836   
 L  r5837   
 L  r5844   
 L  r5847   
 L  r5848   
 L  r5861   
 L  r5863   
 L  r5871   
 L  r5889   
 L  r5891   
 L  r5893   
 L  r5894   
 L  r5898   
 L  r5901   
 L  r5904   
 L  r5906   
 L  r5909   
 L  r5918   
 L  r5919   
 L  r5921   
 L  r5922   
 L  r5924   
 L  r5925   
 L  r5927   
 L  r5932   
 L  r5946   
 L  r5948   
 L  r5951   
 L  r5952   
 L  r5954   
 L  r5959   
 L  r5966   
 L  r5969   
 L  r5972   
 L  r5977   
 L  r5979   
 L  r5980   
 L  r5982   
 L  r5985   
 L  r5988   
 L  r5990   
 L  r5994   
 L  r5999   
 L  r6005   
 L  r6010   
 L  r6011   
 L  r6015   
 L  r6016   
 L  r6019   
 L  r6022   
 L  r6024   
 L  r6025   
 L  r6026   
 L  r6027   
 L  r6028   
 L  r6029   
 L  r6030   
 L  r6033   
 L  r6035   
 L  r6036   
 L  r6037   
 L  r6040   
 L  r6044   
 L  r6047   
 L  r6051   
 L  r6055   
 L  r6065   
 L  r6067   
 L  r6070   
 L  r6077   
 L  r6079   
 L  r6081   
 L  r6083   
 L  r6084   
 L  r6086   
 L  r6091   
 L  r6092   
 L  r6093   
 L  r6094   
 L  r6095   
 L  r6099   
 L  r6104   
 L  r6107   
 L  r6109   
 L  r6113   
 L  r6120   
 L  r6131   
 L  r6134   
 L  r6138   
 L  r6139   
 L  r6140   
 L  r6143   
 L  r6144   
 L  r6145   
 L  r6149   
 L  r6150   
 L  r6155   
 L  r6156   
 L  r6158   
 L  r6162   
 L  r6164   
 L  r6168   
 L  r6169   
 L  r6170   
 L  r6174   
 L  r6178   
 L  r6179   
 L  r6182   
 L  r6186   
 L  r6189   
 L  r6193   
 L  r6195   
 L  r6218   
 L  r6224   
 L  r6225   
 L  r6239   
 L  r6247   
 L  r6249   
 L  r6252   
 L  r6257   
 L  r6260   
 L  r6261   
 L  r6263   
 L  r6265   
 L  r6266   
 L  r6268   
 L  r6269   
 L  r6276   
 L  r6278   
 L  r6282   
 L  r6284   
 L  r6287   
 L  r6293   
 L  r6298   
 L  r6299   
 L  r6303   
 L  r6307   
 L  r6308   
 L  r6309   
 L  r6312   
 L  r6316   
 L  r6326   
 L  r6328   
 L  r6333   
 L  r6336   
 L  r6343   
 L  r6344   
 L  r6345   
 L  r6346   
 L  r6347   
 L  r6348   
 L  r6349   
 L  r6350   
 L  r6351   
 L  r6352   
 L  r6353   
 L  r6354   
 L  r6355   
 L  r6356   
 L  r6357   
 L  r6358   
 L  r6359   
 L  r6360   
 L  r6361   
 L  r6362   
 L  r6363   
 L  r6364   
 L  r6365   
 L  r6366   
 L  r6367   
 L  r6368   
 L  r6369   
 L  r6370   
 L  r6371   
 L  r6372   
 L  r6373   
 L  r6374   
 L  r6375   
 L  r6376   
 L  r6377   
 L  r6378   
 L  r6379   
 L  r6380   
 L  r6381   
 L  r6382   
 L  r6383   
 L  r6384   
 L  r6385   
 L  r6386   
 L  r6387   
 L  r6388   
 L  r6389   
 L  r6390   
 L  r6391   
 L  r6392   
 L  r6393   
 L  r6394   
 L  r6395   
 L  r6396   
 L  r6397   
 L  r6398   
 L  r6399   
 L  r6400   
 L  r6401   
 L  r6402   
 L  r6403   
 L  r6404   
 L  r6405   
 L  r6406   
 L  r6407   
 L  r6408   
 L  r6409   
 L  r6410   
 L  r6411   
 L  r6412   
 L  r6413   
 L  r6414   
 L  r6415   
 L  r6416   
 L  r6417   
 L  r6418   
 L  r6419   
 L  r6420   
 L  r6421   
 L  r6422   
 L  r6423   
 L  r6424   
 L  r6425   
 L  r6426   
 L  r6427   
 L  r6428   
 L  r6429   
 L  r6430   
 L  r6431   
 L  r6432   
 L  r6433   
 L  r6434   
 L  r6435   
 L  r6436   
 L  r6437   
 L  r6438   
 L  r6439   
 L  r6440   
 L  r6441   
 L  r6442   
 L  r6443   
 L  r6444   
 L  r6445   
 L  r6446   
 L  r6447   
 L  r6448   
 L  r6449   
 L  r6450   
 L  r6451   
 L  r6452   
 L  r6453   
 L  r6454   
 L  r6455   
 L  r6456   
 L  r6457   
 L  r6458   
 L  r6459   
 L  r6460   
 L  r6461   
 L  r6462   
 L  r6463   
 L  r6464   
 L  r6465   
 L  r6466   
 L  r6467   
 L  r6468   
 L  r6469   
 L  r6470   
 L  r6471   
 L  r6472   
 L  r6473   
 L  r6474   
 L  r6475   
 L  r6476   
 L  r6477   
 L  r6478   
 L  r6479   
 L  r6480   
 L  r6481   
 L  r6482   
 L  r6483   
 L  r6484   
 L  r6485   
 L  r6486   
 L  r6487   
 L  r6488   
 L  r6489   
 L  r6490   
 L  r6491   
 L  r6492   
 L  r6493   
 L  r6494   
 L  r6495   
 L  r6496   
 L  r6497   
 L  r6498   
 L  r6499   
 L  r6500   
 L  r6501   
 L  r6502   
 L  r6503   
 L  r6504   
 L  r6505   
 L  r6506   
 L  r6507   
 L  r6508   
 L  r6509   
 L  r6510   
 L  r6511   
 L  r6512   
 L  r6513   
 L  r6514   
 L  r6515   
 L  r6516   
 L  r6517   
 L  r6518   
 L  r6519   
 L  r6520   
 L  r6521   
 L  r6522   
 L  r6523   
 L  r6524   
 L  r6525   
 L  r6526   
 L  r6527   
 L  r6528   
 L  r6529   
 L  r6530   
 L  r6531   
 L  r6532   
 L  r6533   
 L  r6534   
 L  r6535   
 L  r6536   
 L  r6537   
 L  r6538   
 L  r6539   
 L  r6540   
 L  r6541   
 L  r6542   
 L  r6543   
 L  r6544   
 L  r6545   
 L  r6546   
 L  r6547   
 L  r6548   
 L  r6549   
 L  r6550   
 L  r6551   
 L  r6552   
 L  r6553   
 L  r6554   
 L  r6555   
 L  r6556   
 L  r6557   
 L  r6558   
 L  r6559   
 L  r6560   
 L  r6561   
 L  r6562   
 L  r6563   
 L  r6564   
 L  r6565   
 L  r6566   
 L  r6567   
 L  r6568   
 L  r6569   
 L  r6570   
 L  r6571   
 L  r6572   
 L  r6573   
 L  r6574   
 L  r6575   
 L  r6576   
 L  r6577   
 L  r6578   
 L  r6579   
 L  r6580   
 L  r6581   
 L  r6582   
 L  r6583   
 L  r6584   
 L  r6585   
 L  r6586   
 L  r6587   
 L  r6588   
 L  r6589   
 L  r6590   
 L  r6591   
 L  r6592   
 L  r6593   
 L  r6594   
 L  r6596   
 L  r6603   
 L  r6606   
 L  r6609   
 L  r6610   
 L  r6613   
 L  r6615   
 L  r6618   
 L  r6623   
 L  r6625   
 L  r6630   
 L  r6632   
 L  r6633   
 L  r6634   
 L  r6636   
 L  r6638   
 L  r6640   
 L  r6642   
 L  r6645   
 L  r6646   
 L  r6647   
 L  r6648   
 L  r6649   
 L  r6650   
 L  r6651   
 L  r6652   
 L  r6653   
 L  r6654   
 L  r6655   
 L  r6656   
 L  r6657   
 L  r6658   
 L  r6659   
 L  r6660   
 L  r6661   
 L  r6662   
 L  r6663   
 L  r6664   
 L  r6665   
 L  r6666   
 L  r6667   
 L  r6668   
 L  r6669   
 L  r6670   
 L  r6671   
 L  r6672   
 L  r6673   
 L  r6674   
 L  r6675   
 L  r6676   
 L  r6677   
 L  r6678   
 L  r6679   
 L  r6680   
 L  r6681   
 L  r6682   
 L  r6683   
 L  r6684   
 L  r6685   
 L  r6686   
 L  r6687   
 L  r6688   
 L  r6689   
 L  r6690   
 L  r6691   
 L  r6692   
 L  r6693   
 L  r6694   
 L  r6695   
 L  r6696   
 L  r6697   
 L  r6698   
 L  r6699   
 L  r6700   
 L  r6701   
 L  r6702   
 L  r6703   
 L  r6704   
 L  r6705   
 L  r6706   
 L  r6707   
 L  r6708   
 L  r6709   
 L  r6710   
 L  r6711   
 L  r6712   
 L  r6713   
 L  r6714   
 L  r6715   
 L  r6716   
 L  r6717   
 L  r6718   
 L  r6719   
 L  r6720   
 L  r6721   
 L  r6722   
 L  r6723   
 L  r6724   
 L  r6725   
 L  r6726   
 L  r6727   
 L  r6728   
 L  r6729   
 L  r6730   
 L  r6731   
 L  r6732   
 L  r6733   
 L  r6734   
 L  r6735   
 L  r6736   
 L  r6737   
 L  r6738   
 L  r6739   
 L  r6740   
 L  r6741   
 L  r6742   
 L  r6743   
 L  r6744   
 L  r6745   
 L  r6746   
 L  r6747   
 L  r6748   
 L  r6749   
 L  r6750   
 L  r6751   
 L  r6752   
 L  r6753   
 L  r6754   
 L  r6755   
 L  r6756   
 L  r6757   
 L  r6758   
 L  r6759   
 L  r6760   
 L  r6761   
 L  r6762   
 L  r6763   
 L  r6764   
 L  r6765   
 L  r6766   
 L  r6767   
 L  r6768   
 L  r6769   
 L  r6770   
 L  r6771   
 L  r6772   
 L  r6773   
 L  r6774   
 L  r6775   
 L  r6776   
 L  r6777   
 L  r6778   
 L  r6779   
 L  r6780   
 L  r6781   
 L  r6784   
 L  r6785   
 L  r6786   
 L  r6787   
 L  r6788   
 L  r6790   
 L  r6791   
 L  r6792   
 L  r6793   
 L  r6795   
 L  r6797   
 L  r6798   
 L  r6800   
 L  r6803   
 L  r6804   
 L  r6805   
 L  r6806   
 L  r6807   
 L  r6808   
 L  r6809   
 L  r6810   
 L  r6811   
 L  r6812   
 L  r6813   
 L  r6814   
 L  r6815   
 L  r6816   
 L  r6817   
 L  r6818   
 L  r6819   
 L  r6820   
 L  r6821   
 L  r6822   
 L  r6823   
 L  r6824   
 L  r6825   
 L  r6826   
 L  r6827   
 L  r6828   
 L  r6829   
 L  r6830   
 L  r6831   
 L  r6832   
 L  r6833   
 L  r6834   
 L  r6835   
 L  r6836   
 L  r6837   
 L  r6838   
 L  r6839   
 L  r6840   
 L  r6841   
 L  r6842   
 L  r6843   
 L  r6844   
 L  r6845   
 L  r6846   
 L  r6847   
 L  r6848   
 L  r6849   
 L  r6850   
 L  r6851   
 L  r6852   
 L  r6853   
 L  r6854   
 L  r6855   
 L  r6856   
 L  r6857   
 L  r6858   
 L  r6859   
 L  r6860   
 L  r6861   
 L  r6862   
 L  r6863   
 L  r6864   
 L  r6865   
 L  r6866   
 L  r6867   
 L  r6868   
 L  r6869   
 L  r6870   
 L  r6871   
 L  r6872   
 L  r6873   
 L  r6874   
 L  r6875   
 L  r6876   
 L  r6877   
 L  r6878   
 L  r6879   
 L  r6880   
 L  r6881   
 L  r6882   
 L  r6883   
 L  r6884   
 L  r6885   
 L  r6886   
 L  r6887   
 L  r6888   
 L  r6889   
 L  r6890   
 L  r6891   
 L  r6892   
 L  r6893   
 L  r6894   
 L  r6895   
 L  r6896   
 L  r6897   
 L  r6898   
 L  r6899   
 L  r6900   
 L  r6901   
 L  r6902   
 L  r6903   
 L  r6904   
 L  r6905   
 L  r6906   
 L  r6907   
 L  r6908   
 L  r6909   
 L  r6910   
 L  r6911   
 L  r6912   
 L  r6913   
 L  r6914   
 L  r6915   
 L  r6916   
 L  r6917   
 L  r6918   
 L  r6919   
 L  r6920   
 L  r6921   
 L  r6922   
 L  r6923   
 L  r6924   
 L  r6925   
 L  r6926   
 L  r6927   
 L  r6928   
 L  r6929   
 L  r6930   
 L  r6931   
 L  r6932   
 L  r6933   
 L  r6934   
 L  r6935   
 L  r6936   
 L  r6937   
 L  r6938   
 L  r6939   
 L  r6940   
 L  r6941   
 L  r6942   
 L  r6943   
 L  r6944   
 L  r6945   
 L  r6946   
 L  r6947   
 L  r6948   
 L  r6949   
 L  r6950   
 L  r6951   
 L  r6952   
 L  r6953   
 L  r6954   
 L  r6955   
 L  r6956   
 L  r6957   
 L  r6958   
 L  r6959   
 L  r6960   
 L  r6961   
 L  r6962   
 L  r6963   
 L  r6964   
 L  r6965   
 L  r6966   
 L  r6967   
 L  r6968   
 L  r6969   
 L  r6970   
 L  r6971   
 L  r6972   
 L  r6973   
 L  r6974   
 L  r6975   
 L  r6976   
 L  r6977   
 L  r6978   
 L  r6979   
 L  r6980   
 L  r6981   
 L  r6982   
 L  r6983   
 L  r6992   
 L  r6993   
 L  r6994   
 L  r6995   
 L  r6996   
 L  r6997   
 L  r6998   
 L  r6999   
 L  r7000   
 L  r7001   
 L  r7002   
 L  r7003   
 L  r7004   
 L  r7005   
 L  r7006   
 L  r7007   
 L  r7008   
 L  r7009   
 L  r7010   
 L  r7011   
 L  r7012   
 L  r7013   
 L  r7014   
 L  r7015   
 L  r7016   
 L  r7017   
 L  r7018   
 L  r7019   
 L  r7020   
 L  r7021   
 L  r7022   
 L  r7023   
 L  r7024   
 L  r7025   
 L  r7026   
 L  r7027   
 L  r7028   
 L  r7029   
 L  r7030   
 L  r7031   
 L  r7032   
 L  r7033   
 L  r7034   
 L  r7035   
 L  r7036   
 L  r7037   
 L  r7038   
 L  r7039   
 L  r7040   
 L  r7041   
 L  r7042   
 L  r7043   
 L  r7044   
 L  r7045   
 L  r7046   
 L  r7047   
 L  r7048   
 L  r7049   
 L  r7050   
 L  r7051   
 L  r7052   
 L  r7053   
 L  r7054   
 L  r7055   
 L  r7056   
 L  r7057   
 L  r7058   
 L  r7059   
 L  r7060   
 L  r7061   
 L  r7062   
 L  r7063   
 L  r7064   
 L  r7065   
 L  r7066   
 L  r7067   
 L  r7068   
 L  r7069   
 L  r7070   
 L  r7071   
 L  r7072   
 L  r7073   
 L  r7074   
 L  r7075   
 L  r7076   
 L  r7077   
 L  r7078   
 L  r7079   
 L  r7080   
 L  r7081   
 L  r7082   
 L  r7083   
 L  r7084   
 L  r7085   
 L  r7086   
 L  r7087   
COLUMNS
    c0        Obj       -3.365
    c0        r1979     1
    c0        r3638     1
    c0        r3658     -1
    c0        r4791     0.03125
    c0        r4882     0.03125
    c1        Obj       -0.052
    c1        r3619     1
    c1        r3620     -1
    c1        r4347     0.03125
    c2        Obj       -0.104
    c2        r3621     1
    c2        r3622     -1
    c2        r4345     0.03125
    c3        Obj       -0.118
    c3        r1982     1
    c3        r3623     1
    c3        r3624     -1
    c3        r4342     0.03125
    c4        Obj       -0.005
    c4        r3658     1
    c4        r3659     -1
    c5        Obj       -0.008
    c5        r3625     1
    c5        r3660     -1
    c5        r4882     0.03125
    c5        r4978     -0.03125
    c6        Obj       -1.606
    c6        r1985     1
    c6        r3659     1
    c6        r3660     -1
    c6        r5662     0.0256
    c7        Obj       -0.133
    c7        r1986     1
    c7        r3626     1
    c7        r3627     -1
    c7        r4465     0.0001
    c8        Obj       -0.118
    c8        r3628     1
    c8        r3629     -1
    c8        r4335     0.03125
    c8        r6708     -0.03125
    c8        r6718     -6.103515625e-05
    c8        r6719     -6.103515625e-05
    c9        Obj       -0.086
    c9        r3630     1
    c9        r3631     -1
    c9        r4332     0.03125
    c9        r4384     0.03125
    c10       Obj       -0.037
    c10       r3632     1
    c10       r3745     -1
    c10       r4660     0.03125
    c11       Obj       -3.35
    c11       r3632     -1
    c11       r3644     1
    c11       r4770     0.03125
    c11       r4790     0.03125
    c11       r5262     -0.03125
    c12       Obj       -0.061
    c12       r1991     1
    c12       r3633     1
    c12       r3634     -1
    c12       r4545     0.03125
    c13       Obj       -1.597
    c13       r1994     1
    c13       r3634     1
    c13       r3635     -1
    c14       Obj       -0.111
    c14       r1995     1
    c14       r3635     1
    c14       r3636     -1
    c14       r4540     0.03125
    c15       Obj       -5.195
    c15       r1998     1
    c15       r3636     1
    c15       r3637     -1
    c16       Obj       -0.112
    c16       r3637     1
    c16       r3638     -1
    c16       r4981     0.03125
    c17       Obj       -1.112
    c17       r3639     -1
    c17       r4252     1
    c17       r6395     -6.103515625e-05
    c18       Obj       -0.086
    c18       r2002     1
    c18       r3639     1
    c18       r3640     -1
    c19       Obj       -1.532
    c19       r3640     1
    c19       r3641     -1
    c19       r4425     0.03125
    c19       r6394     -6.103515625e-05
    c20       Obj       -0.123
    c20       r3641     1
    c20       r3642     -1
    c20       r5262     0.03125
    c21       Obj       -0.348
    c21       r3642     1
    c21       r3643     -1
    c22       Obj       -0.027
    c22       r3643     1
    c22       r3644     -1
    c22       r5040     0.03125
    c23       Obj       -0.049
    c23       r3645     -1
    c23       r3746     1
    c24       Obj       -0.018
    c24       r3645     1
    c24       r3653     -1
    c25       Obj       -0.064
    c25       r3652     1
    c25       r3653     -1
    c26       Obj       -0.025
    c26       r3646     1
    c26       r3651     -1
    c27       Obj       -2.509
    c27       r2012     1
    c27       r3650     1
    c27       r3651     -1
    c27       r4609     0.03125
    c27       r6523     0.00390625
    c27       r6693     6.103515625e-05
    c27       r6766     0.03125
    c27       r6969     0.00390625
    c27       r7047     6.103515625e-05
    c27       r7069     6.103515625e-05
    c28       Obj       -0.249
    c28       r3648     1
    c28       r3649     -1
    c28       r6453     0.00390625
    c28       r6461     6.103515625e-05
    c28       r6567     0.03125
    c28       r6578     0.0016
    c28       r6593     6.103515625e-05
    c28       r6651     0.03125
    c28       r6663     6.103515625e-05
    c28       r6766     -0.03125
    c29       Obj       -0.128
    c29       r3649     1
    c29       r3650     -1
    c29       r6658     6.103515625e-05
    c29       r6717     6.103515625e-05
    c29       r6754     6.103515625e-05
    c30       Obj       -5.76
    c30       r3651     1
    c30       r3652     -1
    c30       r4359     0.03125
    c30       r4672     0.0256
    c30       r4790     0.03125
    c30       r6523     -0.00390625
    c30       r6693     -6.103515625e-05
    c30       r7047     -6.103515625e-05
    c31       Obj       -1.9
    c31       r2017     1
    c31       r3653     1
    c31       r3654     -1
    c31       r4608     0.03125
    c31       r4672     0.0256
    c31       r5585     0.0002
    c32       Obj       -1.638
    c32       r3654     1
    c32       r3655     -1
    c32       r4713     0.03125
    c32       r4875     -0.03125
    c32       r5123     0.03125
    c32       r6404     0.0078125
    c33       Obj       -6.686
    c33       r3655     1
    c33       r3656     -1
    c33       r4875     0.03125
    c33       r5584     0.0002
    c33       r6195     0.03125
    c34       Obj       -1.409
    c34       r3656     1
    c34       r3657     -1
    c34       r5584     0.000133333333333333
    c34       r5585     0.000133333333333333
    c35       Obj       -2.527
    c35       r2021     1
    c35       r3657     1
    c35       r3662     -1
    c35       r5662     0.0256
    c35       r6722     0.0625
    c35       r6778     0.25
    c36       Obj       -0.058
    c36       r3662     -1
    c36       r3743     1
    c36       r4560     -0.03125
    c36       r4962     0.03125
    c36       r5584     0.000266666666666667
    c36       r5585     0.000266666666666667
    c36       r5662     0.0256
    c36       r6894     0.0001
    c37       Obj       -0.418
    c37       r3661     1
    c37       r3664     -1
    c37       r4800     6.103515625e-05
    c38       Obj       -0.255
    c38       r3660     1
    c38       r3661     -1
    c39       Obj       -0.685
    c39       r3662     1
    c39       r3663     -1
    c39       r4421     0.03125
    c39       r4596     -0.03125
    c39       r4745     -0.03125
    c39       r6778     -0.25
    c40       Obj       -0.107
    c40       r3663     1
    c40       r3665     -1
    c40       r4596     0.03125
    c41       Obj       -3.783
    c41       r3664     1
    c41       r3665     -1
    c42       Obj       -1.82
    c42       r3665     1
    c42       r3666     -1
    c43       Obj       -0.02
    c43       r3324     -1
    c43       r3667     1
    c43       r4317     0.03125
    c43       r4408     0.03125
    c43       r6500     -6.103515625e-05
    c43       r6557     -6.103515625e-05
    c44       Obj       -0.3
    c44       r2032     1
    c44       r3329     1
    c44       r3760     -1
    c44       r4439     0.03125
    c45       Obj       -4.426
    c45       r2033     1
    c45       r3686     -1
    c45       r3747     1
    c46       Obj       -11.367
    c46       r2034     1
    c46       r3685     1
    c46       r3686     -1
    c47       Obj       -80
    c47       r2035     1
    c47       r3668     1
    c47       r3750     -1
    c47       r4692     0.0078125
    c47       r4757     0.0078125
    c47       r4885     0.03125
    c47       r5321     6.103515625e-05
    c47       r6843     6.103515625e-05
    c47       r7018     6.103515625e-05
    c48       Obj       -50
    c48       r2036     1
    c48       r3668     -1
    c48       r3751     1
    c48       r5083     6.103515625e-05
    c49       Obj       -13.5
    c49       r2037     1
    c49       r3669     1
    c49       r3675     -1
    c49       r5079     0.03125
    c50       Obj       -1.615
    c50       r3674     1
    c50       r3675     -1
    c50       r4697     0.0256
    c51       Obj       -17.576
    c51       r2039     1
    c51       r3672     1
    c51       r4245     -1
    c52       Obj       -6.75
    c52       r3670     -1
    c52       r3748     1
    c52       r4894     0.0256
    c52       r5187     -6.103515625e-05
    c53       Obj       -8.605
    c53       r2041     1
    c53       r3671     1
    c53       r3672     -1
    c53       r4432     0.0256
    c53       r4753     0.0256
    c54       Obj       -16.907
    c54       r3673     -1
    c54       r4245     1
    c54       r4438     0.0064
    c54       r5029     0.0001
    c55       Obj       -0.014
    c55       r2043     1
    c55       r3318     -1
    c55       r3673     1
    c55       r4982     6.103515625e-05
    c56       Obj       -12.297
    c56       r3315     1
    c56       r3674     -1
    c56       r4601     0.0256
    c56       r4696     0.0256
    c57       Obj       -24.896
    c57       r2045     1
    c57       r3676     -1
    c57       r4248     1
    c58       Obj       -6.27
    c58       r2046     1
    c58       r3676     1
    c58       r3677     -1
    c58       r4490     0.0001
    c59       Obj       -59.831
    c59       r2048     1
    c59       r3677     1
    c59       r3679     -1
    c60       Obj       -13.451
    c60       r3682     -1
    c60       r3754     1
    c60       r4605     0.03125
    c61       Obj       -14.153
    c61       r3682     1
    c61       r3683     -1
    c61       r4851     6.103515625e-05
    c62       Obj       -6.475
    c62       r3678     -1
    c62       r3755     1
    c62       r4605     0.03125
    c63       Obj       -31.58
    c63       r3678     1
    c63       r3753     -1
    c63       r4535     0.0001
    c63       r6843     6.103515625e-05
    c64       Obj       -31.08
    c64       r3753     1
    c64       r4246     -1
    c64       r4442     0.0078125
    c65       Obj       -15
    c65       r2056     1
    c65       r4246     1
    c65       r4247     -1
    c65       r4433     0.0256
    c65       r4645     6.103515625e-05
    c65       r6908     6.103515625e-05
    c65       r6933     0.0001
    c66       Obj       -31
    c66       r2057     1
    c66       r4247     1
    c66       r4248     -1
    c67       Obj       -26
    c67       r2058     1
    c67       r3679     1
    c67       r3680     -1
    c68       Obj       -30
    c68       r2059     1
    c68       r3680     1
    c68       r3681     -1
    c68       r4297     0.03125
    c69       Obj       -8.978
    c69       r2060     1
    c69       r3683     1
    c69       r3684     -1
    c69       r4535     0.0001
    c69       r6843     6.103515625e-05
    c70       Obj       -7.084
    c70       r2061     1
    c70       r3694     -1
    c70       r3762     1
    c70       r4810     6.103515625e-05
    c70       r4812     6.103515625e-05
    c70       r5004     6.103515625e-05
    c70       r5083     6.103515625e-05
    c70       r5159     6.103515625e-05
    c70       r5219     6.103515625e-05
    c70       r5344     0.03125
    c70       r5442     6.103515625e-05
    c70       r5443     6.103515625e-05
    c71       Obj       -10.227
    c71       r2062     1
    c71       r3703     1
    c71       r3704     -1
    c72       Obj       -3.884
    c72       r2063     1
    c72       r3689     1
    c72       r3690     -1
    c72       r5482     6.103515625e-05
    c72       r6850     0.0001
    c72       r7033     6.103515625e-05
    c73       Obj       -3.356
    c73       r2064     1
    c73       r3687     -1
    c73       r3749     1
    c73       r4704     0.03125
    c74       Obj       -4.677
    c74       r2065     1
    c74       r3687     1
    c74       r3688     -1
    c75       Obj       -4.195
    c75       r2066     1
    c75       r3688     1
    c75       r3689     -1
    c75       r6829     6.103515625e-05
    c75       r7014     6.103515625e-05
    c75       r7029     5.60386452015181e-05
    c76       Obj       -1.736
    c76       r2067     1
    c76       r3690     1
    c76       r3691     -1
    c76       r5726     6.103515625e-05
    c77       Obj       -13.264
    c77       r2068     1
    c77       r3691     1
    c77       r3697     -1
    c78       Obj       -0.006
    c78       r2069     1
    c78       r3692     -1
    c78       r3731     1
    c79       Obj       -3.943
    c79       r3692     1
    c79       r3701     -1
    c80       Obj       -4.391
    c80       r2071     1
    c80       r3700     1
    c80       r3701     -1
    c80       r5805     6.103515625e-05
    c81       Obj       -28.51
    c81       r2072     1
    c81       r3693     -1
    c81       r3695     1
    c82       Obj       -1.667
    c82       r2073     1
    c82       r3409     -1
    c82       r3693     1
    c83       Obj       -8.239
    c83       r2074     1
    c83       r3695     -1
    c83       r3696     1
    c84       Obj       -18.107
    c84       r2075     1
    c84       r3407     1
    c84       r3696     -1
    c85       Obj       -0.01
    c85       r2076     1
    c85       r3697     1
    c85       r4249     -1
    c85       r5024     6.103515625e-05
    c86       Obj       -1.181
    c86       r3698     -1
    c86       r3708     1
    c86       r5105     0.0001
    c86       r6850     0.0001
    c87       Obj       -1.075
    c87       r3698     1
    c87       r3699     -1
    c87       r5106     0.0001
    c87       r5726     6.103515625e-05
    c88       Obj       -0.349
    c88       r3699     1
    c88       r3700     -1
    c88       r4870     0.0001
    c89       Obj       -1.102
    c89       r2080     1
    c89       r3701     1
    c89       r3702     -1
    c89       r5643     6.103515625e-05
    c90       Obj       -10.596
    c90       r2081     1
    c90       r3702     1
    c90       r3703     -1
    c91       Obj       -14.831
    c91       r2082     1
    c91       r3704     1
    c91       r3705     -1
    c92       Obj       -14.228
    c92       r2083     1
    c92       r3705     1
    c92       r3706     -1
    c93       Obj       -0.645
    c93       r2084     1
    c93       r3706     1
    c93       r3707     -1
    c94       Obj       -1.913
    c94       r2085     1
    c94       r3707     1
    c94       r3761     -1
    c94       r5221     6.103515625e-05
    c95       Obj       -1.7
    c95       r3708     -1
    c95       r4249     1
    c96       Obj       -15.061
    c96       r2088     1
    c96       r3709     -1
    c96       r3710     1
    c96       r6673     -0.03125
    c97       Obj       -1.664
    c97       r2089     1
    c97       r3709     1
    c97       r3715     -1
    c97       r5734     -0.03125
    c97       r6303     0.0625
    c98       Obj       -4.33
    c98       r2090     1
    c98       r3476     1
    c98       r3710     -1
    c98       r4620     0.0256
    c98       r5277     0.0256
    c98       r5664     0.0256
    c98       r5744     0.0256
    c98       r5871     0.0001
    c98       r5972     0.0256
    c98       r6028     0.0256
    c98       r6303     -0.0625
    c98       r6768     0.0513
    c98       r6971     0.0256
    c99       Obj       -2.187
    c99       r3711     1
    c99       r3724     -1
    c99       r6677     6.103515625e-05
    c99       r6786     0.03125
    c99       r7034     6.103515625e-05
    c100      Obj       -0.015
    c100      r3723     1
    c100      r3724     -1
    c101      Obj       -1.176
    c101      r3711     -1
    c101      r3714     1
    c101      r6686     6.103515625e-05
    c101      r6934     0.0001
    c102      Obj       -6.879
    c102      r3712     -1
    c102      r3715     1
    c102      r5421     0.0256
    c102      r6525     6.103515625e-05
    c102      r6673     0.03125
    c102      r6674     6.103515625e-05
    c102      r6769     0.0256
    c102      r7084     0.0256
    c103      Obj       -0.048
    c103      r2095     1
    c103      r3712     1
    c103      r3713     -1
    c103      r5734     0.03125
    c104      Obj       -0.057
    c104      r2096     1
    c104      r3713     1
    c104      r3714     -1
    c104      r6470     6.103515625e-05
    c104      r6680     -0.03125
    c105      Obj       -34.954
    c105      r3410     1
    c105      r3476     -1
    c105      r4395     0.03125
    c105      r4620     0.0256
    c105      r4880     0.03125
    c105      r5277     0.0256
    c105      r5421     0.0256
    c105      r5664     0.0256
    c105      r5694     0.0001220703125
    c105      r5744     0.0256
    c105      r5871     0.0001
    c105      r5972     0.0256
    c105      r6028     0.0256
    c105      r6472     0.0625
    c105      r6673     0.03125
    c105      r6680     0.03125
    c105      r6769     -0.0256
    c105      r6970     0.0002
    c105      r6971     0.0256
    c106      Obj       -2.998
    c106      r2098     1
    c106      r3719     1
    c106      r3720     -1
    c107      Obj       -10.898
    c107      r3716     1
    c107      r3717     -1
    c107      r6880     6.103515625e-05
    c108      Obj       -3.599
    c108      r3716     -1
    c108      r3723     1
    c108      r6932     6.103515625e-05
    c109      Obj       -6.074
    c109      r2101     1
    c109      r3717     1
    c109      r3718     -1
    c110      Obj       -1.082
    c110      r2102     1
    c110      r3718     1
    c110      r3719     -1
    c111      Obj       -5.016
    c111      r2103     1
    c111      r3720     1
    c111      r4250     -1
    c111      r7063     6.103515625e-05
    c112      Obj       -0.35
    c112      r3721     -1
    c112      r4250     1
    c112      r6914     6.103515625e-05
    c113      Obj       -8.084
    c113      r2105     1
    c113      r3721     1
    c113      r3722     -1
    c113      r4420     0.03125
    c113      r5050     0.03125
    c113      r6613     6.103515625e-05
    c114      Obj       -0.011
    c114      r2106     1
    c114      r3767     -1
    c114      r3768     1
    c114      r5795     0.0001
    c114      r6164     0.000114423017120107
    c114      r6265     0.000109283976856577
    c114      r6344     0.0001
    c114      r6420     8.77414092738715e-05
    c114      r6545     0.000118429033183437
    c114      r6679     0.00010823311630947
    c114      r6800     0.000109283976856577
    c114      r6997     7.2685628046759e-05
    c115      Obj       -0.127
    c115      r3437     1
    c115      r3767     -1
    c115      r4382     0.03125
    c115      r4922     0.0001
    c115      r5795     0.0001
    c115      r6164     0.000114423017120107
    c115      r6265     0.000109283976856577
    c115      r6344     0.0001
    c115      r6420     8.77414092738715e-05
    c115      r6545     0.000118429033183437
    c115      r6679     0.00010823311630947
    c115      r6712     0.03125
    c115      r6800     0.000109283976856577
    c115      r6811     0.0001
    c115      r6997     7.2685628046759e-05
    c116      Obj       -0.01
    c116      r3779     1
    c116      r3780     -1
    c116      r4368     0.0256
    c116      r6575     -0.03125
    c116      r6963     -0.03125
    c117      Obj       -0.006
    c117      r3781     -1
    c117      r3783     1
    c117      r4667     0.03125
    c118      Obj       -0.091
    c118      r2112     1
    c118      r3771     -1
    c118      r4256     1
    c118      r6492     6.103515625e-05
    c118      r6992     6.103515625e-05
    c119      Obj       -0.02
    c119      r2113     1
    c119      r3785     1
    c119      r3786     -1
    c119      r4310     0.03125
    c120      Obj       -0.011
    c120      r3787     -1
    c120      r3788     1
    c120      r4820     0.0001
    c121      Obj       -0.121
    c121      r3787     -1
    c121      r4126     1
    c121      r5693     0.0001
    c122      Obj       -0.114
    c122      r3789     1
    c122      r4281     -1
    c122      r5084     6.103515625e-05
    c122      r5426     0.03125
    c122      r5537     6.103515625e-05
    c122      r6252     6.103515625e-05
    c122      r6432     6.103515625e-05
    c122      r6931     6.103515625e-05
    c122      r6996     9.53971836372719e-05
    c122      r7001     6.103515625e-05
    c123      Obj       -1.348
    c123      r3796     1
    c123      r4281     -1
    c123      r4369     0.03125
    c123      r5178     -7.79684981375495e-05
    c123      r5550     -6.61530201248938e-05
    c123      r6840     -6.103515625e-05
    c123      r6892     -7.79684981375495e-05
    c123      r7035     -6.72799219169098e-05
    c124      Obj       -1.087
    c124      r2119     1
    c124      r3267     1
    c124      r3793     -1
    c124      r6067     6.103515625e-05
    c124      r6170     0.000116344435088454
    c124      r6478     0.0001220703125
    c124      r6542     0.000116344435088454
    c124      r6761     0.0001220703125
    c124      r6803     6.103515625e-05
    c125      Obj       -1.087
    c125      r3794     -1
    c125      r3795     1
    c125      r4303     0.03125
    c125      r6067     6.103515625e-05
    c125      r6170     0.000116344435088454
    c126      Obj       -19.696
    c126      r2123     1
    c126      r3799     -1
    c126      r3839     1
    c127      Obj       -32.074
    c127      r2125     1
    c127      r3798     -1
    c127      r3799     1
    c127      r5826     0.03125
    c127      r5836     0.00390625
    c128      Obj       -0.162
    c128      r3802     -1
    c128      r4258     1
    c128      r4949     0.0256
    c129      Obj       -39.83384
    c129      r2129     1
    c129      r3806     -1
    c129      r3807     1
    c129      r4413     0.03125
    c129      r4798     0.03125
    c129      r4888     0.03125
    c130      Obj       -0.001
    c130      r3263     1
    c130      r3808     -1
    c130      r4288     0.03125
    c130      r4364     0.03125
    c131      Obj       -12
    c131      r3405     -1
    c131      r3809     1
    c131      r5239     0.0001220703125
    c131      r5407     0.0009765625
    c131      r7035     6.72799219169098e-05
    c132      Obj       -0.001
    c132      r3793     1
    c132      r3941     -1
    c132      r4541     0.03125
    c132      r4685     -0.000244140625
    c132      r5162     -0.0001220703125
    c132      r5969     -0.000244140625
    c132      r6632     8.27375139400187e-05
    c132      r6684     -6.103515625e-05
    c133      Obj       -2.697
    c133      r3812     -1
    c133      r3813     1
    c133      r4355     0.03125
    c133      r4842     0.0001
    c133      r5919     0.0001
    c133      r7013     6.103515625e-05
    c133      r7052     0.0001
    c134      Obj       -4.559
    c134      r2135     1
    c134      r4033     1
    c134      r4034     -1
    c134      r6681     0.0078125
    c135      Obj       -12.894
    c135      r2138     1
    c135      r3838     1
    c135      r4115     -1
    c135      r4999     6.103515625e-05
    c136      Obj       -59.339
    c136      r2140     1
    c136      r3839     -1
    c136      r4257     1
    c136      r4486     6.103515625e-05
    c137      Obj       -59
    c137      r2141     1
    c137      r3332     -1
    c137      r3840     1
    c137      r4499     6.103515625e-05
    c137      r5544     6.103515625e-05
    c138      Obj       -0.001
    c138      r3892     -1
    c138      r3908     1
    c138      r4389     0.03125
    c138      r4610     0.03125
    c139      Obj       -0.001
    c139      r2144     1
    c139      r3895     -1
    c139      r3897     1
    c139      r4615     0.03125
    c140      Obj       -0.001
    c140      r2145     1
    c140      r3894     -1
    c140      r3895     1
    c140      r4472     6.103515625e-05
    c141      Obj       -0.001
    c141      r2147     1
    c141      r3896     -1
    c141      r3899     1
    c141      r4466     0.0001
    c142      Obj       -0.001
    c142      r2149     1
    c142      r3901     -1
    c142      r3902     1
    c143      Obj       -0.001
    c143      r2150     1
    c143      r3822     -1
    c143      r3900     1
    c143      r4411     0.03125
    c144      Obj       -0.001
    c144      r2151     1
    c144      r3899     1
    c144      r3900     -1
    c145      Obj       -0.001
    c145      r2152     1
    c145      r3825     -1
    c145      r3897     1
    c145      r4410     0.03125
    c146      Obj       -0.001
    c146      r2153     1
    c146      r3861     -1
    c146      r3901     1
    c146      r5468     6.103515625e-05
    c147      Obj       -0.001
    c147      r3888     1
    c147      r3890     -1
    c147      r4327     0.03125
    c147      r4611     -0.03125
    c147      r4669     0.03125
    c148      Obj       -0.001
    c148      r3861     1
    c148      r4258     -1
    c148      r4302     0.0256
    c148      r5468     -6.103515625e-05
    c149      Obj       -0.001
    c149      r2157     1
    c149      r3885     -1
    c149      r3908     1
    c149      r4610     0.03125
    c149      r5468     6.103515625e-05
    c150      Obj       -0.001
    c150      r3885     1
    c150      r3886     -1
    c150      r4331     0.03125
    c150      r4485     0.0001
    c151      Obj       -0.001
    c151      r2159     1
    c151      r3884     -1
    c151      r3891     1
    c151      r4669     0.03125
    c152      Obj       -0.001
    c152      r3883     -1
    c152      r3884     1
    c153      Obj       -0.001
    c153      r2162     1
    c153      r3889     -1
    c153      r4056     1
    c153      r4837     6.103515625e-05
    c153      r5837     0.03125
    c154      Obj       -0.001
    c154      r2163     1
    c154      r3888     -1
    c154      r3907     1
    c154      r4611     0.03125
    c155      Obj       -29.355
    c155      r2164     1
    c155      r3261     -1
    c155      r3803     1
    c155      r4397     0.0256
    c155      r4548     0.03125
    c155      r4957     0.03125
    c155      r5121     0.0256
    c156      Obj       -1.666
    c156      r4070     1
    c156      r4080     -1
    c156      r5137     0.0032
    c156      r5268     -0.03125
    c156      r5269     -0.03125
    c156      r5270     -0.03125
    c156      r5271     -0.03125
    c156      r5580     0.03125
    c156      r6035     -0.0625
    c156      r6370     0.0032
    c156      r6371     0.00160835783147124
    c156      r6396     0.0032
    c156      r6397     0.0032
    c156      r6398     0.0032
    c156      r6399     0.0032
    c156      r6400     0.0032
    c156      r6401     0.0032
    c156      r6439     8.1381822059175e-05
    c156      r6528     0.00397553361202361
    c156      r6560     5.26071448575251e-05
    c156      r6697     7.58272859959297e-05
    c156      r6805     6.33313256726729e-05
    c156      r6993     0.0001
    c156      r7008     6.05556754038613e-05
    c157      Obj       -15.37775
    c157      r2166     1
    c157      r3845     -1
    c157      r3846     1
    c157      r4403     0.03125
    c157      r4544     0.03125
    c158      Obj       -39.339
    c158      r2167     1
    c158      r3805     1
    c158      r3847     -1
    c158      r4488     6.103515625e-05
    c158      r4888     0.03125
    c158      r4918     6.103515625e-05
    c159      Obj       -15.38344
    c159      r2169     1
    c159      r3848     -1
    c159      r3849     1
    c159      r4493     6.103515625e-05
    c160      Obj       -20.6
    c160      r3850     1
    c160      r3851     -1
    c160      r4878     0.0256
    c161      Obj       -32.8
    c161      r3851     1
    c161      r4194     -1
    c162      Obj       -4.6
    c162      r3852     -1
    c162      r4195     1
    c162      r4818     0.0001
    c162      r6083     6.103515625e-05
    c163      Obj       -0.337
    c163      r3852     1
    c163      r3853     -1
    c163      r4295     0.0256
    c163      r5797     6.103515625e-05
    c164      Obj       -3.604
    c164      r2175     1
    c164      r3463     -1
    c164      r3854     1
    c165      Obj       -8.309
    c165      r3463     1
    c165      r3945     -1
    c165      r4830     0.0001
    c165      r5092     6.103515625e-05
    c166      Obj       -0.001
    c166      r2177     1
    c166      r3857     -1
    c166      r3858     1
    c166      r4340     0.03125
    c166      r6261     9.31210667174636e-05
    c166      r6346     9.88672033125734e-05
    c166      r6422     0.0001
    c166      r6423     6.103515625e-05
    c166      r6431     0.000114292604978001
    c166      r6492     6.103515625e-05
    c166      r6552     0.000104380588267577
    c166      r6556     6.03358541432804e-05
    c166      r6692     8.46071103003263e-05
    c166      r6700     6.09866996136888e-05
    c166      r6755     8.46071103003263e-05
    c166      r6824     6.103515625e-05
    c166      r6835     0.0001
    c166      r6998     8.46071103003263e-05
    c167      Obj       -14.2
    c167      r2178     1
    c167      r3866     1
    c167      r3867     -1
    c167      r5252     8.86688360098604e-05
    c167      r6343     7.8502349312175e-05
    c167      r6481     9.58328545283696e-05
    c167      r6575     0.03125
    c167      r6788     0.0001
    c168      Obj       -14.686
    c168      r2179     1
    c168      r3868     -1
    c168      r3869     1
    c168      r5824     0.03125
    c168      r6560     5.26071448575251e-05
    c168      r6697     7.58272859959297e-05
    c168      r6805     0.000126662651345346
    c168      r7008     6.05556754038613e-05
    c169      Obj       -11.1
    c169      r4013     1
    c169      r4014     -1
    c169      r6276     0.03125
    c169      r6448     -0.03125
    c169      r6981     -0.015625
    c170      Obj       -0.116
    c170      r2182     1
    c170      r3387     1
    c170      r3876     -1
    c170      r4430     0.03125
    c170      r6143     6.103515625e-05
    c170      r6416     6.103515625e-05
    c170      r6466     6.103515625e-05
    c170      r6467     6.103515625e-05
    c171      Obj       -3.621
    c171      r2183     1
    c171      r3881     -1
    c171      r3882     1
    c171      r4661     0.0256
    c171      r5811     6.103515625e-05
    c171      r5919     0.0001
    c171      r6828     6.103515625e-05
    c171      r7013     6.103515625e-05
    c171      r7041     6.103515625e-05
    c171      r7052     0.0001
    c172      Obj       -0.02
    c172      r2184     1
    c172      r3881     -1
    c172      r4093     1
    c172      r5966     0.0032
    c172      r6434     0.0032
    c172      r7028     6.103515625e-05
    c173      Obj       -11.098
    c173      r3881     -1
    c173      r4098     1
    c173      r5102     6.103515625e-05
    c173      r5811     6.103515625e-05
    c173      r7041     6.103515625e-05
    c174      Obj       -0.76
    c174      r2186     1
    c174      r3883     1
    c174      r3909     -1
    c174      r4393     0.03125
    c174      r4557     0.03125
    c174      r5745     0.03125
    c174      r6506     0.03125
    c175      Obj       -0.004
    c175      r3481     1
    c175      r3909     -1
    c176      Obj       -8.458
    c176      r2189     1
    c176      r3912     -1
    c176      r4238     1
    c176      r6065     6.103515625e-05
    c176      r6437     6.103515625e-05
    c176      r6480     0.000137578107740377
    c176      r6532     6.103515625e-05
    c176      r6664     7.36196352139833e-05
    c176      r6675     6.103515625e-05
    c176      r6736     6.103515625e-05
    c176      r6848     5.45780865745698e-05
    c176      r6883     6.103515625e-05
    c177      Obj       -0.001
    c177      r3257     1
    c177      r3914     -1
    c177      r5175     0.0001
    c177      r5263     -0.03125
    c177      r5558     0.0001
    c177      r6522     0.0008
    c177      r6844     6.103515625e-05
    c177      r7016     6.103515625e-05
    c178      Obj       -12.005
    c178      r2192     1
    c178      r3913     -1
    c178      r3914     1
    c178      r4963     0.03125
    c178      r5263     0.03125
    c179      Obj       -21.424
    c179      r2193     1
    c179      r3919     -1
    c179      r3920     1
    c179      r6580     6.103515625e-05
    c179      r6646     0.03125
    c179      r6662     6.103515625e-05
    c180      Obj       -3.632
    c180      r3926     -1
    c180      r3927     1
    c180      r6269     0.0001
    c180      r6385     6.103515625e-05
    c181      Obj       -0.437
    c181      r3928     1
    c181      r3929     -1
    c181      r6396     0.0032
    c182      Obj       -0.12
    c182      r3932     -1
    c182      r3933     1
    c182      r5341     -0.03125
    c182      r6581     0.03125
    c183      Obj       -3.179
    c183      r3932     -1
    c183      r4031     1
    c183      r6606     0.0078125
    c184      Obj       -0.026
    c184      r3936     1
    c184      r4055     -1
    c184      r6030     -0.00390625
    c184      r6345     -6.103515625e-05
    c184      r6369     -0.00390625
    c184      r6710     -0.00390625
    c184      r6713     -0.00390625
    c184      r6749     6.103515625e-05
    c185      Obj       -60.347
    c185      r2201     1
    c185      r3942     -1
    c185      r4187     1
    c185      r5005     0.00390625
    c185      r5074     6.103515625e-05
    c185      r5107     6.29493235275564e-05
    c185      r6418     0.0009765625
    c185      r6548     6.103515625e-05
    c185      r6724     0.00390625
    c185      r6973     6.23550240463078e-05
    c185      r7012     6.103515625e-05
    c186      Obj       -0.025
    c186      r3942     -1
    c186      r4190     1
    c186      r4628     -0.00390625
    c186      r5107     -6.29493235275564e-05
    c186      r6418     -0.0009765625
    c186      r6445     -6.29175895289511e-05
    c186      r6543     -6.103515625e-05
    c186      r6565     -6.103515625e-05
    c186      r6579     -0.00390625
    c186      r6959     -0.00390625
    c186      r6961     -0.00390625
    c186      r7012     -6.103515625e-05
    c187      Obj       -59
    c187      r2203     1
    c187      r3943     1
    c187      r4188     -1
    c187      r4500     6.103515625e-05
    c187      r5047     0.03125
    c188      Obj       -51.806
    c188      r2205     1
    c188      r3876     1
    c188      r3943     -1
    c189      Obj       -25.69
    c189      r3944     -1
    c189      r3945     1
    c189      r5218     6.103515625e-05
    c190      Obj       -27.981
    c190      r2208     1
    c190      r3947     1
    c190      r4169     -1
    c191      Obj       -0.02
    c191      r2209     1
    c191      r3949     1
    c191      r4255     -1
    c191      r4379     0.03125
    c191      r5078     6.103515625e-05
    c191      r6316     6.103515625e-05
    c191      r6931     6.103515625e-05
    c191      r6996     9.53971836372719e-05
    c192      Obj       -0.011
    c192      r2211     1
    c192      r3777     -1
    c192      r3948     1
    c192      r5537     6.103515625e-05
    c192      r5633     0.0001
    c192      r5693     0.0001
    c192      r6252     6.103515625e-05
    c192      r6432     6.103515625e-05
    c192      r6931     6.103515625e-05
    c193      Obj       -0.147
    c193      r3950     1
    c193      r3951     -1
    c193      r4630     0.0078125
    c193      r5005     -0.00390625
    c193      r6961     -0.00390625
    c193      r7012     -6.103515625e-05
    c194      Obj       -0.038
    c194      r3880     1
    c194      r3954     -1
    c194      r5655     0.0256
    c195      Obj       -0.556
    c195      r3954     -1
    c195      r4042     1
    c195      r4399     0.03125
    c196      Obj       -1.257
    c196      r3955     -1
    c196      r3956     1
    c196      r4428     0.03125
    c197      Obj       -1.937
    c197      r3955     -1
    c197      r3992     1
    c197      r4428     0.03125
    c197      r6870     6.103515625e-05
    c198      Obj       -0.002
    c198      r2219     1
    c198      r3957     -1
    c198      r3985     1
    c198      r4564     0.03125
    c199      Obj       -0.013
    c199      r2220     1
    c199      r3958     -1
    c199      r3988     1
    c199      r5211     0.03125
    c200      Obj       -8.683
    c200      r2221     1
    c200      r3959     -1
    c200      r3961     1
    c200      r4398     0.03125
    c200      r4583     6.103515625e-05
    c200      r6896     6.103515625e-05
    c200      r7054     6.103515625e-05
    c201      Obj       -0.006
    c201      r3960     -1
    c201      r3970     1
    c201      r4542     0.03125
    c201      r6896     -6.103515625e-05
    c201      r7054     -6.103515625e-05
    c202      Obj       -0.075
    c202      r2225     1
    c202      r3961     -1
    c202      r3962     1
    c203      Obj       -0.168
    c203      r2226     1
    c203      r3962     -1
    c203      r3963     1
    c204      Obj       -0.082
    c204      r2227     1
    c204      r3963     -1
    c204      r3971     1
    c205      Obj       -0.021
    c205      r3964     -1
    c205      r3976     1
    c206      Obj       -0.087
    c206      r2229     1
    c206      r3964     1
    c206      r3965     -1
    c207      Obj       -0.022
    c207      r2230     1
    c207      r3965     1
    c207      r3966     -1
    c208      Obj       -0.006
    c208      r2231     1
    c208      r3966     1
    c208      r3977     -1
    c209      Obj       -0.022
    c209      r3967     1
    c209      r3968     -1
    c209      r4348     0.0256
    c210      Obj       -3.576
    c210      r3969     1
    c210      r3982     -1
    c211      Obj       -6.708
    c211      r2234     1
    c211      r3969     -1
    c211      r3974     1
    c211      r4375     0.03125
    c211      r4542     0.03125
    c212      Obj       -0.017
    c212      r3970     1
    c212      r3975     -1
    c212      r4398     0.03125
    c213      Obj       -0.035
    c213      r3971     -1
    c213      r3973     1
    c213      r6859     6.103515625e-05
    c214      Obj       -1.062
    c214      r2238     1
    c214      r3972     -1
    c214      r3973     1
    c214      r6859     6.103515625e-05
    c215      Obj       -0.003
    c215      r2239     1
    c215      r3972     -1
    c215      r4261     1
    c216      Obj       -0.168
    c216      r2240     1
    c216      r3974     -1
    c216      r3981     1
    c217      Obj       -5.175
    c217      r3975     1
    c217      r3976     -1
    c218      Obj       -0.033
    c218      r2242     1
    c218      r3977     1
    c218      r3978     -1
    c218      r4474     6.103515625e-05
    c218      r4811     6.103515625e-05
    c219      Obj       -0.034
    c219      r2244     1
    c219      r3979     -1
    c219      r3994     1
    c220      Obj       -0.087
    c220      r2246     1
    c220      r3979     1
    c220      r3980     -1
    c220      r4417     0.03125
    c221      Obj       -2.241
    c221      r2247     1
    c221      r3980     1
    c221      r3981     -1
    c222      Obj       -1.921
    c222      r2248     1
    c222      r3982     1
    c222      r3983     -1
    c223      Obj       -0.01
    c223      r3985     -1
    c223      r3988     1
    c223      r4564     -0.03125
    c223      r7037     -6.103515625e-05
    c224      Obj       -0.055
    c224      r3955     1
    c224      r3986     -1
    c224      r4664     -0.03125
    c224      r4720     0.0128
    c224      r5304     0.00481996554761987
    c224      r5379     0.00481996554762041
    c224      r6927     7.53119616815692e-05
    c224      r7043     6.16955590095415e-05
    c224      r7087     7.53119616815605e-05
    c225      Obj       -0.189
    c225      r3986     1
    c225      r3987     -1
    c226      Obj       -2.816
    c226      r3987     1
    c226      r3988     -1
    c226      r4416     0.03125
    c226      r4664     0.03125
    c226      r5539     0.00789703155322131
    c226      r7037     6.103515625e-05
    c227      Obj       -3.021
    c227      r3989     -1
    c227      r3993     1
    c227      r5401     0.0078125
    c228      Obj       -0.011
    c228      r3989     1
    c228      r3990     -1
    c228      r4862     0.0001
    c229      Obj       -0.246
    c229      r3990     1
    c229      r3991     -1
    c229      r4864     6.103515625e-05
    c230      Obj       -3.271
    c230      r3991     1
    c230      r3992     -1
    c230      r4863     6.103515625e-05
    c230      r4904     0.015625
    c230      r5158     0.0078125
    c231      Obj       -2.857
    c231      r3952     1
    c231      r3993     -1
    c231      r4495     0.0001
    c231      r6830     0.0001
    c232      Obj       -17.119
    c232      r2259     1
    c232      r3913     1
    c232      r4000     -1
    c233      Obj       -40.78
    c233      r2260     1
    c233      r3842     1
    c233      r3908     -1
    c233      r4485     0.0001
    c233      r4961     0.03125
    c233      r5122     0.03125
    c233      r5441     6.103515625e-05
    c233      r6086     6.87890538701883e-05
    c233      r6437     6.103515625e-05
    c233      r6480     0.000137578107740377
    c233      r6524     5.89741767886658e-05
    c233      r6532     6.103515625e-05
    c233      r6675     6.103515625e-05
    c233      r6736     6.103515625e-05
    c233      r6848     5.45780865745698e-05
    c233      r6883     6.103515625e-05
    c233      r6886     0.0001
    c234      Obj       -0.016
    c234      r3461     -1
    c234      r3996     1
    c234      r4629     -0.00390625
    c234      r6713     0.00390625
    c234      r6749     6.103515625e-05
    c235      Obj       -0.027
    c235      r3461     -1
    c235      r4265     1
    c235      r6388     6.103515625e-05
    c235      r6521     -0.0001220703125
    c235      r6749     -6.103515625e-05
    c235      r6751     -6.103515625e-05
    c235      r6808     6.103515625e-05
    c235      r6977     6.103515625e-05
    c236      Obj       -0.031
    c236      r3997     1
    c236      r4029     -1
    c236      r6547     8.27375139400187e-05
    c236      r6632     8.27375139400187e-05
    c237      Obj       -4.641
    c237      r2265     1
    c237      r4020     -1
    c237      r4263     1
    c238      Obj       -11.162
    c238      r2266     1
    c238      r4017     -1
    c238      r4049     1
    c238      r5274     0.03125
    c238      r5282     6.103515625e-05
    c238      r6055     0.015625
    c238      r6424     0.015625
    c238      r6526     0.0078125
    c238      r6603     0.015625
    c238      r6732     6.103515625e-05
    c238      r6733     6.103515625e-05
    c238      r6735     6.103515625e-05
    c238      r6917     6.103515625e-05
    c239      Obj       -19.564
    c239      r2267     1
    c239      r4016     1
    c239      r4017     -1
    c240      Obj       -0.008
    c240      r4021     1
    c240      r4022     -1
    c241      Obj       -128.003
    c241      r2269     1
    c241      r4022     -1
    c241      r5175     0.0001
    c241      r5558     0.0001
    c241      r5627     0.0001220703125
    c241      r6522     0.0008
    c241      r6871     6.103515625e-05
    c241      r7002     0.0001
    c242      Obj       -20.136
    c242      r2270     1
    c242      r4016     -1
    c242      r4262     1
    c243      Obj       -2
    c243      r2271     1
    c243      r3998     -1
    c243      r4030     1
    c243      r4871     0.0001
    c243      r6565     6.103515625e-05
    c243      r6975     6.10094761413026e-05
    c244      Obj       -25.899
    c244      r3998     1
    c244      r3999     -1
    c244      r5111     6.103515625e-05
    c244      r6402     0.0078125
    c244      r6554     5.71492281863633e-05
    c244      r6705     5.34846283089548e-05
    c244      r6836     5.9318620042705e-05
    c244      r7070     6.103515625e-05
    c245      Obj       -0.014
    c245      r4021     1
    c245      r4023     -1
    c246      Obj       -0.016
    c246      r2275     1
    c246      r4022     1
    c246      r4023     -1
    c246      r4872     6.103515625e-05
    c246      r5297     0.015625
    c246      r6653     0.015625
    c247      Obj       -12.493
    c247      r2276     1
    c247      r4000     1
    c247      r4001     -1
    c248      Obj       -8.178
    c248      r2277     1
    c248      r4001     1
    c248      r4002     -1
    c249      Obj       -15.491
    c249      r2278     1
    c249      r4002     1
    c249      r4003     -1
    c250      Obj       -13.42
    c250      r2279     1
    c250      r4003     1
    c250      r4004     -1
    c251      Obj       -10.792
    c251      r2280     1
    c251      r4004     1
    c251      r4005     -1
    c252      Obj       -7.503
    c252      r2281     1
    c252      r4005     1
    c252      r4006     -1
    c253      Obj       -5.668
    c253      r2282     1
    c253      r4006     1
    c253      r4007     -1
    c254      Obj       -28.602
    c254      r2283     1
    c254      r4007     1
    c254      r4008     -1
    c255      Obj       -15.644
    c255      r2284     1
    c255      r4008     1
    c255      r4009     -1
    c256      Obj       -32.997
    c256      r2285     1
    c256      r4009     1
    c256      r4229     -1
    c256      r4764     6.103515625e-05
    c256      r4972     0.015625
    c256      r5731     6.103515625e-05
    c256      r6559     6.23805752444274e-05
    c256      r6638     6.36421271115382e-05
    c256      r6756     6.103515625e-05
    c256      r6810     6.36421271115382e-05
    c256      r7017     6.36421271115382e-05
    c257      Obj       -0.02
    c257      r4010     -1
    c257      r4226     1
    c257      r4627     0.03125
    c257      r5561     6.103515625e-05
    c258      Obj       -15
    c258      r2289     1
    c258      r4011     -1
    c258      r4227     1
    c258      r6834     6.103515625e-05
    c259      Obj       -17.75
    c259      r2290     1
    c259      r4011     1
    c259      r4012     -1
    c259      r6586     0.015625
    c259      r6981     0.015625
    c260      Obj       -30
    c260      r4012     1
    c260      r4013     -1
    c260      r6386     6.103515625e-05
    c260      r6448     0.03125
    c260      r6459     6.103515625e-05
    c260      r6465     6.103515625e-05
    c260      r6490     6.103515625e-05
    c260      r6855     6.103515625e-05
    c260      r6981     0.015625
    c261      Obj       -6
    c261      r4014     1
    c261      r4050     -1
    c261      r5080     6.103515625e-05
    c261      r5267     0.03125
    c261      r5341     0.03125
    c261      r5517     0.03125
    c261      r5699     0.0625
    c261      r6276     -0.03125
    c261      r6386     -6.103515625e-05
    c261      r6606     0.0078125
    c262      Obj       -10.125
    c262      r2296     1
    c262      r3458     1
    c262      r4047     -1
    c262      r7059     6.16585468489889e-05
    c263      Obj       -0.18
    c263      r3445     1
    c263      r4027     -1
    c263      r6065     6.103515625e-05
    c263      r6883     6.103515625e-05
    c264      Obj       -10.628
    c264      r2298     1
    c264      r3919     1
    c264      r4015     -1
    c265      Obj       -25.073
    c265      r2299     1
    c265      r4015     1
    c265      r4262     -1
    c266      Obj       -7.004
    c266      r2300     1
    c266      r4018     1
    c266      r4024     -1
    c267      Obj       -3.684
    c267      r4018     -1
    c267      r4023     1
    c267      r4567     0.015625
    c267      r5131     0.015625
    c267      r5296     6.103515625e-05
    c267      r5516     0.015625
    c267      r6055     0.015625
    c267      r6424     0.015625
    c267      r6526     0.0078125
    c267      r6603     0.015625
    c267      r6917     6.103515625e-05
    c268      Obj       -10.733
    c268      r2302     1
    c268      r4019     -1
    c268      r4259     1
    c269      Obj       -7.252
    c269      r2303     1
    c269      r4019     1
    c269      r4028     -1
    c270      Obj       -0.011
    c270      r3481     -1
    c270      r4264     1
    c271      Obj       -0.024
    c271      r4021     -1
    c271      r4048     1
    c271      r5131     -0.015625
    c271      r5274     -0.03125
    c271      r5296     -6.103515625e-05
    c271      r5558     0.0001
    c271      r6055     -0.015625
    c271      r6424     -0.015625
    c271      r6526     -0.0078125
    c271      r6603     -0.015625
    c271      r6917     -6.103515625e-05
    c272      Obj       -0.229
    c272      r2306     1
    c272      r4024     1
    c272      r4025     -1
    c272      r7046     6.103515625e-05
    c273      Obj       -10.759
    c273      r2307     1
    c273      r4028     1
    c273      r4264     -1
    c273      r5745     0.03125
    c273      r6506     0.03125
    c274      Obj       -1.054
    c274      r2308     1
    c274      r3435     1
    c274      r4282     -1
    c274      r5090     0.0001220703125
    c274      r5979     6.103515625e-05
    c274      r6441     6.103515625e-05
    c275      Obj       -16.534
    c275      r4030     1
    c275      r4031     -1
    c275      r5517     0.03125
    c275      r5699     0.0625
    c275      r6490     6.103515625e-05
    c275      r7058     5.6220122564472e-05
    c276      Obj       -2.199
    c276      r4032     -1
    c276      r4036     1
    c276      r5924     0.03125
    c277      Obj       -0.704
    c277      r4032     1
    c277      r4033     -1
    c277      r4943     6.103515625e-05
    c277      r5946     6.103515625e-05
    c278      Obj       -16.755
    c278      r4034     1
    c278      r4035     -1
    c278      r5034     6.103515625e-05
    c278      r5208     0.0078125
    c279      Obj       -2.882
    c279      r4035     1
    c279      r4057     -1
    c279      r5192     6.103515625e-05
    c279      r5215     6.103515625e-05
    c279      r6562     6.13774574550614e-05
    c279      r6910     6.103515625e-05
    c279      r7019     6.103515625e-05
    c280      Obj       -3.673
    c280      r3932     1
    c280      r4036     -1
    c280      r5343     0.03125
    c280      r6224     0.0078125
    c280      r6402     0.0078125
    c280      r6926     6.103515625e-05
    c280      r6975     6.10094761413026e-05
    c280      r7070     6.103515625e-05
    c281      Obj       -25.072
    c281      r4037     1
    c281      r4041     -1
    c282      Obj       -9.38
    c282      r2317     1
    c282      r4037     -1
    c282      r4038     1
    c283      Obj       -0.123
    c283      r4046     1
    c283      r4059     -1
    c283      r4751     0.03125
    c283      r5419     -0.03125
    c283      r5927     -0.03125
    c283      r5985     -6.103515625e-05
    c283      r6541     -6.103515625e-05
    c284      Obj       -0.487
    c284      r4038     -1
    c284      r4044     1
    c285      Obj       -10.329
    c285      r2321     1
    c285      r4039     1
    c285      r4045     -1
    c285      r6518     6.103515625e-05
    c286      Obj       -0.039
    c286      r3954     1
    c286      r4039     -1
    c286      r4394     0.03125
    c287      Obj       -0.157
    c287      r4040     1
    c287      r4042     -1
    c288      Obj       -4.183
    c288      r2324     1
    c288      r4041     1
    c288      r4042     -1
    c288      r5745     0.03125
    c288      r5837     0.03125
    c289      Obj       -12.017
    c289      r2325     1
    c289      r4043     -1
    c289      r4058     1
    c289      r4754     0.03125
    c289      r5108     6.103515625e-05
    c289      r5192     6.103515625e-05
    c289      r6910     6.103515625e-05
    c289      r7019     6.103515625e-05
    c290      Obj       -20.641
    c290      r2326     1
    c290      r4043     1
    c290      r4044     -1
    c290      r4944     6.103515625e-05
    c290      r6853     6.103515625e-05
    c290      r6910     6.103515625e-05
    c291      Obj       -18.212
    c291      r2327     1
    c291      r4045     1
    c291      r4046     -1
    c291      r5985     6.103515625e-05
    c292      Obj       -2.266
    c292      r2328     1
    c292      r4060     -1
    c292      r4066     1
    c292      r6029     0.00390625
    c292      r6447     -0.03125
    c292      r6887     0.00390625
    c293      Obj       -0.043
    c293      r4060     1
    c293      r4061     -1
    c293      r5062     0.0032
    c293      r6447     0.03125
    c293      r6451     0.00390625
    c293      r6462     6.103515625e-05
    c294      Obj       -0.167
    c294      r2330     1
    c294      r4062     1
    c294      r4064     -1
    c294      r5063     0.0032
    c295      Obj       -5.765
    c295      r4062     -1
    c295      r4266     1
    c295      r6390     0.0001
    c296      Obj       -0.001
    c296      r2332     1
    c296      r4089     -1
    c296      r4270     1
    c296      r5076     0.0001220703125
    c296      r5498     0.03125
    c297      Obj       -8.586
    c297      r2334     1
    c297      r4068     1
    c297      r4266     -1
    c297      r6378     6.103515625e-05
    c297      r6381     6.103515625e-05
    c298      Obj       -0.09
    c298      r2335     1
    c298      r4063     -1
    c298      r4081     1
    c298      r5269     0.03125
    c299      Obj       -0.078
    c299      r4063     1
    c299      r4082     -1
    c299      r5271     0.03125
    c299      r6035     0.0625
    c300      Obj       -0.068
    c300      r3443     -1
    c300      r4064     1
    c300      r5033     6.103515625e-05
    c300      r6363     -0.03125
    c300      r6387     -9.17612158574278e-05
    c300      r6390     -0.0001
    c301      Obj       -0.008
    c301      r4069     -1
    c301      r4088     1
    c302      Obj       -0.017
    c302      r3926     1
    c302      r4065     -1
    c302      r6384     6.103515625e-05
    c302      r6451     -0.00390625
    c302      r6452     -0.00390625
    c303      Obj       -0.276
    c303      r4065     1
    c303      r4066     -1
    c303      r5982     6.103515625e-05
    c303      r6463     6.103515625e-05
    c304      Obj       -6.664
    c304      r3928     1
    c304      r4074     -1
    c304      r6438     0.0001
    c305      Obj       -0.047
    c305      r4067     -1
    c305      r4087     1
    c305      r5056     0.0032
    c306      Obj       -0.124
    c306      r2343     1
    c306      r4067     1
    c306      r4068     -1
    c306      r5057     0.0032
    c307      Obj       -0.033
    c307      r4069     1
    c307      r4070     -1
    c307      r5128     0.03125
    c307      r5656     -0.03125
    c308      Obj       -1.428
    c308      r4071     -1
    c308      r4082     1
    c308      r5656     0.03125
    c309      Obj       -4.465
    c309      r4071     1
    c309      r4072     -1
    c309      r5268     0.03125
    c309      r6026     -0.03125
    c309      r6029     -0.00390625
    c309      r6040     -6.103515625e-05
    c309      r6887     -0.00390625
    c310      Obj       -0.413
    c310      r4072     1
    c310      r4073     -1
    c310      r6563     6.103515625e-05
    c311      Obj       -0.039
    c311      r2348     1
    c311      r4074     1
    c311      r4075     -1
    c311      r5060     0.0032
    c312      Obj       -0.406
    c312      r2349     1
    c312      r4075     1
    c312      r4076     -1
    c312      r5059     0.0032
    c313      Obj       -0.155
    c313      r4076     1
    c313      r4077     -1
    c313      r5058     0.0032
    c314      Obj       -9.212
    c314      r4077     1
    c314      r4078     -1
    c315      Obj       -1.647
    c315      r2352     1
    c315      r4078     1
    c315      r4079     -1
    c315      r6439     8.1381822059175e-05
    c316      Obj       -9.428
    c316      r2353     1
    c316      r4079     1
    c316      r4083     -1
    c316      r6379     6.103515625e-05
    c317      Obj       -0.009
    c317      r2354     1
    c317      r4080     1
    c317      r4081     -1
    c317      r5270     0.03125
    c318      Obj       -22.921
    c318      r2355     1
    c318      r4083     1
    c318      r4086     -1
    c318      r4358     0.03125
    c318      r4616     0.03125
    c318      r6372     6.103515625e-05
    c319      Obj       -0.274
    c319      r4084     1
    c319      r4085     -1
    c319      r4354     0.03125
    c320      Obj       -0.27
    c320      r4086     1
    c320      r4087     -1
    c320      r6260     -6.103515625e-05
    c320      r6355     -6.103515625e-05
    c321      Obj       -0.064
    c321      r3812     1
    c321      r4094     -1
    c321      r6828     6.103515625e-05
    c322      Obj       -0.407
    c322      r4091     1
    c322      r4092     -1
    c322      r4353     0.03125
    c322      r4530     0.03125
    c323      Obj       -0.007
    c323      r4092     1
    c323      r4105     -1
    c323      r4401     0.03125
    c323      r4530     -0.03125
    c324      Obj       -8.085
    c324      r4104     1
    c324      r4105     -1
    c324      r4401     0.03125
    c324      r4534     0.03125
    c324      r4621     0.0256
    c324      r4673     0.0256
    c324      r4699     0.0002
    c324      r4720     0.0256
    c324      r5014     6.103515625e-05
    c324      r5304     0.00963993109523974
    c324      r5379     0.00963993109524082
    c324      r5539     0.0157940631064426
    c324      r6927     0.000150623923363138
    c324      r6938     0.0001220703125
    c324      r7037     0.0001220703125
    c324      r7043     0.000123391118019083
    c324      r7087     0.000150623923363121
    c325      Obj       -0.006
    c325      r4102     -1
    c325      r4104     1
    c325      r4534     0.03125
    c325      r4595     -0.03125
    c325      r4699     0.0002
    c326      Obj       -0.003
    c326      r4101     1
    c326      r4102     -1
    c326      r5158     -0.0078125
    c327      Obj       -1.25
    c327      r4093     -1
    c327      r4095     1
    c327      r5688     0.0032
    c327      r6307     0.0032
    c327      r6868     0.0001
    c327      r6884     6.21482532170052e-05
    c328      Obj       -1.4
    c328      r2367     1
    c328      r4109     -1
    c328      r4112     1
    c328      r7086     6.75209328895683e-05
    c329      Obj       -6.159
    c329      r3838     -1
    c329      r4108     1
    c330      Obj       -14.349
    c330      r4110     -1
    c330      r4116     1
    c330      r5485     6.103515625e-05
    c330      r6863     6.103515625e-05
    c330      r7036     6.103515625e-05
    c330      r7057     6.15215918512414e-05
    c331      Obj       -4.416
    c331      r4109     1
    c331      r4117     -1
    c331      r5323     0.0001
    c331      r5639     0.0001
    c332      Obj       -1.361
    c332      r4094     1
    c332      r4095     -1
    c332      r7041     6.103515625e-05
    c333      Obj       -2.311
    c333      r4096     1
    c333      r4097     -1
    c333      r5194     6.103515625e-05
    c333      r5255     6.103515625e-05
    c334      Obj       -6.006
    c334      r4097     1
    c334      r4098     -1
    c334      r5322     9.17612158574278e-05
    c334      r6387     9.17612158574278e-05
    c335      Obj       -0.946
    c335      r4099     1
    c335      r4100     -1
    c335      r4699     0.0001
    c335      r5158     0.0078125
    c336      Obj       -9.81
    c336      r4105     1
    c336      r4106     -1
    c336      r4850     0.0001
    c336      r5733     0.0001
    c337      Obj       -0.016
    c337      r3881     1
    c337      r4103     -1
    c338      Obj       -0.01
    c338      r4100     1
    c338      r4101     -1
    c338      r4604     0.0256
    c338      r4663     -0.03125
    c339      Obj       -6.452
    c339      r2379     1
    c339      r4103     1
    c339      r4104     -1
    c339      r4621     0.0256
    c339      r4673     0.0256
    c339      r5014     6.103515625e-05
    c339      r5688     0.0032
    c339      r5863     6.103515625e-05
    c339      r6134     6.103515625e-05
    c340      Obj       -3.25
    c340      r4106     1
    c340      r4107     -1
    c340      r4890     0.03125
    c340      r4933     0.0001
    c340      r6920     6.103515625e-05
    c341      Obj       -0.208
    c341      r4107     1
    c341      r4113     -1
    c341      r5101     0.0001
    c341      r6863     6.103515625e-05
    c342      Obj       -8.425
    c342      r4108     -1
    c342      r4110     1
    c343      Obj       -1.7
    c343      r4111     -1
    c343      r4114     1
    c343      r5403     0.0001
    c343      r5733     0.0001
    c344      Obj       -1.18
    c344      r2384     1
    c344      r4111     1
    c344      r4112     -1
    c345      Obj       -0.009
    c345      r4113     1
    c345      r4114     -1
    c345      r5028     0.0001
    c345      r6831     0.0001
    c345      r7057     6.15215918512415e-05
    c346      Obj       -1.117
    c346      r4117     1
    c346      r4267     -1
    c346      r5191     0.0001
    c346      r5483     0.0001
    c347      Obj       -20.6
    c347      r4193     -1
    c347      r4268     1
    c348      Obj       -4.6
    c348      r4118     -1
    c348      r4120     1
    c348      r5165     6.103515625e-05
    c348      r6010     6.103515625e-05
    c348      r6083     6.103515625e-05
    c348      r6109     0.001953125
    c349      Obj       -0.337
    c349      r3937     -1
    c349      r4118     1
    c349      r4919     6.103515625e-05
    c349      r5990     6.103515625e-05
    c349      r6131     6.103515625e-05
    c350      Obj       -30.9
    c350      r4119     1
    c350      r4120     -1
    c350      r5164     0.0001
    c350      r5683     5.40634142331716e-05
    c350      r6083     6.103515625e-05
    c351      Obj       -14.448
    c351      r4121     1
    c351      r4142     -1
    c351      r5824     0.03125
    c351      r6502     -0.03125
    c351      r6594     -6.103515625e-05
    c351      r6610     -0.0001
    c351      r6752     -9.58279909070786e-05
    c352      Obj       -16.448
    c352      r2396     1
    c352      r4122     1
    c352      r4130     -1
    c352      r4476     6.103515625e-05
    c352      r4522     0.03125
    c352      r4722     0.0128
    c352      r4756     0.0128
    c352      r5086     0.0128
    c352      r6954     0.03125
    c352      r6960     0.0128
    c353      Obj       -0.141
    c353      r3779     1
    c353      r4123     -1
    c353      r5540     6.63148467036154e-05
    c353      r5718     6.63148467036154e-05
    c353      r5725     6.63148467036154e-05
    c353      r6539     9.98059035700758e-05
    c353      r6594     6.103515625e-05
    c353      r6762     9.98059035700758e-05
    c354      Obj       -0.296
    c354      r3782     -1
    c354      r4164     1
    c354      r5129     0.03125
    c354      r5399     0.0001220703125
    c355      Obj       -0.007
    c355      r3785     1
    c355      r4124     -1
    c355      r5668     0.0256
    c355      r6856     0.0001
    c356      Obj       -0.009
    c356      r4125     1
    c356      r4162     -1
    c356      r5100     0.0001
    c356      r6358     6.103515625e-05
    c356      r6610     0.0001
    c356      r6968     6.103515625e-05
    c357      Obj       -0.01
    c357      r4162     -1
    c357      r4185     1
    c357      r4362     0.03125
    c357      r6358     6.103515625e-05
    c357      r6594     6.103515625e-05
    c357      r6610     0.0001
    c357      r6667     0.0001
    c358      Obj       -11.706
    c358      r2404     1
    c358      r4127     1
    c358      r4128     -1
    c358      r5399     6.103515625e-05
    c358      r6953     0.03125
    c358      r6960     0.0128
    c359      Obj       -4.742
    c359      r3781     1
    c359      r4127     -1
    c359      r4722     0.0128
    c359      r4756     0.0128
    c360      Obj       -5.993
    c360      r2406     1
    c360      r4174     1
    c360      r4175     -1
    c361      Obj       -24.74
    c361      r2407     1
    c361      r3947     -1
    c361      r4128     1
    c362      Obj       -0.005
    c362      r3947     -1
    c362      r4168     1
    c363      Obj       -14.5
    c363      r4137     1
    c363      r4155     -1
    c363      r5114     8.86688360098634e-05
    c364      Obj       -37.84
    c364      r2410     1
    c364      r4129     -1
    c364      r4143     1
    c364      r5039     0.0256
    c365      Obj       -94.748
    c365      r2411     1
    c365      r4130     1
    c365      r4133     -1
    c366      Obj       -14
    c366      r4131     1
    c366      r4132     -1
    c366      r4298     0.0256
    c366      r4825     0.0001
    c367      Obj       -98.915
    c367      r2413     1
    c367      r4133     1
    c367      r4134     -1
    c367      r4521     0.03125
    c368      Obj       -0.01
    c368      r4135     -1
    c368      r4179     1
    c368      r4346     0.0256
    c369      Obj       -49.584
    c369      r2415     1
    c369      r4136     1
    c369      r4137     -1
    c370      Obj       -0.024
    c370      r4179     1
    c370      r4181     -1
    c370      r4363     0.03125
    c370      r4561     -0.03125
    c370      r4647     -0.0625
    c371      Obj       -0.034
    c371      r4180     1
    c371      r4181     -1
    c371      r4363     0.03125
    c372      Obj       -6
    c372      r4138     -1
    c372      r4271     1
    c372      r4921     6.103515625e-05
    c372      r5239     0.0001220703125
    c372      r6866     6.103515625e-05
    c372      r7035     6.72799219169098e-05
    c373      Obj       -4.328
    c373      r4138     -1
    c373      r4281     1
    c373      r5178     7.79684981375495e-05
    c373      r5325     0.0009765625
    c373      r5550     6.61530201248938e-05
    c373      r6892     7.79684981375495e-05
    c374      Obj       -3.721
    c374      r4139     -1
    c374      r4144     1
    c374      r5183     6.103515625e-05
    c375      Obj       -4.753
    c375      r4139     1
    c375      r4145     -1
    c376      Obj       -35.854
    c376      r2422     1
    c376      r4140     1
    c376      r4141     -1
    c376      r4306     0.03125
    c377      Obj       -60.185
    c377      r2423     1
    c377      r4142     1
    c377      r4143     -1
    c377      r6278     0.03125
    c377      r6513     6.103515625e-05
    c377      r6752     9.58279909070786e-05
    c378      Obj       -15.644
    c378      r3868     1
    c378      r4149     -1
    c378      r4789     0.03125
    c378      r5137     0.0064
    c378      r5824     -0.03125
    c378      r6370     0.0064
    c378      r6371     0.00321671566294248
    c378      r6396     0.0064
    c378      r6397     0.0064
    c378      r6398     0.0064
    c378      r6399     0.0064
    c378      r6400     0.0064
    c378      r6401     0.0064
    c378      r6697     0.000151654571991859
    c378      r6993     0.0002
    c378      r7008     0.000121111350807723
    c379      Obj       -10
    c379      r2425     1
    c379      r3767     1
    c379      r4144     -1
    c379      r4854     6.103515625e-05
    c379      r4937     6.103515625e-05
    c379      r5030     6.103515625e-05
    c380      Obj       -17.38
    c380      r2427     1
    c380      r4145     1
    c380      r4147     -1
    c381      Obj       -0.81
    c381      r4146     -1
    c381      r4270     1
    c382      Obj       -2
    c382      r4146     1
    c382      r4150     -1
    c382      r5458     0.0625
    c382      r5578     0.03125
    c383      Obj       -49.584
    c383      r2432     1
    c383      r4147     1
    c383      r4153     -1
    c383      r5645     6.103515625e-05
    c384      Obj       -11.607
    c384      r4149     1
    c384      r4183     -1
    c384      r5137     0.0032
    c384      r5458     0.0625
    c384      r6370     0.0032
    c384      r6371     0.00160835783147124
    c384      r6396     0.0032
    c384      r6397     0.0032
    c384      r6398     0.0032
    c384      r6399     0.0032
    c384      r6400     0.0032
    c384      r6401     0.0032
    c384      r6439     8.1381822059175e-05
    c384      r6528     0.00397553361202361
    c384      r6993     0.0001
    c385      Obj       -4.162
    c385      r2435     1
    c385      r4160     -1
    c385      r4183     1
    c385      r6805     6.33313256726729e-05
    c386      Obj       -11
    c386      r4150     1
    c386      r4182     -1
    c386      r4517     0.03125
    c387      Obj       -0.901
    c387      r4271     1
    c387      r4272     -1
    c387      r4930     0.0001
    c387      r4931     6.103515625e-05
    c387      r5178     7.79684981375495e-05
    c387      r5407     0.0009765625
    c387      r5475     6.103515625e-05
    c387      r5550     6.61530201248938e-05
    c387      r6892     7.79684981375495e-05
    c388      Obj       -5.7
    c388      r4151     -1
    c388      r4235     1
    c388      r5462     0.0016
    c389      Obj       -11.478
    c389      r3866     -1
    c389      r4154     1
    c389      r4857     9.5367431640625e-05
    c389      r4947     8.86688360098634e-05
    c389      r6963     0.03125
    c390      Obj       -3.022
    c390      r2442     1
    c390      r4153     1
    c390      r4154     -1
    c390      r4299     0.03125
    c390      r6740     6.103515625e-05
    c391      Obj       -14.2
    c391      r2443     1
    c391      r4155     1
    c391      r4156     -1
    c391      r6343     7.8502349312175e-05
    c391      r6481     9.58328545283696e-05
    c391      r6575     0.03125
    c392      Obj       -12.41
    c392      r4157     -1
    c392      r4161     1
    c392      r6861     6.103515625e-05
    c392      r6890     0.0625
    c393      Obj       -15.1
    c393      r4157     1
    c393      r4158     -1
    c393      r6107     0.03125
    c393      r6885     6.103515625e-05
    c394      Obj       -7.68
    c394      r4158     1
    c394      r4163     -1
    c394      r6872     6.103515625e-05
    c395      Obj       -0.015
    c395      r2448     1
    c395      r4159     -1
    c395      r4164     1
    c395      r6406     6.103515625e-05
    c396      Obj       -0.04
    c396      r2449     1
    c396      r4159     1
    c396      r4256     -1
    c397      Obj       -16.198
    c397      r2450     1
    c397      r4160     1
    c397      r4161     -1
    c397      r5056     0.0064
    c397      r5057     0.0064
    c397      r5058     0.0064
    c397      r5059     0.0064
    c397      r5060     0.0064
    c397      r5061     0.0064
    c397      r5062     0.0064
    c397      r5063     0.0064
    c397      r5137     0.0032
    c397      r6107     -0.03125
    c397      r6370     0.0032
    c397      r6371     0.00160835783147124
    c397      r6396     0.0032
    c397      r6397     0.0032
    c397      r6398     0.0032
    c397      r6399     0.0032
    c397      r6400     0.0032
    c397      r6401     0.0032
    c397      r6439     8.1381822059175e-05
    c397      r6528     0.00397553361202361
    c397      r6560     5.26071448575251e-05
    c397      r6697     7.58272859959297e-05
    c397      r6805     6.33313256726729e-05
    c397      r6993     0.0001
    c397      r7008     6.05556754038613e-05
    c398      Obj       -15.06
    c398      r2451     1
    c398      r4163     1
    c398      r4164     -1
    c398      r6425     6.103515625e-05
    c398      r6976     6.103515625e-05
    c398      r7026     6.103515625e-05
    c399      Obj       -27.424
    c399      r2453     1
    c399      r4177     1
    c399      r4178     -1
    c400      Obj       -0.001
    c400      r2454     1
    c400      r4165     1
    c400      r4166     -1
    c400      r4333     0.0256
    c401      Obj       -0.001
    c401      r2455     1
    c401      r4167     -1
    c401      r4273     1
    c402      Obj       -0.034
    c402      r4167     1
    c402      r4168     -1
    c403      Obj       -40.383
    c403      r2458     1
    c403      r4175     1
    c403      r4176     -1
    c403      r7065     6.103515625e-05
    c404      Obj       -26.647
    c404      r2459     1
    c404      r4169     1
    c404      r4170     -1
    c405      Obj       -9.485
    c405      r2460     1
    c405      r4170     1
    c405      r4171     -1
    c406      Obj       -5.799
    c406      r2461     1
    c406      r4171     1
    c406      r4172     -1
    c406      r7079     6.103515625e-05
    c407      Obj       -0.009
    c407      r2462     1
    c407      r4173     1
    c407      r4174     -1
    c408      Obj       -0.087
    c408      r2463     1
    c408      r4172     1
    c408      r4173     -1
    c409      Obj       -8.4
    c409      r2464     1
    c409      r4176     1
    c409      r4177     -1
    c410      Obj       -16.715
    c410      r2465     1
    c410      r3785     -1
    c410      r4178     1
    c410      r7024     6.103515625e-05
    c411      Obj       -1.658
    c411      r3787     1
    c411      r4180     -1
    c411      r4539     0.03125
    c411      r5008     0.0001
    c411      r5170     0.0016
    c411      r5337     0.0009765625
    c411      r5637     0.0001
    c411      r5692     6.103515625e-05
    c411      r5918     0.0009765625
    c411      r6558     0.0001
    c411      r6937     0.000108692704475025
    c411      r6996     9.53971836372719e-05
    c411      r7001     6.103515625e-05
    c412      Obj       -12.325
    c412      r4181     1
    c412      r4283     -1
    c412      r4825     0.0001
    c413      Obj       -30.9
    c413      r4194     1
    c413      r4195     -1
    c413      r5164     0.0001
    c413      r5683     5.40634142331716e-05
    c413      r6083     6.103515625e-05
    c414      Obj       -1.15
    c414      r4191     -1
    c414      r4231     1
    c415      Obj       -31.399
    c415      r2473     1
    c415      r3844     -1
    c415      r4189     1
    c415      r4948     0.03125
    c415      r5836     0.00390625
    c416      Obj       -19.696
    c416      r3942     1
    c416      r4189     -1
    c416      r4407     0.03125
    c416      r5736     0.03125
    c417      Obj       -1.204
    c417      r2476     1
    c417      r4191     1
    c417      r4192     -1
    c418      Obj       -16.5
    c418      r2477     1
    c418      r3946     -1
    c418      r4192     1
    c419      Obj       -0.019
    c419      r2478     1
    c419      r3389     -1
    c419      r3946     1
    c419      r6443     6.103515625e-05
    c419      r6469     6.103515625e-05
    c420      Obj       -25.69
    c420      r3858     -1
    c420      r4196     1
    c420      r4830     0.0001
    c420      r5168     0.0001
    c420      r6174     0.0001
    c420      r6263     0.000106825841804308
    c420      r6440     7.39420869012365e-05
    c420      r6493     7.83571103003273e-05
    c420      r6929     5.15410025492391e-05
    c421      Obj       -32.8
    c421      r4119     -1
    c421      r4193     1
    c421      r5308     6.103515625e-05
    c422      Obj       -16.595
    c422      r3791     -1
    c422      r4198     1
    c422      r4927     0.0001
    c422      r5043     0.03125
    c422      r5480     0.0001
    c422      r6357     7.89594079600832e-05
    c422      r6847     0.0001
    c422      r6878     9.00885318019727e-05
    c422      r6904     0.0001
    c422      r7048     0.000105419978435289
    c423      Obj       -1.19
    c423      r4197     1
    c423      r4198     -1
    c423      r5320     6.103515625e-05
    c424      Obj       -0.454
    c424      r2486     1
    c424      r3355     1
    c424      r4199     -1
    c425      Obj       -51.467
    c425      r2487     1
    c425      r3840     -1
    c425      r4199     1
    c425      r5152     0.0001
    c426      Obj       -1.424
    c426      r2488     1
    c426      r3843     1
    c426      r4200     -1
    c426      r4674     0.03125
    c427      Obj       -28.813
    c427      r2489     1
    c427      r3262     -1
    c427      r4200     1
    c427      r4509     6.103515625e-05
    c427      r4957     0.03125
    c427      r5121     0.0256
    c428      Obj       -57.099
    c428      r0        1
    c428      r3013     -1
    c428      r4208     1
    c428      r4934     6.103515625e-05
    c428      r5524     6.103515625e-05
    c428      r6354     6.103515625e-05
    c428      r6759     8.39874478313481e-05
    c428      r6812     8.39920286734662e-05
    c429      Obj       -1.9
    c429      r3015     -1
    c429      r3016     1
    c429      r5124     -0.03125
    c429      r5613     0.001953125
    c430      Obj       -0.098
    c430      r3016     -1
    c430      r3085     1
    c431      Obj       -1.076
    c431      r3085     1
    c431      r4210     -1
    c432      Obj       -0.596
    c432      r3017     1
    c432      r3018     -1
    c433      Obj       -6.885
    c433      r3206     -1
    c433      r4214     1
    c433      r5456     0.00185185185185185
    c433      r6079     0.00264557902182827
    c433      r6551     0.000825257769834793
    c433      r6623     0.00278859390737487
    c433      r6695     0.00213116957926213
    c434      Obj       -0.002
    c434      r3020     1
    c434      r3212     -1
    c434      r4371     0.03125
    c434      r5097     6.30463666551241e-05
    c434      r5904     6.103515625e-05
    c434      r6715     0.001953125
    c434      r6900     6.103515625e-05
    c435      Obj       -0.002
    c435      r3022     1
    c435      r3212     -1
    c435      r5097     6.30463666551241e-05
    c435      r6442     6.103515625e-05
    c435      r6555     9.59635558098634e-05
    c435      r6716     0.00390625
    c435      r6727     6.103515625e-05
    c436      Obj       -0.01
    c436      r3028     -1
    c436      r3037     1
    c436      r4483     0.0001
    c436      r4589     0.0001
    c436      r4643     6.103515625e-05
    c436      r5032     0.0064
    c437      Obj       -0.2
    c437      r3029     -1
    c437      r3030     1
    c437      r4454     1
    c437      r4847     0.0078125
    c438      Obj       -0.53
    c438      r15       1
    c438      r3032     1
    c438      r4274     -1
    c439      Obj       -0.789
    c439      r16       1
    c439      r3032     -1
    c439      r3034     1
    c439      r4313     0.03125
    c440      Obj       -0.01
    c440      r3037     -1
    c440      r3038     1
    c440      r4455     0.0064
    c441      Obj       -0.83
    c441      r20       1
    c441      r3035     -1
    c441      r3036     1
    c441      r4847     0.0078125
    c441      r5032     0.0064
    c441      r6939     0.0001
    c442      Obj       -0.377
    c442      r3042     1
    c442      r3139     -1
    c443      Obj       -0.71
    c443      r23       1
    c443      r3043     1
    c443      r3115     -1
    c443      r6845     7.06425419560185e-05
    c443      r7020     7.06425419560185e-05
    c444      Obj       -4.856
    c444      r3059     1
    c444      r3060     -1
    c445      Obj       -2.132
    c445      r3045     1
    c445      r3181     -1
    c445      r5222     0.0064
    c445      r5371     0.0078125
    c445      r5386     0.00477133756472706
    c445      r5402     0.00818795151234965
    c445      r6079     0.0102883569503487
    c445      r6149     0.00723356416963093
    c445      r6298     1
    c445      r6419     0.0064
    c445      r6426     0.00390625
    c445      r6551     0.00326323450433374
    c445      r6623     0.00770228798961384
    c445      r6726     0.0131337086411538
    c445      r6804     0.0078125
    c446      Obj       -1.25
    c446      r3045     -1
    c446      r3182     1
    c446      r4682     0.0128
    c446      r4891     -0.25
    c446      r6079     0.00167314212891488
    c446      r6149     0.00236431330767415
    c446      r6293     1
    c446      r6298     -1
    c446      r6623     -0.00435566575316421
    c447      Obj       -0.033
    c447      r3046     -1
    c447      r3185     1
    c447      r5600     6.103515625e-05
    c447      r5901     0.0064
    c447      r6567     -0.03125
    c447      r6663     -6.103515625e-05
    c447      r6670     0.00364180422693394
    c447      r6682     0.00390625
    c447      r6764     -6.103515625e-05
    c447      r7015     9.27182487500392e-05
    c448      Obj       -3.113
    c448      r3185     1
    c448      r4216     -1
    c448      r5600     6.103515625e-05
    c448      r5901     0.0064
    c448      r6361     6.103515625e-05
    c448      r6453     0.00390625
    c448      r6531     0.00390625
    c448      r6578     0.0032
    c448      r6670     0.00364180422693394
    c448      r7015     9.27182487500392e-05
    c449      Obj       -0.039
    c449      r3184     -1
    c449      r3185     1
    c449      r5901     0.0064
    c449      r6404     -0.0078125
    c449      r6454     -0.00398870124598239
    c449      r6577     0.001953125
    c449      r6578     0.0032
    c449      r6770     0.001953125
    c449      r6774     0.03125
    c449      r6891     6.64933453830745e-05
    c449      r7069     -6.103515625e-05
    c450      Obj       -7.164
    c450      r3048     -1
    c450      r3248     1
    c450      r4296     0.03125
    c450      r4391     0.0256
    c450      r6696     0.0001
    c450      r6793     6.103515625e-05
    c450      r6797     0.0001
    c451      Obj       -1.915
    c451      r3049     1
    c451      r3086     -1
    c451      r4719     0.0256
    c451      r5674     0.03125
    c451      r6862     6.73278217309408e-05
    c451      r6888     0.0001
    c451      r6901     0.0001
    c452      Obj       -0.435
    c452      r3049     -1
    c452      r3094     1
    c452      r5112     6.73278217309408e-05
    c452      r6860     6.103515625e-05
    c452      r6876     0.00024918413882772
    c452      r6898     6.103515625e-05
    c452      r6907     6.103515625e-05
    c452      r7073     6.73278217309408e-05
    c453      Obj       -0.02
    c453      r3063     1
    c453      r3076     -1
    c453      r4819     0.0625
    c453      r5242     0.000498368277655441
    c453      r6351     0.00390625
    c453      r6876     0.00024918413882772
    c453      r7060     7.17247353894615e-05
    c454      Obj       -0.8
    c454      r36       1
    c454      r3050     1
    c454      r3071     -1
    c454      r4551     0.03125
    c454      r4613     0.03125
    c454      r4960     0.03125
    c455      Obj       -0.285
    c455      r3017     -1
    c455      r3051     1
    c456      Obj       -0.134
    c456      r3051     -1
    c456      r3064     1
    c457      Obj       -1.652
    c457      r39       1
    c457      r3052     1
    c457      r3079     -1
    c457      r4726     0.00390625
    c457      r4845     6.103515625e-05
    c457      r5538     0.00390625
    c457      r6869     5.43039518629256e-05
    c457      r6928     5.36921498040993e-05
    c457      r7062     6.103515625e-05
    c458      Obj       -0.187
    c458      r3052     -1
    c458      r3065     1
    c458      r4960     0.03125
    c458      r5279     0.03125
    c458      r6948     6.31515315405316e-05
    c459      Obj       -1.069
    c459      r3064     -1
    c459      r3065     1
    c460      Obj       -0.085
    c460      r42       1
    c460      r3053     1
    c460      r3062     -1
    c460      r7075     6.103515625e-05
    c461      Obj       -1.382
    c461      r43       1
    c461      r3053     -1
    c461      r3069     1
    c461      r4405     0.03125
    c462      Obj       -1.097
    c462      r3068     -1
    c462      r3069     1
    c462      r4405     0.03125
    c463      Obj       -0.693
    c463      r45       1
    c463      r3054     1
    c463      r3066     -1
    c464      Obj       -0.168
    c464      r46       1
    c464      r3054     -1
    c464      r3055     1
    c465      Obj       -0.129
    c465      r47       1
    c465      r3055     -1
    c465      r3056     1
    c466      Obj       -0.435
    c466      r48       1
    c466      r3056     -1
    c466      r3057     1
    c467      Obj       -0.077
    c467      r49       1
    c467      r3057     -1
    c467      r3058     1
    c467      r6299     0.03125
    c468      Obj       -0.29
    c468      r50       1
    c468      r3058     -1
    c468      r3073     1
    c468      r4404     0.03125
    c468      r5748     0.03125
    c468      r5847     0.03125
    c469      Obj       -0.029
    c469      r3072     -1
    c469      r3073     1
    c469      r4404     0.03125
    c470      Obj       -0.86
    c470      r52       1
    c470      r3061     1
    c470      r3067     -1
    c471      Obj       -0.216
    c471      r3060     1
    c471      r3079     -1
    c471      r4436     0.0256
    c471      r4726     0.00390625
    c471      r5538     0.00390625
    c471      r5704     0.00404434161793957
    c471      r5894     0.00342984041820218
    c471      r6149     0.000558858203538082
    c471      r6623     0.00265773159367875
    c471      r6869     5.43039518629256e-05
    c471      r6928     5.36921498040993e-05
    c471      r7062     6.103515625e-05
    c471      r7083     0.0001
    c472      Obj       -1.29
    c472      r3077     1
    c472      r3084     -1
    c472      r5044     0.0256
    c472      r5393     0.0625
    c473      Obj       -1.63
    c473      r3076     1
    c473      r3095     -1
    c473      r4402     0.03125
    c473      r5488     6.83101334359297e-05
    c473      r6687     0.00390625
    c473      r6881     6.103515625e-05
    c473      r6909     6.83101334359297e-05
    c473      r7074     6.103515625e-05
    c474      Obj       -0.004
    c474      r3061     -1
    c474      r3062     1
    c474      r6936     6.103515625e-05
    c475      Obj       -2.444
    c475      r3063     -1
    c475      r3199     1
    c476      Obj       -0.127
    c476      r58       1
    c476      r3066     1
    c476      r3067     -1
    c477      Obj       -0.09
    c477      r3068     1
    c477      r3072     -1
    c477      r5009     0.0625
    c478      Obj       -0.023
    c478      r60       1
    c478      r3070     -1
    c478      r3088     1
    c479      Obj       -1.167
    c479      r61       1
    c479      r3087     -1
    c479      r3088     1
    c479      r4400     0.03125
    c479      r4565     0.0512
    c479      r5587     0.03125
    c480      Obj       -0.269
    c480      r3069     -1
    c480      r3070     1
    c481      Obj       -0.045
    c481      r3071     1
    c481      r3075     -1
    c481      r5587     0.03125
    c482      Obj       -0.208
    c482      r64       1
    c482      r3073     -1
    c482      r3074     1
    c482      r5009     0.0625
    c482      r5077     0.0625
    c483      Obj       -0.056
    c483      r65       1
    c483      r3074     -1
    c483      r4209     1
    c484      Obj       -0.02
    c484      r3080     1
    c484      r3089     -1
    c484      r5536     1
    c484      r6698     0.03125
    c485      Obj       -1.067
    c485      r3075     -1
    c485      r3087     1
    c485      r4911     0.0256
    c485      r6901     0.0001
    c486      Obj       -0.017
    c486      r3087     1
    c486      r4209     -1
    c487      Obj       -2.93
    c487      r3076     -1
    c487      r3097     1
    c487      r4819     0.0625
    c487      r5242     0.000498368277655441
    c487      r6876     0.00024918413882772
    c488      Obj       -0.01
    c488      r3077     -1
    c488      r3078     1
    c488      r6266     0.0256
    c489      Obj       -0.05
    c489      r3078     -1
    c489      r4211     1
    c489      r5891     0.0256
    c490      Obj       -0.012
    c490      r3079     1
    c490      r3093     -1
    c490      r4426     0.03125
    c490      r5279     -0.03125
    c490      r7064     0.00347545291922723
    c491      Obj       -0.282
    c491      r3080     -1
    c491      r3081     1
    c491      r4954     0.03125
    c492      Obj       -1.267
    c492      r3081     -1
    c492      r3082     1
    c492      r5459     0.0256
    c493      Obj       -0.33
    c493      r3082     -1
    c493      r3083     1
    c493      r6326     0.0256
    c494      Obj       -0.17
    c494      r3083     -1
    c494      r3084     1
    c494      r6005     0.0256
    c495      Obj       -0.145
    c495      r3086     1
    c495      r3088     -1
    c495      r4427     0.03125
    c495      r4718     0.0256
    c496      Obj       -0.344
    c496      r3089     -1
    c496      r3091     1
    c497      Obj       -0.918
    c497      r3090     1
    c497      r4212     -1
    c497      r5534     0.0256
    c498      Obj       -2.112
    c498      r3090     -1
    c498      r3096     1
    c498      r5533     0.0256
    c499      Obj       -0.01
    c499      r81       1
    c499      r3091     -1
    c499      r3092     1
    c499      r5393     0.0625
    c499      r5613     0.001953125
    c499      r5702     0.001953125
    c499      r6919     0.001953125
    c499      r7068     0.001953125
    c500      Obj       -0.575
    c500      r82       1
    c500      r3092     -1
    c500      r3093     1
    c500      r5595     0.00390625
    c500      r6702     0.0009765625
    c500      r6787     0.00390625
    c501      Obj       -0.75
    c501      r3093     -1
    c501      r4210     1
    c501      r4426     0.03125
    c501      r4726     0.00390625
    c501      r5538     0.00390625
    c501      r6928     5.36921498040993e-05
    c501      r7064     0.00347545291922723
    c502      Obj       -0.7
    c502      r3094     -1
    c502      r3095     1
    c502      r4612     0.03125
    c502      r5109     0.0001
    c502      r6918     6.103515625e-05
    c502      r7083     0.0001
    c503      Obj       -4.19
    c503      r4211     -1
    c503      r4212     1
    c503      r5714     0.0256
    c504      Obj       -0.02
    c504      r3096     -1
    c504      r3098     1
    c504      r5488     6.83101334359297e-05
    c504      r6881     6.103515625e-05
    c504      r6909     6.83101334359297e-05
    c504      r7073     6.73278217309408e-05
    c505      Obj       -0.05
    c505      r3097     -1
    c505      r3098     1
    c506      Obj       -0.062
    c506      r88       1
    c506      r3042     -1
    c506      r3099     1
    c507      Obj       -0.964
    c507      r89       1
    c507      r3099     -1
    c507      r3140     1
    c508      Obj       -0.674
    c508      r90       1
    c508      r3100     1
    c508      r3124     -1
    c509      Obj       -0.2
    c509      r91       1
    c509      r3100     -1
    c509      r3123     1
    c510      Obj       -0.554
    c510      r92       1
    c510      r3122     -1
    c510      r3123     1
    c511      Obj       -0.031
    c511      r3102     -1
    c511      r3105     1
    c511      r6845     7.06425419560185e-05
    c512      Obj       -0.006
    c512      r3101     1
    c512      r3200     -1
    c512      r5665     -1
    c512      r6257     0.00057319972826087
    c512      r6336     0.00057319972826087
    c512      r6429     0.00057319972826087
    c512      r6875     6.64990395569203e-05
    c513      Obj       -0.012
    c513      r3101     1
    c513      r3202     -1
    c514      Obj       -0.023
    c514      r3101     -1
    c514      r3102     1
    c514      r6837     0.00057319972826087
    c514      r6875     6.64990395569203e-05
    c514      r7050     6.103515625e-05
    c515      Obj       -0.03
    c515      r3044     1
    c515      r3103     -1
    c515      r5488     6.83101334359297e-05
    c515      r5666     1
    c515      r6881     6.103515625e-05
    c515      r6909     6.83101334359297e-05
    c516      Obj       -0.013
    c516      r3103     1
    c516      r3104     -1
    c516      r5490     6.83135489426015e-05
    c516      r5666     -1
    c516      r6864     6.83135489426015e-05
    c517      Obj       -1.309
    c517      r3104     1
    c517      r3112     -1
    c517      r5258     6.83101334359297e-05
    c517      r5563     6.103515625e-05
    c517      r6858     6.103515625e-05
    c517      r6895     6.103515625e-05
    c517      r6912     6.103515625e-05
    c517      r7042     6.83101334359297e-05
    c517      r7044     6.103515625e-05
    c518      Obj       -9.464
    c518      r101      1
    c518      r3105     -1
    c518      r3106     1
    c518      r5708     0.00057319972826087
    c518      r6182     0.00048828125
    c518      r6703     6.103515625e-05
    c518      r6839     0.00057319972826087
    c518      r6852     6.103515625e-05
    c518      r7020     7.06425419560185e-05
    c519      Obj       -0.111
    c519      r102      1
    c519      r3106     -1
    c519      r3107     1
    c520      Obj       -0.589
    c520      r103      1
    c520      r3107     -1
    c520      r3108     1
    c521      Obj       -2.183
    c521      r104      1
    c521      r3108     -1
    c521      r3109     1
    c522      Obj       -1.22
    c522      r105      1
    c522      r3109     -1
    c522      r3110     1
    c523      Obj       -0.854
    c523      r106      1
    c523      r3110     -1
    c523      r3111     1
    c524      Obj       -2.189
    c524      r107      1
    c524      r3111     -1
    c524      r3112     1
    c524      r4423     0.03125
    c524      r5251     0.000189373101733534
    c524      r5386     0.000240054832301586
    c524      r6551     0.000158836332351568
    c524      r6623     0.000205130517175296
    c524      r6912     6.103515625e-05
    c525      Obj       -0.004
    c525      r3112     1
    c525      r3204     -1
    c525      r4423     0.03125
    c526      Obj       -0.3
    c526      r3113     -1
    c526      r3137     1
    c527      Obj       -0.015
    c527      r3113     1
    c527      r3203     -1
    c527      r4515     0.03125
    c527      r6912     6.103515625e-05
    c528      Obj       -0.99
    c528      r3113     1
    c528      r3136     -1
    c528      r5251     0.000189373101733534
    c528      r5386     0.000240054832301586
    c528      r6551     0.000158836332351568
    c528      r6623     0.000205130517175296
    c529      Obj       -0.429
    c529      r112      1
    c529      r3114     1
    c529      r3201     -1
    c530      Obj       -0.748
    c530      r3114     -1
    c530      r3115     1
    c530      r6839     0.00057319972826087
    c530      r7051     6.103515625e-05
    c531      Obj       -2.944
    c531      r114      1
    c531      r3043     -1
    c531      r3116     1
    c531      r6837     0.00057319972826087
    c531      r7050     6.103515625e-05
    c531      r7078     7.16499660326087e-05
    c532      Obj       -0.21
    c532      r115      1
    c532      r3116     -1
    c532      r3117     1
    c533      Obj       -0.673
    c533      r116      1
    c533      r3117     -1
    c533      r3118     1
    c534      Obj       -0.348
    c534      r117      1
    c534      r3118     -1
    c534      r3119     1
    c535      Obj       -2.007
    c535      r118      1
    c535      r3119     -1
    c535      r3120     1
    c536      Obj       -0.072
    c536      r119      1
    c536      r3120     -1
    c536      r3121     1
    c537      Obj       -0.137
    c537      r120      1
    c537      r3121     -1
    c537      r3122     1
    c538      Obj       -2.37
    c538      r121      1
    c538      r3124     -1
    c538      r3125     1
    c539      Obj       -1.064
    c539      r122      1
    c539      r3125     -1
    c539      r3126     1
    c540      Obj       -0.345
    c540      r123      1
    c540      r3127     -1
    c540      r3128     1
    c541      Obj       -1.312
    c541      r124      1
    c541      r3126     -1
    c541      r3127     1
    c542      Obj       -0.195
    c542      r125      1
    c542      r3128     -1
    c542      r3130     1
    c543      Obj       -1.007
    c543      r126      1
    c543      r3129     1
    c543      r3134     -1
    c543      r6864     6.83135489426015e-05
    c543      r6912     6.103515625e-05
    c543      r7044     6.103515625e-05
    c544      Obj       -0.484
    c544      r127      1
    c544      r3129     -1
    c544      r3135     1
    c544      r5570     6.103515625e-05
    c544      r5571     6.103515625e-05
    c545      Obj       -0.489
    c545      r128      1
    c545      r3130     -1
    c545      r3131     1
    c546      Obj       -0.218
    c546      r129      1
    c546      r3131     -1
    c546      r3132     1
    c547      Obj       -0.256
    c547      r130      1
    c547      r3132     -1
    c547      r3133     1
    c548      Obj       -0.912
    c548      r131      1
    c548      r3133     -1
    c548      r3134     1
    c549      Obj       -0.029
    c549      r3135     -1
    c549      r3136     1
    c550      Obj       -0.386
    c550      r133      1
    c550      r3137     -1
    c550      r3138     1
    c551      Obj       -0.855
    c551      r134      1
    c551      r3138     -1
    c551      r3139     1
    c552      Obj       -0.81
    c552      r3140     -1
    c552      r3143     1
    c553      Obj       -0.022
    c553      r137      1
    c553      r3141     -1
    c553      r3142     1
    c553      r4330     0.0256
    c554      Obj       -0.018
    c554      r138      1
    c554      r3143     -1
    c554      r3144     1
    c555      Obj       -0.373
    c555      r3173     1
    c555      r3175     -1
    c555      r4459     1
    c556      Obj       -0.069
    c556      r3145     1
    c556      r4213     -1
    c556      r6079     0.00154661451246507
    c556      r6427     0.00390625
    c556      r6995     0.001953125
    c557      Obj       -0.007
    c557      r142      1
    c557      r3146     -1
    c557      r3149     1
    c558      Obj       -0.711
    c558      r3147     1
    c558      r3151     -1
    c559      Obj       -3.311
    c559      r3147     -1
    c559      r3152     1
    c559      r4451     1
    c559      r5456     0.000164819060872966
    c559      r6079     0.000486344453185321
    c559      r6149     0.000264397316125725
    c559      r6497     0.000379357958104221
    c559      r6623     0.000253346081494236
    c559      r6695     0.00018967897905211
    c560      Obj       -0.175
    c560      r3148     -1
    c560      r3152     1
    c561      Obj       -0.02
    c561      r3148     1
    c561      r3155     -1
    c562      Obj       -0.002
    c562      r147      1
    c562      r3149     -1
    c562      r3151     1
    c562      r6911     6.103515625e-05
    c563      Obj       -0.005
    c563      r148      1
    c563      r3150     -1
    c563      r3151     1
    c563      r6911     6.103515625e-05
    c564      Obj       -0.264
    c564      r3152     -1
    c564      r3153     1
    c564      r4977     0.03125
    c564      r6309     0.001953125
    c565      Obj       -10.141
    c565      r3153     -1
    c565      r3154     1
    c565      r4447     0.0296296296296296
    c565      r4457     1
    c565      r4576     0.001953125
    c565      r4577     0.00390625
    c565      r6079     0.00309322902493015
    c565      r6145     0.001953125
    c565      r6218     0.00390625
    c565      r6427     0.00390625
    c565      r6428     0.00390625
    c565      r6551     0.00185185185185185
    c565      r6623     0.000593730604379497
    c565      r6838     0.001953125
    c565      r6995     0.00390625
    c566      Obj       -0.005
    c566      r3154     -1
    c566      r3205     1
    c567      Obj       -0.114
    c567      r3155     -1
    c567      r4213     1
    c567      r6145     0.001953125
    c568      Obj       -4.971
    c568      r3196     -1
    c568      r3197     1
    c568      r4625     0.03125
    c568      r4676     0.03125
    c569      Obj       -0.045
    c569      r3159     1
    c569      r3209     -1
    c569      r4747     0.03125
    c569      r5662     0.0512
    c570      Obj       -0.01
    c570      r3156     -1
    c570      r3159     1
    c570      r4747     0.03125
    c570      r5662     0.0512
    c571      Obj       -0.218
    c571      r3157     1
    c571      r3161     -1
    c572      Obj       -2.861
    c572      r3156     1
    c572      r3188     -1
    c572      r6879     6.103515625e-05
    c573      Obj       -8.906
    c573      r158      1
    c573      r3158     -1
    c573      r3189     1
    c573      r5066     6.103515625e-05
    c573      r5141     6.103515625e-05
    c574      Obj       -0.233
    c574      r3157     -1
    c574      r3158     1
    c575      Obj       -5.656
    c575      r3183     1
    c575      r3207     -1
    c576      Obj       -0.185
    c576      r161      1
    c576      r3165     1
    c576      r3171     -1
    c577      Obj       -3.302
    c577      r162      1
    c577      r3166     -1
    c577      r3172     1
    c578      Obj       -0.006
    c578      r163      1
    c578      r3164     -1
    c578      r3172     1
    c578      r4292     0.0256
    c579      Obj       -0.339
    c579      r3159     -1
    c579      r3160     1
    c579      r5596     6.103515625e-05
    c579      r6879     6.103515625e-05
    c580      Obj       -0.062
    c580      r166      1
    c580      r3160     -1
    c580      r3161     1
    c580      r4730     6.103515625e-05
    c581      Obj       -1.061
    c581      r3167     1
    c581      r3210     -1
    c582      Obj       -0.016
    c582      r169      1
    c582      r3162     -1
    c582      r3163     1
    c583      Obj       -0.102
    c583      r170      1
    c583      r3165     -1
    c583      r3166     1
    c584      Obj       -1.515
    c584      r3167     -1
    c584      r3170     1
    c585      Obj       -0.118
    c585      r3168     -1
    c585      r3169     1
    c585      r4291     0.03125
    c585      r5729     0.0001
    c586      Obj       -0.117
    c586      r3170     -1
    c586      r3171     1
    c586      r6819     6.103515625e-05
    c587      Obj       -1.274
    c587      r3174     -1
    c587      r3176     1
    c587      r4446     0.0128
    c588      Obj       -2.136
    c588      r3173     -1
    c588      r3174     1
    c588      r4458     1
    c588      r4632     -0.03125
    c588      r4924     0.001953125
    c588      r6149     -0.000707762918134222
    c589      Obj       -0.082
    c589      r3174     1
    c589      r3211     -1
    c589      r4450     0.03125
    c589      r4924     0.001953125
    c589      r5302     0.0025769589173366
    c589      r6079     0.00312248536532701
    c589      r6551     0.00152733467193501
    c589      r6819     6.103515625e-05
    c590      Obj       -1.87
    c590      r179      1
    c590      r3175     1
    c590      r4214     -1
    c591      Obj       -9.252
    c591      r3176     -1
    c591      r3179     1
    c591      r4632     0.03125
    c591      r5447     0.00390625
    c591      r5456     0.00374261358233731
    c591      r6079     0.00312698103182957
    c591      r6149     0.000920848343767049
    c591      r6426     0.00390625
    c591      r6497     0.0086142357506994
    c591      r6551     0.00281395638702961
    c591      r6623     0.00565878230100785
    c591      r6695     0.0043071178753497
    c591      r6726     0.0131337086411538
    c591      r6804     0.0078125
    c592      Obj       -2.852
    c592      r3177     -1
    c592      r3179     1
    c592      r4971     1
    c592      r5456     0.000494457182618889
    c592      r6079     0.000913837408353143
    c592      r6497     0.00113807387431264
    c592      r6551     0.000145965722737293
    c592      r6623     0.000744573754930741
    c592      r6695     0.000569036937156321
    c593      Obj       -0.238
    c593      r3178     -1
    c593      r3180     1
    c593      r4681     -0.0128
    c593      r4682     -0.0128
    c593      r4683     -0.0128
    c593      r5371     -0.0078125
    c593      r5386     -0.00553735898008698
    c593      r5402     -0.000699328581722939
    c593      r5456     0.00230522347723079
    c593      r5469     -0.0256
    c593      r5582     1
    c593      r5708     0.00057319972826087
    c593      r6079     -0.0066198998066135
    c593      r6149     -0.00101445597497673
    c593      r6419     -0.0064
    c593      r6473     -0.0256
    c593      r6479     0.00390625
    c593      r6484     -0.0037404446123921
    c593      r6497     0.00530584791992114
    c593      r6549     0.00506399269796516
    c593      r6551     -0.00172414301720269
    c593      r6623     0.000372751096411076
    c593      r6694     0.00390625
    c593      r6695     0.00265292395996057
    c594      Obj       -3.265
    c594      r3180     1
    c594      r4215     -1
    c594      r5134     -0.5
    c594      r5456     -0.00339428470014143
    c594      r6497     -0.0078125
    c594      r6551     -0.000930330860993808
    c594      r6623     -0.00490982137536215
    c594      r6695     -0.00390625
    c595      Obj       -8.434
    c595      r3179     -1
    c595      r4215     1
    c595      r5134     0.5
    c595      r5374     0.00390625
    c595      r5402     0.000937044862188481
    c595      r5456     0.00339428470014143
    c595      r6079     0.00256380382436432
    c595      r6149     0.000598371103903074
    c595      r6476     0.00390625
    c595      r6497     0.0078125
    c595      r6549     0.00506399269796516
    c595      r6551     0.00115807567497475
    c595      r6623     0.00575838404380333
    c595      r6695     0.00390625
    c596      Obj       -4.532
    c596      r3180     -1
    c596      r3181     1
    c596      r4891     0.25
    c596      r5386     0.0031160771210439
    c596      r6079     0.00494675767769862
    c596      r6149     0.00439912119874715
    c596      r6479     0.00390625
    c596      r6484     0.0037404446123921
    c596      r6551     0.00167700866662833
    c596      r6623     0.00316453748373954
    c596      r6694     0.00390625
    c597      Obj       -0.015
    c597      r3182     -1
    c597      r4216     1
    c597      r4683     0.0128
    c597      r6293     -1
    c597      r6577     0.001953125
    c597      r6770     0.001953125
    c597      r6877     6.103515625e-05
    c597      r6891     6.64933453830745e-05
    c598      Obj       -2.241
    c598      r3183     -1
    c598      r3184     1
    c598      r6877     -6.103515625e-05
    c598      r7021     -0.0001
    c599      Obj       -4.665
    c599      r189      1
    c599      r3186     1
    c599      r4217     -1
    c600      Obj       -1.103
    c600      r190      1
    c600      r3185     -1
    c600      r4217     1
    c600      r5349     0.00390625
    c600      r6412     0.00404992014222228
    c600      r6454     0.00398870124598239
    c600      r6577     0.001953125
    c600      r6668     8.13802083333333e-05
    c600      r6693     6.103515625e-05
    c600      r6721     0.00390625
    c600      r6737     0.0032286767807064
    c600      r6746     6.103515625e-05
    c600      r6754     6.103515625e-05
    c600      r6764     6.103515625e-05
    c600      r6770     0.001953125
    c600      r6877     6.103515625e-05
    c600      r7021     0.0001
    c601      Obj       -9.52
    c601      r191      1
    c601      r3186     -1
    c601      r3187     1
    c602      Obj       -6.01
    c602      r192      1
    c602      r3187     -1
    c602      r3188     1
    c602      r5350     6.103515625e-05
    c602      r5431     6.103515625e-05
    c602      r5577     0.03125
    c603      Obj       -0.002
    c603      r193      1
    c603      r3189     -1
    c603      r3190     1
    c604      Obj       -1.27
    c604      r194      1
    c604      r3190     -1
    c604      r3191     1
    c605      Obj       -0.086
    c605      r195      1
    c605      r3191     -1
    c605      r3192     1
    c606      Obj       -3.14
    c606      r196      1
    c606      r3192     -1
    c606      r3193     1
    c607      Obj       -6.681
    c607      r197      1
    c607      r3193     -1
    c607      r3194     1
    c608      Obj       -3.455
    c608      r198      1
    c608      r3194     -1
    c608      r3195     1
    c609      Obj       -0.02
    c609      r199      1
    c609      r3196     -1
    c609      r3208     1
    c609      r5405     6.103515625e-05
    c609      r5577     0.03125
    c610      Obj       -0.892
    c610      r3197     -1
    c610      r3198     1
    c610      r4518     0.03125
    c610      r6913     6.103515625e-05
    c610      r6957     0.03125
    c610      r6958     0.03125
    c610      r7061     6.103515625e-05
    c611      Obj       -1.6
    c611      r202      1
    c611      r3029     1
    c611      r4631     0.0064
    c612      Obj       -1
    c612      r3232     -1
    c612      r4219     1
    c612      r4859     6.103515625e-05
    c612      r4879     0.03125
    c612      r5115     6.103515625e-05
    c613      Obj       -3
    c613      r3244     1
    c613      r4219     -1
    c613      r5020     6.103515625e-05
    c613      r6354     6.103515625e-05
    c613      r6758     0.000136246297338497
    c614      Obj       -13.093
    c614      r205      1
    c614      r3216     -1
    c614      r3234     1
    c614      r6874     6.103515625e-05
    c615      Obj       -0.01
    c615      r206      1
    c615      r2996     1
    c615      r4276     -1
    c616      Obj       -1
    c616      r3226     1
    c616      r4208     -1
    c616      r5522     6.103515625e-05
    c616      r6738     6.103515625e-05
    c616      r6795     6.103515625e-05
    c616      r6812     8.39920286734662e-05
    c616      r7031     6.103515625e-05
    c617      Obj       -3.94
    c617      r209      1
    c617      r3227     1
    c617      r4224     -1
    c617      r6854     6.103515625e-05
    c618      Obj       -14.215
    c618      r210      1
    c618      r3227     -1
    c618      r4279     1
    c618      r7025     6.103515625e-05
    c619      Obj       -16.185
    c619      r211      1
    c619      r3240     1
    c619      r4279     -1
    c619      r6947     6.103515625e-05
    c620      Obj       -21.404
    c620      r212      1
    c620      r3228     1
    c620      r4222     -1
    c620      r4841     0.0001
    c620      r7040     6.103515625e-05
    c621      Obj       -0.468
    c621      r3228     -1
    c621      r3230     1
    c622      Obj       -37.19
    c622      r214      1
    c622      r3229     1
    c622      r3230     -1
    c622      r5316     6.103515625e-05
    c623      Obj       -0.264
    c623      r215      1
    c623      r3035     1
    c623      r4221     -1
    c624      Obj       -0.017
    c624      r3038     -1
    c624      r3231     1
    c624      r6893     6.103515625e-05
    c625      Obj       -0.23
    c625      r3233     1
    c625      r4277     -1
    c625      r6408     -6.103515625e-05
    c625      r6475     -6.103515625e-05
    c626      Obj       -25.255
    c626      r218      1
    c626      r3231     -1
    c626      r4278     1
    c626      r6688     0.0001
    c626      r6709     0.03125
    c626      r6781     0.000581138962555129
    c626      r7006     6.103515625e-05
    c627      Obj       -0.752
    c627      r219      1
    c627      r3216     1
    c627      r3229     -1
    c628      Obj       -13.566
    c628      r220      1
    c628      r3240     -1
    c628      r4222     1
    c628      r6897     6.103515625e-05
    c628      r7055     6.103515625e-05
    c629      Obj       -5.342
    c629      r221      1
    c629      r3241     1
    c629      r3242     -1
    c630      Obj       -0.506
    c630      r222      1
    c630      r3242     1
    c630      r3243     -1
    c631      Obj       -25.539
    c631      r3236     1
    c631      r4223     -1
    c631      r5801     0.000101003763294318
    c631      r5814     6.103515625e-05
    c631      r5904     6.103515625e-05
    c631      r6092     6.52398584726051e-05
    c631      r6178     0.000101003763294318
    c631      r6806     6.103515625e-05
    c631      r6905     6.103515625e-05
    c632      Obj       -29.742
    c632      r3021     -1
    c632      r4223     1
    c632      r5999     6.103515625e-05
    c632      r6630     6.103515625e-05
    c633      Obj       -6.313
    c633      r225      1
    c633      r3241     -1
    c633      r4224     1
    c634      Obj       -7.77
    c634      r3237     1
    c634      r4278     -1
    c634      r5977     8.16584644176811e-05
    c634      r6081     8.16584644176811e-05
    c634      r6413     6.103515625e-05
    c635      Obj       -0.008
    c635      r3244     -1
    c635      r3245     1
    c635      r5627     0.0001220703125
    c635      r6475     6.103515625e-05
    c635      r6584     0.001953125
    c635      r6826     6.103515625e-05
    c635      r7002     0.0001
    c636      Obj       -8.73
    c636      r229      1
    c636      r3236     -1
    c636      r3243     1
    c637      Obj       -46
    c637      r230      1
    c637      r3246     1
    c637      r3247     -1
    c637      r4494     0.0001
    c638      Obj       -4.531
    c638      r3237     -1
    c638      r4277     1
    c638      r6413     -6.103515625e-05
    c639      Obj       -87.8
    c639      r232      1
    c639      r3235     1
    c639      r3246     -1
    c639      r7049     0.000488357173027066
    c640      Obj       -56.8
    c640      r233      1
    c640      r3040     -1
    c640      r4220     1
    c640      r5532     6.103515625e-05
    c640      r5801     0.0001
    c640      r6178     0.0001
    c640      r6354     6.103515625e-05
    c640      r6634     6.103515625e-05
    c640      r6797     0.0001
    c641      Obj       -65
    c641      r235      1
    c641      r3247     1
    c641      r3249     -1
    c641      r6905     6.103515625e-05
    c642      Obj       -0.01
    c642      r236      1
    c642      r3213     -1
    c642      r4275     1
    c642      r6900     6.103515625e-05
    c643      Obj       -0.02
    c643      r3251     -1
    c643      r3252     1
    c643      r5640     6.103515625e-05
    c643      r6564     6.103515625e-05
    c644      Obj       -27
    c644      r239      1
    c644      r4226     -1
    c644      r4227     1
    c644      r4979     0.0009765625
    c644      r6841     6.103515625e-05
    c644      r7016     6.103515625e-05
    c645      Obj       -0.02
    c645      r3253     -1
    c645      r3257     1
    c645      r4963     0.03125
    c645      r6507     0.0256
    c646      Obj       -0.7
    c646      r3254     -1
    c646      r3923     1
    c646      r4301     0.0256
    c646      r4570     0.0009765625
    c646      r4827     6.103515625e-05
    c646      r4828     6.103515625e-05
    c646      r5190     6.95478079421149e-05
    c646      r5319     6.103515625e-05
    c646      r6359     0.0001
    c646      r6636     6.45772165793789e-05
    c646      r7032     6.27562463049122e-05
    c647      Obj       -0.011
    c647      r3264     -1
    c647      r4228     1
    c647      r5121     0.0256
    c648      Obj       -7.984
    c648      r244      1
    c648      r3271     1
    c648      r3272     -1
    c648      r4646     6.103515625e-05
    c648      r5217     6.103515625e-05
    c648      r5248     6.3935438124036e-05
    c648      r6094     6.103515625e-05
    c648      r6512     6.103515625e-05
    c648      r6553     6.103515625e-05
    c648      r6559     6.23805752444274e-05
    c648      r6638     6.36421271115382e-05
    c648      r6665     6.103515625e-05
    c648      r6810     6.36421271115382e-05
    c648      r7017     6.36421271115382e-05
    c649      Obj       -0.011
    c649      r246      1
    c649      r3280     1
    c649      r3282     -1
    c650      Obj       -0.011
    c650      r247      1
    c650      r3280     -1
    c650      r3283     1
    c651      Obj       -13.451
    c651      r248      1
    c651      r3281     -1
    c651      r3284     1
    c652      Obj       -4.24
    c652      r249      1
    c652      r3283     -1
    c652      r3288     1
    c653      Obj       -11.367
    c653      r250      1
    c653      r3287     -1
    c653      r3288     1
    c654      Obj       -14.153
    c654      r251      1
    c654      r3284     -1
    c654      r3285     1
    c655      Obj       -8.978
    c655      r252      1
    c655      r3285     -1
    c655      r3286     1
    c655      r4721     0.0256
    c656      Obj       -12.27
    c656      r253      1
    c656      r3286     -1
    c656      r3287     1
    c656      r4658     0.0256
    c657      Obj       -0.01
    c657      r3291     -1
    c657      r3309     1
    c657      r4942     6.103515625e-05
    c657      r4998     6.103515625e-05
    c657      r5094     6.103515625e-05
    c657      r5649     0.03125
    c657      r6730     0.0256
    c657      r6925     0.0001
    c658      Obj       -0.03
    c658      r255      1
    c658      r3293     -1
    c658      r3310     1
    c659      Obj       -0.05
    c659      r256      1
    c659      r3295     1
    c659      r3312     -1
    c659      r4738     6.103515625e-05
    c660      Obj       -0.05
    c660      r258      1
    c660      r3294     -1
    c660      r3313     1
    c660      r4559     0.03125
    c660      r5329     6.103515625e-05
    c660      r5566     6.103515625e-05
    c660      r6557     6.103515625e-05
    c660      r6561     6.103515625e-05
    c660      r6763     6.103515625e-05
    c660      r6851     6.103515625e-05
    c660      r7022     8.9986253671094e-05
    c661      Obj       -4.255
    c661      r261      1
    c661      r3315     1
    c661      r3316     -1
    c661      r4473     6.103515625e-05
    c662      Obj       -37.21
    c662      r3318     -1
    c662      r3319     1
    c662      r4408     0.03125
    c662      r4868     0.0001
    c663      Obj       -0.01
    c663      r3309     -1
    c663      r3747     1
    c663      r6728     0.0256
    c663      r6924     0.0001
    c664      Obj       -0.001
    c664      r265      1
    c664      r3355     1
    c664      r3356     -1
    c664      r4356     0.03125
    c665      Obj       -0.001
    c665      r3392     -1
    c665      r3396     1
    c666      Obj       -0.001
    c666      r267      1
    c666      r3394     -1
    c666      r3396     1
    c666      r5053     0.03125
    c667      Obj       -0.001
    c667      r268      1
    c667      r3393     1
    c667      r3397     -1
    c667      r4467     0.0001
    c667      r4741     6.103515625e-05
    c668      Obj       -0.011
    c668      r269      1
    c668      r3400     1
    c668      r3401     -1
    c668      r4523     0.03125
    c669      Obj       -78.621
    c669      r270      1
    c669      r3402     -1
    c669      r4231     1
    c669      r6174     0.0001
    c669      r6440     7.39420869012365e-05
    c669      r6493     7.83571103003273e-05
    c670      Obj       -11.796
    c670      r3450     1
    c670      r3459     -1
    c670      r4903     6.103515625e-05
    c670      r4968     -0.015625
    c670      r4970     -0.015625
    c671      Obj       -10.09
    c671      r272      1
    c671      r3447     -1
    c671      r3449     1
    c671      r5046     0.03125
    c672      Obj       -20.205
    c672      r3448     1
    c672      r3449     -1
    c673      Obj       -14.014
    c673      r274      1
    c673      r4020     -1
    c673      r4026     1
    c674      Obj       -8.743
    c674      r275      1
    c674      r4025     -1
    c674      r4263     1
    c675      Obj       -4.37
    c675      r276      1
    c675      r3408     1
    c675      r3488     -1
    c676      Obj       -9.736
    c676      r277      1
    c676      r3407     1
    c676      r3408     -1
    c677      Obj       -0.001
    c677      r278      1
    c677      r3395     -1
    c677      r3411     1
    c677      r4431     0.03125
    c677      r4995     6.103515625e-05
    c678      Obj       -0.001
    c678      r280      1
    c678      r3398     1
    c678      r3763     -1
    c678      r4590     6.103515625e-05
    c679      Obj       -5.871
    c679      r281      1
    c679      r3392     1
    c679      r3409     -1
    c679      r4887     0.03125
    c679      r5053     0.03125
    c680      Obj       -17.858
    c680      r282      1
    c680      r3391     -1
    c680      r3410     1
    c680      r4741     6.103515625e-05
    c680      r4959     0.03125
    c680      r6720     6.103515625e-05
    c680      r6768     0.0513
    c680      r7084     0.0256
    c681      Obj       -0.001
    c681      r283      1
    c681      r3412     -1
    c681      r3764     1
    c681      r4794     0.03125
    c681      r5011     6.103515625e-05
    c682      Obj       -85
    c682      r284      1
    c682      r3764     1
    c682      r4148     -1
    c682      r4756     0.0128
    c682      r4917     6.103515625e-05
    c682      r5017     6.103515625e-05
    c682      r5086     0.0128
    c682      r5119     0.03125
    c682      r5239     0.0001220703125
    c682      r5240     6.103515625e-05
    c682      r5325     0.0009765625
    c682      r5449     6.103515625e-05
    c682      r6488     0.0009765625
    c682      r6960     0.0128
    c682      r7035     6.72799219169098e-05
    c683      Obj       -0.001
    c683      r285      1
    c683      r3413     -1
    c683      r3415     1
    c683      r4794     0.03125
    c683      r5011     6.103515625e-05
    c683      r5017     6.103515625e-05
    c684      Obj       -0.001
    c684      r287      1
    c684      r3414     1
    c684      r3416     -1
    c684      r4809     6.103515625e-05
    c684      r5017     6.103515625e-05
    c685      Obj       -0.05
    c685      r3403     1
    c685      r3420     -1
    c685      r4443     0.0016
    c685      r5144     0.0016
    c685      r5265     0.0512
    c685      r5898     0.0001
    c685      r6444     5.45780865745681e-05
    c685      r6675     6.103515625e-05
    c685      r7059     6.16585468489889e-05
    c686      Obj       -29.795
    c686      r3417     -1
    c686      r3419     1
    c687      Obj       -20.205
    c687      r3417     1
    c687      r3418     -1
    c687      r6444     5.45780865745681e-05
    c688      Obj       -10.125
    c688      r3419     -1
    c688      r3420     1
    c688      r5041     0.03125
    c688      r5898     -0.0001
    c688      r6444     -5.45780865745681e-05
    c688      r7059     -6.16585468489889e-05
    c689      Obj       -0.001
    c689      r292      1
    c689      r3421     1
    c689      r4054     -1
    c689      r5294     6.103515625e-05
    c689      r6807     5.7205257543362e-05
    c689      r7027     6.103515625e-05
    c690      Obj       -0.001
    c690      r3422     -1
    c690      r4053     1
    c690      r6360     6.103515625e-05
    c691      Obj       -0.019
    c691      r295      1
    c691      r3381     1
    c691      r3791     -1
    c691      r5478     6.103515625e-05
    c691      r5808     6.07820559700624e-05
    c692      Obj       -10.615
    c692      r4116     1
    c692      r4267     -1
    c692      r5562     0.0001
    c693      Obj       -17.30686
    c693      r298      1
    c693      r3431     1
    c693      r3432     -1
    c693      r4424     0.03125
    c694      Obj       -17.26719
    c694      r301      1
    c694      r3433     1
    c694      r3434     -1
    c695      Obj       -0.029
    c695      r3435     1
    c695      r3436     -1
    c695      r6485     8.85484805643365e-05
    c695      r6625     0.0001220703125
    c696      Obj       -0.252
    c696      r303      1
    c696      r3435     1
    c696      r4029     -1
    c696      r6625     0.0001220703125
    c697      Obj       -0.009
    c697      r304      1
    c697      r4152     -1
    c697      r4233     1
    c697      r4514     0.0256
    c697      r5015     0.0001
    c697      r6093     8.41503477570771e-05
    c697      r6494     6.103515625e-05
    c697      r6676     0.0001
    c697      r6748     6.09795321548659e-05
    c698      Obj       -2.55
    c698      r305      1
    c698      r3438     1
    c698      r4234     -1
    c698      r4497     6.103515625e-05
    c698      r4992     6.103515625e-05
    c699      Obj       -2.55
    c699      r307      1
    c699      r3439     1
    c699      r4234     -1
    c700      Obj       -8.403
    c700      r309      1
    c700      r3440     -1
    c700      r4235     1
    c700      r4644     6.103515625e-05
    c700      r5093     6.103515625e-05
    c700      r5462     0.0016
    c701      Obj       -8.403
    c701      r310      1
    c701      r3441     -1
    c701      r3442     1
    c701      r5093     6.103515625e-05
    c701      r5385     6.103515625e-05
    c701      r5473     5.84042810005303e-05
    c702      Obj       -5.7
    c702      r3442     -1
    c702      r3465     1
    c702      r5169     6.103515625e-05
    c703      Obj       -7.864
    c703      r313      1
    c703      r3447     1
    c703      r3450     -1
    c703      r4563     0.03125
    c703      r4935     0.03125
    c703      r5292     0.03125
    c703      r6903     6.103515625e-05
    c704      Obj       -29.795
    c704      r3448     -1
    c704      r3458     1
    c704      r4670     0.03125
    c704      r5150     -6.103515625e-05
    c704      r5206     -0.015625
    c704      r5898     -0.0001
    c704      r6444     -5.45780865745681e-05
    c705      Obj       -18.21
    c705      r3451     -1
    c705      r3459     1
    c705      r4873     6.103515625e-05
    c705      r4968     0.015625
    c706      Obj       -9.382
    c706      r3451     1
    c706      r3460     -1
    c706      r4945     6.103515625e-05
    c706      r6818     6.103515625e-05
    c707      Obj       -16.791
    c707      r3452     -1
    c707      r3460     1
    c707      r4970     0.015625
    c707      r5113     6.103515625e-05
    c707      r6982     6.103515625e-05
    c708      Obj       -9.345
    c708      r3452     1
    c708      r3462     -1
    c708      r5110     6.103515625e-05
    c709      Obj       -7.973
    c709      r3453     1
    c709      r3461     -1
    c709      r5750     6.103515625e-05
    c709      r6091     6.103515625e-05
    c709      r6345     6.103515625e-05
    c709      r6350     6.103515625e-05
    c709      r6509     0.0001220703125
    c709      r6514     0.0001220703125
    c709      r6517     0.0001220703125
    c709      r6521     0.0001220703125
    c709      r6739     0.0001220703125
    c709      r6750     0.000116701433279395
    c709      r6779     0.0001220703125
    c709      r6807     5.7205257543362e-05
    c709      r6994     0.0001220703125
    c710      Obj       -10.824
    c710      r3453     -1
    c710      r3462     1
    c710      r6356     6.103515625e-05
    c710      r6496     0.000118024909199262
    c710      r6521     0.0001220703125
    c710      r6596     6.103515625e-05
    c710      r6747     0.0001220703125
    c710      r6773     0.0001220703125
    c710      r6808     6.103515625e-05
    c710      r6967     0.000177260411490202
    c710      r6977     6.103515625e-05
    c710      r6980     6.103515625e-05
    c710      r6982     6.103515625e-05
    c711      Obj       -5.636
    c711      r3454     1
    c711      r3455     -1
    c711      r4925     6.103515625e-05
    c711      r5055     0.00390625
    c712      Obj       -1.069
    c712      r322      1
    c712      r3454     -1
    c712      r4197     1
    c713      Obj       -65.422
    c713      r323      1
    c713      r3455     1
    c713      r3456     -1
    c713      r5022     6.103515625e-05
    c713      r5320     6.103515625e-05
    c713      r5408     6.103515625e-05
    c713      r5480     0.0001
    c713      r6878     9.00885318019727e-05
    c713      r7072     5.97309430545916e-05
    c714      Obj       -7.563
    c714      r3456     1
    c714      r4232     -1
    c714      r4927     0.0001
    c714      r4928     0.0001
    c714      r5314     6.103515625e-05
    c714      r5808     6.07820559700624e-05
    c714      r6140     6.103515625e-05
    c714      r6174     0.0001
    c714      r6263     0.000106825841804308
    c714      r6357     7.89594079600832e-05
    c714      r6440     7.39420869012365e-05
    c714      r6493     7.83571103003273e-05
    c714      r6847     0.0001
    c714      r6878     9.00885318019727e-05
    c714      r6904     0.0001
    c714      r7039     6.43432485566951e-05
    c714      r7048     0.000105419978435289
    c715      Obj       -8.306
    c715      r325      1
    c715      r3457     -1
    c715      r4196     1
    c715      r5019     6.103515625e-05
    c716      Obj       -3.604
    c716      r327      1
    c716      r3457     1
    c716      r3464     -1
    c716      r4822     6.103515625e-05
    c716      r4926     6.103515625e-05
    c716      r5135     0.001953125
    c717      Obj       -15.234
    c717      r3466     -1
    c717      r3467     1
    c717      r5023     6.103515625e-05
    c717      r5177     6.103515625e-05
    c717      r5546     6.4794297397813e-05
    c717      r5642     5.30794884282887e-05
    c718      Obj       -16.302
    c718      r330      1
    c718      r3468     -1
    c718      r3469     1
    c718      r5980     0.0001
    c718      r6368     0.03125
    c719      Obj       -16.302
    c719      r331      1
    c719      r3470     -1
    c719      r3471     1
    c719      r4537     0.0256
    c719      r4832     0.0001
    c719      r5980     0.0001
    c719      r6407     6.103515625e-05
    c719      r6648     0.0256
    c719      r6676     0.0001
    c719      r6712     0.03125
    c720      Obj       -15.234
    c720      r333      1
    c720      r3472     -1
    c720      r3473     1
    c720      r4834     0.0001
    c720      r5023     6.103515625e-05
    c720      r5177     6.103515625e-05
    c720      r5546     6.4794297397813e-05
    c720      r5642     5.30794884282887e-05
    c721      Obj       -1.011
    c721      r335      1
    c721      r3475     1
    c721      r3910     -1
    c721      r6065     6.103515625e-05
    c721      r6437     6.103515625e-05
    c721      r6480     0.000137578107740377
    c721      r6532     6.103515625e-05
    c721      r6664     7.36196352139833e-05
    c721      r6675     6.103515625e-05
    c721      r6736     6.103515625e-05
    c721      r6848     5.45780865745698e-05
    c721      r6883     6.103515625e-05
    c722      Obj       -10.21
    c722      r3475     -1
    c722      r4259     1
    c722      r5175     0.0001
    c722      r5558     0.0001
    c723      Obj       -10.559
    c723      r337      1
    c723      r3477     -1
    c723      r3633     1
    c723      r4380     0.03125
    c723      r4545     0.03125
    c724      Obj       -4.698
    c724      r3601     1
    c724      r4236     -1
    c724      r4549     0.03125
    c724      r7081     -0.0001
    c725      Obj       -2
    c725      r341      1
    c725      r3479     -1
    c725      r3480     1
    c725      r4419     0.03125
    c726      Obj       -2.351
    c726      r342      1
    c726      r3480     1
    c726      r3736     -1
    c726      r4419     0.03125
    c726      r4470     6.103515625e-05
    c726      r5155     6.103515625e-05
    c727      Obj       -1.32
    c727      r4237     1
    c727      r4244     -1
    c727      r5871     0.0001
    c727      r6971     -0.0256
    c728      Obj       -0.003
    c728      r3482     1
    c728      r3525     -1
    c729      Obj       -0.018
    c729      r345      1
    c729      r3483     1
    c729      r3732     -1
    c730      Obj       -0.081
    c730      r3483     1
    c730      r3512     -1
    c731      Obj       -8.731
    c731      r347      1
    c731      r3488     1
    c731      r3694     -1
    c732      Obj       -21.069
    c732      r3670     -1
    c732      r3671     1
    c732      r5104     6.103515625e-05
    c733      Obj       -0.001
    c733      r349      1
    c733      r3494     1
    c733      r3772     -1
    c733      r5338     0.03125
    c733      r6492     6.103515625e-05
    c733      r6835     0.0001
    c734      Obj       -3.058
    c734      r350      1
    c734      r3495     1
    c734      r4026     -1
    c735      Obj       -8.042
    c735      r3495     -1
    c735      r4238     1
    c736      Obj       -12.27
    c736      r3684     -1
    c736      r3685     1
    c736      r5081     0.0256
    c737      Obj       -0.681
    c737      r3508     1
    c737      r3513     -1
    c738      Obj       -0.012
    c738      r3508     -1
    c738      r3509     1
    c739      Obj       -0.032
    c739      r3509     -1
    c739      r3510     1
    c740      Obj       -0.027
    c740      r3511     -1
    c740      r3512     1
    c741      Obj       -0.045
    c741      r3510     -1
    c741      r3511     1
    c742      Obj       -0.045
    c742      r3513     1
    c742      r3519     -1
    c743      Obj       -0.004
    c743      r3516     -1
    c743      r3517     1
    c744      Obj       -0.01
    c744      r360      1
    c744      r3514     -1
    c744      r3515     1
    c744      r4341     0.03125
    c745      Obj       -0.011
    c745      r361      1
    c745      r3516     1
    c745      r4240     -1
    c746      Obj       -0.013
    c746      r3517     -1
    c746      r3518     1
    c747      Obj       -0.02
    c747      r3518     -1
    c747      r3519     1
    c748      Obj       -1.067
    c748      r365      1
    c748      r3522     -1
    c748      r3526     1
    c749      Obj       -4.496
    c749      r366      1
    c749      r3520     1
    c749      r3533     -1
    c749      r6842     6.103515625e-05
    c750      Obj       -0.037
    c750      r3520     -1
    c750      r3535     1
    c750      r4680     0.03125
    c751      Obj       -0.657
    c751      r368      1
    c751      r3534     -1
    c751      r3535     1
    c751      r4680     0.03125
    c752      Obj       -0.072
    c752      r369      1
    c752      r3521     1
    c752      r3522     -1
    c753      Obj       -0.964
    c753      r370      1
    c753      r3521     -1
    c753      r3523     1
    c754      Obj       -0.002
    c754      r371      1
    c754      r3523     1
    c754      r3526     -1
    c755      Obj       -3.45
    c755      r3524     -1
    c755      r3525     1
    c756      Obj       -0.105
    c756      r3523     -1
    c756      r3524     1
    c756      r6921     6.103515625e-05
    c756      r7067     6.103515625e-05
    c757      Obj       -0.025
    c757      r3482     -1
    c757      r3733     1
    c758      Obj       -0.088
    c758      r3527     1
    c758      r3528     -1
    c759      Obj       -0.623
    c759      r3527     -1
    c759      r3542     1
    c760      Obj       -0.02
    c760      r3528     1
    c760      r3541     -1
    c761      Obj       -6.043
    c761      r3529     1
    c761      r3532     -1
    c762      Obj       -0.167
    c762      r3529     -1
    c762      r3530     1
    c763      Obj       -0.02
    c763      r3530     -1
    c763      r3533     1
    c763      r6821     6.103515625e-05
    c763      r7011     6.103515625e-05
    c764      Obj       -0.006
    c764      r3531     1
    c764      r3544     -1
    c765      Obj       -0.194
    c765      r3531     -1
    c765      r3532     1
    c766      Obj       -3.128
    c766      r383      1
    c766      r3533     -1
    c766      r3534     1
    c767      Obj       -0.02
    c767      r3536     1
    c767      r3734     -1
    c767      r4456     0.0625
    c768      Obj       -0.139
    c768      r3537     -1
    c768      r3538     1
    c769      Obj       -0.419
    c769      r3536     -1
    c769      r3537     1
    c770      Obj       -0.333
    c770      r3538     -1
    c770      r3539     1
    c771      Obj       -0.469
    c771      r3539     -1
    c771      r3540     1
    c772      Obj       -7.147
    c772      r3540     -1
    c772      r3541     1
    c773      Obj       -0.109
    c773      r3542     -1
    c773      r3543     1
    c774      Obj       -0.706
    c774      r3543     -1
    c774      r3544     1
    c775      Obj       -0.166
    c775      r392      1
    c775      r3545     -1
    c775      r3546     1
    c776      Obj       -2.187
    c776      r3597     -1
    c776      r3598     1
    c777      Obj       -0.103
    c777      r394      1
    c777      r3549     -1
    c777      r3550     1
    c778      Obj       -0.143
    c778      r3548     1
    c778      r3738     -1
    c778      r4552     0.03125
    c778      r4649     0.0002
    c779      Obj       -0.087
    c779      r3547     -1
    c779      r3548     1
    c779      r4552     0.03125
    c779      r4649     0.0002
    c779      r4657     -0.03125
    c780      Obj       -0.221
    c780      r397      1
    c780      r3546     -1
    c780      r3547     1
    c780      r4636     0.0001
    c780      r4649     0.0001
    c780      r4657     0.03125
    c781      Obj       -1.16
    c781      r398      1
    c781      r3548     -1
    c781      r3549     1
    c781      r5293     0.0001
    c782      Obj       -0.533
    c782      r399      1
    c782      r3550     -1
    c782      r3551     1
    c783      Obj       -0.85
    c783      r400      1
    c783      r3551     -1
    c783      r3552     1
    c784      Obj       -1.116
    c784      r401      1
    c784      r3552     -1
    c784      r3553     1
    c784      r5352     6.103515625e-05
    c784      r5450     6.103515625e-05
    c785      Obj       -0.069
    c785      r3553     1
    c785      r3737     -1
    c785      r4594     0.03125
    c786      Obj       -0.358
    c786      r403      1
    c786      r3554     1
    c786      r3739     -1
    c786      r4550     0.03125
    c786      r4637     6.103515625e-05
    c787      Obj       -0.209
    c787      r3554     1
    c787      r3555     -1
    c787      r4550     0.03125
    c787      r4743     -0.03125
    c788      Obj       -0.076
    c788      r405      1
    c788      r3555     -1
    c788      r3556     1
    c788      r4656     0.03125
    c789      Obj       -0.474
    c789      r406      1
    c789      r3556     -1
    c789      r3557     1
    c790      Obj       -1.556
    c790      r407      1
    c790      r3557     -1
    c790      r3558     1
    c791      Obj       -0.005
    c791      r408      1
    c791      r3558     -1
    c791      r3735     1
    c791      r5450     6.103515625e-05
    c792      Obj       -0.189
    c792      r3647     -1
    c792      r3648     1
    c792      r4893     0.03125
    c792      r6516     6.103515625e-05
    c792      r6593     6.103515625e-05
    c792      r6652     -0.03125
    c792      r6877     6.103515625e-05
    c792      r7021     0.0001
    c793      Obj       -1.214
    c793      r411      1
    c793      r3579     -1
    c793      r3580     1
    c794      Obj       -0.098
    c794      r412      1
    c794      r3559     1
    c794      r3560     -1
    c795      Obj       -0.043
    c795      r3560     -1
    c795      r3566     1
    c796      Obj       -0.307
    c796      r414      1
    c796      r3560     1
    c796      r3565     -1
    c796      r4553     0.03125
    c796      r4997     6.103515625e-05
    c796      r5345     0.03125
    c796      r6409     6.103515625e-05
    c796      r6483     6.103515625e-05
    c797      Obj       -0.819
    c797      r415      1
    c797      r3581     -1
    c797      r3582     1
    c798      Obj       -0.291
    c798      r416      1
    c798      r3561     1
    c798      r3583     -1
    c799      Obj       -0.396
    c799      r417      1
    c799      r3561     -1
    c799      r3584     1
    c800      Obj       -0.062
    c800      r418      1
    c800      r3562     -1
    c800      r3588     1
    c801      Obj       -1.041
    c801      r419      1
    c801      r3562     1
    c801      r3587     -1
    c802      Obj       -0.692
    c802      r420      1
    c802      r3563     -1
    c802      r3564     1
    c803      Obj       -0.183
    c803      r421      1
    c803      r3563     1
    c803      r3588     -1
    c804      Obj       -1.948
    c804      r422      1
    c804      r3564     -1
    c804      r3565     1
    c804      r5601     6.103515625e-05
    c805      Obj       -0.007
    c805      r423      1
    c805      r3574     -1
    c805      r3575     1
    c806      Obj       -0.047
    c806      r424      1
    c806      r3573     -1
    c806      r3575     1
    c807      Obj       -0.192
    c807      r425      1
    c807      r3567     1
    c807      r4242     -1
    c807      r6949     0.03125
    c807      r6966     6.103515625e-05
    c808      Obj       -0.024
    c808      r426      1
    c808      r3566     -1
    c808      r3740     1
    c809      Obj       -0.75
    c809      r427      1
    c809      r3567     -1
    c809      r3568     1
    c810      Obj       -0.009
    c810      r428      1
    c810      r3568     -1
    c810      r3569     1
    c811      Obj       -1.229
    c811      r429      1
    c811      r3569     -1
    c811      r3570     1
    c812      Obj       -0.092
    c812      r430      1
    c812      r3570     -1
    c812      r3571     1
    c813      Obj       -0.631
    c813      r431      1
    c813      r3571     -1
    c813      r4241     1
    c814      Obj       -0.177
    c814      r432      1
    c814      r3572     1
    c814      r4241     -1
    c815      Obj       -0.045
    c815      r433      1
    c815      r3572     -1
    c815      r3573     1
    c816      Obj       -0.026
    c816      r434      1
    c816      r3744     -1
    c816      r4242     1
    c816      r6394     6.103515625e-05
    c816      r6395     6.103515625e-05
    c817      Obj       -0.014
    c817      r435      1
    c817      r3574     -1
    c817      r3576     1
    c817      r4300     0.03125
    c817      r4415     0.03125
    c818      Obj       -0.009
    c818      r436      1
    c818      r3575     -1
    c818      r3576     1
    c818      r4415     0.03125
    c819      Obj       -0.089
    c819      r437      1
    c819      r3576     -1
    c819      r3577     1
    c819      r7082     6.103515625e-05
    c820      Obj       -0.088
    c820      r438      1
    c820      r3577     -1
    c820      r3578     1
    c821      Obj       -0.075
    c821      r439      1
    c821      r3578     -1
    c821      r3579     1
    c822      Obj       -0.122
    c822      r440      1
    c822      r3580     -1
    c822      r3581     1
    c823      Obj       -0.369
    c823      r441      1
    c823      r3582     -1
    c823      r3583     1
    c824      Obj       -0.672
    c824      r442      1
    c824      r3584     -1
    c824      r3585     1
    c825      Obj       -0.543
    c825      r443      1
    c825      r3585     -1
    c825      r3586     1
    c826      Obj       -0.28
    c826      r444      1
    c826      r3586     -1
    c826      r3587     1
    c827      Obj       -0.019
    c827      r3476     -1
    c827      r3589     1
    c827      r4395     0.03125
    c827      r5694     0.0001220703125
    c827      r6970     0.0002
    c828      Obj       -0.096
    c828      r446      1
    c828      r3590     -1
    c828      r3591     1
    c828      r4305     0.0256
    c829      Obj       -0.134
    c829      r447      1
    c829      r3591     -1
    c829      r3592     1
    c829      r4709     0.0256
    c830      Obj       -2.62
    c830      r448      1
    c830      r3594     1
    c830      r3595     -1
    c831      Obj       -5.166
    c831      r449      1
    c831      r3479     1
    c831      r3594     -1
    c832      Obj       -0.285
    c832      r3400     -1
    c832      r3595     1
    c832      r4880     0.03125
    c832      r6472     0.0625
    c833      Obj       -1.015
    c833      r3480     -1
    c833      r4243     1
    c834      Obj       -1.014
    c834      r3596     1
    c834      r4243     -1
    c834      r4412     0.03125
    c834      r5293     0.0002
    c834      r5450     0.0001220703125
    c835      Obj       -0.026
    c835      r3596     1
    c835      r4251     -1
    c835      r4412     0.03125
    c835      r5293     0.0002
    c835      r6284     0.03125
    c836      Obj       -0.23
    c836      r3596     -1
    c836      r3597     1
    c836      r6970     0.0001
    c837      Obj       -1.472
    c837      r3598     -1
    c837      r3599     1
    c837      r5421     0.0256
    c837      r5677     6.103515625e-05
    c837      r6769     0.0256
    c837      r7084     0.0256
    c838      Obj       -2.024
    c838      r3599     -1
    c838      r4244     1
    c838      r5153     6.103515625e-05
    c838      r5154     6.103515625e-05
    c838      r6120     6.103515625e-05
    c838      r6392     6.103515625e-05
    c838      r6951     0.0256
    c838      r6971     0.0256
    c838      r7081     0.0001
    c839      Obj       -1.32
    c839      r3600     1
    c839      r4237     -1
    c840      Obj       -1.116
    c840      r3600     -1
    c840      r4236     1
    c840      r6519     0.0001
    c841      Obj       -0.075
    c841      r3601     -1
    c841      r3602     1
    c842      Obj       -0.141
    c842      r461      1
    c842      r3602     -1
    c842      r3603     1
    c842      r4638     6.103515625e-05
    c843      Obj       -0.008
    c843      r462      1
    c843      r3603     -1
    c843      r3604     1
    c843      r4547     0.03125
    c844      Obj       -0.085
    c844      r3604     -1
    c844      r3605     1
    c845      Obj       -1.873
    c845      r3605     -1
    c845      r3606     1
    c845      r5277     0.0256
    c845      r5664     0.0256
    c845      r5744     0.0256
    c845      r5831     -0.0256
    c845      r5972     0.0256
    c845      r6028     0.0256
    c845      r6392     -6.103515625e-05
    c845      r6519     -0.0001
    c845      r6951     -0.0256
    c845      r7081     -0.0001
    c846      Obj       -2.468
    c846      r3606     -1
    c846      r3607     1
    c846      r5676     6.103515625e-05
    c846      r5831     0.0256
    c847      Obj       -2.406
    c847      r3607     -1
    c847      r3610     1
    c848      Obj       -0.296
    c848      r468      1
    c848      r3612     1
    c848      r3615     -1
    c849      Obj       -0.015
    c849      r3608     1
    c849      r3741     -1
    c849      r5345     0.03125
    c849      r6409     6.103515625e-05
    c850      Obj       -0.063
    c850      r3608     -1
    c850      r3609     1
    c850      r5002     6.103515625e-05
    c850      r5345     -0.03125
    c850      r6409     -6.103515625e-05
    c851      Obj       -0.022
    c851      r3609     -1
    c851      r3611     1
    c851      r4546     0.03125
    c851      r4748     -0.03125
    c852      Obj       -1.03
    c852      r3610     -1
    c852      r3614     1
    c852      r4546     0.03125
    c852      r5694     6.103515625e-05
    c853      Obj       -0.476
    c853      r474      1
    c853      r3611     -1
    c853      r3614     1
    c854      Obj       -0.221
    c854      r3612     -1
    c854      r3616     1
    c854      r5848     0.03125
    c855      Obj       -1.012
    c855      r476      1
    c855      r3613     1
    c855      r3617     -1
    c856      Obj       -5.453
    c856      r477      1
    c856      r3613     -1
    c856      r3742     1
    c857      Obj       -0.01
    c857      r3614     -1
    c857      r3615     1
    c857      r4392     0.03125
    c857      r6483     6.103515625e-05
    c858      Obj       -1.366
    c858      r479      1
    c858      r3616     -1
    c858      r3617     1
    c859      Obj       -0.128
    c859      r480      1
    c859      r3618     1
    c859      r3666     -1
    c859      r4321     0.0256
    c860      Obj       -3.365
    c860      r481      1
    c860      r3638     -1
    c860      r3658     1
    c860      r4778     6.103515625e-05
    c861      Obj       -0.052
    c861      r482      1
    c861      r3619     -1
    c861      r3620     1
    c861      r4343     0.0256
    c862      Obj       -0.104
    c862      r483      1
    c862      r3621     -1
    c862      r3622     1
    c862      r4351     0.0256
    c863      Obj       -0.118
    c863      r484      1
    c863      r3623     -1
    c863      r3624     1
    c863      r4344     0.03125
    c864      Obj       -0.005
    c864      r485      1
    c864      r3658     -1
    c864      r3659     1
    c864      r6879     6.103515625e-05
    c865      Obj       -0.008
    c865      r3625     -1
    c865      r3660     1
    c866      Obj       -1.606
    c866      r3659     -1
    c866      r3660     1
    c867      Obj       -0.133
    c867      r488      1
    c867      r3626     -1
    c867      r3627     1
    c868      Obj       -0.118
    c868      r489      1
    c868      r3628     -1
    c868      r3629     1
    c869      Obj       -0.086
    c869      r490      1
    c869      r3630     -1
    c869      r3631     1
    c870      Obj       -0.037
    c870      r3632     -1
    c870      r3745     1
    c871      Obj       -3.35
    c871      r3632     1
    c871      r3644     -1
    c871      r5117     -0.03125
    c872      Obj       -0.061
    c872      r493      1
    c872      r3633     -1
    c872      r3634     1
    c873      Obj       -1.597
    c873      r496      1
    c873      r3634     -1
    c873      r3635     1
    c873      r4540     0.03125
    c874      Obj       -0.111
    c874      r497      1
    c874      r3635     -1
    c874      r3636     1
    c875      Obj       -5.195
    c875      r500      1
    c875      r3636     -1
    c875      r3637     1
    c875      r4555     0.03125
    c875      r4981     0.03125
    c876      Obj       -0.112
    c876      r501      1
    c876      r3637     -1
    c876      r3638     1
    c877      Obj       -1.112
    c877      r3639     1
    c877      r4252     -1
    c877      r4672     0.0256
    c877      r5951     6.103515625e-05
    c877      r5952     6.103515625e-05
    c877      r6047     6.103515625e-05
    c877      r6099     0.03125
    c877      r6395     6.103515625e-05
    c878      Obj       -0.086
    c878      r504      1
    c878      r3639     -1
    c878      r3640     1
    c878      r4425     0.03125
    c878      r6965     0.0625
    c878      r6966     6.103515625e-05
    c879      Obj       -1.532
    c879      r3640     -1
    c879      r3641     1
    c879      r5353     6.103515625e-05
    c879      r5354     6.103515625e-05
    c879      r5357     6.103515625e-05
    c879      r5821     0.03125
    c879      r6099     -0.03125
    c879      r6394     6.103515625e-05
    c880      Obj       -0.123
    c880      r3641     -1
    c880      r3642     1
    c880      r5821     -0.03125
    c881      Obj       -0.348
    c881      r3642     -1
    c881      r3643     1
    c881      r5117     0.03125
    c882      Obj       -0.027
    c882      r3643     -1
    c882      r3644     1
    c883      Obj       -0.049
    c883      r510      1
    c883      r3645     1
    c883      r3746     -1
    c883      r4608     0.03125
    c884      Obj       -0.018
    c884      r3645     -1
    c884      r3653     1
    c884      r5123     0.03125
    c884      r6404     0.0078125
    c885      Obj       -0.064
    c885      r3652     -1
    c885      r3653     1
    c885      r4713     0.03125
    c886      Obj       -0.025
    c886      r513      1
    c886      r3646     -1
    c886      r3651     1
    c886      r4290     0.0256
    c886      r4359     0.03125
    c886      r6746     6.103515625e-05
    c886      r6877     6.103515625e-05
    c886      r6969     0.00390625
    c886      r7021     0.0001
    c887      Obj       -2.509
    c887      r514      1
    c887      r3650     -1
    c887      r3651     1
    c887      r4359     0.03125
    c887      r5600     6.103515625e-05
    c887      r6361     6.103515625e-05
    c887      r6404     0.0078125
    c887      r6767     0.03125
    c887      r6770     0.001953125
    c887      r6772     6.103515625e-05
    c887      r6775     6.103515625e-05
    c887      r6776     6.103515625e-05
    c887      r6969     0.00390625
    c888      Obj       -0.249
    c888      r3648     -1
    c888      r3649     1
    c888      r6391     6.103515625e-05
    c888      r6454     0.00398870124598239
    c888      r6516     6.103515625e-05
    c888      r6520     6.103515625e-05
    c888      r6566     0.03125
    c888      r6577     0.001953125
    c888      r6593     6.103515625e-05
    c888      r6652     0.03125
    c888      r6767     -0.03125
    c888      r6775     -6.103515625e-05
    c889      Obj       -0.128
    c889      r516      1
    c889      r3649     -1
    c889      r3650     1
    c889      r4609     0.03125
    c889      r6647     0.03125
    c889      r6659     6.103515625e-05
    c889      r6663     6.103515625e-05
    c889      r6668     8.13802083333333e-05
    c889      r6708     0.03125
    c889      r6718     6.103515625e-05
    c889      r6719     6.103515625e-05
    c890      Obj       -5.76
    c890      r3651     -1
    c890      r3652     1
    c890      r4608     0.03125
    c890      r4672     0.0256
    c890      r5123     0.03125
    c890      r6693     6.103515625e-05
    c890      r7047     6.103515625e-05
    c891      Obj       -1.9
    c891      r519      1
    c891      r3653     -1
    c891      r3654     1
    c891      r4672     0.0256
    c891      r7069     6.103515625e-05
    c892      Obj       -1.638
    c892      r520      1
    c892      r3654     -1
    c892      r3655     1
    c892      r4790     0.03125
    c893      Obj       -6.686
    c893      r521      1
    c893      r3655     -1
    c893      r3656     1
    c894      Obj       -1.409
    c894      r522      1
    c894      r3656     -1
    c894      r3657     1
    c895      Obj       -2.527
    c895      r523      1
    c895      r3657     -1
    c895      r3662     1
    c895      r4421     0.03125
    c895      r5662     0.0256
    c895      r6722     0.0625
    c895      r6778     0.25
    c895      r6879     0.0001220703125
    c896      Obj       -0.058
    c896      r3662     1
    c896      r3743     -1
    c896      r4421     0.03125
    c896      r4641     0.0001
    c896      r5662     0.0256
    c896      r6879     0.0001220703125
    c897      Obj       -0.418
    c897      r525      1
    c897      r3661     -1
    c897      r3664     1
    c897      r4801     6.103515625e-05
    c897      r4882     0.03125
    c898      Obj       -0.255
    c898      r3660     -1
    c898      r3661     1
    c898      r4791     0.03125
    c899      Obj       -0.685
    c899      r527      1
    c899      r3662     -1
    c899      r3663     1
    c899      r5584     0.000266666666666667
    c899      r5585     0.000266666666666667
    c900      Obj       -0.107
    c900      r3663     -1
    c900      r3665     1
    c901      Obj       -3.783
    c901      r3664     -1
    c901      r3665     1
    c901      r4745     0.03125
    c902      Obj       -1.82
    c902      r531      1
    c902      r3665     -1
    c902      r3666     1
    c903      Obj       -0.02
    c903      r3324     1
    c903      r3667     -1
    c903      r6500     6.103515625e-05
    c903      r6557     6.103515625e-05
    c903      r7004     8.99952522964611e-05
    c904      Obj       -0.3
    c904      r534      1
    c904      r3329     -1
    c904      r3760     1
    c904      r6780     8.95094165128909e-05
    c905      Obj       -4.426
    c905      r3686     1
    c905      r3747     -1
    c905      r6729     0.0256
    c905      r6923     0.0001
    c906      Obj       -11.367
    c906      r3685     -1
    c906      r3686     1
    c906      r6731     0.0256
    c907      Obj       -80
    c907      r537      1
    c907      r3668     -1
    c907      r3750     1
    c907      r4442     0.0078125
    c907      r4865     9.49502203723103e-05
    c908      Obj       -50
    c908      r538      1
    c908      r3668     1
    c908      r3751     -1
    c908      r4797     6.103515625e-05
    c908      r5221     6.103515625e-05
    c909      Obj       -13.5
    c909      r3669     -1
    c909      r3675     1
    c909      r6946     0.0001
    c910      Obj       -1.615
    c910      r540      1
    c910      r3674     -1
    c910      r3675     1
    c911      Obj       -17.576
    c911      r3672     -1
    c911      r4245     1
    c911      r4867     6.103515625e-05
    c912      Obj       -6.75
    c912      r3670     1
    c912      r3748     -1
    c912      r5187     6.103515625e-05
    c913      Obj       -8.605
    c913      r3671     -1
    c913      r3672     1
    c914      Obj       -16.907
    c914      r544      1
    c914      r3673     1
    c914      r4245     -1
    c915      Obj       -0.014
    c915      r545      1
    c915      r3318     1
    c915      r3673     -1
    c915      r4951     0.03125
    c916      Obj       -12.297
    c916      r546      1
    c916      r3315     -1
    c916      r3674     1
    c917      Obj       -24.896
    c917      r547      1
    c917      r3676     1
    c917      r4248     -1
    c918      Obj       -6.27
    c918      r548      1
    c918      r3676     -1
    c918      r3677     1
    c918      r4491     0.0001
    c919      Obj       -59.831
    c919      r550      1
    c919      r3677     -1
    c919      r3679     1
    c920      Obj       -13.451
    c920      r551      1
    c920      r3682     1
    c920      r3754     -1
    c921      Obj       -14.153
    c921      r552      1
    c921      r3682     -1
    c921      r3683     1
    c922      Obj       -6.475
    c922      r553      1
    c922      r3678     1
    c922      r3755     -1
    c923      Obj       -31.58
    c923      r3678     -1
    c923      r3753     1
    c923      r4442     0.0078125
    c923      r4535     0.0001
    c924      Obj       -31.08
    c924      r3753     -1
    c924      r4246     1
    c924      r6843     6.103515625e-05
    c925      Obj       -15
    c925      r4246     -1
    c925      r4247     1
    c925      r4692     0.0078125
    c926      Obj       -31
    c926      r559      1
    c926      r4247     -1
    c926      r4248     1
    c926      r6908     6.103515625e-05
    c926      r7018     6.103515625e-05
    c927      Obj       -26
    c927      r560      1
    c927      r3679     -1
    c927      r3680     1
    c928      Obj       -30
    c928      r561      1
    c928      r3680     -1
    c928      r3681     1
    c929      Obj       -8.978
    c929      r562      1
    c929      r3683     -1
    c929      r3684     1
    c930      Obj       -7.084
    c930      r563      1
    c930      r3694     1
    c930      r3762     -1
    c930      r5082     6.103515625e-05
    c930      r5221     6.103515625e-05
    c931      Obj       -10.227
    c931      r564      1
    c931      r3703     -1
    c931      r3704     1
    c931      r5643     6.103515625e-05
    c931      r5805     6.103515625e-05
    c932      Obj       -3.884
    c932      r3689     -1
    c932      r3690     1
    c933      Obj       -3.356
    c933      r566      1
    c933      r3687     1
    c933      r3749     -1
    c933      r4729     6.103515625e-05
    c934      Obj       -4.677
    c934      r567      1
    c934      r3687     -1
    c934      r3688     1
    c935      Obj       -4.195
    c935      r568      1
    c935      r3688     -1
    c935      r3689     1
    c936      Obj       -1.736
    c936      r3690     -1
    c936      r3691     1
    c937      Obj       -13.264
    c937      r3691     -1
    c937      r3697     1
    c937      r5106     0.0001
    c937      r5174     6.103515625e-05
    c937      r7014     6.103515625e-05
    c938      Obj       -0.006
    c938      r3692     1
    c938      r3731     -1
    c938      r4452     0.0159252613532467
    c938      r4453     0.015625
    c938      r4572     0.03125
    c938      r4633     0.03125
    c938      r6820     6.103515625e-05
    c939      Obj       -3.943
    c939      r3692     -1
    c939      r3701     1
    c940      Obj       -4.391
    c940      r3700     -1
    c940      r3701     1
    c941      Obj       -28.51
    c941      r574      1
    c941      r3693     1
    c941      r3695     -1
    c942      Obj       -1.667
    c942      r575      1
    c942      r3409     1
    c942      r3693     -1
    c943      Obj       -8.239
    c943      r576      1
    c943      r3695     1
    c943      r3696     -1
    c944      Obj       -18.107
    c944      r577      1
    c944      r3407     -1
    c944      r3696     1
    c945      Obj       -0.01
    c945      r3697     -1
    c945      r4249     1
    c946      Obj       -1.181
    c946      r3698     1
    c946      r3708     -1
    c946      r7033     6.103515625e-05
    c947      Obj       -1.075
    c947      r3698     -1
    c947      r3699     1
    c948      Obj       -0.349
    c948      r3699     -1
    c948      r3700     1
    c949      Obj       -1.102
    c949      r3701     -1
    c949      r3702     1
    c950      Obj       -10.596
    c950      r583      1
    c950      r3702     -1
    c950      r3703     1
    c950      r5024     6.103515625e-05
    c950      r5105     0.0001
    c950      r5180     6.103515625e-05
    c950      r5181     6.103515625e-05
    c950      r5189     6.103515625e-05
    c950      r5726     6.103515625e-05
    c950      r6850     0.0001
    c950      r7033     6.103515625e-05
    c951      Obj       -14.831
    c951      r584      1
    c951      r3704     -1
    c951      r3705     1
    c952      Obj       -14.228
    c952      r585      1
    c952      r3705     -1
    c952      r3706     1
    c953      Obj       -0.645
    c953      r586      1
    c953      r3706     -1
    c953      r3707     1
    c954      Obj       -1.913
    c954      r587      1
    c954      r3707     -1
    c954      r3761     1
    c954      r5083     6.103515625e-05
    c955      Obj       -1.7
    c955      r3708     1
    c955      r4249     -1
    c955      r5482     6.103515625e-05
    c955      r6829     6.103515625e-05
    c956      Obj       -15.061
    c956      r3709     1
    c956      r3710     -1
    c956      r4880     0.03125
    c956      r5202     0.03125
    c956      r6472     0.0625
    c956      r6673     0.03125
    c957      Obj       -1.664
    c957      r3709     -1
    c957      r3715     1
    c957      r6389     0.03125
    c958      Obj       -4.33
    c958      r3476     -1
    c958      r3710     1
    c958      r4395     0.03125
    c958      r4620     0.0256
    c958      r5202     -0.03125
    c958      r5277     0.0256
    c958      r5664     0.0256
    c958      r5694     0.0001220703125
    c958      r5744     0.0256
    c958      r5871     0.0001
    c958      r5972     0.0256
    c958      r6028     0.0256
    c958      r6768     0.0513
    c958      r6970     0.0002
    c958      r6971     0.0256
    c959      Obj       -2.187
    c959      r593      1
    c959      r3711     -1
    c959      r3724     1
    c959      r5921     0.03125
    c959      r6650     -0.03125
    c959      r6677     -6.103515625e-05
    c959      r6786     -0.03125
    c960      Obj       -0.015
    c960      r3723     -1
    c960      r3724     1
    c960      r6680     0.03125
    c960      r6685     6.103515625e-05
    c960      r6867     6.103515625e-05
    c961      Obj       -1.176
    c961      r3711     1
    c961      r3714     -1
    c961      r6880     6.103515625e-05
    c962      Obj       -6.879
    c962      r3712     1
    c962      r3715     -1
    c962      r5421     0.0256
    c962      r6769     0.0256
    c962      r7084     0.0256
    c963      Obj       -0.048
    c963      r3712     -1
    c963      r3713     1
    c963      r5921     -0.03125
    c963      r6470     6.103515625e-05
    c964      Obj       -0.057
    c964      r3713     -1
    c964      r3714     1
    c964      r6525     6.103515625e-05
    c964      r6680     0.03125
    c965      Obj       -34.954
    c965      r3410     -1
    c965      r3476     1
    c965      r4620     0.0256
    c965      r5277     0.0256
    c965      r5421     0.0256
    c965      r5664     0.0256
    c965      r5744     0.0256
    c965      r5871     0.0001
    c965      r5972     0.0256
    c965      r6028     0.0256
    c965      r6673     0.03125
    c965      r6769     0.0256
    c965      r6971     0.0256
    c966      Obj       -2.998
    c966      r600      1
    c966      r3719     -1
    c966      r3720     1
    c967      Obj       -10.898
    c967      r601      1
    c967      r3716     -1
    c967      r3717     1
    c967      r6650     0.03125
    c967      r6677     6.103515625e-05
    c967      r6678     6.103515625e-05
    c967      r6685     6.103515625e-05
    c967      r6686     6.103515625e-05
    c968      Obj       -3.599
    c968      r3716     1
    c968      r3723     -1
    c968      r6786     0.03125
    c969      Obj       -6.074
    c969      r603      1
    c969      r3717     -1
    c969      r3718     1
    c969      r6786     0.03125
    c969      r6867     6.103515625e-05
    c969      r6932     6.103515625e-05
    c969      r7034     6.103515625e-05
    c970      Obj       -1.082
    c970      r604      1
    c970      r3718     -1
    c970      r3719     1
    c971      Obj       -5.016
    c971      r605      1
    c971      r3720     -1
    c971      r4250     1
    c971      r6914     6.103515625e-05
    c972      Obj       -0.35
    c972      r606      1
    c972      r3721     1
    c972      r4250     -1
    c973      Obj       -8.084
    c973      r607      1
    c973      r3721     -1
    c973      r3722     1
    c973      r4905     6.103515625e-05
    c973      r7063     6.103515625e-05
    c974      Obj       -0.011
    c974      r3767     1
    c974      r3768     -1
    c974      r6344     -0.0001
    c975      Obj       -0.127
    c975      r3437     -1
    c975      r3767     1
    c975      r5183     6.103515625e-05
    c975      r6093     8.41503477570771e-05
    c975      r6494     0.0001220703125
    c975      r6672     0.000104347826086957
    c975      r6711     0.03125
    c975      r6748     0.000121959064309732
    c976      Obj       -0.01
    c976      r3779     -1
    c976      r3780     1
    c976      r6343     7.8502349312175e-05
    c976      r6573     -0.0625
    c976      r6962     -0.03125
    c977      Obj       -0.006
    c977      r3781     1
    c977      r3783     -1
    c978      Obj       -0.091
    c978      r614      1
    c978      r3771     1
    c978      r4256     -1
    c978      r6556     6.03358541432804e-05
    c979      Obj       -0.02
    c979      r615      1
    c979      r3785     -1
    c979      r3786     1
    c980      Obj       -0.011
    c980      r616      1
    c980      r3787     1
    c980      r3788     -1
    c980      r6162     0.0001
    c980      r6937     0.000108692704475025
    c981      Obj       -0.121
    c981      r3787     1
    c981      r4126     -1
    c981      r4448     0.0008
    c981      r4932     0.0001
    c981      r5637     0.0001
    c981      r5692     6.103515625e-05
    c981      r5693     0.0001
    c981      r5918     0.0009765625
    c981      r6558     0.0001
    c981      r6856     0.0001
    c981      r6931     6.103515625e-05
    c981      r6996     9.53971836372719e-05
    c981      r7001     6.103515625e-05
    c982      Obj       -0.114
    c982      r3789     -1
    c982      r4281     1
    c982      r5078     6.103515625e-05
    c982      r5120     0.03125
    c982      r5178     7.79684981375495e-05
    c982      r5537     6.103515625e-05
    c982      r5550     6.61530201248938e-05
    c982      r6252     6.103515625e-05
    c982      r6840     6.103515625e-05
    c982      r6892     7.79684981375495e-05
    c982      r6931     6.103515625e-05
    c983      Obj       -1.348
    c983      r3796     -1
    c983      r4281     1
    c983      r5178     7.79684981375495e-05
    c983      r5550     6.61530201248938e-05
    c984      Obj       -1.087
    c984      r3267     -1
    c984      r3793     1
    c984      r4541     0.03125
    c984      r5739     0.03125
    c984      r5979     6.103515625e-05
    c984      r6308     0.000244140625
    c984      r6411     0.0001220703125
    c984      r6441     6.103515625e-05
    c984      r6547     8.27375139400187e-05
    c984      r6632     0.000165475027880037
    c985      Obj       -1.087
    c985      r622      1
    c985      r3794     1
    c985      r3795     -1
    c985      r4311     0.0256
    c985      r6441     6.103515625e-05
    c985      r6547     8.27375139400187e-05
    c985      r6632     8.27375139400187e-05
    c986      Obj       -19.696
    c986      r625      1
    c986      r3799     1
    c986      r3839     -1
    c986      r5826     0.03125
    c986      r5836     0.00390625
    c987      Obj       -32.074
    c987      r627      1
    c987      r3798     1
    c987      r3799     -1
    c987      r4906     6.103515625e-05
    c987      r5425     0.03125
    c988      Obj       -0.162
    c988      r630      1
    c988      r3802     1
    c988      r4258     -1
    c989      Obj       -39.83384
    c989      r631      1
    c989      r3806     1
    c989      r3807     -1
    c990      Obj       -0.001
    c990      r632      1
    c990      r3263     -1
    c990      r3808     1
    c990      r4464     0.0001
    c990      r4468     6.103515625e-05
    c991      Obj       -12
    c991      r3405     1
    c991      r3809     -1
    c991      r4606     0.03125
    c991      r4931     6.103515625e-05
    c991      r5118     0.03125
    c991      r5240     6.103515625e-05
    c991      r5325     0.0009765625
    c991      r6488     0.0009765625
    c992      Obj       -0.001
    c992      r3793     -1
    c992      r3941     1
    c992      r6541     -6.103515625e-05
    c992      r6632     -8.27375139400187e-05
    c993      Obj       -2.697
    c993      r636      1
    c993      r3812     1
    c993      r3813     -1
    c993      r5688     0.0032
    c993      r6016     6.103515625e-05
    c993      r6884     6.21482532170052e-05
    c994      Obj       -4.559
    c994      r4033     -1
    c994      r4034     1
    c994      r4860     6.103515625e-05
    c995      Obj       -12.894
    c995      r640      1
    c995      r3838     -1
    c995      r4115     1
    c996      Obj       -59.339
    c996      r642      1
    c996      r3839     1
    c996      r4257     -1
    c996      r4487     6.103515625e-05
    c996      r5813     6.103515625e-05
    c996      r6189     0.03125
    c997      Obj       -59
    c997      r643      1
    c997      r3332     1
    c997      r3840     -1
    c997      r4498     6.103515625e-05
    c997      r5148     6.103515625e-05
    c997      r6489     6.103515625e-05
    c998      Obj       -0.001
    c998      r645      1
    c998      r3892     1
    c998      r3908     -1
    c998      r4485     0.0001
    c999      Obj       -0.001
    c999      r646      1
    c999      r3895     1
    c999      r3897     -1
    c1000     Obj       -0.001
    c1000     r647      1
    c1000     r3894     1
    c1000     r3895     -1
    c1000     r4388     0.03125
    c1000     r4615     0.03125
    c1001     Obj       -0.001
    c1001     r649      1
    c1001     r3896     1
    c1001     r3899     -1
    c1001     r4320     0.03125
    c1001     r4374     0.0256
    c1002     Obj       -0.001
    c1002     r651      1
    c1002     r3901     1
    c1002     r3902     -1
    c1002     r4318     0.03125
    c1003     Obj       -0.001
    c1003     r652      1
    c1003     r3822     1
    c1003     r3900     -1
    c1003     r4510     6.103515625e-05
    c1004     Obj       -0.001
    c1004     r653      1
    c1004     r3899     -1
    c1004     r3900     1
    c1004     r4808     0.0001
    c1005     Obj       -0.001
    c1005     r654      1
    c1005     r3825     1
    c1005     r3897     -1
    c1005     r4505     0.0001
    c1005     r4508     6.103515625e-05
    c1005     r4939     6.103515625e-05
    c1006     Obj       -0.001
    c1006     r655      1
    c1006     r3861     1
    c1006     r3901     -1
    c1006     r4396     0.0256
    c1006     r5395     6.103515625e-05
    c1007     Obj       -0.001
    c1007     r657      1
    c1007     r3888     -1
    c1007     r3890     1
    c1008     Obj       -0.001
    c1008     r658      1
    c1008     r3861     -1
    c1008     r4258     1
    c1009     Obj       -0.001
    c1009     r659      1
    c1009     r3885     1
    c1009     r3908     -1
    c1010     Obj       -0.001
    c1010     r660      1
    c1010     r3885     -1
    c1010     r3886     1
    c1010     r4485     0.0001
    c1011     Obj       -0.001
    c1011     r661      1
    c1011     r3884     1
    c1011     r3891     -1
    c1011     r4557     0.03125
    c1012     Obj       -0.001
    c1012     r662      1
    c1012     r3883     1
    c1012     r3884     -1
    c1012     r4393     0.03125
    c1012     r6944     6.103515625e-05
    c1013     Obj       -0.001
    c1013     r664      1
    c1013     r3889     1
    c1013     r4056     -1
    c1013     r4838     6.103515625e-05
    c1014     Obj       -0.001
    c1014     r665      1
    c1014     r3888     1
    c1014     r3907     -1
    c1014     r4653     6.103515625e-05
    c1015     Obj       -29.355
    c1015     r666      1
    c1015     r3261     1
    c1015     r3803     -1
    c1015     r4888     0.03125
    c1015     r5121     0.0256
    c1016     Obj       -1.666
    c1016     r4070     -1
    c1016     r4080     1
    c1016     r5275     -0.03125
    c1017     Obj       -15.37775
    c1017     r668      1
    c1017     r3845     1
    c1017     r3846     -1
    c1017     r4507     6.103515625e-05
    c1018     Obj       -39.339
    c1018     r669      1
    c1018     r3805     -1
    c1018     r3847     1
    c1018     r4484     6.103515625e-05
    c1018     r4489     6.103515625e-05
    c1019     Obj       -15.38344
    c1019     r671      1
    c1019     r3848     1
    c1019     r3849     -1
    c1019     r4492     6.103515625e-05
    c1019     r4543     0.03125
    c1020     Obj       -20.6
    c1020     r673      1
    c1020     r3850     -1
    c1020     r3851     1
    c1021     Obj       -32.8
    c1021     r674      1
    c1021     r3851     -1
    c1021     r4194     1
    c1021     r5457     6.103515625e-05
    c1021     r6033     0.001953125
    c1022     Obj       -4.6
    c1022     r675      1
    c1022     r3852     1
    c1022     r4195     -1
    c1022     r5398     6.103515625e-05
    c1022     r6010     6.103515625e-05
    c1023     Obj       -0.337
    c1023     r676      1
    c1023     r3852     -1
    c1023     r3853     1
    c1024     Obj       -3.604
    c1024     r677      1
    c1024     r3463     1
    c1024     r3854     -1
    c1024     r4926     6.103515625e-05
    c1024     r6929     5.15410025492391e-05
    c1025     Obj       -8.309
    c1025     r678      1
    c1025     r3463     -1
    c1025     r3945     1
    c1025     r5019     6.103515625e-05
    c1025     r5168     0.0001
    c1025     r5218     6.103515625e-05
    c1025     r6263     0.000106825841804308
    c1025     r6422     0.0001
    c1025     r6692     8.46071103003263e-05
    c1025     r6755     8.46071103003263e-05
    c1025     r6929     5.1541002549239e-05
    c1025     r6998     8.46071103003263e-05
    c1026     Obj       -0.001
    c1026     r679      1
    c1026     r3857     1
    c1026     r3858     -1
    c1026     r4956     0.0256
    c1026     r6174     0.0001
    c1026     r6263     0.000106825841804308
    c1026     r6431     0.000114292604978001
    c1026     r6440     7.39420869012365e-05
    c1026     r6493     7.83571103003273e-05
    c1027     Obj       -14.2
    c1027     r3866     -1
    c1027     r3867     1
    c1027     r5099     6.103515625e-05
    c1027     r5540     6.63148467036154e-05
    c1027     r5645     6.103515625e-05
    c1027     r5718     6.63148467036154e-05
    c1027     r5725     6.63148467036154e-05
    c1027     r6539     9.98059035700758e-05
    c1027     r6573     0.0625
    c1027     r6661     0.000798447228560607
    c1027     r6690     6.63148467036154e-05
    c1027     r6725     0.000798447228560607
    c1027     r6762     9.98059035700758e-05
    c1027     r6788     -0.0001
    c1028     Obj       -14.686
    c1028     r681      1
    c1028     r3868     1
    c1028     r3869     -1
    c1028     r5492     0.03125
    c1028     r5654     0.03125
    c1028     r6439     0.00016276364411835
    c1028     r6513     6.103515625e-05
    c1029     Obj       -11.1
    c1029     r4013     -1
    c1029     r4014     1
    c1029     r6036     6.103515625e-05
    c1029     r6037     6.103515625e-05
    c1029     r6104     0.03125
    c1029     r6386     6.103515625e-05
    c1029     r6834     6.103515625e-05
    c1029     r6981     0.015625
    c1030     Obj       -0.116
    c1030     r684      1
    c1030     r3387     -1
    c1030     r3876     1
    c1030     r5445     6.103515625e-05
    c1031     Obj       -3.621
    c1031     r685      1
    c1031     r3881     1
    c1031     r3882     -1
    c1031     r4586     6.103515625e-05
    c1031     r5688     0.0032
    c1031     r5863     6.103515625e-05
    c1031     r6134     6.103515625e-05
    c1032     Obj       -0.02
    c1032     r3881     1
    c1032     r4093     -1
    c1033     Obj       -11.098
    c1033     r3881     1
    c1033     r4098     -1
    c1033     r5033     6.103515625e-05
    c1033     r5194     6.103515625e-05
    c1033     r5491     6.103515625e-05
    c1033     r5688     0.0032
    c1033     r5799     6.103515625e-05
    c1033     r5863     6.103515625e-05
    c1033     r6134     6.103515625e-05
    c1033     r6371     0.00160835783147124
    c1033     r6805     6.33313256726729e-05
    c1034     Obj       -0.76
    c1034     r688      1
    c1034     r3883     -1
    c1034     r3909     1
    c1034     r4669     0.03125
    c1034     r5201     0.03125
    c1034     r5499     0.03125
    c1034     r5583     0.03125
    c1034     r6945     6.103515625e-05
    c1035     Obj       -0.004
    c1035     r689      1
    c1035     r3481     -1
    c1035     r3909     1
    c1035     r5201     0.03125
    c1036     Obj       -8.458
    c1036     r691      1
    c1036     r3912     1
    c1036     r4238     -1
    c1036     r4961     0.03125
    c1036     r5051     0.03125
    c1036     r5125     0.03125
    c1036     r5441     6.103515625e-05
    c1036     r5909     6.103515625e-05
    c1036     r6065     6.103515625e-05
    c1036     r6086     6.87890538701883e-05
    c1036     r6436     6.103515625e-05
    c1036     r6437     6.103515625e-05
    c1036     r6524     5.89741767886658e-05
    c1036     r6532     6.103515625e-05
    c1036     r6675     6.103515625e-05
    c1036     r6736     6.103515625e-05
    c1036     r6848     5.45780865745698e-05
    c1036     r6883     6.103515625e-05
    c1036     r6886     0.0001
    c1036     r6902     6.103515625e-05
    c1036     r7056     6.103515625e-05
    c1037     Obj       -0.001
    c1037     r693      1
    c1037     r3257     -1
    c1037     r3914     1
    c1037     r7032     6.27562463049122e-05
    c1038     Obj       -12.005
    c1038     r694      1
    c1038     r3913     1
    c1038     r3914     -1
    c1038     r5175     0.0001
    c1038     r5319     6.103515625e-05
    c1038     r5561     6.103515625e-05
    c1038     r5640     6.103515625e-05
    c1038     r6564     6.103515625e-05
    c1038     r6636     6.45772165793789e-05
    c1038     r6882     6.45772165793789e-05
    c1039     Obj       -21.424
    c1039     r695      1
    c1039     r3919     1
    c1039     r3920     -1
    c1039     r4651     6.103515625e-05
    c1039     r4671     0.03125
    c1039     r6662     6.103515625e-05
    c1040     Obj       -3.632
    c1040     r3926     1
    c1040     r3927     -1
    c1040     r6025     0.03125
    c1040     r6040     6.103515625e-05
    c1040     r6385     -6.103515625e-05
    c1040     r6499     6.103515625e-05
    c1041     Obj       -0.437
    c1041     r697      1
    c1041     r3928     -1
    c1041     r3929     1
    c1041     r5061     0.0032
    c1041     r6449     0.03125
    c1041     r6499     6.103515625e-05
    c1042     Obj       -0.12
    c1042     r699      1
    c1042     r3932     1
    c1042     r3933     -1
    c1042     r5924     0.03125
    c1043     Obj       -3.179
    c1043     r3932     1
    c1043     r4031     -1
    c1043     r5107     6.29493235275564e-05
    c1043     r5208     0.0078125
    c1043     r5343     0.03125
    c1043     r5924     0.03125
    c1044     Obj       -0.026
    c1044     r3936     -1
    c1044     r4055     1
    c1044     r4440     0.0032
    c1044     r4568     0.00390625
    c1044     r4629     0.00390625
    c1044     r5085     6.103515625e-05
    c1044     r5404     6.103515625e-05
    c1044     r5750     6.103515625e-05
    c1044     r6019     -0.03125
    c1044     r6091     6.103515625e-05
    c1044     r6345     6.103515625e-05
    c1044     r6496     5.90124545996312e-05
    c1044     r6514     0.0001220703125
    c1044     r6517     0.0001220703125
    c1044     r6750     0.000116701433279395
    c1044     r6751     6.103515625e-05
    c1045     Obj       -60.347
    c1045     r703      1
    c1045     r3942     1
    c1045     r4187     -1
    c1045     r4407     0.03125
    c1045     r4788     0.0256
    c1045     r4840     0.0001
    c1045     r5047     0.03125
    c1045     r5836     0.00390625
    c1045     r6816     6.103515625e-05
    c1046     Obj       -0.025
    c1046     r3942     1
    c1046     r4190     -1
    c1046     r4407     0.03125
    c1046     r6543     6.103515625e-05
    c1047     Obj       -59
    c1047     r705      1
    c1047     r3943     -1
    c1047     r4188     1
    c1047     r5074     6.103515625e-05
    c1048     Obj       -51.806
    c1048     r707      1
    c1048     r3876     -1
    c1048     r3943     1
    c1049     Obj       -25.69
    c1049     r708      1
    c1049     r3944     1
    c1049     r3945     -1
    c1049     r4920     0.0001
    c1049     r5453     0.000148468020153255
    c1049     r6692     8.46071103003263e-05
    c1049     r6755     8.46071103003263e-05
    c1049     r6791     6.103515625e-05
    c1049     r6998     8.46071103003263e-05
    c1049     r7003     6.103515625e-05
    c1050     Obj       -27.981
    c1050     r710      1
    c1050     r3947     -1
    c1050     r4169     1
    c1051     Obj       -0.02
    c1051     r711      1
    c1051     r3949     -1
    c1051     r4255     1
    c1051     r5537     0.0001220703125
    c1051     r6162     0.0001
    c1051     r6252     0.0001220703125
    c1051     r6432     0.0001220703125
    c1051     r6931     6.103515625e-05
    c1051     r7001     6.103515625e-05
    c1051     r7007     6.103515625e-05
    c1052     Obj       -0.011
    c1052     r713      1
    c1052     r3777     1
    c1052     r3948     -1
    c1052     r5426     0.03125
    c1052     r5537     6.103515625e-05
    c1052     r5692     6.103515625e-05
    c1052     r6162     0.0001
    c1052     r6252     6.103515625e-05
    c1052     r6432     6.103515625e-05
    c1052     r6558     0.0001
    c1052     r6931     6.103515625e-05
    c1052     r6996     9.53971836372719e-05
    c1052     r7001     6.103515625e-05
    c1052     r7007     6.103515625e-05
    c1053     Obj       -0.147
    c1053     r3950     -1
    c1053     r3951     1
    c1053     r4628     0.00390625
    c1053     r5005     0.00390625
    c1053     r5836     -0.00390625
    c1053     r6543     6.103515625e-05
    c1053     r6576     0.00390625
    c1053     r6579     0.00390625
    c1053     r6724     0.00390625
    c1053     r6961     0.00390625
    c1053     r7012     0.0001220703125
    c1054     Obj       -0.038
    c1054     r3880     -1
    c1054     r3954     1
    c1054     r4394     0.03125
    c1055     Obj       -0.556
    c1055     r718      1
    c1055     r3954     1
    c1055     r4042     -1
    c1055     r4394     0.03125
    c1055     r6518     6.103515625e-05
    c1056     Obj       -1.257
    c1056     r719      1
    c1056     r3955     1
    c1056     r3956     -1
    c1056     r4378     0.03125
    c1056     r7043     6.16955590095415e-05
    c1057     Obj       -1.937
    c1057     r720      1
    c1057     r3955     1
    c1057     r3992     -1
    c1057     r6832     6.103515625e-05
    c1057     r7043     6.16955590095415e-05
    c1058     Obj       -0.002
    c1058     r3957     1
    c1058     r3985     -1
    c1059     Obj       -0.013
    c1059     r3958     1
    c1059     r3988     -1
    c1059     r4416     0.03125
    c1060     Obj       -8.683
    c1060     r723      1
    c1060     r3959     1
    c1060     r3961     -1
    c1061     Obj       -0.006
    c1061     r3960     1
    c1061     r3970     -1
    c1061     r4684     -0.03125
    c1062     Obj       -0.075
    c1062     r727      1
    c1062     r3961     1
    c1062     r3962     -1
    c1063     Obj       -0.168
    c1063     r728      1
    c1063     r3962     1
    c1063     r3963     -1
    c1064     Obj       -0.082
    c1064     r729      1
    c1064     r3963     1
    c1064     r3971     -1
    c1064     r7030     6.103515625e-05
    c1065     Obj       -0.021
    c1065     r730      1
    c1065     r3964     1
    c1065     r3976     -1
    c1065     r6896     6.103515625e-05
    c1066     Obj       -0.087
    c1066     r731      1
    c1066     r3964     -1
    c1066     r3965     1
    c1066     r7054     6.103515625e-05
    c1067     Obj       -0.022
    c1067     r732      1
    c1067     r3965     -1
    c1067     r3966     1
    c1068     Obj       -0.006
    c1068     r733      1
    c1068     r3966     -1
    c1068     r3977     1
    c1069     Obj       -0.022
    c1069     r734      1
    c1069     r3967     -1
    c1069     r3968     1
    c1069     r4338     0.03125
    c1070     Obj       -3.576
    c1070     r735      1
    c1070     r3969     -1
    c1070     r3982     1
    c1070     r4375     0.03125
    c1071     Obj       -6.708
    c1071     r736      1
    c1071     r3969     1
    c1071     r3974     -1
    c1072     Obj       -0.017
    c1072     r3970     -1
    c1072     r3975     1
    c1073     Obj       -0.035
    c1073     r738      1
    c1073     r3971     1
    c1073     r3973     -1
    c1074     Obj       -1.062
    c1074     r740      1
    c1074     r3972     1
    c1074     r3973     -1
    c1074     r7030     6.103515625e-05
    c1075     Obj       -0.003
    c1075     r3972     1
    c1075     r4261     -1
    c1075     r4804     0.03125
    c1076     Obj       -0.168
    c1076     r742      1
    c1076     r3974     1
    c1076     r3981     -1
    c1077     Obj       -5.175
    c1077     r743      1
    c1077     r3975     -1
    c1077     r3976     1
    c1077     r4398     0.03125
    c1078     Obj       -0.033
    c1078     r744      1
    c1078     r3977     -1
    c1078     r3978     1
    c1078     r5211     0.03125
    c1078     r6938     6.103515625e-05
    c1078     r7037     6.103515625e-05
    c1079     Obj       -0.034
    c1079     r746      1
    c1079     r3979     1
    c1079     r3994     -1
    c1079     r4417     0.03125
    c1080     Obj       -0.087
    c1080     r748      1
    c1080     r3979     -1
    c1080     r3980     1
    c1081     Obj       -2.241
    c1081     r749      1
    c1081     r3980     -1
    c1081     r3981     1
    c1082     Obj       -1.921
    c1082     r750      1
    c1082     r3982     -1
    c1082     r3983     1
    c1082     r4542     0.03125
    c1082     r4890     0.03125
    c1082     r7010     6.103515625e-05
    c1083     Obj       -0.01
    c1083     r3985     1
    c1083     r3988     -1
    c1083     r4416     0.03125
    c1083     r6870     6.103515625e-05
    c1083     r7037     6.103515625e-05
    c1084     Obj       -0.055
    c1084     r3955     -1
    c1084     r3986     1
    c1084     r4428     0.03125
    c1085     Obj       -0.189
    c1085     r754      1
    c1085     r3986     -1
    c1085     r3987     1
    c1085     r4904     0.015625
    c1085     r5158     0.0078125
    c1086     Obj       -2.816
    c1086     r3987     -1
    c1086     r3988     1
    c1086     r6938     6.103515625e-05
    c1087     Obj       -3.021
    c1087     r756      1
    c1087     r3989     1
    c1087     r3993     -1
    c1088     Obj       -0.011
    c1088     r757      1
    c1088     r3989     -1
    c1088     r3990     1
    c1089     Obj       -0.246
    c1089     r758      1
    c1089     r3990     -1
    c1089     r3991     1
    c1090     Obj       -3.271
    c1090     r759      1
    c1090     r3991     -1
    c1090     r3992     1
    c1090     r5401     0.0078125
    c1090     r6927     7.53119616815692e-05
    c1090     r7087     7.53119616815605e-05
    c1091     Obj       -2.857
    c1091     r760      1
    c1091     r3952     -1
    c1091     r3993     1
    c1091     r4434     0.0256
    c1092     Obj       -17.119
    c1092     r761      1
    c1092     r3913     -1
    c1092     r4000     1
    c1093     Obj       -40.78
    c1093     r762      1
    c1093     r3842     -1
    c1093     r3908     1
    c1093     r4610     0.03125
    c1093     r5175     0.0001
    c1093     r5558     0.0001
    c1093     r6065     6.103515625e-05
    c1093     r6086     6.87890538701883e-05
    c1093     r6436     6.103515625e-05
    c1093     r6437     6.103515625e-05
    c1093     r6480     0.000137578107740377
    c1093     r6522     0.0008
    c1093     r6532     6.103515625e-05
    c1093     r6664     7.36196352139833e-05
    c1093     r6675     6.103515625e-05
    c1093     r6736     6.103515625e-05
    c1093     r6848     5.45780865745698e-05
    c1094     Obj       -0.016
    c1094     r3461     1
    c1094     r3996     -1
    c1094     r4409     0.03125
    c1094     r6669     6.103515625e-05
    c1094     r6710     0.00390625
    c1094     r6747     0.0001220703125
    c1094     r6750     0.000116701433279395
    c1094     r6751     6.103515625e-05
    c1095     Obj       -0.027
    c1095     r3461     1
    c1095     r4265     -1
    c1095     r4409     0.03125
    c1095     r6019     0.03125
    c1095     r6345     -6.103515625e-05
    c1095     r6514     -0.0001220703125
    c1095     r6521     0.0001220703125
    c1095     r6669     6.103515625e-05
    c1095     r6747     0.0001220703125
    c1095     r6979     6.103515625e-05
    c1096     Obj       -0.031
    c1096     r3997     -1
    c1096     r4029     1
    c1096     r4529     0.03125
    c1096     r5969     0.000244140625
    c1096     r6308     0.000244140625
    c1096     r6410     6.103515625e-05
    c1096     r6411     0.0001220703125
    c1096     r6478     0.0001220703125
    c1096     r6485     8.85484805643365e-05
    c1096     r6541     6.103515625e-05
    c1096     r6542     0.000116344435088454
    c1096     r6684     6.103515625e-05
    c1097     Obj       -4.641
    c1097     r767      1
    c1097     r4020     1
    c1097     r4263     -1
    c1098     Obj       -11.162
    c1098     r768      1
    c1098     r4017     1
    c1098     r4049     -1
    c1098     r5274     0.03125
    c1098     r6055     0.015625
    c1098     r6424     0.015625
    c1098     r6526     0.0078125
    c1098     r6603     0.015625
    c1098     r6653     0.015625
    c1098     r6734     6.103515625e-05
    c1098     r6917     0.0001220703125
    c1099     Obj       -19.564
    c1099     r769      1
    c1099     r4016     -1
    c1099     r4017     1
    c1100     Obj       -0.008
    c1100     r770      1
    c1100     r4021     -1
    c1100     r4022     1
    c1100     r4872     6.103515625e-05
    c1100     r5516     0.015625
    c1100     r6653     0.015625
    c1101     Obj       119.911
    c1101     r4022     1
    c1102     Obj       -20.136
    c1102     r772      1
    c1102     r4016     1
    c1102     r4262     -1
    c1103     Obj       -2
    c1103     r3998     1
    c1103     r4030     -1
    c1103     r5107     6.29493235275564e-05
    c1103     r5111     6.103515625e-05
    c1103     r6581     0.03125
    c1104     Obj       -25.899
    c1104     r775      1
    c1104     r3998     -1
    c1104     r3999     1
    c1104     r4630     0.0078125
    c1104     r4984     0.0256
    c1104     r6418     0.0009765625
    c1104     r6445     6.29175895289511e-05
    c1104     r6508     0.0256
    c1104     r6565     6.103515625e-05
    c1104     r6785     0.00373620624851763
    c1104     r6974     6.1548701380684e-05
    c1104     r7085     0.0001
    c1105     Obj       -0.014
    c1105     r776      1
    c1105     r4021     -1
    c1105     r4023     1
    c1105     r4567     0.015625
    c1105     r5516     0.015625
    c1106     Obj       -0.016
    c1106     r4022     -1
    c1106     r4023     1
    c1106     r4567     0.015625
    c1107     Obj       -12.493
    c1107     r778      1
    c1107     r4000     -1
    c1107     r4001     1
    c1108     Obj       -8.178
    c1108     r779      1
    c1108     r4001     -1
    c1108     r4002     1
    c1109     Obj       -15.491
    c1109     r780      1
    c1109     r4002     -1
    c1109     r4003     1
    c1110     Obj       -13.42
    c1110     r781      1
    c1110     r4003     -1
    c1110     r4004     1
    c1111     Obj       -10.792
    c1111     r782      1
    c1111     r4004     -1
    c1111     r4005     1
    c1112     Obj       -7.503
    c1112     r783      1
    c1112     r4005     -1
    c1112     r4006     1
    c1113     Obj       -5.668
    c1113     r784      1
    c1113     r4006     -1
    c1113     r4007     1
    c1114     Obj       -28.602
    c1114     r785      1
    c1114     r4007     -1
    c1114     r4008     1
    c1115     Obj       -15.644
    c1115     r786      1
    c1115     r4008     -1
    c1115     r4009     1
    c1116     Obj       -32.997
    c1116     r787      1
    c1116     r4009     -1
    c1116     r4229     1
    c1116     r4774     0.015625
    c1116     r4795     0.015625
    c1116     r4805     6.103515625e-05
    c1116     r5254     6.103515625e-05
    c1116     r6015     6.103515625e-05
    c1117     Obj       -0.02
    c1117     r4010     1
    c1117     r4226     -1
    c1118     Obj       -15
    c1118     r4011     1
    c1118     r4227     -1
    c1119     Obj       -17.75
    c1119     r792      1
    c1119     r4011     -1
    c1119     r4012     1
    c1119     r6855     6.103515625e-05
    c1120     Obj       -30
    c1120     r4012     -1
    c1120     r4013     1
    c1120     r6382     6.103515625e-05
    c1120     r6460     6.103515625e-05
    c1120     r6464     6.103515625e-05
    c1120     r6468     6.103515625e-05
    c1120     r6586     0.015625
    c1120     r6899     6.103515625e-05
    c1121     Obj       -6
    c1121     r4014     -1
    c1121     r4050     1
    c1121     r5343     0.03125
    c1121     r6464     -6.103515625e-05
    c1121     r6468     -6.103515625e-05
    c1122     Obj       -10.125
    c1122     r3458     -1
    c1122     r4047     1
    c1122     r5150     6.103515625e-05
    c1122     r5206     0.015625
    c1122     r5898     0.0001
    c1122     r6444     5.45780865745681e-05
    c1123     Obj       -0.18
    c1123     r3445     -1
    c1123     r4027     1
    c1123     r4725     0.0016
    c1123     r5051     0.03125
    c1123     r5441     6.103515625e-05
    c1123     r5909     6.103515625e-05
    c1123     r6065     6.103515625e-05
    c1123     r6086     6.87890538701883e-05
    c1123     r6436     6.103515625e-05
    c1123     r6437     6.103515625e-05
    c1123     r6524     5.89741767886658e-05
    c1123     r6532     6.103515625e-05
    c1123     r6765     6.103515625e-05
    c1123     r6883     6.103515625e-05
    c1124     Obj       -10.628
    c1124     r800      1
    c1124     r3919     -1
    c1124     r4015     1
    c1125     Obj       -25.073
    c1125     r801      1
    c1125     r4015     -1
    c1125     r4262     1
    c1126     Obj       -7.004
    c1126     r4018     -1
    c1126     r4024     1
    c1126     r5296     6.103515625e-05
    c1126     r5297     0.015625
    c1126     r6653     0.015625
    c1126     r6871     6.103515625e-05
    c1127     Obj       -3.684
    c1127     r4018     1
    c1127     r4023     -1
    c1128     Obj       -10.733
    c1128     r804      1
    c1128     r4019     1
    c1128     r4259     -1
    c1128     r5300     6.103515625e-05
    c1129     Obj       -7.252
    c1129     r805      1
    c1129     r4019     -1
    c1129     r4028     1
    c1130     Obj       -0.011
    c1130     r806      1
    c1130     r3481     1
    c1130     r4264     -1
    c1130     r5499     0.03125
    c1131     Obj       -0.024
    c1131     r4021     1
    c1131     r4048     -1
    c1132     Obj       -0.229
    c1132     r808      1
    c1132     r4024     -1
    c1132     r4025     1
    c1133     Obj       -10.759
    c1133     r809      1
    c1133     r4028     -1
    c1133     r4264     1
    c1133     r5583     0.03125
    c1133     r6944     6.103515625e-05
    c1133     r6945     6.103515625e-05
    c1134     Obj       -1.054
    c1134     r3435     -1
    c1134     r4282     1
    c1134     r4685     0.000244140625
    c1134     r5162     0.0001220703125
    c1134     r5969     0.000244140625
    c1134     r6684     6.103515625e-05
    c1135     Obj       -16.534
    c1135     r4030     -1
    c1135     r4031     1
    c1135     r4630     0.0078125
    c1135     r6418     0.0009765625
    c1135     r6445     6.29175895289511e-05
    c1136     Obj       -2.199
    c1136     r4032     1
    c1136     r4036     -1
    c1136     r5034     6.103515625e-05
    c1136     r6581     0.03125
    c1136     r6681     0.0078125
    c1137     Obj       -0.704
    c1137     r4032     -1
    c1137     r4033     1
    c1137     r5922     0.03125
    c1138     Obj       -16.755
    c1138     r4034     -1
    c1138     r4035     1
    c1138     r4943     6.103515625e-05
    c1138     r5932     0.0078125
    c1138     r6224     0.0078125
    c1138     r6565     6.103515625e-05
    c1138     r6606     0.0078125
    c1138     r6926     6.103515625e-05
    c1138     r7058     5.6220122564472e-05
    c1139     Obj       -2.882
    c1139     r815      1
    c1139     r4035     -1
    c1139     r4057     1
    c1139     r4502     6.103515625e-05
    c1139     r5198     0.03125
    c1139     r6224     0.0078125
    c1139     r6827     6.103515625e-05
    c1139     r7071     6.103515625e-05
    c1140     Obj       -3.673
    c1140     r3932     -1
    c1140     r4036     1
    c1140     r5517     0.03125
    c1140     r5699     0.0625
    c1140     r5922     -0.03125
    c1140     r5932     -0.0078125
    c1140     r6224     -0.0078125
    c1140     r6445     6.29175895289511e-05
    c1140     r6490     6.103515625e-05
    c1140     r6926     -6.103515625e-05
    c1140     r6974     6.1548701380684e-05
    c1141     Obj       -25.072
    c1141     r818      1
    c1141     r4037     -1
    c1141     r4041     1
    c1141     r5035     6.103515625e-05
    c1141     r5108     6.103515625e-05
    c1141     r5133     0.0078125
    c1141     r6562     6.13774574550614e-05
    c1141     r6827     6.103515625e-05
    c1141     r6853     6.103515625e-05
    c1142     Obj       -9.38
    c1142     r4037     1
    c1142     r4038     -1
    c1142     r4944     6.103515625e-05
    c1142     r7019     6.103515625e-05
    c1143     Obj       -0.123
    c1143     r4046     -1
    c1143     r4059     1
    c1144     Obj       -0.487
    c1144     r4038     1
    c1144     r4044     -1
    c1144     r5192     6.103515625e-05
    c1144     r6910     6.103515625e-05
    c1145     Obj       -10.329
    c1145     r823      1
    c1145     r4039     -1
    c1145     r4045     1
    c1145     r5745     0.03125
    c1146     Obj       -0.039
    c1146     r824      1
    c1146     r3954     -1
    c1146     r4039     1
    c1146     r5837     0.03125
    c1146     r6518     6.103515625e-05
    c1147     Obj       -0.157
    c1147     r825      1
    c1147     r4040     -1
    c1147     r4042     1
    c1147     r4399     0.03125
    c1148     Obj       -4.183
    c1148     r826      1
    c1148     r4041     -1
    c1148     r4042     1
    c1148     r4399     0.03125
    c1149     Obj       -12.017
    c1149     r4043     1
    c1149     r4058     -1
    c1150     Obj       -20.641
    c1150     r4043     -1
    c1150     r4044     1
    c1151     Obj       -18.212
    c1151     r829      1
    c1151     r4045     -1
    c1151     r4046     1
    c1151     r4751     0.03125
    c1151     r5383     0.0001220703125
    c1151     r6542     0.000116344435088454
    c1151     r6547     8.27375139400187e-05
    c1151     r6625     0.0001220703125
    c1151     r6632     8.27375139400187e-05
    c1151     r6761     0.0001220703125
    c1151     r6803     6.103515625e-05
    c1152     Obj       -2.266
    c1152     r4060     1
    c1152     r4066     -1
    c1152     r6446     -0.03125
    c1152     r6462     -6.103515625e-05
    c1153     Obj       -0.043
    c1153     r4060     -1
    c1153     r4061     1
    c1153     r6156     0.0001
    c1153     r6269     0.0001
    c1153     r6401     0.0032
    c1153     r6446     0.03125
    c1154     Obj       -0.167
    c1154     r4062     -1
    c1154     r4064     1
    c1154     r5194     6.103515625e-05
    c1154     r6430     6.04134265737728e-05
    c1155     Obj       -5.765
    c1155     r4062     1
    c1155     r4266     -1
    c1155     r4708     0.03125
    c1155     r5322     9.17612158574278e-05
    c1155     r6387     9.17612158574278e-05
    c1155     r6430     6.04134265737728e-05
    c1156     Obj       -0.001
    c1156     r4089     1
    c1156     r4270     -1
    c1157     Obj       -8.586
    c1157     r4068     -1
    c1157     r4266     1
    c1157     r5255     6.103515625e-05
    c1157     r5786     6.103515625e-05
    c1157     r6179     6.103515625e-05
    c1158     Obj       -0.09
    c1158     r4063     1
    c1158     r4081     -1
    c1159     Obj       -0.078
    c1159     r4063     -1
    c1159     r4082     1
    c1160     Obj       -0.068
    c1160     r3443     1
    c1160     r4064     -1
    c1160     r4955     0.03125
    c1160     r6362     -0.03125
    c1160     r6390     0.0001
    c1161     Obj       -0.008
    c1161     r4069     1
    c1161     r4088     -1
    c1161     r5116     0.03125
    c1161     r5275     0.03125
    c1162     Obj       -0.017
    c1162     r3926     -1
    c1162     r4065     1
    c1162     r6027     0.03125
    c1162     r6450     -0.00390625
    c1162     r6463     -6.103515625e-05
    c1163     Obj       -0.276
    c1163     r4065     -1
    c1163     r4066     1
    c1163     r6450     0.00390625
    c1163     r6463     6.103515625e-05
    c1163     r6618     6.103515625e-05
    c1164     Obj       -6.664
    c1164     r3928     -1
    c1164     r4074     1
    c1164     r5415     0.03125
    c1164     r6155     0.0001
    c1165     Obj       -0.047
    c1165     r4067     1
    c1165     r4087     -1
    c1165     r6397     0.0032
    c1165     r6560     5.26071448575251e-05
    c1166     Obj       -0.124
    c1166     r4067     -1
    c1166     r4068     1
    c1166     r5889     6.103515625e-05
    c1167     Obj       -0.033
    c1167     r4069     -1
    c1167     r4070     1
    c1168     Obj       -1.428
    c1168     r4071     1
    c1168     r4082     -1
    c1169     Obj       -4.465
    c1169     r4071     -1
    c1169     r4072     1
    c1169     r6024     -0.03125
    c1169     r6025     -0.03125
    c1169     r6027     -0.03125
    c1169     r6384     -6.103515625e-05
    c1169     r6499     -6.103515625e-05
    c1170     Obj       -0.413
    c1170     r4072     -1
    c1170     r4073     1
    c1170     r6024     0.03125
    c1171     Obj       -0.039
    c1171     r4074     -1
    c1171     r4075     1
    c1171     r6158     0.0001
    c1171     r6400     0.0032
    c1172     Obj       -0.406
    c1172     r4075     -1
    c1172     r4076     1
    c1172     r6399     0.0032
    c1173     Obj       -0.155
    c1173     r4076     -1
    c1173     r4077     1
    c1173     r6398     0.0032
    c1174     Obj       -9.212
    c1174     r4077     -1
    c1174     r4078     1
    c1174     r5137     0.0032
    c1174     r6247     6.103515625e-05
    c1174     r6439     8.1381822059175e-05
    c1174     r6697     7.58272859959297e-05
    c1174     r7008     6.05556754038614e-05
    c1175     Obj       -1.647
    c1175     r4078     -1
    c1175     r4079     1
    c1175     r6370     0.0032
    c1175     r6528     0.00397553361202361
    c1175     r6993     0.0001
    c1176     Obj       -9.428
    c1176     r4079     -1
    c1176     r4083     1
    c1176     r6328     6.103515625e-05
    c1176     r6393     7.58272859959312e-05
    c1177     Obj       -0.009
    c1177     r4080     -1
    c1177     r4081     1
    c1178     Obj       -22.921
    c1178     r4083     -1
    c1178     r4086     1
    c1178     r6333     6.103515625e-05
    c1179     Obj       -0.274
    c1179     r859      1
    c1179     r4084     -1
    c1179     r4085     1
    c1179     r4322     0.0256
    c1180     Obj       -0.27
    c1180     r4086     -1
    c1180     r4087     1
    c1180     r4616     0.03125
    c1181     Obj       -0.064
    c1181     r3812     -1
    c1181     r4094     1
    c1181     r5863     6.103515625e-05
    c1182     Obj       -0.407
    c1182     r863      1
    c1182     r4091     -1
    c1182     r4092     1
    c1182     r4581     6.103515625e-05
    c1183     Obj       -0.007
    c1183     r4092     -1
    c1183     r4105     1
    c1184     Obj       -8.085
    c1184     r4104     -1
    c1184     r4105     1
    c1184     r4621     0.0256
    c1184     r4673     0.0256
    c1184     r4890     0.03125
    c1184     r5014     6.103515625e-05
    c1185     Obj       -0.006
    c1185     r4102     1
    c1185     r4104     -1
    c1186     Obj       -0.003
    c1186     r867      1
    c1186     r4101     -1
    c1186     r4102     1
    c1186     r4595     0.03125
    c1187     Obj       -1.25
    c1187     r4093     1
    c1187     r4095     -1
    c1187     r6833     6.103515625e-05
    c1188     Obj       -1.4
    c1188     r4109     1
    c1188     r4112     -1
    c1188     r5485     6.103515625e-05
    c1188     r6831     0.0001
    c1188     r6863     6.103515625e-05
    c1188     r7057     6.15215918512414e-05
    c1189     Obj       -6.159
    c1189     r870      1
    c1189     r3838     1
    c1189     r4108     -1
    c1189     r4765     0.0256
    c1190     Obj       -14.349
    c1190     r871      1
    c1190     r4110     1
    c1190     r4116     -1
    c1190     r5483     0.0001
    c1190     r5519     0.0256
    c1190     r5639     0.0001
    c1190     r7086     6.75209328895683e-05
    c1191     Obj       -4.416
    c1191     r4109     -1
    c1191     r4117     1
    c1192     Obj       -1.361
    c1192     r873      1
    c1192     r4094     -1
    c1192     r4095     1
    c1192     r5688     0.0032
    c1192     r6134     6.103515625e-05
    c1193     Obj       -2.311
    c1193     r875      1
    c1193     r4096     -1
    c1193     r4097     1
    c1194     Obj       -6.006
    c1194     r876      1
    c1194     r4097     -1
    c1194     r4098     1
    c1194     r4941     6.103515625e-05
    c1194     r5811     6.103515625e-05
    c1194     r5863     6.103515625e-05
    c1194     r6134     6.103515625e-05
    c1194     r7041     6.103515625e-05
    c1195     Obj       -0.946
    c1195     r4099     -1
    c1195     r4100     1
    c1195     r4673     0.0256
    c1195     r4904     0.015625
    c1195     r5014     6.103515625e-05
    c1196     Obj       -9.81
    c1196     r4105     -1
    c1196     r4106     1
    c1196     r4401     0.03125
    c1196     r4720     0.0256
    c1196     r5304     0.00963993109523974
    c1196     r5379     0.00963993109524082
    c1196     r5539     0.0157940631064426
    c1196     r6927     0.000150623923363138
    c1196     r6938     0.0001220703125
    c1196     r7037     0.0001220703125
    c1196     r7043     0.000123391118019083
    c1196     r7087     0.000150623923363121
    c1197     Obj       -0.016
    c1197     r3881     -1
    c1197     r4103     1
    c1197     r5919     0.0001
    c1197     r7052     0.0001
    c1198     Obj       -0.01
    c1198     r880      1
    c1198     r4100     -1
    c1198     r4101     1
    c1198     r4621     0.0256
    c1199     Obj       -6.452
    c1199     r881      1
    c1199     r4103     -1
    c1199     r4104     1
    c1199     r4534     0.03125
    c1199     r4621     0.0256
    c1199     r4673     0.0256
    c1199     r4699     0.0002
    c1199     r5014     6.103515625e-05
    c1199     r5811     6.103515625e-05
    c1199     r6169     6.103515625e-05
    c1199     r6828     6.103515625e-05
    c1199     r7013     6.103515625e-05
    c1199     r7041     6.103515625e-05
    c1200     Obj       -3.25
    c1200     r4106     -1
    c1200     r4107     1
    c1201     Obj       -0.208
    c1201     r4107     -1
    c1201     r4113     1
    c1201     r5733     0.0001
    c1202     Obj       -8.425
    c1202     r884      1
    c1202     r4108     1
    c1202     r4110     -1
    c1202     r5598     0.0256
    c1202     r7057     6.15215918512414e-05
    c1203     Obj       -1.7
    c1203     r4111     1
    c1203     r4114     -1
    c1203     r5396     0.0001
    c1203     r7036     6.103515625e-05
    c1203     r7086     6.75209328895683e-05
    c1204     Obj       -1.18
    c1204     r4111     -1
    c1204     r4112     1
    c1204     r5487     6.103515625e-05
    c1204     r6920     6.103515625e-05
    c1205     Obj       -0.009
    c1205     r4113     -1
    c1205     r4114     1
    c1206     Obj       -1.117
    c1206     r4117     -1
    c1206     r4267     1
    c1207     Obj       -20.6
    c1207     r890      1
    c1207     r4193     1
    c1207     r4268     -1
    c1207     r4895     0.0016
    c1207     r5021     6.103515625e-05
    c1207     r5628     6.103515625e-05
    c1207     r5683     5.40634142331716e-05
    c1208     Obj       -4.6
    c1208     r892      1
    c1208     r4118     1
    c1208     r4120     -1
    c1209     Obj       -0.337
    c1209     r3937     1
    c1209     r4118     -1
    c1209     r5959     0.0016
    c1210     Obj       -30.9
    c1210     r896      1
    c1210     r4119     -1
    c1210     r4120     1
    c1210     r5398     6.103515625e-05
    c1210     r5797     6.103515625e-05
    c1210     r6010     6.103515625e-05
    c1210     r6033     0.001953125
    c1210     r6083     6.103515625e-05
    c1210     r6109     0.001953125
    c1210     r6131     6.103515625e-05
    c1211     Obj       -14.448
    c1211     r4121     -1
    c1211     r4142     1
    c1211     r6503     -0.03125
    c1211     r6594     6.103515625e-05
    c1212     Obj       -16.448
    c1212     r898      1
    c1212     r4122     -1
    c1212     r4130     1
    c1212     r4722     0.0128
    c1212     r4756     0.0128
    c1212     r5086     0.0128
    c1212     r6960     0.0128
    c1213     Obj       -0.141
    c1213     r3779     -1
    c1213     r4123     1
    c1213     r4445     0.0008
    c1213     r5138     0.03125
    c1213     r6667     0.0001
    c1213     r6784     0.0001
    c1213     r6788     0.0001
    c1213     r6792     6.103515625e-05
    c1213     r6972     0.0008
    c1214     Obj       -0.296
    c1214     r3782     1
    c1214     r4164     -1
    c1214     r4703     0.0256
    c1214     r6425     6.103515625e-05
    c1215     Obj       -0.007
    c1215     r3785     -1
    c1215     r4124     1
    c1215     r4831     0.0001
    c1216     Obj       -0.009
    c1216     r4125     -1
    c1216     r4162     1
    c1216     r6343     7.8502349312175e-05
    c1216     r6609     0.0008
    c1216     r6723     6.103515625e-05
    c1216     r6741     6.63148467036154e-05
    c1216     r6752     9.58279909070786e-05
    c1216     r6972     0.0008
    c1216     r6983     0.0001
    c1217     Obj       -0.01
    c1217     r4162     1
    c1217     r4185     -1
    c1217     r6482     0.0001
    c1217     r6546     0.0001
    c1217     r6784     0.0001
    c1218     Obj       -11.706
    c1218     r906      1
    c1218     r4127     -1
    c1218     r4128     1
    c1218     r4807     6.103515625e-05
    c1218     r5007     6.103515625e-05
    c1218     r5086     0.0128
    c1218     r5129     0.03125
    c1218     r5204     0.03125
    c1218     r5399     6.103515625e-05
    c1219     Obj       -4.742
    c1219     r3781     -1
    c1219     r4127     1
    c1219     r4667     0.03125
    c1219     r4722     0.0128
    c1219     r4756     0.0128
    c1220     Obj       -5.993
    c1220     r4174     -1
    c1220     r4175     1
    c1220     r6873     6.103515625e-05
    c1221     Obj       -24.74
    c1221     r909      1
    c1221     r3947     1
    c1221     r4128     -1
    c1222     Obj       -0.005
    c1222     r910      1
    c1222     r3947     1
    c1222     r4168     -1
    c1223     Obj       -14.5
    c1223     r911      1
    c1223     r4137     -1
    c1223     r4155     1
    c1224     Obj       -37.84
    c1224     r912      1
    c1224     r4129     1
    c1224     r4143     -1
    c1224     r4796     6.103515625e-05
    c1224     r6278     0.03125
    c1225     Obj       -94.748
    c1225     r913      1
    c1225     r4130     -1
    c1225     r4133     1
    c1225     r6954     0.03125
    c1226     Obj       -14
    c1226     r914      1
    c1226     r4131     -1
    c1226     r4132     1
    c1226     r4319     0.03125
    c1226     r6856     0.0001
    c1226     r7024     6.103515625e-05
    c1227     Obj       -98.915
    c1227     r915      1
    c1227     r4133     -1
    c1227     r4134     1
    c1227     r4579     6.103515625e-05
    c1228     Obj       -0.01
    c1228     r4135     1
    c1228     r4179     -1
    c1228     r4561     0.03125
    c1228     r4647     0.0625
    c1229     Obj       -49.584
    c1229     r917      1
    c1229     r4136     -1
    c1229     r4137     1
    c1229     r4316     0.03125
    c1229     r4947     8.86688360098634e-05
    c1229     r5114     8.86688360098634e-05
    c1230     Obj       -0.024
    c1230     r4179     -1
    c1230     r4181     1
    c1231     Obj       -0.034
    c1231     r4180     -1
    c1231     r4181     1
    c1231     r4539     0.03125
    c1231     r5170     0.0008
    c1231     r5337     0.0009765625
    c1231     r5692     6.103515625e-05
    c1231     r6558     0.0001
    c1231     r7001     6.103515625e-05
    c1231     r7024     6.103515625e-05
    c1232     Obj       -6
    c1232     r4138     1
    c1232     r4271     -1
    c1232     r5240     6.103515625e-05
    c1232     r5325     0.0009765625
    c1232     r6488     0.0009765625
    c1232     r6840     6.103515625e-05
    c1233     Obj       -4.328
    c1233     r4138     1
    c1233     r4281     -1
    c1233     r4930     0.0001
    c1234     Obj       -3.721
    c1234     r922      1
    c1234     r4139     1
    c1234     r4144     -1
    c1234     r4854     6.103515625e-05
    c1234     r5795     0.0001
    c1234     r6164     0.000114423017120107
    c1234     r6265     0.000109283976856577
    c1234     r6344     0.0001
    c1234     r6420     8.77414092738715e-05
    c1234     r6545     0.000118429033183437
    c1234     r6679     0.00010823311630947
    c1234     r6800     0.000109283976856577
    c1234     r6997     7.2685628046759e-05
    c1235     Obj       -4.753
    c1235     r923      1
    c1235     r4139     -1
    c1235     r4145     1
    c1235     r4937     6.103515625e-05
    c1236     Obj       -35.854
    c1236     r924      1
    c1236     r4140     -1
    c1236     r4141     1
    c1236     r4312     0.03125
    c1237     Obj       -60.185
    c1237     r925      1
    c1237     r4142     -1
    c1237     r4143     1
    c1237     r5824     0.03125
    c1237     r6741     6.63148467036154e-05
    c1237     r6805     0.000126662651345346
    c1238     Obj       -15.644
    c1238     r926      1
    c1238     r3868     -1
    c1238     r4149     1
    c1238     r5056     0.0064
    c1238     r5057     0.0064
    c1238     r5058     0.0064
    c1238     r5059     0.0064
    c1238     r5060     0.0064
    c1238     r5061     0.0064
    c1238     r5062     0.0064
    c1238     r5063     0.0064
    c1238     r5575     0.03125
    c1238     r6697     -0.000151654571991859
    c1238     r7008     -0.000121111350807723
    c1239     Obj       -10
    c1239     r3767     -1
    c1239     r4144     1
    c1240     Obj       -17.38
    c1240     r929      1
    c1240     r4145     -1
    c1240     r4147     1
    c1240     r5030     6.103515625e-05
    c1241     Obj       -0.81
    c1241     r4146     1
    c1241     r4270     -1
    c1241     r5420     0.03125
    c1241     r5497     -0.03125
    c1241     r5498     -0.03125
    c1242     Obj       -2
    c1242     r4146     -1
    c1242     r4150     1
    c1242     r5076     -6.103515625e-05
    c1242     r5588     6.103515625e-05
    c1243     Obj       -49.584
    c1243     r934      1
    c1243     r4147     -1
    c1243     r4153     1
    c1243     r4299     0.03125
    c1243     r4947     8.86688360098634e-05
    c1243     r5025     6.103515625e-05
    c1243     r5114     8.86688360098634e-05
    c1244     Obj       -11.607
    c1244     r4149     -1
    c1244     r4183     1
    c1244     r5137     0.0032
    c1244     r5575     -0.03125
    c1244     r5654     -0.03125
    c1244     r6370     0.0032
    c1244     r6371     0.00160835783147124
    c1244     r6393     0.000227481857987793
    c1244     r6396     0.0032
    c1244     r6397     0.0032
    c1244     r6398     0.0032
    c1244     r6399     0.0032
    c1244     r6400     0.0032
    c1244     r6401     0.0032
    c1244     r6439     -8.1381822059175e-05
    c1244     r6528     0.00397553361202361
    c1244     r6560     5.26071448575251e-05
    c1244     r6697     7.58272859959297e-05
    c1244     r6805     0.000126662651345346
    c1244     r6993     0.0001
    c1244     r7008     6.05556754038613e-05
    c1245     Obj       -4.162
    c1245     r4160     1
    c1245     r4183     -1
    c1245     r4789     0.03125
    c1245     r6390     0.0002
    c1245     r6430     0.000120826853147546
    c1246     Obj       -11
    c1246     r4150     -1
    c1246     r4182     1
    c1247     Obj       -0.901
    c1247     r4271     -1
    c1247     r4272     1
    c1247     r5309     6.103515625e-05
    c1248     Obj       -5.7
    c1248     r941      1
    c1248     r4151     1
    c1248     r4235     -1
    c1248     r5385     6.103515625e-05
    c1248     r5394     0.0001
    c1249     Obj       -11.478
    c1249     r942      1
    c1249     r3866     1
    c1249     r4154     -1
    c1249     r6962     0.03125
    c1250     Obj       -3.022
    c1250     r4153     -1
    c1250     r4154     1
    c1250     r4857     9.5367431640625e-05
    c1250     r5252     8.86688360098604e-05
    c1251     Obj       -14.2
    c1251     r4155     -1
    c1251     r4156     1
    c1251     r5224     6.103515625e-05
    c1251     r5540     6.63148467036154e-05
    c1251     r5645     6.103515625e-05
    c1251     r5718     6.63148467036154e-05
    c1251     r5725     6.63148467036154e-05
    c1251     r6539     9.98059035700758e-05
    c1251     r6573     0.0625
    c1251     r6661     0.000798447228560607
    c1251     r6690     6.63148467036154e-05
    c1251     r6725     0.000798447228560607
    c1251     r6762     9.98059035700758e-05
    c1252     Obj       -12.41
    c1252     r4157     1
    c1252     r4161     -1
    c1252     r5151     6.103515625e-05
    c1252     r5362     6.103515625e-05
    c1252     r5422     0.03125
    c1252     r6393     7.58272859959311e-05
    c1252     r6563     6.103515625e-05
    c1252     r6890     0.0625
    c1253     Obj       -15.1
    c1253     r4157     -1
    c1253     r4158     1
    c1253     r6113     6.103515625e-05
    c1254     Obj       -7.68
    c1254     r949      1
    c1254     r4158     -1
    c1254     r4163     1
    c1255     Obj       -0.015
    c1255     r950      1
    c1255     r4159     1
    c1255     r4164     -1
    c1255     r6425     6.103515625e-05
    c1255     r6976     6.103515625e-05
    c1256     Obj       -0.04
    c1256     r951      1
    c1256     r4159     -1
    c1256     r4256     1
    c1257     Obj       -16.198
    c1257     r4160     -1
    c1257     r4161     1
    c1257     r5137     0.0096
    c1257     r5422     -0.03125
    c1257     r5458     0.0625
    c1257     r6113     -6.103515625e-05
    c1257     r6370     0.0096
    c1257     r6371     0.00482507349441372
    c1257     r6396     0.0096
    c1257     r6397     0.0096
    c1257     r6398     0.0096
    c1257     r6399     0.0096
    c1257     r6400     0.0096
    c1257     r6401     0.0096
    c1257     r6439     0.000244145466177525
    c1257     r6528     0.0119266008360708
    c1257     r6560     0.000157821434572575
    c1257     r6697     0.000227481857987789
    c1257     r6805     0.000189993977018019
    c1257     r6993     0.0003
    c1257     r7008     0.000181667026211584
    c1258     Obj       -15.06
    c1258     r953      1
    c1258     r4163     -1
    c1258     r4164     1
    c1258     r6406     6.103515625e-05
    c1259     Obj       -27.424
    c1259     r955      1
    c1259     r4177     -1
    c1259     r4178     1
    c1260     Obj       -0.001
    c1260     r956      1
    c1260     r4165     -1
    c1260     r4166     1
    c1260     r4286     0.03125
    c1261     Obj       -0.001
    c1261     r957      1
    c1261     r4167     1
    c1261     r4273     -1
    c1262     Obj       -0.034
    c1262     r959      1
    c1262     r4167     -1
    c1262     r4168     1
    c1263     Obj       -40.383
    c1263     r960      1
    c1263     r4175     -1
    c1263     r4176     1
    c1264     Obj       -26.647
    c1264     r961      1
    c1264     r4169     -1
    c1264     r4170     1
    c1265     Obj       -9.485
    c1265     r962      1
    c1265     r4170     -1
    c1265     r4171     1
    c1266     Obj       -5.799
    c1266     r963      1
    c1266     r4171     -1
    c1266     r4172     1
    c1267     Obj       -0.009
    c1267     r964      1
    c1267     r4173     -1
    c1267     r4174     1
    c1267     r7065     6.103515625e-05
    c1268     Obj       -0.087
    c1268     r965      1
    c1268     r4172     -1
    c1268     r4173     1
    c1269     Obj       -8.4
    c1269     r966      1
    c1269     r4176     -1
    c1269     r4177     1
    c1270     Obj       -16.715
    c1270     r967      1
    c1270     r3785     1
    c1270     r4178     -1
    c1271     Obj       -1.658
    c1271     r3787     -1
    c1271     r4180     1
    c1271     r4901     0.0008
    c1271     r5633     0.0001
    c1271     r6856     0.0001
    c1271     r7024     6.103515625e-05
    c1272     Obj       -12.325
    c1272     r971      1
    c1272     r4181     -1
    c1272     r4283     1
    c1272     r4363     0.03125
    c1273     Obj       -30.9
    c1273     r4194     -1
    c1273     r4195     1
    c1273     r5164     0.0001
    c1273     r5628     6.103515625e-05
    c1273     r5683     5.40634142331716e-05
    c1273     r5797     6.103515625e-05
    c1273     r6083     6.103515625e-05
    c1274     Obj       -1.15
    c1274     r974      1
    c1274     r4191     1
    c1274     r4231     -1
    c1274     r6930     6.103515625e-05
    c1275     Obj       -31.399
    c1275     r975      1
    c1275     r3844     1
    c1275     r4189     -1
    c1275     r4986     6.103515625e-05
    c1275     r5005     0.00390625
    c1275     r5107     6.29493235275564e-05
    c1275     r5425     0.03125
    c1275     r5736     0.03125
    c1275     r6418     0.0009765625
    c1275     r6548     6.103515625e-05
    c1275     r6973     6.23550240463078e-05
    c1275     r7012     6.103515625e-05
    c1276     Obj       -19.696
    c1276     r3942     -1
    c1276     r4189     1
    c1277     Obj       -1.204
    c1277     r978      1
    c1277     r4191     -1
    c1277     r4192     1
    c1277     r7077     6.103515625e-05
    c1278     Obj       -16.5
    c1278     r979      1
    c1278     r3946     1
    c1278     r4192     -1
    c1279     Obj       -0.019
    c1279     r980      1
    c1279     r3389     1
    c1279     r3946     -1
    c1279     r5657     0.03125
    c1279     r6143     6.103515625e-05
    c1279     r6367     0.03125
    c1279     r6416     6.103515625e-05
    c1279     r6421     6.103515625e-05
    c1279     r6443     6.103515625e-05
    c1279     r6466     6.103515625e-05
    c1279     r6467     6.103515625e-05
    c1279     r6878     9.00885318019727e-05
    c1280     Obj       -25.69
    c1280     r3858     1
    c1280     r4196     -1
    c1280     r4830     0.0001
    c1280     r4920     0.0002
    c1280     r5453     9.69360403065096e-05
    c1280     r6174     -0.0001
    c1280     r6440     -7.39420869012365e-05
    c1280     r6493     -7.83571103003273e-05
    c1281     Obj       -32.8
    c1281     r985      1
    c1281     r4119     1
    c1281     r4193     -1
    c1281     r5457     6.103515625e-05
    c1281     r5988     6.103515625e-05
    c1282     Obj       -16.595
    c1282     r986      1
    c1282     r3791     1
    c1282     r4198     -1
    c1283     Obj       -1.19
    c1283     r987      1
    c1283     r4197     -1
    c1283     r4198     1
    c1283     r7072     5.97309430545916e-05
    c1284     Obj       -0.454
    c1284     r988      1
    c1284     r3355     -1
    c1284     r4199     1
    c1285     Obj       -51.467
    c1285     r989      1
    c1285     r3840     1
    c1285     r4199     -1
    c1286     Obj       -1.424
    c1286     r990      1
    c1286     r3843     -1
    c1286     r4200     1
    c1286     r4888     0.03125
    c1286     r4918     6.103515625e-05
    c1287     Obj       -28.813
    c1287     r991      1
    c1287     r3262     1
    c1287     r4200     -1
    c1287     r4554     0.03125
    c1287     r4675     0.03125
    c1287     r5121     0.0256
    c1288     Obj       -57.099
    c1288     r3013     1
    c1288     r4208     -1
    c1288     r4716     0.03125
    c1288     r5376     6.103515625e-05
    c1288     r5522     6.103515625e-05
    c1288     r6150     6.103515625e-05
    c1288     r6413     6.103515625e-05
    c1288     r6491     6.103515625e-05
    c1288     r6696     0.0001
    c1288     r6704     6.103515625e-05
    c1288     r6758     0.000136246297338497
    c1288     r6795     6.103515625e-05
    c1289     Obj       -1.9
    c1289     r3015     1
    c1289     r3016     -1
    c1289     r4551     0.03125
    c1289     r4613     0.03125
    c1289     r4877     -0.03125
    c1289     r5613     -0.001953125
    c1290     Obj       -0.098
    c1290     r3016     1
    c1290     r3085     -1
    c1290     r4877     0.03125
    c1291     Obj       -1.076
    c1291     r3085     -1
    c1291     r4210     1
    c1291     r4793     0.03125
    c1291     r5042     0.03125
    c1291     r5595     0.00390625
    c1291     r6702     0.0009765625
    c1291     r6787     0.00390625
    c1291     r7064     0.00347545291922723
    c1292     Obj       -0.596
    c1292     r3017     -1
    c1292     r3018     1
    c1292     r4372     0.03125
    c1293     Obj       -6.885
    c1293     r3206     1
    c1293     r4214     -1
    c1293     r4435     1
    c1293     r5456     0.00185185185185185
    c1293     r6079     0.00264557902182827
    c1293     r6551     0.000825257769834793
    c1293     r6623     0.00642713085457048
    c1293     r6695     0.00213116957926213
    c1293     r6838     0.001953125
    c1294     Obj       -0.002
    c1294     r3020     -1
    c1294     r3212     1
    c1294     r6268     6.103515625e-05
    c1294     r6498     6.103515625e-05
    c1294     r6857     6.103515625e-05
    c1295     Obj       -0.002
    c1295     r3022     -1
    c1295     r3212     1
    c1295     r4881     0.03125
    c1295     r6900     6.103515625e-05
    c1296     Obj       -0.01
    c1296     r1508     1
    c1296     r3028     1
    c1296     r3037     -1
    c1296     r4598     0.0256
    c1296     r4631     0.0064
    c1296     r4642     6.103515625e-05
    c1297     Obj       -0.2
    c1297     r3029     1
    c1297     r3030     -1
    c1297     r4847     -0.0078125
    c1298     Obj       -0.53
    c1298     r1513     1
    c1298     r3032     -1
    c1298     r4274     1
    c1298     r7076     6.103515625e-05
    c1299     Obj       -0.789
    c1299     r1514     1
    c1299     r3032     1
    c1299     r3034     -1
    c1300     Obj       -0.01
    c1300     r3037     1
    c1300     r3038     -1
    c1301     Obj       -0.83
    c1301     r1518     1
    c1301     r3035     1
    c1301     r3036     -1
    c1302     Obj       -0.377
    c1302     r3042     -1
    c1302     r3139     1
    c1302     r5103     -6.103515625e-05
    c1303     Obj       -0.71
    c1303     r3043     -1
    c1303     r3115     1
    c1303     r6257     0.00057319972826087
    c1304     Obj       -4.856
    c1304     r3059     -1
    c1304     r3060     1
    c1304     r5210     0.0256
    c1304     r5704     0.00404434161793957
    c1304     r5787     1
    c1304     r5894     0.00342984041820218
    c1304     r6149     0.000936821907163993
    c1304     r6551     0.000669306529597942
    c1304     r6623     0.00445519304280995
    c1304     r6702     0.0009765625
    c1304     r6787     0.00390625
    c1305     Obj       -2.132
    c1305     r3045     -1
    c1305     r3181     1
    c1305     r4775     -1
    c1305     r5386     -0.00260906414255021
    c1305     r5402     -0.00163637344391139
    c1305     r5447     0.00390625
    c1305     r6149     0.00153245561100642
    c1305     r6426     0.00390625
    c1305     r6551     -0.000253221633483004
    c1306     Obj       -1.25
    c1306     r3045     1
    c1306     r3182     -1
    c1306     r6419     0.0064
    c1306     r6476     0.00390625
    c1307     Obj       -0.033
    c1307     r1525     1
    c1307     r3046     1
    c1307     r3185     -1
    c1307     r6412     0.00404992014222228
    c1307     r6566     -0.03125
    c1307     r6693     6.103515625e-05
    c1308     Obj       -3.113
    c1308     r3185     -1
    c1308     r4216     1
    c1308     r4775     1
    c1308     r5075     0.00390625
    c1308     r6412     0.00404992014222228
    c1308     r6454     0.00398870124598239
    c1308     r6577     0.001953125
    c1308     r6668     8.13802083333333e-05
    c1308     r6770     0.001953125
    c1308     r6877     6.103515625e-05
    c1309     Obj       -0.039
    c1309     r3184     1
    c1309     r3185     -1
    c1309     r5349     0.00390625
    c1309     r6412     0.00404992014222228
    c1309     r6454     0.00398870124598239
    c1309     r6523     -0.00390625
    c1309     r6577     0.001953125
    c1309     r6668     8.13802083333333e-05
    c1309     r6721     0.00390625
    c1309     r6737     0.0032286767807064
    c1309     r6754     6.103515625e-05
    c1309     r6764     6.103515625e-05
    c1309     r6770     0.001953125
    c1309     r6969     -0.00390625
    c1309     r7047     -6.103515625e-05
    c1310     Obj       -7.164
    c1310     r3048     1
    c1310     r3248     -1
    c1310     r4294     0.03125
    c1310     r6745     8.88674483022152e-05
    c1310     r7045     8.88674483022152e-05
    c1311     Obj       -1.915
    c1311     r1531     1
    c1311     r3049     -1
    c1311     r3086     1
    c1311     r5242     0.000498368277655441
    c1311     r6876     0.00024918413882772
    c1311     r6918     6.103515625e-05
    c1312     Obj       -0.435
    c1312     r3049     1
    c1312     r3094     -1
    c1312     r4819     0.0625
    c1312     r7060     7.17247353894615e-05
    c1313     Obj       -0.02
    c1313     r3063     -1
    c1313     r3076     1
    c1313     r4402     0.03125
    c1313     r4524     -0.03125
    c1313     r5109     0.0001
    c1313     r5112     6.73278217309408e-05
    c1313     r5802     0.0064
    c1313     r6351     -0.00390625
    c1313     r6687     0.00390625
    c1313     r6860     6.103515625e-05
    c1313     r6862     6.73278217309408e-05
    c1313     r6876     0.00024918413882772
    c1313     r6881     6.103515625e-05
    c1313     r6898     6.103515625e-05
    c1313     r6907     6.103515625e-05
    c1313     r7073     6.73278217309408e-05
    c1313     r7074     6.103515625e-05
    c1314     Obj       -0.8
    c1314     r3050     -1
    c1314     r3071     1
    c1314     r4718     -0.0256
    c1314     r4719     -0.0256
    c1314     r4911     -0.0256
    c1314     r6888     -0.0001
    c1314     r6901     -0.0001
    c1315     Obj       -0.285
    c1315     r3017     1
    c1315     r3051     -1
    c1315     r4613     0.03125
    c1316     Obj       -0.134
    c1316     r3051     1
    c1316     r3064     -1
    c1316     r4769     0.03125
    c1316     r4784     -0.03125
    c1317     Obj       -1.652
    c1317     r3052     -1
    c1317     r3079     1
    c1317     r4727     0.00390625
    c1317     r5068     6.103515625e-05
    c1317     r5069     6.103515625e-05
    c1317     r5070     6.103515625e-05
    c1317     r5071     6.103515625e-05
    c1317     r5072     6.103515625e-05
    c1317     r5317     6.103515625e-05
    c1317     r5384     0.00390625
    c1317     r5613     0.001953125
    c1317     r5702     0.001953125
    c1317     r6702     0.0009765625
    c1317     r6787     0.00390625
    c1317     r6919     0.001953125
    c1317     r6948     6.31515315405316e-05
    c1317     r7068     0.001953125
    c1318     Obj       -0.187
    c1318     r3052     1
    c1318     r3065     -1
    c1318     r5595     0.00390625
    c1318     r7064     0.00347545291922723
    c1319     Obj       -1.069
    c1319     r3064     1
    c1319     r3065     -1
    c1319     r4784     0.03125
    c1320     Obj       -0.085
    c1320     r1540     1
    c1320     r3053     -1
    c1320     r3062     1
    c1321     Obj       -1.382
    c1321     r1541     1
    c1321     r3053     1
    c1321     r3069     -1
    c1322     Obj       -1.097
    c1322     r1542     1
    c1322     r3068     1
    c1322     r3069     -1
    c1322     r5748     0.03125
    c1322     r5847     0.03125
    c1322     r6299     0.03125
    c1323     Obj       -0.693
    c1323     r1543     1
    c1323     r3054     -1
    c1323     r3066     1
    c1324     Obj       -0.168
    c1324     r1544     1
    c1324     r3054     1
    c1324     r3055     -1
    c1325     Obj       -0.129
    c1325     r1545     1
    c1325     r3055     1
    c1325     r3056     -1
    c1326     Obj       -0.435
    c1326     r1546     1
    c1326     r3056     1
    c1326     r3057     -1
    c1327     Obj       -0.077
    c1327     r3057     1
    c1327     r3058     -1
    c1328     Obj       -0.29
    c1328     r3058     1
    c1328     r3073     -1
    c1328     r5009     0.0625
    c1328     r5077     0.0625
    c1329     Obj       -0.029
    c1329     r1549     1
    c1329     r3072     1
    c1329     r3073     -1
    c1329     r5077     0.0625
    c1330     Obj       -0.86
    c1330     r1550     1
    c1330     r3061     -1
    c1330     r3067     1
    c1330     r7075     6.103515625e-05
    c1331     Obj       -0.216
    c1331     r3060     -1
    c1331     r3079     1
    c1331     r4681     0.0128
    c1331     r4726     -0.00390625
    c1331     r4727     0.00390625
    c1331     r5136     -0.0511805189748131
    c1331     r5279     -0.03125
    c1331     r5280     0.0064
    c1331     r5317     6.103515625e-05
    c1331     r5384     0.00390625
    c1331     r5469     0.0256
    c1331     r6419     0.0064
    c1331     r6476     0.00390625
    c1331     r6551     0.000367942476134278
    c1331     r6746     6.103515625e-05
    c1331     r6787     0.00390625
    c1331     r6948     6.31515315405316e-05
    c1332     Obj       -1.29
    c1332     r1552     1
    c1332     r3077     -1
    c1332     r3084     1
    c1333     Obj       -1.63
    c1333     r1553     1
    c1333     r3076     -1
    c1333     r3095     1
    c1334     Obj       -0.004
    c1334     r1554     1
    c1334     r3061     1
    c1334     r3062     -1
    c1335     Obj       -2.444
    c1335     r3063     1
    c1335     r3199     -1
    c1335     r4524     0.03125
    c1335     r6351     0.00390625
    c1335     r7000     0.0064
    c1336     Obj       -0.127
    c1336     r1556     1
    c1336     r3066     -1
    c1336     r3067     1
    c1337     Obj       -0.09
    c1337     r1557     1
    c1337     r3068     -1
    c1337     r3072     1
    c1338     Obj       -0.023
    c1338     r3070     1
    c1338     r3088     -1
    c1338     r4427     0.03125
    c1339     Obj       -1.167
    c1339     r1559     1
    c1339     r3087     1
    c1339     r3088     -1
    c1339     r4427     0.03125
    c1339     r6898     6.103515625e-05
    c1340     Obj       -0.269
    c1340     r3069     1
    c1340     r3070     -1
    c1340     r4405     0.03125
    c1341     Obj       -0.045
    c1341     r3071     -1
    c1341     r3075     1
    c1341     r6888     0.0001
    c1342     Obj       -0.208
    c1342     r3073     1
    c1342     r3074     -1
    c1342     r4404     0.03125
    c1342     r4565     0.0256
    c1343     Obj       -0.056
    c1343     r3074     1
    c1343     r4209     -1
    c1343     r4562     0.03125
    c1344     Obj       -0.02
    c1344     r1564     1
    c1344     r3080     -1
    c1344     r3089     1
    c1344     r5536     1
    c1345     Obj       -1.067
    c1345     r3075     1
    c1345     r3087     -1
    c1345     r4400     0.03125
    c1345     r4565     0.0512
    c1345     r5674     0.03125
    c1346     Obj       -0.017
    c1346     r3087     -1
    c1346     r4209     1
    c1346     r4400     0.03125
    c1346     r4562     -0.03125
    c1347     Obj       -2.93
    c1347     r3076     1
    c1347     r3097     -1
    c1347     r4402     0.03125
    c1347     r4612     0.03125
    c1347     r5109     0.0001
    c1347     r6687     0.00390625
    c1347     r6862     6.73278217309408e-05
    c1347     r6918     6.103515625e-05
    c1347     r7074     6.103515625e-05
    c1347     r7083     0.0001
    c1348     Obj       -0.01
    c1348     r1568     1
    c1348     r3077     1
    c1348     r3078     -1
    c1349     Obj       -0.05
    c1349     r1569     1
    c1349     r3078     1
    c1349     r4211     -1
    c1350     Obj       -0.012
    c1350     r3079     -1
    c1350     r3093     1
    c1350     r4727     -0.00390625
    c1350     r5317     -6.103515625e-05
    c1350     r5384     -0.00390625
    c1350     r6948     -6.31515315405316e-05
    c1350     r7064     -0.00347545291922723
    c1351     Obj       -0.282
    c1351     r3080     1
    c1351     r3081     -1
    c1352     Obj       -1.267
    c1352     r1572     1
    c1352     r3081     1
    c1352     r3082     -1
    c1353     Obj       -0.33
    c1353     r1573     1
    c1353     r3082     1
    c1353     r3083     -1
    c1354     Obj       -0.17
    c1354     r1574     1
    c1354     r3083     1
    c1354     r3084     -1
    c1355     Obj       -0.145
    c1355     r1575     1
    c1355     r3086     -1
    c1355     r3088     1
    c1356     Obj       -0.344
    c1356     r1576     1
    c1356     r3089     1
    c1356     r3091     -1
    c1356     r4954     -0.03125
    c1356     r5393     0.0625
    c1357     Obj       -0.918
    c1357     r1577     1
    c1357     r3090     -1
    c1357     r4212     1
    c1358     Obj       -2.112
    c1358     r1578     1
    c1358     r3090     1
    c1358     r3096     -1
    c1358     r6687     0.00390625
    c1358     r6909     6.83101334359297e-05
    c1358     r7083     0.0001
    c1359     Obj       -0.01
    c1359     r1579     1
    c1359     r3091     1
    c1359     r3092     -1
    c1359     r4726     0.00390625
    c1359     r5044     -0.0256
    c1359     r5393     -0.0625
    c1359     r5459     -0.0256
    c1359     r5533     -0.0256
    c1359     r5534     -0.0256
    c1359     r5538     0.00390625
    c1359     r5714     -0.0256
    c1359     r5891     -0.0256
    c1359     r6005     -0.0256
    c1359     r6266     -0.0256
    c1359     r6326     -0.0256
    c1359     r6698     -0.03125
    c1359     r6869     5.43039518629256e-05
    c1359     r6928     5.36921498040993e-05
    c1360     Obj       -0.575
    c1360     r3092     1
    c1360     r3093     -1
    c1360     r4426     0.03125
    c1360     r5317     6.103515625e-05
    c1360     r6928     5.36921498040993e-05
    c1360     r7064     0.00347545291922723
    c1361     Obj       -0.75
    c1361     r3093     1
    c1361     r4210     -1
    c1361     r4793     -0.03125
    c1361     r7064     -0.00347545291922723
    c1362     Obj       -0.7
    c1362     r3094     1
    c1362     r3095     -1
    c1362     r6687     0.00390625
    c1363     Obj       -4.19
    c1363     r1583     1
    c1363     r4211     1
    c1363     r4212     -1
    c1363     r6907     6.103515625e-05
    c1364     Obj       -0.02
    c1364     r3096     1
    c1364     r3098     -1
    c1364     r7060     7.17247353894615e-05
    c1365     Obj       -0.05
    c1365     r3097     1
    c1365     r3098     -1
    c1365     r5112     6.73278217309408e-05
    c1365     r6860     6.103515625e-05
    c1365     r6876     0.00024918413882772
    c1365     r6898     6.103515625e-05
    c1365     r6907     6.103515625e-05
    c1366     Obj       -0.062
    c1366     r3042     1
    c1366     r3099     -1
    c1367     Obj       -0.964
    c1367     r3099     1
    c1367     r3140     -1
    c1368     Obj       -0.674
    c1368     r1588     1
    c1368     r3100     -1
    c1368     r3124     1
    c1369     Obj       -0.2
    c1369     r1589     1
    c1369     r3100     1
    c1369     r3123     -1
    c1370     Obj       -0.554
    c1370     r1590     1
    c1370     r3122     1
    c1370     r3123     -1
    c1371     Obj       -0.031
    c1371     r3102     1
    c1371     r3105     -1
    c1371     r6336     0.00057319972826087
    c1372     Obj       -0.006
    c1372     r3101     -1
    c1372     r3200     1
    c1372     r6182     0.00048828125
    c1372     r6703     6.103515625e-05
    c1372     r6837     0.00057319972826087
    c1372     r6839     0.00057319972826087
    c1372     r6845     7.06425419560185e-05
    c1372     r6852     6.103515625e-05
    c1372     r7020     7.06425419560185e-05
    c1372     r7050     6.103515625e-05
    c1373     Obj       -0.012
    c1373     r3101     -1
    c1373     r3202     1
    c1373     r5708     0.00057319972826087
    c1373     r6703     6.103515625e-05
    c1373     r6852     6.103515625e-05
    c1374     Obj       -0.023
    c1374     r3101     1
    c1374     r3102     -1
    c1374     r6429     0.00057319972826087
    c1375     Obj       -0.03
    c1375     r3044     -1
    c1375     r3103     1
    c1376     Obj       -0.013
    c1376     r3103     -1
    c1376     r3104     1
    c1377     Obj       -1.309
    c1377     r3104     -1
    c1377     r3112     1
    c1377     r4423     0.03125
    c1377     r5251     0.000189373101733534
    c1377     r5386     0.00266133669134465
    c1377     r6473     0.0256
    c1377     r6551     0.000158836332351568
    c1377     r6623     0.000205130517175296
    c1377     r6912     6.103515625e-05
    c1378     Obj       -9.464
    c1378     r1599     1
    c1378     r3105     1
    c1378     r3106     -1
    c1378     r5706     0.00057319972826087
    c1378     r6257     0.00057319972826087
    c1378     r6875     6.64990395569203e-05
    c1378     r7078     7.16499660326087e-05
    c1379     Obj       -0.111
    c1379     r1600     1
    c1379     r3106     1
    c1379     r3107     -1
    c1380     Obj       -0.589
    c1380     r1601     1
    c1380     r3107     1
    c1380     r3108     -1
    c1381     Obj       -2.183
    c1381     r1602     1
    c1381     r3108     1
    c1381     r3109     -1
    c1382     Obj       -1.22
    c1382     r1603     1
    c1382     r3109     1
    c1382     r3110     -1
    c1383     Obj       -0.854
    c1383     r1604     1
    c1383     r3110     1
    c1383     r3111     -1
    c1384     Obj       -2.189
    c1384     r1605     1
    c1384     r3111     1
    c1384     r3112     -1
    c1384     r5258     6.83101334359297e-05
    c1384     r5490     6.83135489426015e-05
    c1384     r5563     6.103515625e-05
    c1384     r6858     6.103515625e-05
    c1384     r6864     6.83135489426015e-05
    c1384     r6895     6.103515625e-05
    c1384     r6912     6.103515625e-05
    c1384     r7042     6.83101334359297e-05
    c1384     r7044     6.103515625e-05
    c1385     Obj       -0.004
    c1385     r3112     -1
    c1385     r3204     1
    c1385     r4593     -0.03125
    c1386     Obj       -0.3
    c1386     r3113     1
    c1386     r3137     -1
    c1386     r5258     -6.83101334359297e-05
    c1386     r5490     -6.83135489426015e-05
    c1386     r6858     -6.103515625e-05
    c1386     r6864     -6.83135489426015e-05
    c1386     r7042     -6.83101334359297e-05
    c1386     r7044     -6.103515625e-05
    c1387     Obj       -0.015
    c1387     r3113     -1
    c1387     r3203     1
    c1388     Obj       -0.99
    c1388     r3113     -1
    c1388     r3136     1
    c1388     r5103     6.103515625e-05
    c1388     r5258     6.83101334359297e-05
    c1388     r7042     6.83101334359297e-05
    c1388     r7044     6.103515625e-05
    c1389     Obj       -0.429
    c1389     r3114     -1
    c1389     r3201     1
    c1389     r4701     0.03125
    c1390     Obj       -0.748
    c1390     r3114     1
    c1390     r3115     -1
    c1390     r5706     0.00057319972826087
    c1390     r7078     7.16499660326087e-05
    c1391     Obj       -2.944
    c1391     r1612     1
    c1391     r3043     1
    c1391     r3116     -1
    c1391     r6336     0.00057319972826087
    c1391     r6429     0.00057319972826087
    c1391     r6875     6.64990395569203e-05
    c1392     Obj       -0.21
    c1392     r1613     1
    c1392     r3116     1
    c1392     r3117     -1
    c1393     Obj       -0.673
    c1393     r1614     1
    c1393     r3117     1
    c1393     r3118     -1
    c1394     Obj       -0.348
    c1394     r1615     1
    c1394     r3118     1
    c1394     r3119     -1
    c1395     Obj       -2.007
    c1395     r1616     1
    c1395     r3119     1
    c1395     r3120     -1
    c1396     Obj       -0.072
    c1396     r1617     1
    c1396     r3120     1
    c1396     r3121     -1
    c1397     Obj       -0.137
    c1397     r1618     1
    c1397     r3121     1
    c1397     r3122     -1
    c1398     Obj       -2.37
    c1398     r1619     1
    c1398     r3124     1
    c1398     r3125     -1
    c1399     Obj       -1.064
    c1399     r1620     1
    c1399     r3125     1
    c1399     r3126     -1
    c1400     Obj       -0.345
    c1400     r1621     1
    c1400     r3127     1
    c1400     r3128     -1
    c1401     Obj       -1.312
    c1401     r1622     1
    c1401     r3126     1
    c1401     r3127     -1
    c1402     Obj       -0.195
    c1402     r1623     1
    c1402     r3128     1
    c1402     r3130     -1
    c1403     Obj       -1.007
    c1403     r1624     1
    c1403     r3129     -1
    c1403     r3134     1
    c1404     Obj       -0.484
    c1404     r3129     1
    c1404     r3135     -1
    c1405     Obj       -0.489
    c1405     r1626     1
    c1405     r3130     1
    c1405     r3131     -1
    c1406     Obj       -0.218
    c1406     r1627     1
    c1406     r3131     1
    c1406     r3132     -1
    c1407     Obj       -0.256
    c1407     r1628     1
    c1407     r3132     1
    c1407     r3133     -1
    c1408     Obj       -0.912
    c1408     r1629     1
    c1408     r3133     1
    c1408     r3134     -1
    c1409     Obj       -0.029
    c1409     r3135     1
    c1409     r3136     -1
    c1409     r5490     6.83135489426015e-05
    c1409     r6858     6.103515625e-05
    c1409     r6864     6.83135489426015e-05
    c1410     Obj       -0.386
    c1410     r3137     1
    c1410     r3138     -1
    c1411     Obj       -0.855
    c1411     r3138     1
    c1411     r3139     -1
    c1412     Obj       -0.81
    c1412     r3140     1
    c1412     r3143     -1
    c1413     Obj       -0.022
    c1413     r1635     1
    c1413     r3141     1
    c1413     r3142     -1
    c1413     r4323     0.03125
    c1414     Obj       -0.018
    c1414     r1636     1
    c1414     r3143     1
    c1414     r3144     -1
    c1415     Obj       -0.373
    c1415     r3173     -1
    c1415     r3175     1
    c1415     r4575     1
    c1416     Obj       -0.069
    c1416     r3145     -1
    c1416     r4213     1
    c1416     r5374     0.00390625
    c1416     r6079     0.00256380382436432
    c1416     r6427     -0.00390625
    c1417     Obj       -0.007
    c1417     r1640     1
    c1417     r3146     1
    c1417     r3149     -1
    c1417     r7023     6.103515625e-05
    c1418     Obj       -0.711
    c1418     r3147     -1
    c1418     r3151     1
    c1419     Obj       -3.311
    c1419     r3147     1
    c1419     r3152     -1
    c1420     Obj       -0.175
    c1420     r3148     1
    c1420     r3152     -1
    c1420     r5599     1
    c1420     r6079     0.00154661451246507
    c1420     r6995     0.001953125
    c1421     Obj       -0.02
    c1421     r3148     -1
    c1421     r3155     1
    c1421     r5501     1
    c1422     Obj       -0.002
    c1422     r3149     1
    c1422     r3151     -1
    c1422     r4307     0.0256
    c1423     Obj       -0.005
    c1423     r1646     1
    c1423     r3150     1
    c1423     r3151     -1
    c1424     Obj       -0.264
    c1424     r3152     1
    c1424     r3153     -1
    c1425     Obj       -10.141
    c1425     r3153     1
    c1425     r3154     -1
    c1425     r4446     0.0128
    c1425     r4573     1
    c1425     r6309     0.001953125
    c1426     Obj       -0.005
    c1426     r1649     1
    c1426     r3154     1
    c1426     r3205     -1
    c1426     r6497     0.00426233915852427
    c1426     r6623     0.00185185185185185
    c1427     Obj       -0.114
    c1427     r3155     1
    c1427     r4213     -1
    c1427     r5278     1
    c1427     r6145     -0.001953125
    c1428     Obj       -4.971
    c1428     r1651     1
    c1428     r3196     1
    c1428     r3197     -1
    c1428     r5596     6.103515625e-05
    c1429     Obj       -0.045
    c1429     r3159     -1
    c1429     r3209     1
    c1429     r4676     -0.03125
    c1429     r5662     -0.0512
    c1429     r6913     -6.103515625e-05
    c1429     r6957     -0.03125
    c1429     r6958     -0.03125
    c1430     Obj       -0.01
    c1430     r3156     1
    c1430     r3159     -1
    c1430     r4520     -0.03125
    c1430     r5493     -0.03125
    c1430     r5662     -0.0512
    c1431     Obj       -0.218
    c1431     r3157     -1
    c1431     r3161     1
    c1431     r4766     0.03125
    c1431     r5260     -0.03125
    c1432     Obj       -2.861
    c1432     r3156     -1
    c1432     r3188     1
    c1432     r4520     0.03125
    c1432     r5662     0.0512
    c1432     r6879     6.103515625e-05
    c1433     Obj       -8.906
    c1433     r1656     1
    c1433     r3158     1
    c1433     r3189     -1
    c1433     r5260     0.03125
    c1433     r7009     0.0256
    c1434     Obj       -0.233
    c1434     r3157     1
    c1434     r3158     -1
    c1434     r4953     0.03125
    c1435     Obj       -5.656
    c1435     r3183     -1
    c1435     r3207     1
    c1435     r4284     0.0256
    c1435     r5894     0.00342984041820218
    c1435     r6693     6.103515625e-05
    c1436     Obj       -0.185
    c1436     r3165     -1
    c1436     r3171     1
    c1437     Obj       -3.302
    c1437     r3166     1
    c1437     r3172     -1
    c1438     Obj       -0.006
    c1438     r1661     1
    c1438     r3164     1
    c1438     r3172     -1
    c1438     r4293     0.03125
    c1439     Obj       -0.339
    c1439     r3159     1
    c1439     r3160     -1
    c1439     r5577     0.03125
    c1439     r5662     0.0512
    c1439     r6879     -6.103515625e-05
    c1440     Obj       -0.062
    c1440     r3160     1
    c1440     r3161     -1
    c1440     r4747     0.03125
    c1440     r4766     -0.03125
    c1440     r4953     -0.03125
    c1440     r6879     6.103515625e-05
    c1441     Obj       -1.061
    c1441     r3167     -1
    c1441     r3210     1
    c1442     Obj       -0.016
    c1442     r1667     1
    c1442     r3162     1
    c1442     r3163     -1
    c1443     Obj       -0.102
    c1443     r3165     1
    c1443     r3166     -1
    c1444     Obj       -1.515
    c1444     r3167     1
    c1444     r3170     -1
    c1445     Obj       -0.118
    c1445     r1671     1
    c1445     r3168     1
    c1445     r3169     -1
    c1445     r4352     0.0256
    c1446     Obj       -0.117
    c1446     r1672     1
    c1446     r3170     1
    c1446     r3171     -1
    c1446     r6865     0.0001
    c1447     Obj       -1.274
    c1447     r3174     1
    c1447     r3176     -1
    c1447     r4924     0.001953125
    c1448     Obj       -2.136
    c1448     r3173     1
    c1448     r3174     -1
    c1448     r4574     1
    c1448     r6149     0.000707762918134219
    c1449     Obj       -0.082
    c1449     r1676     1
    c1449     r3174     -1
    c1449     r3211     1
    c1450     Obj       -1.87
    c1450     r3175     -1
    c1450     r4214     1
    c1450     r4447     0.0296296296296296
    c1450     r6551     0.00185185185185185
    c1451     Obj       -9.252
    c1451     r3176     1
    c1451     r3179     -1
    c1451     r5302     0.0025769589173366
    c1451     r5374     0.00390625
    c1451     r6079     0.00568628918969133
    c1451     r6551     0.00152733467193501
    c1451     r6623     0.000836896509066478
    c1452     Obj       -2.852
    c1452     r3177     1
    c1452     r3179     -1
    c1452     r5456     0.000164819060872966
    c1452     r6149     0.000567883956579217
    c1452     r6497     0.000379357958104221
    c1452     r6623     0.000259263017476822
    c1452     r6695     0.00018967897905211
    c1453     Obj       -0.238
    c1453     r3178     1
    c1453     r3180     -1
    c1453     r5222     0.0064
    c1453     r5371     0.0078125
    c1453     r5386     0.013236540912039
    c1453     r5402     0.00480199426671502
    c1453     r5456     0.000889967394333517
    c1453     r5507     0.00390625
    c1453     r6079     0.0120318910265169
    c1453     r6149     0.00903901927376698
    c1453     r6426     0.00390625
    c1453     r6484     0.0037404446123921
    c1453     r6497     0.00204840515232588
    c1453     r6551     0.0042223661548416
    c1453     r6623     0.00160957237048107
    c1453     r6695     0.00102420257616294
    c1453     r6726     0.0131337086411538
    c1453     r6804     0.0078125
    c1454     Obj       -3.265
    c1454     r3180     -1
    c1454     r4215     1
    c1454     r5222     0.0064
    c1454     r5371     0.0078125
    c1454     r5447     0.00390625
    c1454     r5456     0.00412408552475608
    c1454     r6149     0.00221804872154806
    c1454     r6426     0.00390625
    c1454     r6497     0.00949225566164631
    c1454     r6551     0.00404746566756365
    c1454     r6623     0.009412957068257
    c1454     r6695     0.00474612783082316
    c1454     r6726     0.0131337086411538
    c1454     r6804     0.0078125
    c1455     Obj       -8.434
    c1455     r3179     1
    c1455     r4215     -1
    c1455     r5386     0.00769404235396505
    c1455     r5402     0.00480199426671502
    c1455     r6079     0.0102043069208978
    c1455     r6149     0.00646617202127254
    c1455     r6479     0.00390625
    c1455     r6484     0.0037404446123921
    c1455     r6551     0.00264936912097733
    c1455     r6623     0.000131116968981381
    c1455     r6694     0.00390625
    c1456     Obj       -4.532
    c1456     r3180     1
    c1456     r3181     -1
    c1456     r6549     0.00506399269796516
    c1456     r6623     0.00315949694316799
    c1457     Obj       -0.015
    c1457     r3182     1
    c1457     r4216     -1
    c1457     r5065     1
    c1457     r5349     0.00390625
    c1457     r6737     0.0032286767807064
    c1457     r6764     6.103515625e-05
    c1457     r7021     0.0001
    c1458     Obj       -2.241
    c1458     r3183     1
    c1458     r3184     -1
    c1458     r4728     0.0256
    c1458     r5439     0.0128
    c1458     r6774     0.03125
    c1458     r6877     6.103515625e-05
    c1458     r7021     0.0001
    c1459     Obj       -4.665
    c1459     r1687     1
    c1459     r3186     -1
    c1459     r4217     1
    c1460     Obj       -1.103
    c1460     r1688     1
    c1460     r3185     1
    c1460     r4217     -1
    c1460     r5600     6.103515625e-05
    c1460     r5901     0.0064
    c1460     r6361     6.103515625e-05
    c1460     r6453     0.00390625
    c1460     r6531     0.00390625
    c1460     r6577     0.001953125
    c1460     r6578     0.0032
    c1460     r6670     0.00364180422693394
    c1460     r6682     0.00390625
    c1460     r6770     0.001953125
    c1460     r6891     6.64933453830745e-05
    c1460     r7015     9.27182487500392e-05
    c1461     Obj       -9.52
    c1461     r1689     1
    c1461     r3186     1
    c1461     r3187     -1
    c1462     Obj       -6.01
    c1462     r1690     1
    c1462     r3187     1
    c1462     r3188     -1
    c1462     r5493     0.03125
    c1462     r5596     6.103515625e-05
    c1463     Obj       -0.002
    c1463     r3189     1
    c1463     r3190     -1
    c1463     r6825     0.0256
    c1464     Obj       -1.27
    c1464     r1692     1
    c1464     r3190     1
    c1464     r3191     -1
    c1465     Obj       -0.086
    c1465     r3191     1
    c1465     r3192     -1
    c1465     r5604     0.0256
    c1466     Obj       -3.14
    c1466     r1694     1
    c1466     r3192     1
    c1466     r3193     -1
    c1467     Obj       -6.681
    c1467     r1695     1
    c1467     r3193     1
    c1467     r3194     -1
    c1468     Obj       -3.455
    c1468     r1696     1
    c1468     r3194     1
    c1468     r3195     -1
    c1469     Obj       -0.02
    c1469     r3196     1
    c1469     r3208     -1
    c1469     r5596     6.103515625e-05
    c1470     Obj       -0.892
    c1470     r1698     1
    c1470     r3197     1
    c1470     r3198     -1
    c1471     Obj       -1.6
    c1471     r3029     -1
    c1472     Obj       -1
    c1472     r3232     1
    c1472     r4219     -1
    c1472     r5091     6.103515625e-05
    c1472     r7006     6.103515625e-05
    c1472     r7045     8.88674483022152e-05
    c1473     Obj       -3
    c1473     r3244     -1
    c1473     r4219     1
    c1474     Obj       -13.093
    c1474     r1703     1
    c1474     r3216     1
    c1474     r3234     -1
    c1474     r6893     6.103515625e-05
    c1475     Obj       -0.01
    c1475     r2996     -1
    c1475     r4276     1
    c1475     r4479     0.00321678596117403
    c1476     Obj       -1
    c1476     r3226     -1
    c1476     r4208     1
    c1476     r6092     6.45915125781014e-05
    c1476     r6095     7.32319388336948e-05
    c1476     r6759     8.39874478313481e-05
    c1476     r6812     8.39920286734662e-05
    c1477     Obj       -3.94
    c1477     r3227     -1
    c1477     r4224     1
    c1478     Obj       -14.215
    c1478     r1708     1
    c1478     r3227     1
    c1478     r4279     -1
    c1479     Obj       -16.185
    c1479     r1709     1
    c1479     r3240     -1
    c1479     r4279     1
    c1479     r7040     6.103515625e-05
    c1480     Obj       -21.404
    c1480     r1710     1
    c1480     r3228     -1
    c1480     r4222     1
    c1481     Obj       -0.468
    c1481     r3228     1
    c1481     r3230     -1
    c1481     r6897     6.103515625e-05
    c1482     Obj       -37.19
    c1482     r1712     1
    c1482     r3229     -1
    c1482     r3230     1
    c1482     r7055     6.103515625e-05
    c1483     Obj       -0.264
    c1483     r1713     1
    c1483     r3035     -1
    c1483     r4221     1
    c1483     r4475     0.03125
    c1483     r6915     6.103515625e-05
    c1484     Obj       -0.017
    c1484     r1714     1
    c1484     r3038     1
    c1484     r3231     -1
    c1485     Obj       -0.23
    c1485     r3233     -1
    c1485     r4277     1
    c1485     r4915     0.0001
    c1485     r6312     6.103515625e-05
    c1485     r6408     6.103515625e-05
    c1485     r6475     6.103515625e-05
    c1485     r6574     0.03125
    c1486     Obj       -25.255
    c1486     r1716     1
    c1486     r3231     1
    c1486     r4278     -1
    c1486     r6826     6.103515625e-05
    c1487     Obj       -0.752
    c1487     r1717     1
    c1487     r3216     -1
    c1487     r3229     1
    c1488     Obj       -13.566
    c1488     r3240     1
    c1488     r4222     -1
    c1488     r6947     6.103515625e-05
    c1489     Obj       -5.342
    c1489     r1719     1
    c1489     r3241     -1
    c1489     r3242     1
    c1490     Obj       -0.506
    c1490     r1720     1
    c1490     r3242     -1
    c1490     r3243     1
    c1491     Obj       -25.539
    c1491     r1721     1
    c1491     r3236     -1
    c1491     r4223     1
    c1491     r5388     6.103515625e-05
    c1491     r5565     6.103515625e-05
    c1491     r5999     6.103515625e-05
    c1491     r6268     6.103515625e-05
    c1491     r6347     6.103515625e-05
    c1491     r6442     6.103515625e-05
    c1491     r6498     6.103515625e-05
    c1491     r6555     9.59635558098634e-05
    c1491     r6727     6.103515625e-05
    c1491     r6857     6.103515625e-05
    c1492     Obj       -29.742
    c1492     r1722     1
    c1492     r3021     1
    c1492     r4223     -1
    c1492     r4841     0.0001
    c1492     r5801     0.00010141517852032
    c1492     r6092     6.55055977900566e-05
    c1492     r6178     0.00010141517852032
    c1492     r6727     6.103515625e-05
    c1493     Obj       -6.313
    c1493     r1723     1
    c1493     r3241     1
    c1493     r4224     -1
    c1493     r6854     6.103515625e-05
    c1493     r7025     6.103515625e-05
    c1494     Obj       -7.77
    c1494     r3237     -1
    c1494     r4278     1
    c1494     r6239     0.0001
    c1494     r6471     0.0001
    c1494     r6527     0.0001
    c1494     r6688     0.0001
    c1494     r7002     0.0001
    c1495     Obj       -0.008
    c1495     r3244     1
    c1495     r3245     -1
    c1495     r5087     0.0009765625
    c1495     r6691     6.103515625e-05
    c1496     Obj       -8.73
    c1496     r1727     1
    c1496     r3236     1
    c1496     r3243     -1
    c1496     r6630     6.103515625e-05
    c1496     r6716     0.00390625
    c1496     r6905     6.103515625e-05
    c1497     Obj       -46
    c1497     r1728     1
    c1497     r3246     -1
    c1497     r3247     1
    c1497     r4536     0.0256
    c1497     r6704     6.103515625e-05
    c1497     r6744     7.50525172634404e-05
    c1498     Obj       -4.531
    c1498     r3237     1
    c1498     r4277     -1
    c1498     r4449     0.0008
    c1498     r5088     0.0001
    c1498     r5977     8.16584644176811e-05
    c1498     r6081     8.16584644176811e-05
    c1498     r6413     6.103515625e-05
    c1498     r6634     6.103515625e-05
    c1498     r6709     0.03125
    c1498     r6781     0.000581138962555129
    c1498     r6978     0.0001
    c1499     Obj       -87.8
    c1499     r1730     1
    c1499     r3235     -1
    c1499     r3246     1
    c1499     r4717     0.03125
    c1499     r6095     7.32319388336948e-05
    c1499     r7049     0.000488357173027066
    c1500     Obj       -56.8
    c1500     r3040     1
    c1500     r4220     -1
    c1500     r5376     6.103515625e-05
    c1500     r5647     0.03125
    c1500     r5977     8.16584644176811e-05
    c1500     r6081     8.16584644176811e-05
    c1500     r6354     6.103515625e-05
    c1500     r6413     6.103515625e-05
    c1500     r6758     0.000272492594676994
    c1501     Obj       -65
    c1501     r1733     1
    c1501     r3247     -1
    c1501     r3249     1
    c1501     r4556     0.03125
    c1502     Obj       -0.01
    c1502     r1734     1
    c1502     r3213     1
    c1502     r4275     -1
    c1502     r4334     0.03125
    c1502     r5463     6.103515625e-05
    c1502     r6011     5.78832137753131e-05
    c1502     r6225     6.103515625e-05
    c1502     r6474     6.103515625e-05
    c1502     r6530     6.103515625e-05
    c1502     r7038     6.103515625e-05
    c1503     Obj       -0.02
    c1503     r1735     1
    c1503     r3251     1
    c1503     r3252     -1
    c1503     r4387     0.0256
    c1503     r5190     6.95478079421149e-05
    c1503     r6359     0.0001
    c1503     r6841     6.103515625e-05
    c1503     r7016     6.103515625e-05
    c1504     Obj       -27
    c1504     r1737     1
    c1504     r4226     1
    c1504     r4227     -1
    c1504     r4627     0.03125
    c1504     r5190     6.95478079421149e-05
    c1504     r6359     0.0001
    c1505     Obj       -0.02
    c1505     r3253     1
    c1505     r3257     -1
    c1505     r5319     6.103515625e-05
    c1505     r5561     6.103515625e-05
    c1505     r5640     6.103515625e-05
    c1505     r6540     6.103515625e-05
    c1505     r6564     6.103515625e-05
    c1505     r6636     6.45772165793789e-05
    c1505     r6882     6.45772165793789e-05
    c1505     r7032     6.27562463049122e-05
    c1506     Obj       -0.7
    c1506     r1739     1
    c1506     r3254     1
    c1506     r3923     -1
    c1506     r4833     0.0001
    c1506     r4979     0.0009765625
    c1506     r4990     6.103515625e-05
    c1506     r5640     6.103515625e-05
    c1506     r6564     6.103515625e-05
    c1506     r6841     6.103515625e-05
    c1506     r6844     6.103515625e-05
    c1506     r7016     6.103515625e-05
    c1507     Obj       -0.011
    c1507     r3264     1
    c1507     r4228     -1
    c1507     r4350     0.03125
    c1507     r5576     -0.03125
    c1507     r6478     -0.0001220703125
    c1507     r6541     -6.103515625e-05
    c1507     r6542     -0.000116344435088454
    c1508     Obj       -7.984
    c1508     r1742     1
    c1508     r3271     -1
    c1508     r3272     1
    c1508     r5000     6.103515625e-05
    c1508     r5216     6.103515625e-05
    c1508     r5217     6.103515625e-05
    c1508     r5603     0.001953125
    c1508     r5646     6.103515625e-05
    c1508     r5731     6.103515625e-05
    c1508     r6084     6.50450124635623e-05
    c1508     r6660     0.0001220703125
    c1508     r6665     6.103515625e-05
    c1508     r6756     6.103515625e-05
    c1508     r6798     6.103515625e-05
    c1508     r6906     0.001953125
    c1509     Obj       -0.011
    c1509     r3280     -1
    c1509     r3282     1
    c1509     r4287     0.0256
    c1509     r4390     0.03125
    c1510     Obj       -0.011
    c1510     r1745     1
    c1510     r3280     1
    c1510     r3283     -1
    c1511     Obj       -13.451
    c1511     r1746     1
    c1511     r3281     1
    c1511     r3284     -1
    c1511     r4535     0.0001
    c1511     r6843     6.103515625e-05
    c1512     Obj       -4.24
    c1512     r1747     1
    c1512     r3283     1
    c1512     r3288     -1
    c1513     Obj       -11.367
    c1513     r1748     1
    c1513     r3287     1
    c1513     r3288     -1
    c1514     Obj       -14.153
    c1514     r1749     1
    c1514     r3284     1
    c1514     r3285     -1
    c1515     Obj       -8.978
    c1515     r1750     1
    c1515     r3285     1
    c1515     r3286     -1
    c1516     Obj       -12.27
    c1516     r3286     1
    c1516     r3287     -1
    c1517     Obj       -0.01
    c1517     r1752     1
    c1517     r3291     1
    c1517     r3309     -1
    c1518     Obj       -0.03
    c1518     r1753     1
    c1518     r3293     1
    c1518     r3310     -1
    c1519     Obj       -0.05
    c1519     r1754     1
    c1519     r3295     -1
    c1519     r3312     1
    c1519     r4325     0.03125
    c1519     r4559     0.03125
    c1519     r4737     6.103515625e-05
    c1520     Obj       -0.05
    c1520     r1756     1
    c1520     r3294     1
    c1520     r3313     -1
    c1520     r5574     0.03125
    c1520     r5610     6.103515625e-05
    c1520     r6403     0.00575912023495001
    c1520     r6557     6.103515625e-05
    c1520     r6561     6.103515625e-05
    c1520     r7005     6.103515625e-05
    c1520     r7022     8.9986253671094e-05
    c1521     Obj       -4.255
    c1521     r3315     -1
    c1521     r3316     1
    c1521     r4599     0.03125
    c1521     r5079     0.03125
    c1522     Obj       -37.21
    c1522     r1760     1
    c1522     r3318     1
    c1522     r3319     -1
    c1523     Obj       -0.01
    c1523     r1762     1
    c1523     r3309     1
    c1523     r3747     -1
    c1524     Obj       -0.001
    c1524     r1763     1
    c1524     r3355     -1
    c1524     r3356     1
    c1525     Obj       -0.001
    c1525     r3392     1
    c1525     r3396     -1
    c1525     r4431     0.03125
    c1525     r4887     0.03125
    c1526     Obj       -0.001
    c1526     r1765     1
    c1526     r3394     1
    c1526     r3396     -1
    c1526     r4431     0.03125
    c1526     r4993     6.103515625e-05
    c1527     Obj       -0.001
    c1527     r1766     1
    c1527     r3393     -1
    c1527     r3397     1
    c1527     r4385     0.0256
    c1527     r4887     0.03125
    c1527     r5003     6.103515625e-05
    c1527     r5053     0.03125
    c1528     Obj       -0.011
    c1528     r3400     -1
    c1528     r3401     1
    c1529     Obj       -78.621
    c1529     r1768     1
    c1529     r3402     1
    c1529     r4231     -1
    c1529     r4690     6.103515625e-05
    c1529     r6552     0.000104380588267577
    c1529     r6700     6.09866996136888e-05
    c1529     r6824     6.103515625e-05
    c1529     r6930     6.103515625e-05
    c1529     r7077     6.103515625e-05
    c1530     Obj       -11.796
    c1530     r3450     -1
    c1530     r3459     1
    c1530     r4711     0.03125
    c1530     r6980     6.103515625e-05
    c1531     Obj       -10.09
    c1531     r3447     1
    c1531     r3449     -1
    c1531     r4670     0.03125
    c1531     r7059     6.16585468489889e-05
    c1532     Obj       -20.205
    c1532     r1771     1
    c1532     r3448     -1
    c1532     r3449     1
    c1532     r4563     0.03125
    c1532     r5046     0.03125
    c1532     r5292     0.03125
    c1533     Obj       -14.014
    c1533     r1772     1
    c1533     r4020     1
    c1533     r4026     -1
    c1534     Obj       -8.743
    c1534     r1773     1
    c1534     r4025     1
    c1534     r4263     -1
    c1535     Obj       -4.37
    c1535     r1774     1
    c1535     r3408     -1
    c1535     r3488     1
    c1536     Obj       -9.736
    c1536     r1775     1
    c1536     r3407     -1
    c1536     r3408     1
    c1537     Obj       -0.001
    c1537     r1776     1
    c1537     r3395     1
    c1537     r3411     -1
    c1537     r4324     0.0256
    c1537     r4994     6.103515625e-05
    c1538     Obj       -0.001
    c1538     r1778     1
    c1538     r3398     -1
    c1538     r3763     1
    c1538     r4714     0.03125
    c1538     r4741     6.103515625e-05
    c1539     Obj       -5.871
    c1539     r1779     1
    c1539     r3392     -1
    c1539     r3409     1
    c1540     Obj       -17.858
    c1540     r1780     1
    c1540     r3391     1
    c1540     r3410     -1
    c1540     r4887     0.03125
    c1540     r5053     0.03125
    c1540     r6389     0.03125
    c1540     r6470     6.103515625e-05
    c1540     r6525     6.103515625e-05
    c1540     r6769     0.0256
    c1541     Obj       -0.001
    c1541     r3412     1
    c1541     r3764     -1
    c1541     r4722     0.0128
    c1541     r4809     6.103515625e-05
    c1542     Obj       -85
    c1542     r1782     1
    c1542     r3764     -1
    c1542     r4148     1
    c1542     r4606     0.03125
    c1542     r4749     0.03125
    c1542     r4780     6.103515625e-05
    c1542     r4917     6.103515625e-05
    c1542     r5017     6.103515625e-05
    c1542     r5449     6.103515625e-05
    c1542     r6488     0.0009765625
    c1542     r6866     6.103515625e-05
    c1542     r7035     6.72799219169098e-05
    c1543     Obj       -0.001
    c1543     r1783     1
    c1543     r3413     1
    c1543     r3415     -1
    c1543     r4336     0.0256
    c1543     r4803     6.103515625e-05
    c1543     r4809     6.103515625e-05
    c1543     r4917     6.103515625e-05
    c1543     r5449     6.103515625e-05
    c1544     Obj       -0.001
    c1544     r1785     1
    c1544     r3414     -1
    c1544     r3416     1
    c1544     r4794     0.03125
    c1544     r4917     6.103515625e-05
    c1544     r5011     6.103515625e-05
    c1544     r5449     6.103515625e-05
    c1545     Obj       -0.05
    c1545     r3403     -1
    c1545     r3420     1
    c1545     r4839     0.0001
    c1545     r6486     6.103515625e-05
    c1545     r6736     6.103515625e-05
    c1545     r6753     0.0001
    c1545     r6848     5.45780865745698e-05
    c1545     r6886     0.0001
    c1546     Obj       -29.795
    c1546     r1787     1
    c1546     r3417     1
    c1546     r3419     -1
    c1546     r4935     0.03125
    c1547     Obj       -20.205
    c1547     r1788     1
    c1547     r3417     -1
    c1547     r3418     1
    c1547     r4386     0.03125
    c1547     r6903     6.103515625e-05
    c1548     Obj       -10.125
    c1548     r3419     1
    c1548     r3420     -1
    c1548     r5046     0.03125
    c1548     r5292     0.03125
    c1548     r5898     0.0001
    c1548     r6444     5.45780865745681e-05
    c1548     r6675     6.103515625e-05
    c1548     r6736     6.103515625e-05
    c1548     r6848     5.45780865745698e-05
    c1548     r7059     6.16585468489889e-05
    c1549     Obj       -0.001
    c1549     r3421     -1
    c1549     r4054     1
    c1549     r5085     6.103515625e-05
    c1549     r5631     6.103515625e-05
    c1549     r6360     6.103515625e-05
    c1550     Obj       -0.001
    c1550     r1792     1
    c1550     r3422     1
    c1550     r4053     -1
    c1550     r5294     6.103515625e-05
    c1550     r5404     6.103515625e-05
    c1550     r6345     6.103515625e-05
    c1550     r6495     6.103515625e-05
    c1550     r6640     8.39055367669584e-05
    c1550     r6807     5.7205257543362e-05
    c1550     r7027     6.103515625e-05
    c1551     Obj       -0.019
    c1551     r3381     -1
    c1551     r3791     1
    c1551     r4928     0.0001
    c1551     r7039     6.43432485566951e-05
    c1552     Obj       -10.615
    c1552     r1795     1
    c1552     r4116     -1
    c1552     r4267     1
    c1552     r5487     6.103515625e-05
    c1552     r6920     6.103515625e-05
    c1552     r7086     6.75209328895683e-05
    c1553     Obj       -17.30686
    c1553     r1796     1
    c1553     r3431     -1
    c1553     r3432     1
    c1553     r4337     0.03125
    c1554     Obj       -17.26719
    c1554     r1799     1
    c1554     r3433     -1
    c1554     r3434     1
    c1554     r4304     0.0256
    c1555     Obj       -0.029
    c1555     r3435     -1
    c1555     r3436     1
    c1555     r5383     0.0001220703125
    c1555     r5419     0.03125
    c1555     r6485     -8.85484805643365e-05
    c1555     r6541     6.103515625e-05
    c1556     Obj       -0.252
    c1556     r3435     -1
    c1556     r4029     1
    c1556     r4751     0.03125
    c1556     r5162     0.0001220703125
    c1556     r5383     0.0001220703125
    c1556     r5969     0.000244140625
    c1556     r6170     0.000116344435088454
    c1556     r6410     6.103515625e-05
    c1556     r6541     6.103515625e-05
    c1556     r6542     0.000116344435088454
    c1556     r6684     6.103515625e-05
    c1557     Obj       -0.009
    c1557     r4152     1
    c1557     r4233     -1
    c1557     r4308     0.03125
    c1557     r4967     0.0256
    c1557     r5980     0.0001
    c1557     r6689     0.0001
    c1558     Obj       -2.55
    c1558     r3438     -1
    c1558     r4234     1
    c1558     r4914     6.103515625e-05
    c1558     r4992     6.103515625e-05
    c1559     Obj       -2.55
    c1559     r3439     -1
    c1559     r4234     1
    c1559     r4817     6.103515625e-05
    c1559     r4976     0.0009765625
    c1560     Obj       -8.403
    c1560     r3440     1
    c1560     r4235     -1
    c1560     r5172     6.103515625e-05
    c1560     r5473     5.84042810005303e-05
    c1561     Obj       -8.403
    c1561     r3441     1
    c1561     r3442     -1
    c1562     Obj       -5.7
    c1562     r1809     1
    c1562     r3442     1
    c1562     r3465     -1
    c1563     Obj       -7.864
    c1563     r3447     -1
    c1563     r3450     1
    c1563     r4711     -0.03125
    c1563     r4903     -6.103515625e-05
    c1563     r5110     6.103515625e-05
    c1564     Obj       -29.795
    c1564     r3448     1
    c1564     r3458     -1
    c1564     r4935     0.03125
    c1564     r5150     6.103515625e-05
    c1565     Obj       -18.21
    c1565     r3451     1
    c1565     r3459     -1
    c1566     Obj       -9.382
    c1566     r1814     1
    c1566     r3451     -1
    c1566     r3460     1
    c1566     r4903     6.103515625e-05
    c1566     r6967     0.000177260411490202
    c1566     r6982     6.103515625e-05
    c1567     Obj       -16.791
    c1567     r3452     1
    c1567     r3460     -1
    c1568     Obj       -9.345
    c1568     r1816     1
    c1568     r3452     -1
    c1568     r3462     1
    c1568     r6818     6.103515625e-05
    c1568     r6980     6.103515625e-05
    c1569     Obj       -7.973
    c1569     r3453     -1
    c1569     r3461     1
    c1569     r4409     0.03125
    c1569     r5294     6.103515625e-05
    c1569     r6356     6.103515625e-05
    c1569     r6433     6.103515625e-05
    c1569     r6495     6.103515625e-05
    c1569     r6496     0.000177037363798893
    c1569     r6521     0.000244140625
    c1569     r6596     6.103515625e-05
    c1569     r6669     6.103515625e-05
    c1569     r6747     0.0001220703125
    c1569     r6779     -0.0001220703125
    c1569     r6979     6.103515625e-05
    c1570     Obj       -10.824
    c1570     r1818     1
    c1570     r3453     1
    c1570     r3462     -1
    c1570     r6750     0.000116701433279395
    c1570     r6779     0.0001220703125
    c1570     r6807     5.7205257543362e-05
    c1571     Obj       -5.636
    c1571     r3454     -1
    c1571     r3455     1
    c1571     r5314     6.103515625e-05
    c1572     Obj       -1.069
    c1572     r3454     1
    c1572     r4197     -1
    c1572     r5408     6.103515625e-05
    c1573     Obj       -65.422
    c1573     r3455     -1
    c1573     r3456     1
    c1573     r4849     6.103515625e-05
    c1573     r5073     6.29882981875534e-05
    c1573     r5132     0.0078125
    c1573     r6671     0.00390625
    c1573     r6929     5.1541002549239e-05
    c1574     Obj       -7.563
    c1574     r1822     1
    c1574     r3456     -1
    c1574     r4232     1
    c1574     r4927     0.0001
    c1574     r4928     0.0001
    c1574     r5808     6.07820559700624e-05
    c1574     r6139     6.103515625e-05
    c1574     r6261     9.31210667174636e-05
    c1574     r6357     7.89594079600832e-05
    c1574     r6552     0.000104380588267577
    c1574     r6666     0.0078125
    c1574     r6700     6.09866996136888e-05
    c1574     r6824     6.103515625e-05
    c1574     r6847     0.0001
    c1574     r6878     9.00885318019727e-05
    c1574     r6904     0.0001
    c1574     r6929     5.15410025492391e-05
    c1574     r7039     6.43432485566951e-05
    c1574     r7048     0.000105419978435289
    c1575     Obj       -8.306
    c1575     r3457     1
    c1575     r4196     -1
    c1576     Obj       -3.604
    c1576     r3457     -1
    c1576     r3464     1
    c1577     Obj       -15.234
    c1577     r3466     1
    c1577     r3467     -1
    c1577     r4406     0.03125
    c1577     r4538     0.0256
    c1577     r4829     0.0001
    c1578     Obj       -16.302
    c1578     r3468     1
    c1578     r3469     -1
    c1578     r4816     0.0001
    c1579     Obj       -16.302
    c1579     r1829     1
    c1579     r3470     1
    c1579     r3471     -1
    c1579     r5023     6.103515625e-05
    c1579     r5095     0.0001
    c1579     r5177     6.103515625e-05
    c1579     r5546     6.4794297397813e-05
    c1579     r5642     5.30794884282887e-05
    c1579     r6366     0.03125
    c1579     r6420     8.77414092738715e-05
    c1579     r6649     0.03125
    c1579     r6672     0.000104347826086957
    c1579     r6679     0.00010823311630947
    c1579     r6711     0.03125
    c1580     Obj       -15.234
    c1580     r3472     1
    c1580     r3473     -1
    c1580     r4571     0.0016
    c1580     r4829     0.0001
    c1580     r5234     6.103515625e-05
    c1580     r5680     0.0009765625
    c1581     Obj       -1.011
    c1581     r1833     1
    c1581     r3475     -1
    c1581     r3910     1
    c1581     r4961     0.03125
    c1581     r5051     0.03125
    c1581     r5287     6.103515625e-05
    c1581     r5441     6.103515625e-05
    c1581     r5909     6.103515625e-05
    c1581     r6065     6.103515625e-05
    c1581     r6086     6.87890538701883e-05
    c1581     r6282     0.03125
    c1581     r6436     6.103515625e-05
    c1581     r6437     6.103515625e-05
    c1581     r6522     0.0008
    c1581     r6524     5.89741767886658e-05
    c1581     r6532     6.103515625e-05
    c1581     r6675     6.103515625e-05
    c1581     r6736     6.103515625e-05
    c1581     r6765     6.103515625e-05
    c1581     r6848     5.45780865745698e-05
    c1581     r6883     6.103515625e-05
    c1581     r6886     0.0001
    c1582     Obj       -10.21
    c1582     r3475     1
    c1582     r4259     -1
    c1582     r5175     0.0001
    c1582     r5558     0.0001
    c1583     Obj       -10.559
    c1583     r1835     1
    c1583     r3477     1
    c1583     r3633     -1
    c1584     Obj       -4.698
    c1584     r3601     -1
    c1584     r4236     1
    c1584     r5277     0.0256
    c1584     r5572     0.0256
    c1585     Obj       -2
    c1585     r3479     1
    c1585     r3480     -1
    c1585     r5195     0.03125
    c1586     Obj       -2.351
    c1586     r1840     1
    c1586     r3480     -1
    c1586     r3736     1
    c1586     r4376     0.03125
    c1587     Obj       -1.32
    c1587     r4237     -1
    c1587     r4244     1
    c1587     r5664     0.0256
    c1587     r6392     6.103515625e-05
    c1587     r6971     0.0256
    c1588     Obj       -0.003
    c1588     r1842     1
    c1588     r3482     -1
    c1588     r3525     1
    c1589     Obj       -0.018
    c1589     r3483     -1
    c1589     r3732     1
    c1590     Obj       -0.081
    c1590     r1844     1
    c1590     r3483     -1
    c1590     r3512     1
    c1591     Obj       -8.731
    c1591     r1845     1
    c1591     r3488     -1
    c1591     r3694     1
    c1592     Obj       -21.069
    c1592     r3670     1
    c1592     r3671     -1
    c1592     r4373     0.0256
    c1592     r5104     -6.103515625e-05
    c1593     Obj       -0.001
    c1593     r1847     1
    c1593     r3494     -1
    c1593     r3772     1
    c1593     r4357     0.03125
    c1593     r6556     6.03358541432804e-05
    c1593     r6692     8.46071103003263e-05
    c1593     r6755     8.46071103003263e-05
    c1593     r6791     6.103515625e-05
    c1593     r6998     8.46071103003263e-05
    c1593     r7003     6.103515625e-05
    c1594     Obj       -3.058
    c1594     r1848     1
    c1594     r3495     -1
    c1594     r4026     1
    c1594     r7056     6.103515625e-05
    c1595     Obj       -8.042
    c1595     r1849     1
    c1595     r3495     1
    c1595     r4238     -1
    c1595     r6902     6.103515625e-05
    c1596     Obj       -12.27
    c1596     r1850     1
    c1596     r3684     1
    c1596     r3685     -1
    c1597     Obj       -0.681
    c1597     r1851     1
    c1597     r3508     -1
    c1597     r3513     1
    c1598     Obj       -0.012
    c1598     r3508     1
    c1598     r3509     -1
    c1599     Obj       -0.032
    c1599     r1853     1
    c1599     r3509     1
    c1599     r3510     -1
    c1600     Obj       -0.027
    c1600     r1854     1
    c1600     r3511     1
    c1600     r3512     -1
    c1601     Obj       -0.045
    c1601     r1855     1
    c1601     r3510     1
    c1601     r3511     -1
    c1602     Obj       -0.045
    c1602     r1856     1
    c1602     r3513     -1
    c1602     r3519     1
    c1603     Obj       -0.004
    c1603     r3516     1
    c1603     r3517     -1
    c1604     Obj       -0.01
    c1604     r1858     1
    c1604     r3514     1
    c1604     r3515     -1
    c1604     r4349     0.0256
    c1605     Obj       -0.011
    c1605     r1859     1
    c1605     r3516     -1
    c1605     r4240     1
    c1606     Obj       -0.013
    c1606     r3517     1
    c1606     r3518     -1
    c1607     Obj       -0.02
    c1607     r1862     1
    c1607     r3518     1
    c1607     r3519     -1
    c1608     Obj       -1.067
    c1608     r1863     1
    c1608     r3522     1
    c1608     r3526     -1
    c1608     r7053     6.103515625e-05
    c1609     Obj       -4.496
    c1609     r1864     1
    c1609     r3520     -1
    c1609     r3533     1
    c1609     r7011     6.103515625e-05
    c1610     Obj       -0.037
    c1610     r3520     1
    c1610     r3535     -1
    c1611     Obj       -0.657
    c1611     r1866     1
    c1611     r3534     1
    c1611     r3535     -1
    c1611     r6820     6.103515625e-05
    c1612     Obj       -0.072
    c1612     r1867     1
    c1612     r3521     -1
    c1612     r3522     1
    c1613     Obj       -0.964
    c1613     r1868     1
    c1613     r3521     1
    c1613     r3523     -1
    c1613     r6921     6.103515625e-05
    c1614     Obj       -0.002
    c1614     r1869     1
    c1614     r3523     -1
    c1614     r3526     1
    c1614     r7067     6.103515625e-05
    c1615     Obj       -3.45
    c1615     r3524     1
    c1615     r3525     -1
    c1616     Obj       -0.105
    c1616     r1871     1
    c1616     r3523     1
    c1616     r3524     -1
    c1617     Obj       -0.025
    c1617     r1872     1
    c1617     r3482     1
    c1617     r3733     -1
    c1618     Obj       -0.088
    c1618     r1873     1
    c1618     r3527     -1
    c1618     r3528     1
    c1619     Obj       -0.623
    c1619     r1874     1
    c1619     r3527     1
    c1619     r3542     -1
    c1620     Obj       -0.02
    c1620     r1875     1
    c1620     r3528     -1
    c1620     r3541     1
    c1621     Obj       -6.043
    c1621     r1876     1
    c1621     r3529     -1
    c1621     r3532     1
    c1622     Obj       -0.167
    c1622     r1877     1
    c1622     r3529     1
    c1622     r3530     -1
    c1623     Obj       -0.02
    c1623     r3530     1
    c1623     r3533     -1
    c1624     Obj       -0.006
    c1624     r1879     1
    c1624     r3531     -1
    c1624     r3544     1
    c1625     Obj       -0.194
    c1625     r1880     1
    c1625     r3531     1
    c1625     r3532     -1
    c1626     Obj       -3.128
    c1626     r1881     1
    c1626     r3533     1
    c1626     r3534     -1
    c1626     r6821     6.103515625e-05
    c1627     Obj       -0.02
    c1627     r1882     1
    c1627     r3536     -1
    c1627     r3734     1
    c1628     Obj       -0.139
    c1628     r1883     1
    c1628     r3537     1
    c1628     r3538     -1
    c1629     Obj       -0.419
    c1629     r1884     1
    c1629     r3536     1
    c1629     r3537     -1
    c1630     Obj       -0.333
    c1630     r1885     1
    c1630     r3538     1
    c1630     r3539     -1
    c1631     Obj       -0.469
    c1631     r1886     1
    c1631     r3539     1
    c1631     r3540     -1
    c1632     Obj       -7.147
    c1632     r1887     1
    c1632     r3540     1
    c1632     r3541     -1
    c1633     Obj       -0.109
    c1633     r1888     1
    c1633     r3542     1
    c1633     r3543     -1
    c1634     Obj       -0.706
    c1634     r1889     1
    c1634     r3543     1
    c1634     r3544     -1
    c1635     Obj       -0.166
    c1635     r3545     1
    c1635     r3546     -1
    c1635     r4285     0.0256
    c1636     Obj       -2.187
    c1636     r3597     1
    c1636     r3598     -1
    c1636     r4662     0.03125
    c1637     Obj       -0.103
    c1637     r1892     1
    c1637     r3549     1
    c1637     r3550     -1
    c1638     Obj       -0.143
    c1638     r3548     -1
    c1638     r3738     1
    c1639     Obj       -0.087
    c1639     r3547     1
    c1639     r3548     -1
    c1640     Obj       -0.221
    c1640     r3546     1
    c1640     r3547     -1
    c1640     r4597     0.0256
    c1641     Obj       -1.16
    c1641     r1896     1
    c1641     r3548     1
    c1641     r3549     -1
    c1641     r4552     0.03125
    c1641     r4649     0.0002
    c1642     Obj       -0.533
    c1642     r1897     1
    c1642     r3550     1
    c1642     r3551     -1
    c1643     Obj       -0.85
    c1643     r1898     1
    c1643     r3551     1
    c1643     r3552     -1
    c1644     Obj       -1.116
    c1644     r1899     1
    c1644     r3552     1
    c1644     r3553     -1
    c1644     r5283     6.103515625e-05
    c1644     r6284     0.03125
    c1645     Obj       -0.069
    c1645     r3553     -1
    c1645     r3737     1
    c1646     Obj       -0.358
    c1646     r1901     1
    c1646     r3554     -1
    c1646     r3739     1
    c1646     r4592     0.03125
    c1647     Obj       -0.209
    c1647     r3554     -1
    c1647     r3555     1
    c1647     r4656     -0.03125
    c1648     Obj       -0.076
    c1648     r3555     1
    c1648     r3556     -1
    c1649     Obj       -0.474
    c1649     r1904     1
    c1649     r3556     1
    c1649     r3557     -1
    c1649     r4733     6.103515625e-05
    c1649     r4743     0.03125
    c1650     Obj       -1.556
    c1650     r1905     1
    c1650     r3557     1
    c1650     r3558     -1
    c1651     Obj       -0.005
    c1651     r1906     1
    c1651     r3558     1
    c1651     r3735     -1
    c1652     Obj       -0.189
    c1652     r3647     1
    c1652     r3648     -1
    c1652     r6391     6.103515625e-05
    c1652     r6593     -6.103515625e-05
    c1653     Obj       -1.214
    c1653     r1909     1
    c1653     r3579     1
    c1653     r3580     -1
    c1654     Obj       -0.098
    c1654     r3559     -1
    c1654     r3560     1
    c1654     r4370     0.03125
    c1654     r4553     0.03125
    c1654     r4997     6.103515625e-05
    c1655     Obj       -0.043
    c1655     r3560     1
    c1655     r3566     -1
    c1655     r4553     0.03125
    c1655     r4748     -0.03125
    c1655     r5687     -6.103515625e-05
    c1655     r6409     -6.103515625e-05
    c1656     Obj       -0.307
    c1656     r1912     1
    c1656     r3560     -1
    c1656     r3565     1
    c1656     r5002     6.103515625e-05
    c1656     r5345     0.03125
    c1656     r5687     6.103515625e-05
    c1656     r6409     6.103515625e-05
    c1657     Obj       -0.819
    c1657     r1913     1
    c1657     r3581     1
    c1657     r3582     -1
    c1658     Obj       -0.291
    c1658     r1914     1
    c1658     r3561     -1
    c1658     r3583     1
    c1659     Obj       -0.396
    c1659     r1915     1
    c1659     r3561     1
    c1659     r3584     -1
    c1660     Obj       -0.062
    c1660     r1916     1
    c1660     r3562     1
    c1660     r3588     -1
    c1661     Obj       -1.041
    c1661     r1917     1
    c1661     r3562     -1
    c1661     r3587     1
    c1662     Obj       -0.692
    c1662     r1918     1
    c1662     r3563     1
    c1662     r3564     -1
    c1663     Obj       -0.183
    c1663     r1919     1
    c1663     r3563     -1
    c1663     r3588     1
    c1664     Obj       -1.948
    c1664     r1920     1
    c1664     r3564     1
    c1664     r3565     -1
    c1664     r6483     6.103515625e-05
    c1665     Obj       -0.007
    c1665     r1921     1
    c1665     r3574     1
    c1665     r3575     -1
    c1665     r6940     6.103515625e-05
    c1666     Obj       -0.047
    c1666     r1922     1
    c1666     r3573     1
    c1666     r3575     -1
    c1666     r7082     6.103515625e-05
    c1667     Obj       -0.192
    c1667     r1923     1
    c1667     r3567     -1
    c1667     r4242     1
    c1667     r6950     0.03125
    c1667     r7080     6.103515625e-05
    c1668     Obj       -0.024
    c1668     r3566     1
    c1668     r3740     -1
    c1668     r4326     0.0256
    c1668     r5345     0.03125
    c1669     Obj       -0.75
    c1669     r1925     1
    c1669     r3567     1
    c1669     r3568     -1
    c1670     Obj       -0.009
    c1670     r1926     1
    c1670     r3568     1
    c1670     r3569     -1
    c1671     Obj       -1.229
    c1671     r1927     1
    c1671     r3569     1
    c1671     r3570     -1
    c1672     Obj       -0.092
    c1672     r1928     1
    c1672     r3570     1
    c1672     r3571     -1
    c1673     Obj       -0.631
    c1673     r1929     1
    c1673     r3571     1
    c1673     r4241     -1
    c1674     Obj       -0.177
    c1674     r1930     1
    c1674     r3572     -1
    c1674     r4241     1
    c1675     Obj       -0.045
    c1675     r1931     1
    c1675     r3572     1
    c1675     r3573     -1
    c1676     Obj       -0.026
    c1676     r3744     1
    c1676     r4242     -1
    c1676     r4584     6.103515625e-05
    c1676     r6916     6.103515625e-05
    c1677     Obj       -0.014
    c1677     r3574     1
    c1677     r3576     -1
    c1677     r6940     6.103515625e-05
    c1678     Obj       -0.009
    c1678     r3575     1
    c1678     r3576     -1
    c1679     Obj       -0.089
    c1679     r1935     1
    c1679     r3576     1
    c1679     r3577     -1
    c1679     r4300     0.03125
    c1679     r4415     0.03125
    c1680     Obj       -0.088
    c1680     r1936     1
    c1680     r3577     1
    c1680     r3578     -1
    c1681     Obj       -0.075
    c1681     r1937     1
    c1681     r3578     1
    c1681     r3579     -1
    c1682     Obj       -0.122
    c1682     r1938     1
    c1682     r3580     1
    c1682     r3581     -1
    c1683     Obj       -0.369
    c1683     r1939     1
    c1683     r3582     1
    c1683     r3583     -1
    c1684     Obj       -0.672
    c1684     r1940     1
    c1684     r3584     1
    c1684     r3585     -1
    c1685     Obj       -0.543
    c1685     r1941     1
    c1685     r3585     1
    c1685     r3586     -1
    c1686     Obj       -0.28
    c1686     r1942     1
    c1686     r3586     1
    c1686     r3587     -1
    c1687     Obj       -0.019
    c1687     r3476     1
    c1687     r3589     -1
    c1687     r4655     -0.03125
    c1688     Obj       -0.096
    c1688     r3590     1
    c1688     r3591     -1
    c1689     Obj       -0.134
    c1689     r3591     1
    c1689     r3592     -1
    c1689     r4289     0.03125
    c1690     Obj       -2.62
    c1690     r3594     -1
    c1690     r3595     1
    c1690     r4950     0.03125
    c1690     r5038     -0.03125
    c1690     r5155     -6.103515625e-05
    c1691     Obj       -5.166
    c1691     r3479     -1
    c1691     r3594     1
    c1691     r5038     0.03125
    c1692     Obj       -0.285
    c1692     r3400     1
    c1692     r3595     -1
    c1692     r4950     -0.03125
    c1692     r5195     -0.03125
    c1693     Obj       -1.015
    c1693     r3480     1
    c1693     r4243     -1
    c1693     r4419     0.03125
    c1693     r4528     -0.03125
    c1694     Obj       -1.014
    c1694     r3596     -1
    c1694     r4243     1
    c1694     r4528     0.03125
    c1695     Obj       -0.026
    c1695     r3596     -1
    c1695     r4251     1
    c1695     r4527     -0.03125
    c1695     r6284     -0.03125
    c1696     Obj       -0.23
    c1696     r3596     1
    c1696     r3597     -1
    c1696     r4412     0.03125
    c1696     r4620     0.0256
    c1696     r4662     -0.03125
    c1696     r5293     0.0002
    c1696     r5450     0.0001220703125
    c1696     r5871     0.0001
    c1696     r6284     0.03125
    c1696     r6673     0.03125
    c1696     r6768     0.0513
    c1697     Obj       -1.472
    c1697     r1954     1
    c1697     r3598     1
    c1697     r3599     -1
    c1697     r5130     -0.03125
    c1698     Obj       -2.024
    c1698     r3599     1
    c1698     r4244     -1
    c1698     r5130     0.03125
    c1698     r6044     6.103515625e-05
    c1698     r6515     6.103515625e-05
    c1698     r6519     0.0001
    c1698     r6935     6.103515625e-05
    c1698     r6952     0.03125
    c1698     r7081     0.0001
    c1699     Obj       -1.32
    c1699     r3600     -1
    c1699     r4237     1
    c1699     r5972     0.0256
    c1700     Obj       -1.116
    c1700     r3600     1
    c1700     r4236     -1
    c1700     r5652     0.03125
    c1700     r5741     0.0256
    c1701     Obj       -0.075
    c1701     r3601     1
    c1701     r3602     -1
    c1701     r4549     0.03125
    c1701     r4659     -0.03125
    c1702     Obj       -0.141
    c1702     r3602     1
    c1702     r3603     -1
    c1702     r4600     0.03125
    c1702     r4659     0.03125
    c1703     Obj       -0.008
    c1703     r3603     1
    c1703     r3604     -1
    c1703     r4600     -0.03125
    c1704     Obj       -0.085
    c1704     r3604     1
    c1704     r3605     -1
    c1704     r4547     0.03125
    c1705     Obj       -1.873
    c1705     r3605     1
    c1705     r3606     -1
    c1705     r5572     -0.0256
    c1705     r5741     -0.0256
    c1705     r6952     -0.03125
    c1706     Obj       -2.468
    c1706     r1964     1
    c1706     r3606     1
    c1706     r3607     -1
    c1707     Obj       -2.406
    c1707     r3607     1
    c1707     r3610     -1
    c1707     r5694     6.103515625e-05
    c1707     r5744     0.0256
    c1707     r5871     0.0001
    c1708     Obj       -0.296
    c1708     r1966     1
    c1708     r3612     -1
    c1708     r3615     1
    c1708     r4546     0.03125
    c1709     Obj       -0.015
    c1709     r3608     -1
    c1709     r3741     1
    c1709     r4516     -0.03125
    c1710     Obj       -0.063
    c1710     r3608     1
    c1710     r3609     -1
    c1710     r4980     0.03125
    c1710     r5002     -6.103515625e-05
    c1710     r5345     -0.03125
    c1710     r6409     -6.103515625e-05
    c1711     Obj       -0.022
    c1711     r3609     1
    c1711     r3611     -1
    c1711     r4980     -0.03125
    c1711     r4997     -6.103515625e-05
    c1711     r5601     -6.103515625e-05
    c1712     Obj       -1.03
    c1712     r1971     1
    c1712     r3610     1
    c1712     r3614     -1
    c1712     r4392     0.03125
    c1712     r6028     0.0256
    c1712     r6483     6.103515625e-05
    c1713     Obj       -0.476
    c1713     r3611     1
    c1713     r3614     -1
    c1713     r4392     0.03125
    c1714     Obj       -0.221
    c1714     r3612     1
    c1714     r3616     -1
    c1714     r6943     0.0001
    c1715     Obj       -1.012
    c1715     r3613     -1
    c1715     r3617     1
    c1715     r6942     0.0001
    c1716     Obj       -5.453
    c1716     r3613     1
    c1716     r3742     -1
    c1716     r4560     0.03125
    c1717     Obj       -0.01
    c1717     r1976     1
    c1717     r3614     1
    c1717     r3615     -1
    c1717     r4623     -0.0256
    c1717     r5848     0.03125
    c1718     Obj       -1.366
    c1718     r3616     1
    c1718     r3617     -1
    c1718     r4623     0.0256
    c1718     r6941     0.0001
    c1719     Obj       -0.128
    c1719     r1978     1
    c1719     r3618     -1
    c1719     r3666     1
    c1719     r4314     0.03125
    c1719     r4361     0.03125
    c1720     r0        -10000
    c1720     r5376     0.508697483337402
    c1720     r5522     0.508697483337402
    c1720     r5532     0.101654079162598
    c1720     r5977     0.136002207845763
    c1720     r6081     0.136002207845763
    c1720     r6150     0.508697483337402
    c1720     r6354     0.508697483337402
    c1720     r6413     0.508697483337402
    c1720     r6491     0.508697483337402
    c1720     r6634     0.101654079162598
    c1720     r6696     0.8334499567
    c1720     r6758     0.192806080375245
    c1720     r6759     -0.699993347583806
    c1720     r6797     0.1665500433
    c1720     r6812     -0.700031526610456
    c1721     r5613     -0.686007218749999
    c1722     r5317     -0.0107188627929686
    c1723     r4793     -0.0625343749999843
    c1723     r5595     0.693824015624998
    c1723     r7064     0.603396833663336
    c1724     r5069     -0.6103515625
    c1724     r7068     -0.693824015624998
    c1725     r6838     -0.52734375
    c1726     r5097     0.590239458448759
    c1726     r5904     -0.0316017192993163
    c1726     r6268     0.578749843200684
    c1726     r6498     0.0316017192993163
    c1726     r6715     -0.623056574218751
    c1726     r6857     0.0316017192993163
    c1726     r6900     -0.0194705179443359
    c1727     r5565     0.0316017192993163
    c1727     r6498     -0.547148123901367
    c1727     r6714     0.623056574218751
    c1727     r6857     -0.0316017192993163
    c1728     r3019     -1
    c1728     r3020     1
    c1728     r4707     0.03125
    c1728     r5565     6.103515625e-05
    c1728     r6900     6.103515625e-05
    c1729     r5097     -0.0201121040512414
    c1729     r6442     0.0121312013549804
    c1729     r6555     -0.940562071770509
    c1729     r6716     0.87478360546875
    c1729     r6727     -0.0121312013549804
    c1729     r6900     -0.0194705179443359
    c1730     r4482     -0.6103515625
    c1731     r3014     -1
    c1731     r3022     1
    c1731     r6707     -0.03125
    c1731     r6714     -0.001953125
    c1731     r6715     -0.001953125
    c1732     r1508     10000
    c1732     r4483     -0.0110484207999999
    c1732     r4589     -0.0119299507999999
    c1732     r4631     -0.763516851199995
    c1732     r5032     -0.707098931199994
    c1733     r11       -10000
    c1734     r11       1
    c1734     r3037     1
    c1734     r3047     -1
    c1735     r12       -10000
    c1736     r12       1
    c1736     r3037     1
    c1736     r3039     -1
    c1737     r4454     -110.484208
    c1738     r1512     10000
    c1738     r4483     -0.9889515792
    c1738     r5032     0.707098931199994
    c1739     r3030     1
    c1739     r3036     -1
    c1740     r15       -10000
    c1740     r1513     10000
    c1740     r7076     0.609813519287109
    c1741     r16       -10000
    c1741     r1514     10000
    c1742     r1515     10000
    c1742     r4847     -0.863157875000013
    c1742     r5032     0.763516851199995
    c1743     r3034     1
    c1743     r3036     -1
    c1744     r4455     -0.763516851199995
    c1745     r6874     -0.601637072753906
    c1746     r3038     1
    c1746     r3234     -1
    c1747     r20       -10000
    c1747     r1518     10000
    c1747     r4847     0.863157875000013
    c1747     r5032     -0.763516851199995
    c1747     r6939     -0.000881530000000019
    c1748     r1519     10000
    c1748     r4589     -0.9880700492
    c1749     r3033     -1
    c1749     r3036     1
    c1750     Obj       0
    c1751     r23       -10000
    c1751     r6257     0.854067595108696
    c1751     r6845     -0.696888676396123
    c1751     r7020     -0.696888676396123
    c1752     r5210     0.373683200000016
    c1752     r5704     -0.153723216687364
    c1752     r5787     92.3810519999985
    c1752     r5894     0.0500653805844969
    c1752     r6149     0.0136747893788734
    c1752     r6551     0.00976986741254159
    c1752     r6623     0.0650324528458996
    c1752     r6702     0.146090820312499
    c1752     r6787     0.584363281249997
    c1753     r5222     -0.457154188800002
    c1753     r5371     -0.558049546875003
    c1753     r5402     0.00167857731165717
    c1753     r5447     0.528444023437503
    c1753     r5600     -0.012599508178711
    c1753     r5901     -0.457154188800002
    c1753     r6079     -0.229365046879889
    c1753     r6149     -0.397820336949121
    c1753     r6298     0.28167000000002
    c1753     r6361     -0.012599508178711
    c1753     r6419     -0.457154188800009
    c1753     r6426     -0.279024773437501
    c1753     r6453     -0.806368523437501
    c1753     r6531     -0.806368523437501
    c1753     r6551     -0.197134261206619
    c1753     r6578     -0.660577094400001
    c1753     r6623     -0.232200218592615
    c1753     r6668     0.0109863281250001
    c1753     r6670     0.491643570636085
    c1753     r6726     -0.934445928253012
    c1753     r6804     -0.558049546875003
    c1754     r4682     -0.917913753600004
    c1754     r5386     0.420670411340929
    c1754     r6079     0.480712660653553
    c1754     r6149     0.319182296536012
    c1754     r6426     0.527343750000003
    c1754     r6484     0.504960022672936
    c1754     r6549     0.683639014225301
    c1754     r6551     0.0174511404753228
    c1754     r6623     0.00622294679118783
    c1755     r1525     10000
    c1755     r5600     -0.0129701160888671
    c1755     r5901     -0.864000000000004
    c1755     r6412     0.290427921838092
    c1755     r6520     0.6103515625
    c1755     r6670     0.745539046551418
    c1755     r6693     0.0333513769531248
    c1755     r7015     -0.889035514844142
    c1756     r4775     -0.281669999999991
    c1756     r5075     0.527343750000003
    c1756     r5901     -0.00180268799999994
    c1756     r6412     0.54673921920001
    c1756     r6454     0.538474668207626
    c1756     r6577     0.263671875000001
    c1756     r6668     -0.0168222666015625
    c1756     r6670     -0.752804679059621
    c1756     r6737     -0.6674062734375
    c1756     r6770     0.263671875000001
    c1756     r6877     0.00823974609375004
    c1756     r7015     0.0125169635812554
    c1757     r5349     0.807468796875
    c1757     r5901     -0.864000000000004
    c1757     r6412     0.290427921838092
    c1757     r6578     -0.863098656000005
    c1757     r6668     -0.813802083333333
    c1757     r6721     0.807468796875007
    c1757     r6754     0.0126166999511719
    c1757     r6764     -0.597734862548828
    c1757     r6891     -0.655396710666682
    c1758     r6797     -0.8334499567
    c1759     r5186     -0.555490613586426
    c1759     r6408     0.0523995339355469
    c1759     r6529     0.103675345703125
    c1759     r6696     0.6668999134
    c1759     r6743     1
    c1759     r6745     0.0762939453125
    c1759     r7045     -0.812380537709652
    c1760     r3245     -1
    c1760     r3248     1
    c1760     r5186     6.103515625e-05
    c1760     r6408     6.103515625e-05
    c1760     r6793     6.103515625e-05
    c1761     r32       -10000
    c1761     r6225     -0.6103515625
    c1762     r32       1
    c1762     r3214     -1
    c1762     r3249     1
    c1763     r1531     10000
    c1763     r4719     -0.777683276800019
    c1763     r5242     0.987682776554397
    c1763     r5674     -0.949320406250024
    c1763     r6862     -0.663741474145346
    c1763     r6876     0.493841388277198
    c1763     r6888     -0.00303782530000007
    c1763     r6901     -0.00303782530000007
    c1763     r6918     0.0168851558837888
    c1764     r4819     0.127306249999947
    c1764     r5112     -0.663741474145346
    c1764     r6860     0.602236138916016
    c1764     r6876     -0.556778472604583
    c1764     r6898     0.601188525756836
    c1764     r6907     -0.601706152709961
    c1764     r7060     0.707710610730553
    c1764     r7073     0.0095367431640625
    c1765     r4819     -0.127306249999947
    c1765     r5112     -0.000137140040083699
    c1765     r5242     -0.010982491897842
    c1765     r5469     0.118003046399934
    c1765     r6860     -0.000124322509765576
    c1765     r6862     -0.000137140040083699
    c1765     r6876     -0.00599880912129898
    c1765     r6898     -0.000124322509765576
    c1765     r6907     -0.000124322509765576
    c1765     r7060     -0.000146096113514807
    c1765     r7073     -0.000137140040083699
    c1766     r36       -10000
    c1767     r5072     -0.6103515625
    c1768     r5071     -0.6103515625
    c1769     r39       -10000
    c1769     r4727     0.693824015624998
    c1769     r4845     -0.00823974609374989
    c1769     r5317     0.0108410002441406
    c1769     r5384     0.148474429687501
    c1769     r5538     -0.360863484374993
    c1769     r5613     0.689915617187498
    c1769     r5702     0.693824015624998
    c1769     r6702     0.765876605468744
    c1769     r6787     0.860304281249997
    c1769     r6869     -0.533502775465194
    c1769     r6928     0.0095367431640625
    c1769     r6948     -0.0738172961340677
    c1769     r7062     -0.599510562255859
    c1770     r5595     0.693824015624998
    c1770     r6948     -0.555297664038129
    c1770     r7064     0.6103515625
    c1771     r5070     -0.6103515625
    c1771     r6919     -0.693824015624998
    c1772     r42       -10000
    c1772     r1540     10000
    c1772     r7075     0.6097359375
    c1773     r43       -10000
    c1773     r1541     10000
    c1774     r1542     10000
    c1774     r5748     -0.0460263124999756
    c1774     r5847     -0.210898187499993
    c1774     r6299     -0.0460263124999756
    c1775     r45       -10000
    c1775     r1543     10000
    c1776     r46       -10000
    c1776     r1544     10000
    c1777     r47       -10000
    c1777     r1545     10000
    c1778     r48       -10000
    c1778     r1546     10000
    c1779     r49       -10000
    c1779     r6299     0.0460263124999756
    c1780     r50       -10000
    c1780     r5009     0.0920526249999511
    c1780     r5077     0.0920526249999511
    c1780     r5748     0.0460263124999756
    c1780     r5847     0.210898187499993
    c1781     r1549     10000
    c1781     r5077     -0.0920526249999511
    c1782     r52       -10000
    c1782     r1550     10000
    c1782     r7075     -0.6097359375
    c1783     r4436     -0.973042022400023
    c1783     r4681     -0.545522534399993
    c1783     r4726     -0.693824015625
    c1783     r4727     0.527343749999996
    c1783     r5280     0.591238732799997
    c1783     r5317     0.00823974609374993
    c1783     r5384     0.527343749999996
    c1783     r5469     -0.973042022400051
    c1783     r5538     -0.693824015625
    c1783     r5704     0.373620533312633
    c1783     r5894     0.316852266025631
    c1783     r6149     0.0516279087616772
    c1783     r6419     0.591238732799989
    c1783     r6476     0.360863484374993
    c1783     r6551     0.0368852352612933
    c1783     r6623     0.245524040557675
    c1783     r6746     0.00563849194335927
    c1783     r6787     0.360863484374993
    c1783     r6869     0.00501665620085434
    c1783     r6928     0.00496013728304417
    c1783     r6948     0.0085254567579717
    c1783     r7083     -0.00380094540000009
    c1784     r1552     10000
    c1784     r5044     -0.00511234560002549
    c1784     r5393     -0.0124813125000622
    c1785     r1553     10000
    c1785     r5488     -0.673564591195235
    c1785     r6881     0.577392578125
    c1785     r6909     -0.673564591195235
    c1785     r7060     -0.0095367431640625
    c1785     r7073     -0.663741474145346
    c1785     r7074     0.60211181640625
    c1786     r1554     10000
    c1786     r6936     -0.609975830078125
    c1787     r6351     -0.509337914062506
    c1788     r58       -10000
    c1788     r1556     10000
    c1789     r1557     10000
    c1789     r5009     -0.0920526249999511
    c1790     r60       -10000
    c1791     r61       -10000
    c1791     r1559     10000
    c1791     r5587     -0.153889718749951
    c1791     r6898     -0.592543115966797
    c1792     r6898     -0.6103515625
    c1793     r5587     -0.153889718749951
    c1793     r6888     0.9969621747
    c1794     r64       -10000
    c1794     r4565     0.135063039999977
    c1794     r5009     -0.0920526249999511
    c1794     r5077     -0.0920526249999511
    c1794     r5748     -0.0460263124999756
    c1795     r65       -10000
    c1795     r4562     0.164871875000017
    c1795     r6299     -0.0460263124999756
    c1796     r1564     10000
    c1796     r5536     -0.052951
    c1796     r6698     -0.00165471874998957
    c1797     r4911     -0.126066457600018
    c1797     r5674     0.795430687500016
    c1797     r6901     -0.9974546218
    c1798     r5847     -0.210898187499993
    c1799     r4819     -0.127306249999947
    c1799     r5109     0.9860390506
    c1799     r5242     -0.987682776554397
    c1799     r6862     0.663741474145346
    c1799     r6876     -0.493841388277198
    c1799     r7074     -0.60211181640625
    c1800     r1568     10000
    c1800     r6266     -0.00511234560002549
    c1801     r1569     10000
    c1801     r5891     -0.00511234560002549
    c1802     r4845     -0.60211181640625
    c1803     r5064     -1
    c1804     r1572     10000
    c1804     r5459     -0.00511234560002549
    c1805     r1573     10000
    c1805     r6326     -0.00511234560002549
    c1806     r1574     10000
    c1806     r6005     -0.00511234560002549
    c1807     r1575     10000
    c1807     r4718     -0.560574796799983
    c1808     r1576     10000
    c1808     r5393     -0.00917187500010641
    c1809     r1577     10000
    c1809     r5534     -0.0919859456000154
    c1810     r1578     10000
    c1810     r5533     -0.0919859456000154
    c1810     r6687     0.545349585937501
    c1810     r6909     -0.664027848031172
    c1810     r7083     0.0177618948
    c1811     r81       -10000
    c1811     r1579     10000
    c1811     r5064     -1
    c1811     r5538     0.360863484374993
    c1811     r5613     -0.689915617187498
    c1811     r5702     -0.693824015624998
    c1811     r6869     0.533502775465194
    c1811     r6919     -0.693824015624998
    c1811     r6928     0.0095367431640625
    c1811     r7068     -0.693824015624998
    c1812     r82       -10000
    c1812     r5317     0.599632699707031
    c1812     r5595     -0.693824015624998
    c1812     r6702     -0.765876605468744
    c1812     r6787     -0.860304281249997
    c1812     r6928     0.527384754876931
    c1812     r7064     -0.6103515625
    c1813     r5538     -0.360863484374993
    c1813     r5613     0.00390839843749902
    c1814     r5109     -0.9860390506
    c1814     r6687     0.545349585937501
    c1814     r6918     0.593466406616211
    c1814     r7083     -0.9822381052
    c1815     r1583     10000
    c1815     r5714     -0.00511234560002549
    c1815     r6907     -0.592853620117187
    c1816     r5488     -0.673564591195235
    c1816     r6881     0.577392578125
    c1816     r6909     0.673564591195235
    c1816     r7060     0.69817386756649
    c1816     r7073     -0.654204730981283
    c1817     r5112     0.663741474145346
    c1817     r6860     -0.602236138916016
    c1817     r6876     0.556778472604583
    c1817     r6898     0.601706152709961
    c1817     r6907     -0.601499029907226
    c1818     r88       -10000
    c1819     r89       -10000
    c1820     r90       -10000
    c1820     r1588     10000
    c1821     r91       -10000
    c1821     r1589     10000
    c1822     r92       -10000
    c1822     r1590     10000
    c1823     r6336     0.854067595108696
    c1823     r6845     -0.696888676396123
    c1824     r5010     1
    c1824     r6079     -0.115253431136211
    c1824     r6257     -0.0114639945652174
    c1824     r6336     -0.0114639945652174
    c1824     r6429     -0.0114639945652174
    c1824     r6837     0.0114639945652174
    c1824     r6839     0.0114639945652174
    c1824     r6875     -0.00132998079113841
    c1825     r5708     0.854067595108696
    c1825     r6703     -0.60211181640625
    c1825     r6852     -0.60211181640625
    c1825     r7051     0.6103515625
    c1826     r6429     0.854067595108696
    c1826     r6837     -0.854067595108696
    c1826     r6875     -0.459175868140535
    c1826     r7050     0.60211181640625
    c1827     r5686     -1
    c1828     r5010     1
    c1828     r5384     0.545349585937497
    c1828     r5402     -0.122181753725456
    c1828     r5456     -0.300579255639201
    c1828     r5704     0.564628486843682
    c1828     r5802     0.893500761599995
    c1828     r5894     0.478838285285952
    c1828     r6497     -0.691832195037563
    c1828     r6551     -0.0253217599964729
    c1828     r6623     -0.0831010731603671
    c1828     r6695     -0.345916097518781
    c1828     r6948     0.00881655336369861
    c1828     r7000     0.0295007615999908
    c1829     r3044     1
    c1829     r3199     -1
    c1830     r5369     -0.944024371199703
    c1830     r7000     -0.864000000000004
    c1831     r5251     0.00880453536000354
    c1831     r5512     -1
    c1831     r6473     -0.118003046399963
    c1832     r101      -10000
    c1832     r1599     10000
    c1832     r5706     0.854067595108696
    c1832     r5708     -0.854067595108696
    c1832     r6182     0.7177734375
    c1832     r6257     0.854067595108696
    c1832     r6703     0.60211181640625
    c1832     r6839     -0.854067595108696
    c1832     r6875     0.451528478591489
    c1832     r7020     -0.696888676396123
    c1832     r7078     0.106758449388587
    c1833     r102      -10000
    c1833     r1600     10000
    c1834     r103      -10000
    c1834     r1601     10000
    c1835     r104      -10000
    c1835     r1602     10000
    c1836     r105      -10000
    c1836     r1603     10000
    c1837     r106      -10000
    c1837     r1604     10000
    c1838     r107      -10000
    c1838     r1605     10000
    c1838     r5251     -0.670190181031636
    c1838     r5258     0.673564591195235
    c1838     r5386     -0.849552497397945
    c1838     r5490     0.673666582973737
    c1838     r5563     0.601830475219727
    c1838     r6551     -0.562120751884209
    c1838     r6623     -0.725955572266368
    c1838     r6858     -0.60211181640625
    c1838     r6864     0.673666582973737
    c1838     r6895     0.00823974609375
    c1838     r7042     -0.673879466345447
    c1838     r7044     0.601830475219727
    c1839     r6895     -0.593590729125977
    c1840     Obj       0
    c1841     r5103     -0.6103515625
    c1841     r6912     -0.601830475219727
    c1842     r5251     -0.670190181031636
    c1842     r5258     0.673564591195235
    c1842     r5386     -0.849552497397945
    c1842     r5571     -0.6103515625
    c1842     r6551     -0.562120751884209
    c1842     r6623     -0.725955572266368
    c1842     r7042     -0.673879466345447
    c1842     r7044     -0.601849134887695
    c1843     r112      -10000
    c1844     r5706     0.854067595108696
    c1844     r6839     -0.854067595108696
    c1844     r7078     -0.708259914232337
    c1845     r114      -10000
    c1845     r1612     10000
    c1845     r6336     0.854067595108696
    c1845     r6429     0.854067595108696
    c1845     r6837     -0.854067595108696
    c1845     r6875     0.657343006020157
    c1845     r7050     0.60211181640625
    c1845     r7078     0.098518703294837
    c1846     r115      -10000
    c1846     r1613     10000
    c1847     r116      -10000
    c1847     r1614     10000
    c1848     r117      -10000
    c1848     r1615     10000
    c1849     r118      -10000
    c1849     r1616     10000
    c1850     r119      -10000
    c1850     r1617     10000
    c1851     r120      -10000
    c1851     r1618     10000
    c1852     r121      -10000
    c1852     r1619     10000
    c1853     r122      -10000
    c1853     r1620     10000
    c1854     r123      -10000
    c1854     r1621     10000
    c1855     r124      -10000
    c1855     r1622     10000
    c1856     r125      -10000
    c1856     r1623     10000
    c1857     r126      -10000
    c1857     r1624     10000
    c1857     r6864     0.645705589576197
    c1857     r7044     0.593328047607422
    c1858     r127      -10000
    c1859     r128      -10000
    c1859     r1626     10000
    c1860     r129      -10000
    c1860     r1627     10000
    c1861     r130      -10000
    c1861     r1628     10000
    c1862     r131      -10000
    c1862     r1629     10000
    c1863     r5490     0.673598269424795
    c1863     r6858     -0.60211181640625
    c1863     r6864     -0.655242809577418
    c1864     r133      -10000
    c1865     r134      -10000
    c1866     Obj       0
    c1867     r136      -10000
    c1868     r136      1
    c1868     r3141     -1
    c1868     r3143     1
    c1869     r137      -10000
    c1869     r1635     10000
    c1870     r138      -10000
    c1870     r1636     10000
    c1871     r139      -10000
    c1872     r139      1
    c1872     r3142     -1
    c1872     r3144     1
    c1873     r4459     -295.458332
    c1873     r4575     244.541668
    c1874     r5374     -0.595266050781246
    c1874     r6427     -0.986765199218747
    c1874     r6995     0.493382599609374
    c1875     r142      -10000
    c1875     r1640     10000
    c1875     r7023     0.609555770324707
    c1876     r6911     -0.000795792175292969
    c1877     r4451     -13.0382590000008
    c1877     r5456     0.00214895360379863
    c1877     r6079     0.006341084943844
    c1877     r6149     0.0034472806865523
    c1877     r6497     0.00494616731147429
    c1877     r6551     0.000579557052617068
    c1877     r6623     0.00330319182715717
    c1877     r6695     0.00247308365573715
    c1878     r4576     -0.501878400390623
    c1878     r5599     283.038259
    c1878     r6079     0.437751078952248
    c1878     r6995     0.552809099609375
    c1879     r4577     -0.986765199218747
    c1880     r147      -10000
    c1880     r6911     0.609555770324707
    c1881     r148      -10000
    c1881     r1646     10000
    c1881     r6911     0.609555770324707
    c1882     r4977     -0.543378406250026
    c1882     r6309     0.52734375
    c1883     r4457     -270
    c1883     r4573     270
    c1883     r4576     -0.0254653496093766
    c1883     r4577     -0.0679223007812531
    c1883     r6079     -0.444478620089296
    c1883     r6145     -0.0339611503906266
    c1883     r6218     -0.0679223007812533
    c1883     r6309     -0.0339611503906266
    c1883     r6427     -0.0679223007812533
    c1883     r6428     -0.0679223007812533
    c1883     r6623     -0.0103238524655871
    c1884     r1649     270
    c1884     r6497     -0.350765051419565
    c1884     r6623     -0.129824206115396
    c1885     r6145     -0.561304900390626
    c1885     r6428     -0.986765199218747
    c1886     r1651     10000
    c1886     r4625     -0.278181249999989
    c1886     r4676     -0.278181249999989
    c1886     r5596     0.609808239746094
    c1887     r5596     -0.6103515625
    c1888     r5431     -0.6103515625
    c1889     r5141     -0.6103515625
    c1890     r5350     -0.6103515625
    c1891     r158      -10000
    c1891     r1656     10000
    c1891     r7009     0.0139159039999868
    c1892     r5066     -0.6103515625
    c1893     r5894     -0.180431742187497
    c1894     r161      -10000
    c1895     r162      -10000
    c1896     r163      -10000
    c1896     r1661     10000
    c1897     r164      -10000
    c1898     r164      1
    c1898     r3163     -1
    c1898     r3172     1
    c1899     r4730     -0.6103515625
    c1900     r166      -10000
    c1900     r6879     0.00147795410156237
    c1901     Obj       0
    c1902     r168      -10000
    c1903     r168      1
    c1903     r3162     -1
    c1903     r3164     1
    c1904     r169      -10000
    c1904     r1667     10000
    c1905     r170      -10000
    c1906     Obj       0
    c1907     r172      -10000
    c1908     r172      1
    c1908     r3168     -1
    c1908     r3170     1
    c1909     r1671     10000
    c1909     r5729     -0.997144375
    c1910     r1672     10000
    c1910     r6819     -0.608608627319336
    c1910     r6865     0.00285562500000003
    c1911     r6865     -0.997144375
    c1912     r3169     -1
    c1912     r3171     1
    c1913     r4446     -0.691740582400001
    c1913     r4924     0.421792513671873
    c1914     r4458     -295.458332
    c1914     r4574     244.541668
    c1914     r4924     -0.577067054687498
    c1915     r1676     10000
    c1916     r179      -295.458332
    c1916     r4447     -0.754320948148147
    c1916     r6551     0.119227911605349
    c1917     r4632     -0.893246906250035
    c1917     r5302     0.556514293438746
    c1917     r5374     0.00110027343750296
    c1917     r5447     0.31624127734375
    c1917     r5456     0.00105418196773979
    c1917     r6079     0.0839156368037019
    c1917     r6149     -0.00297970494394215
    c1917     r6426     -0.738446222656257
    c1917     r6497     -0.709883739438695
    c1917     r6551     -0.153126891957258
    c1917     r6623     0.000810579118549517
    c1917     r6695     -0.354941869719347
    c1917     r6726     -0.518755525983587
    c1917     r6804     -0.424405492187504
    c1918     r5456     -0.100465860054347
    c1918     r6149     0.0667899060018439
    c1918     r6218     0.986765199218747
    c1918     r6497     -0.23123856747841
    c1918     r6551     0.00374432191851956
    c1918     r6695     -0.115619283739205
    c1919     r5386     0.743302784197596
    c1919     r5402     -0.583605284556115
    c1919     r5456     0.0580209722215357
    c1919     r5512     -1
    c1919     r5686     -1
    c1919     r5708     -0.0114639945652174
    c1919     r5901     -0.864
    c1919     r6079     -0.433489193272866
    c1919     r6149     -0.431550870702497
    c1919     r6412     -0.546739219200001
    c1919     r6479     -0.528444023437499
    c1919     r6484     0.504960022672934
    c1919     r6497     0.13354473343437
    c1919     r6549     -0.685065389048532
    c1919     r6551     -0.152528288981788
    c1919     r6623     -0.357112635094384
    c1919     r6694     -0.528444023437499
    c1919     r6695     0.0667723667171851
    c1919     r6726     0.191019416555759
    c1919     r6804     -0.00220054687500504
    c1919     r6881     0.00823974609375005
    c1919     r6891     -0.00897660162671506
    c1920     r5222     0.865802688000004
    c1920     r5371     0.00220054687500526
    c1920     r5386     0.0847713177666527
    c1920     r5447     -0.0557130468749982
    c1920     r5456     -0.150653033817086
    c1920     r6149     0.268195643553612
    c1920     r6426     0.00110027343750263
    c1920     r6497     0.365557575512515
    c1920     r6551     0.349657406359624
    c1920     r6623     0.160563679337873
    c1920     r6695     0.182778787756257
    c1920     r6726     -0.187320044842796
    c1920     r6804     0.00220054687500526
    c1921     r5374     -0.211102472656254
    c1921     r5386     0.0127493278502326
    c1921     r6079     -0.219072805916793
    c1921     r6476     -0.806368523437499
    c1921     r6479     0.249419250000001
    c1921     r6484     0.00105357103397252
    c1921     r6549     -0.360296355477921
    c1921     r6623     0.000683045386185843
    c1921     r6694     0.528444023437503
    c1922     r4891     0.0704174999999623
    c1922     r5386     0.000877705442683966
    c1922     r6079     0.00139335323507662
    c1922     r6149     0.346559999853784
    c1922     r6484     -0.267181237895227
    c1922     r6551     0.194206987340875
    c1922     r6623     0.214261153530782
    c1922     r6694     -0.279024773437502
    c1923     r4683     -0.917913753600004
    c1923     r5065     135.000000000001
    c1923     r5349     0.527343750000003
    c1923     r6419     0.863999999999993
    c1923     r6476     0.527343750000003
    c1923     r6577     -0.403734398437501
    c1923     r6737     0.435871365395366
    c1923     r6770     -0.403734398437501
    c1923     r6877     -0.0126166999511719
    c1923     r7021     0.0135000000000001
    c1924     r4728     -0.320025600000008
    c1924     r5439     0.835623065599975
    c1925     r6454     0.335900545892343
    c1925     r6531     -0.781255398437494
    c1925     r6670     0.745539046551418
    c1925     r6746     -0.6103515625
    c1925     r6877     -0.6103515625
    c1926     r3184     1
    c1926     r3646     -1
    c1926     r6531     0.00390625
    c1926     r6746     6.103515625e-05
    c1926     r6877     6.103515625e-05
    c1926     r7069     6.103515625e-05
    c1927     r189      -10000
    c1927     r1687     10000
    c1928     r190      -10000
    c1928     r1688     10000
    c1928     r5349     -0.807468796875
    c1928     r5600     0.0129701160888671
    c1928     r5901     0.864000000000004
    c1928     r6361     0.0290790003662109
    c1928     r6412     -0.290427921838092
    c1928     r6453     0.526243476562499
    c1928     r6454     -0.824512459823929
    c1928     r6531     0.781255398437494
    c1928     r6578     0.863098656000005
    c1928     r6670     -0.745539046551418
    c1928     r6682     0.52734375
    c1928     r6693     -0.0333513769531248
    c1928     r6721     -0.807468796875007
    c1928     r6746     -0.0377283308105471
    c1928     r6754     -0.0126166999511719
    c1928     r6764     0.597734862548828
    c1928     r6877     -0.0248410073242187
    c1928     r6891     0.655396710666682
    c1928     r7015     0.889035514844142
    c1928     r7021     -0.0478707075999997
    c1929     r191      -10000
    c1929     r1689     10000
    c1930     r192      -10000
    c1930     r1690     10000
    c1931     r193      -10000
    c1931     r6825     0.0139159039999868
    c1932     r194      -10000
    c1932     r1692     10000
    c1933     r195      -10000
    c1933     r5604     0.0139159039999868
    c1934     r196      -10000
    c1934     r1694     10000
    c1935     r197      -10000
    c1935     r1695     10000
    c1936     r198      -10000
    c1936     r1696     10000
    c1937     r199      -10000
    c1938     r1698     10000
    c1938     r6913     -0.000543322753906228
    c1938     r6958     -0.278181249999989
    c1938     r7061     0.609808239746094
    c1939     r1699     10000
    c1939     r6913     -0.609808239746094
    c1939     r6957     0.278181249999989
    c1939     r7061     0.000543322753906228
    c1940     r3198     1
    c1940     r3625     -1
    c1940     r4791     0.03125
    c1940     r4978     0.03125
    c1941     r202      -139.450105
    c1941     r4631     0.640575327999995
    c1942     r4859     -0.607890147521973
    c1942     r5091     0.557952028564453
    c1942     r7006     -0.557628652099609
    c1942     r7045     0.736086592397152
    c1943     r5020     0.555490613586426
    c1943     r6354     -0.156515028076172
    c1943     r6758     -0.908626438961144
    c1943     r6978     0.9101158213
    c1944     r205      -10000
    c1944     r1703     10000
    c1944     r6874     -0.00871448974609379
    c1944     r6893     0.608918536865234
    c1945     r206      -146.583412
    c1945     r4479     0.669590686503941
    c1946     r5520     -0.813106203124987
    c1946     r5696     -0.813106203124979
    c1947     r2996     1
    c1947     r2998     -1
    c1947     r5906     6.103515625e-05
    c1948     r5522     -0.508697483337402
    c1948     r6092     0.583415125781014
    c1948     r6095     -0.488383736663052
    c1948     r6738     -0.508697483337402
    c1948     r6759     0.699993347583806
    c1948     r6795     -0.508697483337402
    c1948     r7031     -0.508697483337402
    c1949     r209      -10000
    c1949     r6854     0.608349609375
    c1950     r210      -10000
    c1950     r1708     10000
    c1950     r7025     0.608349609375
    c1951     r211      -10000
    c1951     r1709     10000
    c1951     r6947     -0.609923490356445
    c1951     r7040     -0.608987943481445
    c1952     r212      -10000
    c1952     r1710     10000
    c1952     r4841     0.9720913863
    c1952     r7040     0.608987943481445
    c1953     r5316     -0.6103515625
    c1953     r6897     0.609416015625
    c1954     r214      -10000
    c1954     r1712     10000
    c1954     r7055     0.609416015625
    c1955     r215      -10000
    c1955     r1713     10000
    c1955     r4475     -0.275478125000006
    c1955     r6915     0.609813519287109
    c1955     r7076     0.000538043212890527
    c1956     r1714     10000
    c1956     r6893     -0.608918536865234
    c1957     r4915     0.9141486036
    c1957     r5977     -0.0702308738310478
    c1957     r6312     9.41345214843237e-05
    c1957     r6408     0.557952028564453
    c1958     r218      -10000
    c1958     r1716     10000
    c1958     r6688     0.9136187836
    c1958     r6709     -0.117371875000003
    c1958     r6781     -0.501994904829461
    c1958     r6826     0.557628652099609
    c1958     r7006     0.505229118164062
    c1959     r219      -10000
    c1959     r1717     10000
    c1960     r220      -10000
    c1960     r6897     -0.609416015625
    c1960     r6947     0.609923490356445
    c1960     r7055     -0.609416015625
    c1961     r221      -10000
    c1961     r1719     10000
    c1962     r222      -10000
    c1962     r1720     10000
    c1963     r1721     10000
    c1963     r5388     0.59822036114502
    c1963     r5565     -0.0316017192993163
    c1963     r5801     0.989962367056821
    c1963     r5814     -0.0121312013549804
    c1963     r5904     0.566618641845703
    c1963     r5999     0.59822036114502
    c1963     r6092     -0.589898584726051
    c1963     r6178     -0.913275693943179
    c1963     r6268     0.578749843200684
    c1963     r6347     0.59822036114502
    c1963     r6442     0.59822036114502
    c1963     r6498     0.578749843200684
    c1963     r6555     0.940562071770509
    c1963     r6727     0.59822036114502
    c1963     r6806     -0.0121312013549804
    c1963     r6857     0.578749843200684
    c1963     r6905     -0.0121394459838866
    c1964     r1722     10000
    c1964     r4841     -0.9720913863
    c1964     r5801     -0.985848214796799
    c1964     r6092     0.592555977900566
    c1964     r6178     0.917389846203201
    c1964     r6630     -0.596683068664551
    c1964     r6727     0.0121312013549804
    c1965     r225      -10000
    c1965     r1723     10000
    c1965     r6854     -0.608349609375
    c1965     r7025     -0.608349609375
    c1966     r5977     0.404118480823189
    c1966     r6081     0.404118480823189
    c1966     r6239     0.9139943736
    c1966     r6413     0.354549735717773
    c1966     r6471     0.9139943736
    c1966     r6527     0.9139943736
    c1966     r6688     -0.99962441
    c1966     r7002     0.9139943736
    c1967     r227      -10000
    c1967     r6239     -0.0860056264
    c1967     r6826     -0.0527229104003906
    c1967     r7002     -0.0860056263999999
    c1968     r227      1
    c1968     r3237     1
    c1968     r3238     -1
    c1969     r5087     -0.556053991210938
    c1969     r5627     -0.298193273193359
    c1969     r6405     -1
    c1969     r6475     0.0177402940063476
    c1969     r6584     0.564677103515624
    c1969     r6691     0.575598188049316
    c1969     r6743     -1
    c1969     r6826     -0.590243988037109
    c1969     r7002     -0.2442799294
    c1970     r229      -10000
    c1970     r1727     10000
    c1970     r6630     0.596683068664551
    c1970     r6716     -0.87478360546875
    c1970     r6905     0.608814270019531
    c1971     r230      -10000
    c1971     r1728     10000
    c1971     r6704     0.508697483337402
    c1971     r6744     0.625525172634404
    c1972     r4449     -0.6880450112
    c1972     r5088     0.9139943736
    c1972     r5977     -0.6103515625
    c1972     r6081     -0.680582436331048
    c1972     r6312     0.557857894042969
    c1972     r6475     0.557857894042969
    c1972     r6529     0.506676216796875
    c1972     r6634     0.456203814880371
    c1972     r6709     0.117371875000003
    c1972     r6781     -0.497629505170539
    c1972     r6978     0.00387855229999978
    c1973     r232      -10000
    c1973     r1730     10000
    c1973     r6095     0.6103515625
    c1974     r233      -10000
    c1974     r5376     0.508697483337402
    c1974     r5532     -0.6103515625
    c1974     r5801     -0.903238061
    c1974     r5977     -0.6103515625
    c1974     r6081     -0.6103515625
    c1974     r6178     -0.903238061
    c1974     r6354     0.563558432250977
    c1974     r6413     0.101654079162598
    c1974     r6634     -0.6103515625
    c1974     r6758     0.874514252124474
    c1974     r6797     -1
    c1975     r1732     10000
    c1975     r6744     -0.500525172634404
    c1976     r3226     -1
    c1976     r4220     1
    c1976     r5647     -0.03125
    c1976     r6744     7.50525172634404e-05
    c1977     r235      -10000
    c1977     r1733     10000
    c1977     r4556     -0.00422125000000051
    c1977     r6905     -0.0121394459838866
    c1978     r236      -10000
    c1978     r1734     10000
    c1979     r1735     10000
    c1979     r5190     0.03814697265625
    c1979     r5640     -0.576873779296875
    c1979     r6359     -0.83545
    c1979     r6564     -0.576873779296875
    c1979     r6841     -0.576873779296875
    c1979     r7016     -0.509918212890625
    c1980     r5190     -0.657331106764898
    c1980     r5561     0.576873779296875
    c1980     r6359     -0.16455
    c1980     r6882     0.574930959206211
    c1980     r7032     0.593140661950878
    c1981     r3252     1
    c1981     r3255     -1
    c1981     r6537     6.103515625e-05
    c1981     r6882     6.45772165793789e-05
    c1981     r7032     6.27562463049122e-05
    c1982     r239      -10000
    c1982     r1737     10000
    c1982     r4979     -0.53564453125
    c1982     r5190     0.619184134108648
    c1982     r6359     0.8903
    c1982     r6841     0.576873779296875
    c1982     r7016     0.509918212890625
    c1983     r5319     -0.576873779296875
    c1983     r5561     0.033477783203125
    c1983     r5640     0.033477783203125
    c1983     r6564     0.033477783203125
    c1983     r6636     0.0354206032937893
    c1983     r6882     0.0354206032937893
    c1983     r7032     -0.593140661950878
    c1984     r1739     10000
    c1984     r4827     -0.576873779296875
    c1985     r6761     -0.320194970703125
    c1985     r6803     -0.160097485351562
    c1986     r243      -10000
    c1987     r243      1
    c1987     r3871     -1
    c1987     r4228     1
    c1987     r4702     -0.03125
    c1988     r244      -10000
    c1988     r1742     10000
    c1988     r5000     -0.0178976553955078
    c1988     r5248     0.58134874375964
    c1988     r5603     -0.572724972656253
    c1988     r5646     0.600562044311523
    c1988     r5731     0.600562044311523
    c1988     r6084     0.631376638307498
    c1988     r6094     -0.0276871735839844
    c1988     r6553     -0.0455848289794923
    c1988     r6559     0.596897372555726
    c1988     r6638     0.571644488375916
    c1988     r6660     0.6103515625
    c1988     r6665     -0.6103515625
    c1988     r6756     0.579289895996094
    c1988     r6810     0.571644488375916
    c1988     r6906     -0.885989554687502
    c1988     r7017     0.571644488375916
    c1989     r5217     -0.6103515625
    c1990     r3271     1
    c1990     r3916     -1
    c1990     r6665     -6.103515625e-05
    c1991     r246      -10000
    c1992     r247      -10000
    c1992     r1745     10000
    c1993     r248      -10000
    c1993     r1746     10000
    c1994     r249      -10000
    c1994     r1747     10000
    c1995     r250      -10000
    c1995     r1748     10000
    c1996     r251      -10000
    c1996     r1749     10000
    c1997     r252      -10000
    c1997     r1750     10000
    c1998     r253      -10000
    c1999     r1752     10000
    c1999     r6730     0.168364774400004
    c1999     r6925     -0.9993423251
    c2000     r255      -10000
    c2000     r1753     10000
    c2001     r256      -10000
    c2001     r1754     10000
    c2002     r4737     -0.6103515625
    c2003     r3294     -1
    c2003     r3295     1
    c2003     r5610     -6.103515625e-05
    c2003     r7005     -6.103515625e-05
    c2004     r258      -10000
    c2004     r1756     10000
    c2004     r5329     -0.603883056640625
    c2004     r5566     -0.603883056640625
    c2004     r6403     0.6103515625
    c2004     r6557     0.00646850585937497
    c2004     r6763     -0.603883056640625
    c2004     r6851     -0.603883056640625
    c2004     r7022     -0.871252307218752
    c2005     r5566     -0.603883056640625
    c2005     r6561     -0.00646850585937486
    c2005     r6809     0.603883056640625
    c2005     r7022     -0.890325793546877
    c2006     r3313     1
    c2006     r3320     -1
    c2006     r5566     6.103515625e-05
    c2006     r7022     8.9986253671094e-05
    c2007     r6403     -0.6103515625
    c2008     r3313     1
    c2008     r3328     -1
    c2009     r261      -10000
    c2009     r5079     0.152290624999978
    c2010     r1760     10000
    c2010     r4868     -0.00850907719999983
    c2011     r4982     -0.6103515625
    c2012     r3317     -1
    c2012     r3319     1
    c2013     r1762     10000
    c2013     r6728     0.168364774400004
    c2013     r6924     -0.9993423251
    c2014     r265      -10000
    c2014     r1763     10000
    c2015     r4993     -0.6103515625
    c2016     r267      -10000
    c2016     r1765     10000
    c2017     r268      -10000
    c2017     r1766     10000
    c2018     r269      -10000
    c2019     r270      -10000
    c2019     r1768     10000
    c2019     r6174     -0.0738708599999996
    c2019     r6440     -0.0625
    c2019     r6493     -0.1157661425
    c2019     r6552     0.0659853474978786
    c2019     r6700     0.0706088578492288
    c2019     r6824     0.0706649597167966
    c2019     r6930     -0.609762829589844
    c2019     r7077     -0.609762829589844
    c2020     r4711     0.0147209374999875
    c2020     r4903     -0.6103515625
    c2020     r6980     0.6103515625
    c2020     r6982     -0.6103515625
    c2021     r272      -10000
    c2021     r7059     0.597511982161764
    c2022     r1771     10000
    c2022     r4563     -0.0415000000000418
    c2022     r5292     -0.0415000000000418
    c2023     r274      -10000
    c2023     r1772     10000
    c2024     r275      -10000
    c2024     r1773     10000
    c2025     r276      -10000
    c2025     r1774     10000
    c2026     r277      -10000
    c2026     r1775     10000
    c2027     r278      -10000
    c2027     r1776     10000
    c2028     r279      -10000
    c2028     r5003     -0.6103515625
    c2029     r279      1
    c2029     r3397     -1
    c2029     r3398     1
    c2029     r4714     -0.03125
    c2030     r280      -10000
    c2030     r1778     10000
    c2031     r281      -10000
    c2031     r1779     10000
    c2032     r282      -10000
    c2032     r1780     10000
    c2032     r6389     0.0832937500000526
    c2032     r6470     0.000162683105468853
    c2032     r6525     0.000162683105468853
    c2032     r6769     0.0682342399999811
    c2032     r7084     -0.068234240000038
    c2033     r283      -10000
    c2033     r4722     0.824926720000008
    c2034     r284      -10000
    c2034     r1782     10000
    c2034     r4756     -0.824926720000008
    c2034     r5086     -0.824926720000008
    c2034     r5239     -0.103679528808594
    c2034     r5240     -0.0518397644042969
    c2034     r5325     -0.829436230468751
    c2034     r6488     -0.703283886718751
    c2034     r6866     0.566396319580078
    c2034     r6960     -0.824926720000008
    c2035     r285      -10000
    c2035     r1783     10000
    c2036     r4917     -0.6103515625
    c2036     r5011     -0.6103515625
    c2036     r5449     -0.6103515625
    c2037     r3412     -1
    c2037     r3414     1
    c2037     r5017     -6.103515625e-05
    c2038     r287      -10000
    c2038     r1785     10000
    c2039     r4443     -0.559154415999998
    c2039     r4839     0.965052849
    c2039     r6486     0.0112021911621093
    c2039     r6675     0.589021514282227
    c2039     r6736     0.6103515625
    c2039     r6848     0.526707379417573
    c2039     r6886     -0.0349471509999999
    c2039     r7059     0.0165990671845282
    c2040     r1787     10000
    c2040     r4935     -0.0415000000000418
    c2041     r1788     10000
    c2041     r6444     -0.0572204589843751
    c2041     r6903     -0.00253045654296868
    c2042     r5292     -0.0415000000000418
    c2042     r5898     0.965052849
    c2042     r6444     0.019073486328125
    c2042     r6675     0.589021514282227
    c2042     r6736     0.6103515625
    c2042     r6848     0.545780865745698
    c2042     r7059     0.597511982161764
    c2043     r292      -10000
    c2043     r5294     0.0138844812011718
    c2043     r5631     0.0138745697021485
    c2043     r6360     -0.6103515625
    c2043     r6495     0.0026822900390624
    c2043     r6807     -0.259934553583034
    c2043     r7027     -0.6103515625
    c2044     r293      -10000
    c2044     r5631     -0.596476992797851
    c2044     r6350     -0.582582600097656
    c2044     r6360     -0.0138745697021485
    c2044     r6823     -0.6103515625
    c2044     r7027     -0.596476992797851
    c2045     r293      1
    c2045     r3421     1
    c2045     r4265     -1
    c2045     r5085     -6.103515625e-05
    c2045     r6360     -6.103515625e-05
    c2046     r1792     10000
    c2046     r5294     -0.0138844812011718
    c2046     r5404     0.596476992797852
    c2046     r6345     0.596476992797851
    c2046     r6495     -0.0026822900390624
    c2046     r6640     0.819981881341459
    c2046     r6807     0.259934553583034
    c2046     r7027     0.0138745697021485
    c2047     r295      -10000
    c2047     r4928     0.9742934
    c2047     r5808     -0.560945559700624
    c2047     r7039     -0.593811100966525
    c2048     r5808     0.03125
    c2048     r6847     -0.9485868
    c2048     r7048     0.0541997843528921
    c2049     r3381     1
    c2049     r3384     -1
    c2049     r5043     -0.03125
    c2049     r5264     0.03125
    c2049     r5808     6.07820559700624e-05
    c2049     r6287     0.03125
    c2049     r6421     6.103515625e-05
    c2049     r6443     6.103515625e-05
    c2049     r6550     6.103515625e-05
    c2050     r1795     10000
    c2050     r5487     0.602772441833496
    c2050     r5562     -0.996588326
    c2050     r6920     0.602772441833496
    c2050     r7086     0.656168378826255
    c2051     r298      -10000
    c2051     r1796     10000
    c2052     r299      -10000
    c2053     r299      1
    c2053     r3431     1
    c2053     r3849     -1
    c2054     r300      -10000
    c2055     r300      1
    c2055     r3431     1
    c2055     r3433     -1
    c2056     r301      -10000
    c2056     r1799     10000
    c2057     r6170     -0.30517578125
    c2058     r303      -10000
    c2058     r5162     0.900508154296875
    c2058     r5383     -0.320194970703125
    c2058     r5969     -0.64038994140625
    c2058     r6170     0.55309278838454
    c2058     r6541     -0.6103515625
    c2058     r6625     -0.320194970703125
    c2058     r6684     -0.6103515625
    c2059     r304      -10000
    c2059     r6676     -0.0571904516999999
    c2059     r6689     0.9428095483
    c2060     r305      -10000
    c2060     r4914     0.57769387713623
    c2060     r4992     0.6103515625
    c2061     Obj       0
    c2062     r3438     1
    c2062     r3439     -1
    c2063     r307      -10000
    c2063     r4817     0.57769387713623
    c2063     r4976     -0.522522965820313
    c2064     r5473     -0.015625
    c2065     r3439     1
    c2065     r3441     -1
    c2066     r309      -10000
    c2066     r5093     0.577693840515137
    c2066     r5462     0.0589456000000013
    c2066     r5473     0.552792810005303
    c2067     r310      -10000
    c2067     r5093     0.577693840515137
    c2067     r5169     -0.6103515625
    c2067     r5385     0.575445244323731
    c2068     r1809     10000
    c2069     r5394     -0.9428094883
    c2070     r3465     1
    c2070     r4151     -1
    c2071     r313      -10000
    c2071     r4563     0.0415000000000418
    c2071     r4935     0.0415000000000418
    c2071     r5110     0.605501112670898
    c2071     r5292     0.0415000000000418
    c2071     r6903     -0.607821105957031
    c2072     r4935     -0.0415000000000418
    c2072     r5150     0.6103515625
    c2073     r4873     -0.607810725708008
    c2073     r4968     0.643093749999991
    c2074     r1814     10000
    c2074     r4903     0.00302317932128904
    c2074     r4945     -0.607357135009766
    c2074     r6818     0.608524291992188
    c2074     r6967     -0.0916655899876049
    c2074     r6982     0.292388840637207
    c2075     r4970     0.7665734375
    c2075     r5113     -0.607357135009766
    c2075     r6982     0.00299442749023437
    c2076     r1816     10000
    c2076     r5110     -0.605501112670898
    c2076     r6818     -0.605529864501953
    c2076     r6980     0.286371233825684
    c2077     r5294     -0.0138844812011718
    c2077     r5750     -0.0138943927001953
    c2077     r6091     -0.0138844812011718
    c2077     r6345     -0.0138745697021484
    c2077     r6350     -0.0277689624023437
    c2077     r6356     -0.610286901855469
    c2077     r6433     0.596476992797851
    c2077     r6495     -0.0026822900390624
    c2077     r6496     0.563545082691083
    c2077     r6509     -0.638130436401367
    c2077     r6514     -0.0277689624023438
    c2077     r6517     -0.0277887854003906
    c2077     r6521     -0.0555379248046872
    c2077     r6596     0.6103515625
    c2077     r6739     -0.0555379248046874
    c2077     r6750     -0.0533425306472004
    c2077     r6779     -0.638130436401367
    c2077     r6807     -0.0130132430515241
    c2077     r6979     0.31905530670166
    c2077     r6994     -0.0277689624023438
    c2078     r1818     10000
    c2078     r6356     0.59641233215332
    c2078     r6496     0.0265794633052281
    c2078     r6521     -0.666008897094726
    c2078     r6596     -0.319129878845215
    c2078     r6747     -0.63825975769043
    c2078     r6750     0.556598109649416
    c2078     r6773     -0.63825975769043
    c2078     r6779     -0.000129321289062512
    c2078     r6807     -0.0261569821645035
    c2078     r6808     -0.0278336230468751
    c2078     r6967     0.932134852444811
    c2078     r6977     -6.46606445311448e-05
    c2078     r6980     0.00485044982910154
    c2078     r6982     -0.00116715698242187
    c2079     r4925     -0.599387817382812
    c2079     r5055     0.701679687499997
    c2079     r5314     0.605625244140625
    c2080     r322      -10000
    c2080     r5022     0.0109637451171875
    c2080     r5408     0.594661499023437
    c2081     r323      -10000
    c2081     r4849     0.605625244140625
    c2081     r5022     -0.599387817382813
    c2081     r5073     -0.00487756185845145
    c2081     r5132     -0.604968749999998
    c2081     r5320     -0.599387817382812
    c2081     r5408     -0.599387817382812
    c2081     r5480     -0.982037
    c2081     r6671     -0.718685546875001
    c2081     r6878     -0.900885318019727
    c2081     r6929     0.431280203674095
    c2081     r7072     -0.58657996124502
    c2082     r1822     10000
    c2082     r4927     0.0257065999999999
    c2082     r4928     0.0257065999999999
    c2082     r5314     -0.594661499023437
    c2082     r5808     0.015625
    c2082     r6174     -0.0738708599999996
    c2082     r6261     -0.0687893328253637
    c2082     r6263     -0.0789131680430819
    c2082     r6357     0.0202977791666667
    c2082     r6440     -0.0625
    c2082     r6493     -0.1157661425
    c2082     r6552     0.0659853474978786
    c2082     r6666     -0.832402343750005
    c2082     r6700     0.0706088578492288
    c2082     r6824     0.0706649597167966
    c2082     r6847     0.0257065999999999
    c2082     r6878     0.0231586985162058
    c2082     r6904     0.0257065999999999
    c2082     r6929     0.0420649109091476
    c2082     r7039     0.0165404615334753
    c2082     r7048     0.027099892176446
    c2083     r325      -10000
    c2083     r5019     0.571767510986328
    c2084     r5168     -0.0632161099999999
    c2084     r6263     -0.0675311416634374
    c2084     r6422     -0.0632161099999999
    c2084     r6692     -0.0534853239152756
    c2084     r6755     -0.0534853239152756
    c2084     r6929     -0.0325822168666297
    c2084     r6998     -0.0534853239152756
    c2085     r3945     -1
    c2085     r4196     1
    c2086     r327      -10000
    c2086     r4822     -0.0299310974121094
    c2086     r4926     0.580420465087891
    c2086     r5135     -0.957795117187501
    c2087     Obj       0
    c2088     r3457     1
    c2088     r3463     -1
    c2089     r4829     0.9428095483
    c2089     r5023     -0.6103515625
    c2089     r5177     -0.575445280944824
    c2089     r5546     -0.610886822620479
    c2089     r5642     -0.5004384850907
    c2090     r330      -10000
    c2090     r4816     0.9428095483
    c2090     r5980     -0.0571904517000006
    c2091     r331      -10000
    c2091     r1829     10000
    c2091     r4832     -0.0571905117
    c2091     r5023     0.575445280944824
    c2091     r5095     -0.0571904516999999
    c2091     r5177     0.575445280944824
    c2091     r5546     0.573830671262828
    c2091     r5642     0.5004384850907
    c2091     r5980     -0.0571904517000006
    c2091     r6676     -0.0571904516999999
    c2091     r6679     -0.0618990081063717
    c2092     r1830     10000
    c2092     r6407     0.6103515625
    c2093     r3469     -1
    c2093     r3471     1
    c2093     r6407     6.103515625e-05
    c2093     r6649     -0.03125
    c2093     r6672     -0.000104347826086957
    c2093     r6679     -0.00010823311630947
    c2093     r6711     -0.03125
    c2094     r333      -10000
    c2094     r4571     -0.915047227199999
    c2094     r4829     0.9428095483
    c2094     r4834     -0.0571905117
    c2094     r5023     -0.575445280944824
    c2094     r5177     -0.6103515625
    c2094     r5546     -0.610886822620479
    c2094     r5642     -0.5004384850907
    c2094     r5680     -0.558500504882812
    c2095     r5234     -0.6103515625
    c2096     r3467     -1
    c2096     r3473     1
    c2097     r335      -10000
    c2097     r1833     10000
    c2097     r5909     0.589021514282227
    c2097     r6065     -0.0426600964355466
    c2097     r6086     0.567691466064453
    c2097     r6436     0.589021514282227
    c2097     r6437     -0.0213300482177735
    c2097     r6480     -0.528875919604692
    c2097     r6522     0.676955091200002
    c2097     r6532     -0.6103515625
    c2097     r6664     -0.10291186033552
    c2097     r6765     0.589021514282227
    c2097     r6848     -0.019073486328125
    c2097     r6883     -0.0213300482177734
    c2097     r6886     0.930105698
    c2098     r5175     0.9153806136
    c2098     r5300     -0.610212463378906
    c2098     r5558     0.966572678
    c2099     r337      -10000
    c2099     r1835     10000
    c2100     r338      -10000
    c2101     r338      1
    c2101     r3619     -1
    c2101     r3633     1
    c2101     r4545     0.03125
    c2102     r5277     -0.157965465600114
    c2102     r6515     0.6103515625
    c2103     r340      -10000
    c2104     r340      1
    c2104     r3590     -1
    c2104     r3601     1
    c2104     r4549     0.03125
    c2105     r341      -10000
    c2106     r342      -10000
    c2106     r1840     10000
    c2107     r5664     -0.157965465600114
    c2107     r6392     0.6103515625
    c2107     r6971     -0.157965465600114
    c2108     r1842     10000
    c2109     r345      -10000
    c2110     r1844     10000
    c2111     r347      -10000
    c2111     r1845     10000
    c2112     r5104     -0.605158033935547
    c2113     r349      -10000
    c2113     r1847     10000
    c2113     r6492     0.571762460388184
    c2113     r6556     0.565211568776554
    c2113     r6692     -0.0625
    c2113     r6755     0.685615131257435
    c2113     r6835     0.9367756151
    c2113     r6998     0.667585779087987
    c2114     r350      -10000
    c2114     r1848     10000
    c2114     r7056     -0.609479736328125
    c2115     r1849     10000
    c2115     r6902     -0.609479736328125
    c2116     r1850     10000
    c2116     r5081     -0.0186506239999744
    c2117     r1851     10000
    c2118     Obj       0
    c2119     r1853     10000
    c2120     r1854     10000
    c2121     r1855     10000
    c2122     r1856     10000
    c2123     Obj       0
    c2124     r360      -10000
    c2124     r1858     10000
    c2125     r361      -10000
    c2125     r1859     10000
    c2126     r362      -10000
    c2127     r362      1
    c2127     r3515     -1
    c2127     r3516     1
    c2128     Obj       0
    c2129     r1862     10000
    c2130     r365      -10000
    c2130     r1863     10000
    c2130     r7053     0.610009716796875
    c2131     r366      -10000
    c2131     r1864     10000
    c2131     r7011     0.608610308898926
    c2132     r6842     -0.6103515625
    c2133     r368      -10000
    c2133     r1866     10000
    c2133     r6820     0.608610308898926
    c2134     r369      -10000
    c2134     r1867     10000
    c2135     r370      -10000
    c2135     r1868     10000
    c2135     r6921     0.609995877685547
    c2136     r371      -10000
    c2136     r1869     10000
    c2136     r7067     0.609995877685547
    c2137     Obj       0
    c2138     r1871     10000
    c2139     r1872     10000
    c2140     r1873     10000
    c2141     r1874     10000
    c2142     r1875     10000
    c2143     r1876     10000
    c2144     r1877     10000
    c2145     Obj       0
    c2146     r1879     10000
    c2147     r1880     10000
    c2148     r383      -10000
    c2148     r1881     10000
    c2148     r6821     0.608610308898926
    c2149     r1882     10000
    c2150     r1883     10000
    c2151     r1884     10000
    c2152     r1885     10000
    c2153     r1886     10000
    c2154     r1887     10000
    c2155     r1888     10000
    c2156     r1889     10000
    c2157     r392      -10000
    c2158     r5154     -0.609974943481445
    c2159     r394      -10000
    c2159     r1892     10000
    c2160     r4732     -0.6103515625
    c2161     r4649     -1
    c2162     r397      -10000
    c2163     r398      -10000
    c2163     r1896     10000
    c2164     r399      -10000
    c2164     r1897     10000
    c2165     r400      -10000
    c2165     r1898     10000
    c2166     r401      -10000
    c2166     r1899     10000
    c2167     r5283     -0.6103515625
    c2168     r403      -10000
    c2168     r1901     10000
    c2169     r4733     -0.6103515625
    c2170     r405      -10000
    c2171     r406      -10000
    c2171     r1904     10000
    c2172     r407      -10000
    c2172     r1905     10000
    c2173     r408      -10000
    c2173     r1906     10000
    c2173     r5450     -0.6103515625
    c2174     r6391     -0.6103515625
    c2174     r6516     -0.6103515625
    c2174     r6593     -0.6103515625
    c2174     r6659     -0.6103515625
    c2174     r6719     -0.6103515625
    c2174     r6772     -0.6103515625
    c2174     r6877     -0.0330807534179687
    c2174     r6891     -0.00476837158203125
    c2174     r7021     -0.0478707075999997
    c2175     r4584     -0.6103515625
    c2176     r3744     -1
    c2176     r4252     1
    c2176     r6950     -0.03125
    c2177     r411      -10000
    c2177     r1909     10000
    c2178     r412      -10000
    c2178     r4997     -0.6103515625
    c2179     r4997     -0.6103515625
    c2180     r414      -10000
    c2180     r1912     10000
    c2180     r6409     -0.6103515625
    c2180     r6483     -0.6103515625
    c2181     r415      -10000
    c2181     r1913     10000
    c2182     r416      -10000
    c2182     r1914     10000
    c2183     r417      -10000
    c2183     r1915     10000
    c2184     r418      -10000
    c2184     r1916     10000
    c2185     r419      -10000
    c2185     r1917     10000
    c2186     r420      -10000
    c2186     r1918     10000
    c2187     r421      -10000
    c2187     r1919     10000
    c2188     r422      -10000
    c2188     r1920     10000
    c2188     r6483     0.30517578125
    c2189     r423      -10000
    c2189     r1921     10000
    c2189     r6940     0.609861331176758
    c2190     r424      -10000
    c2190     r1922     10000
    c2190     r7082     -0.609861331176758
    c2191     r425      -10000
    c2191     r1923     10000
    c2191     r6966     -0.000356750488281321
    c2191     r7080     0.609994812011719
    c2192     r426      -10000
    c2192     r6483     -0.30517578125
    c2193     r427      -10000
    c2193     r1925     10000
    c2194     r428      -10000
    c2194     r1926     10000
    c2195     r429      -10000
    c2195     r1927     10000
    c2196     r430      -10000
    c2196     r1928     10000
    c2197     r431      -10000
    c2197     r1929     10000
    c2198     r432      -10000
    c2198     r1930     10000
    c2199     r433      -10000
    c2199     r1931     10000
    c2200     r434      -10000
    c2200     r6394     -0.00035675048828121
    c2200     r6395     -0.00035675048828121
    c2200     r6916     0.609994812011719
    c2201     r435      -10000
    c2201     r6940     0.609861331176758
    c2202     r436      -10000
    c2203     r437      -10000
    c2203     r1935     10000
    c2203     r7082     0.609861331176758
    c2204     r438      -10000
    c2204     r1936     10000
    c2205     r439      -10000
    c2205     r1937     10000
    c2206     r440      -10000
    c2206     r1938     10000
    c2207     r441      -10000
    c2207     r1939     10000
    c2208     r442      -10000
    c2208     r1940     10000
    c2209     r443      -10000
    c2209     r1941     10000
    c2210     r444      -10000
    c2210     r1942     10000
    c2211     r5694     -0.609787815795898
    c2211     r6970     -1
    c2212     r446      -10000
    c2213     r447      -10000
    c2214     r448      -10000
    c2215     r449      -10000
    c2216     r6472     -0.166587500000105
    c2217     r4470     -0.6103515625
    c2218     r3735     -1
    c2218     r3736     1
    c2219     r5155     -0.6103515625
    c2220     r5450     -0.6103515625
    c2221     r5293     -1
    c2222     r5450     0.6103515625
    c2222     r5677     -0.6103515625
    c2222     r5871     0.000617052600000001
    c2223     r1954     10000
    c2223     r5153     -0.609974943481445
    c2223     r5421     -0.068234240000038
    c2223     r6769     -0.068234240000038
    c2224     r5130     -0.192828937499996
    c2224     r5153     -0.000376619018554791
    c2224     r5154     -0.000376619018554791
    c2224     r6935     0.609974943481445
    c2224     r6971     -0.157965465600114
    c2225     r5972     -0.157965465600114
    c2225     r6044     0.6103515625
    c2226     r6120     -0.6103515625
    c2226     r7084     -0.068234240000038
    c2227     r4638     -0.6103515625
    c2228     r461      -10000
    c2229     r462      -10000
    c2230     r463      -10000
    c2230     r1961     10000
    c2231     r463      1
    c2231     r3592     -1
    c2231     r3604     1
    c2231     r4547     0.03125
    c2232     r5676     -0.610164434814453
    c2233     r5277     -0.1579654656
    c2233     r5664     -0.1579654656
    c2233     r5744     -0.1579654656
    c2233     r5871     -0.000617052600000001
    c2233     r5972     -0.1579654656
    c2233     r6028     -0.1579654656
    c2233     r6519     1
    c2233     r6971     -0.1579654656
    c2233     r7081     1
    c2234     r1964     10000
    c2234     r5676     -0.000187127685546962
    c2234     r5831     -0.0784870400000273
    c2235     r5694     -0.000563746704101642
    c2235     r5744     -0.236452505600141
    c2235     r5871     0.998459304799999
    c2236     r468      -10000
    c2236     r1966     10000
    c2237     r4578     -0.6103515625
    c2237     r6409     -0.6103515625
    c2238     r470      -10000
    c2238     r5601     -0.6103515625
    c2239     r470      1
    c2239     r3559     -1
    c2239     r3608     1
    c2239     r4748     0.03125
    c2239     r5687     6.103515625e-05
    c2240     r5002     -0.6103515625
    c2241     r5687     -0.6103515625
    c2242     r1971     10000
    c2242     r5694     0.6103515625
    c2242     r6028     -0.236452505600141
    c2242     r6483     0.30517578125
    c2243     r474      -10000
    c2244     r5848     -0.11426562500003
    c2244     r6943     0.99963435
    c2245     r476      -10000
    c2245     r6942     0.99963435
    c2246     r477      -10000
    c2246     r4560     0.125
    c2247     r1976     10000
    c2247     r4641     -0.99923435
    c2247     r5848     0.11426562500003
    c2247     r6483     -0.30517578125
    c2247     r6879     -0.608873608398438
    c2248     r479      -10000
    c2248     r4623     -0.0936063999999988
    c2248     r6941     0.99963435
    c2249     r480      -10000
    c2249     r1978     10000
    c2250     r481      -10000
    c2250     r1979     10000
    c2251     r482      -10000
    c2252     r483      -10000
    c2253     r484      -10000
    c2253     r1982     10000
    c2254     r485      -10000
    c2254     r6879     0.000543322753906159
    c2255     r4639     -0.6103515625
    c2256     r1985     10000
    c2256     r4778     -0.6103515625
    c2256     r5662     0.227886080000019
    c2257     r488      -10000
    c2257     r1986     10000
    c2258     r489      -10000
    c2259     r490      -10000
    c2259     r6966     -0.609994812011719
    c2260     r5357     -0.6103515625
    c2261     r5354     -0.6103515625
    c2262     r493      -10000
    c2262     r1991     10000
    c2263     r494      -10000
    c2264     r494      1
    c2264     r3620     -1
    c2264     r3634     1
    c2265     r495      -10000
    c2266     r495      1
    c2266     r3621     -1
    c2266     r3635     1
    c2266     r4540     0.03125
    c2267     r496      -10000
    c2267     r1994     10000
    c2268     r497      -10000
    c2268     r1995     10000
    c2269     r498      -10000
    c2270     r498      1
    c2270     r3622     -1
    c2270     r3636     1
    c2271     r499      -10000
    c2272     r499      1
    c2272     r3623     -1
    c2272     r3637     1
    c2272     r4555     0.03125
    c2272     r4981     0.03125
    c2273     r500      -10000
    c2273     r1998     10000
    c2274     r501      -10000
    c2275     r502      -10000
    c2276     r502      1
    c2276     r3624     -1
    c2276     r3638     1
    c2277     r6395     -0.6103515625
    c2278     r504      -10000
    c2278     r2002     10000
    c2279     r505      -10000
    c2279     r6965     -0.365312500000073
    c2280     r505      1
    c2280     r3631     -1
    c2280     r3640     1
    c2280     r4425     0.03125
    c2281     r6394     -0.6103515625
    c2282     r5951     -0.6103515625
    c2282     r6965     -0.365312500000073
    c2283     r5952     -0.6103515625
    c2284     r6047     -0.6103515625
    c2284     r6964     -0.365312500000073
    c2285     r510      -10000
    c2285     r7069     -0.00398456127929681
    c2286     r6404     -0.510023843749977
    c2287     r5600     -0.597381446411133
    c2288     r513      -10000
    c2288     r6746     -0.0377283308105471
    c2288     r6877     -0.0248410073242187
    c2288     r6969     -0.799675578124997
    c2288     r7015     -0.03814697265625
    c2288     r7021     -0.0478707075999997
    c2288     r7047     -0.0124949309082031
    c2289     r514      -10000
    c2289     r2012     10000
    c2289     r5600     -0.0129701160888671
    c2289     r6361     -0.0290790003662109
    c2289     r6404     -0.510023843749977
    c2289     r6523     0.799675578124997
    c2289     r6693     0.0333513769531248
    c2289     r6770     -0.791015625
    c2289     r7069     0.606367001220703
    c2290     r6453     0.526243476562499
    c2290     r6454     -0.824512459823929
    c2290     r6577     -0.791015625
    c2290     r6578     0.647098656000004
    c2290     r6663     -0.6103515625
    c2290     r6718     -0.6103515625
    c2291     r516      -10000
    c2292     r6717     -0.6103515625
    c2292     r6775     -0.6103515625
    c2293     r3629     -1
    c2293     r3650     1
    c2293     r4609     0.03125
    c2294     r6361     -0.581272562133789
    c2294     r6693     -0.6103515625
    c2294     r7047     -0.6103515625
    c2295     r519      -10000
    c2295     r2017     10000
    c2295     r5585     0.666666666666667
    c2295     r7069     -0.606367001220703
    c2296     r520      -10000
    c2296     r6404     0.510023843749977
    c2297     r521      -10000
    c2297     r5584     0.666666666666667
    c2297     r6195     0.125
    c2298     r522      -10000
    c2299     r523      -10000
    c2299     r2021     10000
    c2299     r6722     0.25
    c2299     r6778     1
    c2299     r6879     -0.608873608398438
    c2300     r4641     -0.000765649999999951
    c2300     r4962     -0.125
    c2300     r6894     0.99923435
    c2301     r525      -10000
    c2302     r6722     -0.25
    c2303     r527      -10000
    c2303     r6722     -0.25
    c2303     r6778     -1
    c2304     r4800     -0.6103515625
    c2305     r4801     -0.6103515625
    c2306     r530      -10000
    c2307     r530      1
    c2307     r3626     -1
    c2307     r3666     1
    c2308     r531      -10000
    c2309     r6500     -0.603883056640625
    c2309     r6557     -0.603883056640625
    c2309     r7004     -0.890414826126232
    c2310     r5618     -0.603883056640625
    c2310     r6815     -0.6103515625
    c2311     r3326     -1
    c2311     r3327     1
    c2311     r5618     6.103515625e-05
    c2311     r6815     6.103515625e-05
    c2312     r534      -10000
    c2312     r2032     10000
    c2312     r6780     -0.885607957166872
    c2313     r2033     10000
    c2313     r6729     0.168364774400004
    c2313     r6923     -0.9993423251
    c2314     r2034     10000
    c2314     r6731     -0.157992934399999
    c2315     r537      -10000
    c2315     r2035     10000
    c2315     r4442     0.784682812499994
    c2315     r4692     0.78468749999999
    c2315     r4757     0.784687500000004
    c2315     r4865     -0.930428717394978
    c2315     r5321     0.00613037109375003
    c2315     r6843     0.0122607055664061
    c2315     r7018     -0.603400817871094
    c2316     r538      -10000
    c2316     r2036     10000
    c2317     r2037     10000
    c2317     r5079     0.152290624999978
    c2317     r6946     -0.99951267
    c2318     r540      -10000
    c2318     r4697     0.0932864000000109
    c2319     r2039     10000
    c2319     r4867     -0.606874769775391
    c2320     r5187     -0.605158033935547
    c2321     r2041     10000
    c2321     r4432     -0.452121599999998
    c2321     r4753     -0.452121599999998
    c2322     r544      -10000
    c2322     r4438     -0.544580940800003
    c2322     r5029     0.9914909228
    c2322     r5104     0.00347679272460932
    c2322     r5187     0.0051935285644531
    c2322     r5245     0.0051935285644531
    c2322     r6846     0.0051935285644531
    c2322     r7029     0.00476837158203125
    c2323     r545      -10000
    c2323     r2043     10000
    c2324     r546      -10000
    c2324     r4696     0.124756479999974
    c2325     r547      -10000
    c2325     r2045     10000
    c2326     r548      -10000
    c2326     r2046     10000
    c2327     r4897     -0.60422119140625
    c2328     r3750     -1
    c2328     r3752     1
    c2329     r550      -10000
    c2329     r2048     10000
    c2330     r551      -10000
    c2331     r552      -10000
    c2332     r553      -10000
    c2333     r4442     0.784682812499994
    c2333     r4535     -1
    c2333     r6843     -0.0122607055664061
    c2334     r4865     -0.0095367431640625
    c2334     r5321     0.60422119140625
    c2335     r3750     -1
    c2335     r3753     1
    c2336     r4865     -0.0095367431640625
    c2336     r4897     -0.00613037109374992
    c2337     r3752     -1
    c2337     r3753     1
    c2337     r4897     6.103515625e-05
    c2338     r4442     -0.784682812499994
    c2338     r4645     0.6103515625
    c2338     r6843     -0.0122607055664061
    c2339     r2056     10000
    c2339     r4433     0.356054271999994
    c2339     r4692     -0.78468749999999
    c2339     r6908     -0.609531188964844
    c2339     r6933     0.0013908370000002
    c2340     r559      -10000
    c2340     r2057     10000
    c2340     r6908     0.609531188964844
    c2340     r7018     0.603400817871094
    c2341     r560      -10000
    c2341     r2058     10000
    c2342     r561      -10000
    c2342     r2059     10000
    c2343     r562      -10000
    c2343     r2060     10000
    c2343     r6843     0.598090856933594
    c2344     r563      -10000
    c2344     r2061     10000
    c2345     r564      -10000
    c2345     r2062     10000
    c2345     r5643     0.606530737304688
    c2345     r5805     0.603354589904785
    c2346     r2063     10000
    c2346     r5482     -0.60335693359375
    c2346     r6850     -0.9776253001
    c2346     r7033     -0.596695129455566
    c2347     r566      -10000
    c2347     r2064     10000
    c2348     r567      -10000
    c2348     r2065     10000
    c2349     r568      -10000
    c2349     r2066     10000
    c2349     r6829     -0.60335693359375
    c2349     r7014     -0.60335693359375
    c2349     r7029     0.55561808043315
    c2350     r2067     10000
    c2350     r5726     -0.596695129455566
    c2351     r2068     10000
    c2351     r5106     -0.98854
    c2351     r5174     -0.60335693359375
    c2351     r7014     0.6103515625
    c2352     r2069     10000
    c2353     r4452     -0.828718734374991
    c2354     r2071     10000
    c2354     r5805     -0.603354589904785
    c2355     r574      -10000
    c2355     r2072     10000
    c2356     r575      -10000
    c2356     r2073     10000
    c2357     r576      -10000
    c2357     r2074     10000
    c2358     r577      -10000
    c2358     r2075     10000
    c2359     r2076     10000
    c2359     r5024     -0.596695129455566
    c2360     r5105     -0.9890853001
    c2360     r6850     0.98854
    c2360     r7033     -0.6103515625
    c2361     r5106     0.98854
    c2361     r5181     -0.603689758361816
    c2361     r5726     0.60335693359375
    c2362     r4870     0.98854
    c2362     r5189     -0.603689758361816
    c2363     r2080     10000
    c2363     r5643     -0.606530737304688
    c2364     r583      -10000
    c2364     r2081     10000
    c2364     r5024     0.596695129455566
    c2364     r5105     0.9776253001
    c2364     r5180     -0.00666180413818362
    c2364     r5181     -0.00666180413818362
    c2364     r5189     -0.00666180413818362
    c2364     r5726     0.596695129455566
    c2364     r6850     0.9776253001
    c2364     r7033     0.596695129455566
    c2365     r584      -10000
    c2365     r2082     10000
    c2366     r585      -10000
    c2366     r2083     10000
    c2367     r586      -10000
    c2367     r2084     10000
    c2368     r587      -10000
    c2368     r2085     10000
    c2369     r5221     -0.6103515625
    c2369     r5291     -0.6103515625
    c2369     r5436     -0.6103515625
    c2370     r3761     1
    c2370     r3836     -1
    c2370     r5291     6.103515625e-05
    c2371     r5180     -0.603689758361816
    c2371     r5482     0.60335693359375
    c2371     r6829     0.60335693359375
    c2372     r2088     10000
    c2372     r6472     0.166587500000105
    c2372     r6685     -0.608600370727539
    c2373     r2089     10000
    c2373     r6389     -0.0832937500000526
    c2373     r6470     -0.000162683105468853
    c2373     r6472     -0.166587500000105
    c2374     r2090     10000
    c2374     r6686     -0.608600370727539
    c2375     r593      -10000
    c2375     r6303     -0.166587499999991
    c2375     r6677     0.6103515625
    c2375     r6786     0.813316437500021
    c2375     r7034     -0.608763053833008
    c2376     r6685     -0.6103515625
    c2376     r6867     0.608763053833008
    c2377     r6686     0.6103515625
    c2377     r6880     -0.608763053833008
    c2377     r6934     0.00385421260000007
    c2378     r5421     -0.0682342399999811
    c2378     r6525     0.6103515625
    c2378     r6673     -0.0832937499999957
    c2378     r6769     -0.0682342399999811
    c2379     r2095     10000
    c2379     r6470     0.6103515625
    c2379     r6674     0.6103515625
    c2379     r6932     -0.608763053833008
    c2380     r2096     10000
    c2380     r6525     -0.000162683105468853
    c2380     r6680     -0.0832937500000526
    c2381     r6472     0.166587500000105
    c2381     r6680     0.0832937500000526
    c2381     r6720     -0.6103515625
    c2382     r600      -10000
    c2382     r2098     10000
    c2383     r601      -10000
    c2383     r6650     -0.813316437500021
    c2383     r6677     -0.00158850866699223
    c2383     r6678     -0.00158850866699223
    c2383     r6685     -0.00175119177246108
    c2383     r6686     -0.00175119177246108
    c2383     r6880     0.6103515625
    c2384     r6678     -0.608763053833008
    c2384     r6932     0.6103515625
    c2385     r603      -10000
    c2385     r2101     10000
    c2385     r6786     -0.813316437500021
    c2385     r6867     0.608763053833008
    c2385     r6932     -0.00158850866699223
    c2385     r7034     0.608763053833008
    c2386     r604      -10000
    c2386     r2102     10000
    c2387     r605      -10000
    c2387     r2103     10000
    c2387     r6914     -0.609587646484375
    c2387     r7063     -0.609587646484375
    c2388     r606      -10000
    c2388     r6914     0.609587646484375
    c2389     r607      -10000
    c2389     r2105     10000
    c2389     r7063     0.609587646484375
    c2390     r2106     10000
    c2390     r6093     -0.0481259639893931
    c2390     r6164     0.144230171201071
    c2390     r6265     0.13775241282978
    c2390     r6420     0.110598014276359
    c2390     r6494     -0.0349062815551757
    c2390     r6545     0.0815496539611456
    c2390     r6679     0.136427803494766
    c2390     r6748     -0.0348744698839145
    c2390     r6800     0.0752524128297809
    c2390     r6997     0.0500509685490766
    c2391     r4922     0.9428095483
    c2391     r5183     -0.603229370117188
    c2391     r5795     0.1260499634
    c2391     r6093     -0.735432045512211
    c2391     r6164     0.14423017120107
    c2391     r6265     0.13775241282978
    c2391     r6344     0.0688594517000001
    c2391     r6420     0.110598014276359
    c2391     r6545     0.217009852004246
    c2391     r6679     0.136427803494766
    c2391     r6748     -0.139498025886536
    c2391     r6800     0.13775241282978
    c2391     r6997     0.0916202075499996
    c2392     r2108     10000
    c2392     r5795     -0.8739500366
    c2392     r6093     -0.783558009501605
    c2392     r6164     -0.790330788459172
    c2392     r6265     -0.754834942906214
    c2392     r6344     -0.9311405483
    c2392     r6420     -0.606038355894324
    c2392     r6494     -0.575445280944824
    c2392     r6545     -0.750270627825875
    c2392     r6679     -0.747576547998795
    c2392     r6748     -0.574920851664745
    c2392     r6800     -0.754834942906214
    c2392     r6997     -0.54361586536759
    c2393     r3767     1
    c2393     r4140     -1
    c2393     r6093     8.41503477570771e-05
    c2393     r6494     6.103515625e-05
    c2393     r6748     6.09795321548659e-05
    c2394     r6725     -0.635687846672997
    c2394     r6762     -0.0794609808341247
    c2395     Obj       0
    c2396     r4476     -0.6103515625
    c2396     r6976     0.6103515625
    c2397     r3781     1
    c2397     r4122     -1
    c2397     r4522     -0.03125
    c2397     r5399     6.103515625e-05
    c2397     r6953     0.03125
    c2398     r614      -10000
    c2398     r2112     10000
    c2398     r6492     -0.571762460388184
    c2398     r6556     -0.565211568776554
    c2399     r615      -10000
    c2399     r2113     10000
    c2400     r616      -10000
    c2400     r4820     0.92002495
    c2400     r6162     -0.92002495
    c2400     r6937     -0.0869270447502537
    c2401     r4448     -0.6398004
    c2401     r4932     -0.07997505
    c2401     r5637     0.92002495
    c2401     r5692     -0.0488128967285156
    c2401     r5693     -0.07997505
    c2401     r5918     -0.78100634765625
    c2401     r6558     -0.07997505
    c2401     r6931     -0.0488128967285157
    c2401     r6996     0.801383945747719
    c2401     r7001     -0.0488128967285157
    c2402     r2116     10000
    c2402     r5633     0.92002495
    c2402     r6856     -1
    c2402     r6996     -0.0762939453125
    c2402     r7024     -0.0488128967285159
    c2403     r3787     1
    c2403     r4131     -1
    c2403     r5170     0.0008
    c2403     r5637     0.0001
    c2403     r6856     0.0001
    c2403     r6996     9.53971836372719e-05
    c2404     r5178     0.0762939453125
    c2404     r5550     -0.549157031796875
    c2404     r6840     0.6103515625
    c2404     r6892     0.0762939453125
    c2404     r6931     0.0488128967285155
    c2404     r6996     0.0762939453125
    c2404     r7001     0.0488128967285157
    c2405     r5309     -0.0518397644042969
    c2406     r2119     10000
    c2406     r5979     -0.160097485351562
    c2406     r6067     0.450254077148438
    c2406     r6170     0.55309278838454
    c2406     r6308     -0.64038994140625
    c2406     r6441     0.450254077148438
    c2406     r6478     0.320194970703125
    c2406     r6542     0.6103515625
    c2406     r6632     0.6103515625
    c2406     r6761     0.900508154296875
    c2406     r6803     0.6103515625
    c2407     r622      -10000
    c2407     r6067     -0.160097485351562
    c2407     r6170     -0.30517578125
    c2407     r6441     0.6103515625
    c2407     r6547     0.6103515625
    c2408     r623      -10000
    c2408     r6067     -0.6103515625
    c2408     r6170     -0.85826856963454
    c2408     r6308     0.64038994140625
    c2408     r6478     -0.320194970703125
    c2408     r6542     -0.30517578125
    c2408     r6632     -0.6103515625
    c2408     r6761     -0.58031318359375
    c2408     r6803     -0.290156591796875
    c2409     r623      1
    c2409     r3793     -1
    c2409     r3794     1
    c2409     r6478     0.0001220703125
    c2409     r6542     0.000116344435088454
    c2409     r6547     8.27375139400187e-05
    c2409     r6632     8.27375139400187e-05
    c2409     r6761     0.0001220703125
    c2409     r6803     6.103515625e-05
    c2410     r6866     -0.0439552429199219
    c2411     r3405     -1
    c2411     r3796     1
    c2412     r625      -10000
    c2412     r2123     10000
    c2412     r5836     0.826835312500009
    c2413     r6468     -0.609594970703125
    c2414     r3797     -1
    c2414     r3799     1
    c2415     r627      -10000
    c2415     r2125     10000
    c2415     r5836     -0.826835312500009
    c2416     r628      -10000
    c2416     r6138     -1
    c2417     r628      1
    c2417     r3798     1
    c2417     r3833     -1
    c2417     r5425     0.03125
    c2418     r4986     -0.6103515625
    c2419     r3798     1
    c2419     r3844     -1
    c2420     r630      -10000
    c2421     r631      -10000
    c2421     r2129     10000
    c2422     r632      -10000
    c2423     r4931     0.558511798095703
    c2423     r5239     -0.103679528808594
    c2423     r5240     -0.602467041015625
    c2423     r5407     0.12615234375
    c2423     r7035     -0.6156555086324
    c2424     r6410     -0.160097485351562
    c2424     r6542     -0.30517578125
    c2425     r5090     -0.900508154296875
    c2425     r6485     -0.6103515625
    c2425     r6625     -0.900508154296875
    c2426     r3941     1
    c2426     r4282     -1
    c2426     r5090     0.0001220703125
    c2426     r5979     6.103515625e-05
    c2426     r6441     6.103515625e-05
    c2427     r636      -10000
    c2427     r4842     0.98208965
    c2427     r5688     -0.573131199999999
    c2427     r5919     0.98208965
    c2427     r6016     -0.0109316101074219
    c2427     r6884     -0.011130969670052
    c2427     r7013     0.599419952392578
    c2427     r7052     -0.98208965
    c2428     r2135     10000
    c2428     r4860     -0.606313757324219
    c2428     r6681     -0.1455078125
    c2429     r5000     -0.6103515625
    c2429     r6084     -0.019073486328125
    c2429     r6756     -0.0310616665039064
    c2429     r6790     0.57272497265625
    c2430     r3274     -1
    c2430     r4230     1
    c2431     r5098     -0.572724972656246
    c2431     r5248     -0.6103515625
    c2431     r5603     -0.313264582031248
    c2431     r6553     -0.564766733520508
    c2431     r6756     -0.592453907104492
    c2431     r6810     -0.617759160134395
    c2432     r3276     -1
    c2432     r4230     1
    c2433     r640      -10000
    c2433     r2138     10000
    c2434     r641      -10000
    c2434     r2139     10000
    c2434     r4850     -0.9837038637
    c2434     r4933     -0.9840929437
    c2434     r5028     -0.9841706947
    c2434     r5101     -0.9841706947
    c2434     r5191     -0.9913665004
    c2434     r5323     -0.9913665004
    c2434     r5403     -0.9841706947
    c2434     r5483     -0.9913665004
    c2434     r5639     -0.9913665004
    c2434     r5733     -0.999533169
    c2434     r6831     -0.9841706947
    c2434     r7057     -0.605477477912862
    c2435     r641      1
    c2435     r3837     -1
    c2435     r4115     1
    c2435     r4889     0.03125
    c2435     r5052     0.03125
    c2435     r5126     0.03125
    c2435     r5291     6.103515625e-05
    c2435     r5417     0.03125
    c2436     r642      -10000
    c2436     r2140     10000
    c2437     r643      -10000
    c2437     r2141     10000
    c2437     r6489     0.6103515625
    c2438     r4499     -0.6103515625
    c2439     r3332     1
    c2439     r3344     -1
    c2439     r5544     -6.103515625e-05
    c2440     r645      -10000
    c2441     r646      -10000
    c2441     r2144     10000
    c2442     r647      -10000
    c2442     r2145     10000
    c2443     r4472     -0.6103515625
    c2444     r3891     -1
    c2444     r3894     1
    c2445     r649      -10000
    c2445     r2147     10000
    c2446     r650      -10000
    c2447     r650      1
    c2447     r3896     1
    c2447     r3903     -1
    c2448     r651      -10000
    c2448     r2149     10000
    c2449     r652      -10000
    c2449     r2150     10000
    c2450     r653      -10000
    c2450     r2151     10000
    c2451     r654      -10000
    c2451     r2152     10000
    c2452     r655      -10000
    c2452     r2153     10000
    c2453     Obj       0
    c2454     r3861     1
    c2454     r3865     -1
    c2455     r657      -10000
    c2456     r658      -10000
    c2457     r659      -10000
    c2457     r2157     10000
    c2458     r660      -10000
    c2459     r661      -10000
    c2459     r2159     10000
    c2460     r662      -10000
    c2460     r6944     0.000570953369140703
    c2461     r4653     -0.6103515625
    c2461     r6944     -0.609780609130859
    c2462     r3883     1
    c2462     r3890     -1
    c2462     r4393     0.03125
    c2462     r4557     0.03125
    c2462     r6944     6.103515625e-05
    c2463     r664      -10000
    c2463     r2162     10000
    c2464     r665      -10000
    c2464     r2163     10000
    c2465     r666      -10000
    c2465     r2164     10000
    c2466     r5137     -0.053680159999999
    c2466     r6370     -0.053680159999999
    c2466     r6371     -0.0269802830408211
    c2466     r6396     -0.053680159999999
    c2466     r6397     -0.053680159999999
    c2466     r6398     -0.053680159999999
    c2466     r6399     -0.053680159999999
    c2466     r6400     -0.053680159999999
    c2466     r6401     -0.053680159999999
    c2466     r6435     1
    c2466     r6439     0.0177402980626741
    c2466     r6697     0.0190734863281252
    c2466     r6805     0.0229616942267293
    c2466     r7008     0.0152320873909154
    c2467     r668      -10000
    c2467     r2166     10000
    c2468     r669      -10000
    c2468     r2167     10000
    c2469     r4918     -0.6103515625
    c2470     r3806     -1
    c2470     r3847     1
    c2471     r671      -10000
    c2471     r2169     10000
    c2472     r4493     -0.6103515625
    c2473     r3845     -1
    c2473     r3848     1
    c2474     r673      -10000
    c2475     r674      -10000
    c2475     r5457     0.580420465087891
    c2475     r6033     -0.957795117187501
    c2476     r675      -10000
    c2476     r4818     0.95096089
    c2476     r5398     0.580420465087891
    c2476     r6010     -0.580420465087891
    c2476     r6083     0.0299310974121095
    c2477     r676      -10000
    c2478     r677      -10000
    c2478     r2175     10000
    c2478     r4926     0.580420465087891
    c2478     r6440     0.0625
    c2478     r6929     -0.0420649109091476
    c2479     r678      -10000
    c2479     r4830     0.93678389
    c2479     r5019     0.571767510986328
    c2479     r5092     0.571767510986328
    c2479     r5218     0.6103515625
    c2479     r6174     0.0632161099999995
    c2479     r6261     0.872343151205351
    c2479     r6263     -0.98934525
    c2479     r6346     0.0625
    c2479     r6431     0.0722513388847585
    c2479     r6493     0.107417388290276
    c2479     r6755     -0.685615131257435
    c2479     r6824     0.0385840515136718
    c2479     r6835     0.0632161099999999
    c2479     r6998     -0.667585779087987
    c2480     r679      -10000
    c2480     r2177     10000
    c2480     r6174     -0.0738708599999996
    c2480     r6261     -0.0687893328253637
    c2480     r6263     -0.0789131680430819
    c2480     r6346     0.863672033125734
    c2480     r6422     -0.0632161099999999
    c2480     r6423     0.571767510986328
    c2480     r6431     0.0722513388847583
    c2480     r6440     -0.0703783445041096
    c2480     r6492     0.571767510986328
    c2480     r6493     -0.1157661425
    c2480     r6552     -0.0882283289547581
    c2480     r6556     0.565216561508148
    c2480     r6692     0.721071103003263
    c2480     r6700     0.0320554387360696
    c2480     r6755     0.739100455172711
    c2480     r6824     -0.0385840515136718
    c2480     r6835     0.9367756151
    c2480     r6998     0.721071103003263
    c2481     r2178     10000
    c2481     r5252     0.877151140097383
    c2481     r5540     0.557554657963846
    c2481     r5645     0.60378662109375
    c2481     r5718     -0.0527969045361538
    c2481     r5725     0.557554657963846
    c2481     r6343     0.53502349312175
    c2481     r6481     0.882030785273931
    c2481     r6539     0.839137133916051
    c2481     r6661     -0.635687846672997
    c2481     r6690     0.504757753427692
    c2481     r6740     0.60378662109375
    c2481     r6788     0.9203844883
    c2482     r681      -10000
    c2482     r2179     10000
    c2482     r6439     -0.0354805961253485
    c2482     r6560     0.019073486328125
    c2482     r6697     0.019073486328125
    c2482     r6805     0.0459233884534587
    c2482     r7008     0.0524195165901339
    c2483     r6560     -0.506997962247126
    c2483     r6697     -0.739199373631172
    c2483     r6741     -0.0527969045361538
    c2483     r6752     0.805692018445786
    c2483     r7008     -0.553137237448479
    c2484     r3868     1
    c2484     r4142     -1
    c2484     r6741     6.63148467036154e-05
    c2485     r6386     -0.6103515625
    c2485     r6834     0.607572473144531
    c2485     r6981     -0.508609374999992
    c2486     r684      -10000
    c2486     r2182     10000
    c2486     r6467     -0.6103515625
    c2487     r685      -10000
    c2487     r2183     10000
    c2487     r5811     0.599419952392578
    c2487     r5863     -0.0045882263183592
    c2487     r5919     0.98208965
    c2487     r6134     -0.0045882263183592
    c2487     r6828     0.599419952392578
    c2487     r7013     0.599419952392578
    c2487     r7041     -0.0218632202148439
    c2487     r7052     0.98208965
    c2488     r2184     10000
    c2488     r5966     0.573131199999999
    c2488     r6016     -0.599419952392578
    c2488     r6434     0.573131199999999
    c2488     r7028     0.0109316101074218
    c2489     r5033     0.604008178710937
    c2489     r5102     0.604008178710937
    c2489     r5491     -0.00634338378906252
    c2489     r5811     -0.00634338378906252
    c2489     r5863     -0.6103515625
    c2489     r6134     -0.6103515625
    c2489     r6371     -0.583133549489922
    c2489     r6805     -0.0229616942267293
    c2489     r7041     -0.0218632202148439
    c2490     r688      -10000
    c2490     r2186     10000
    c2490     r5583     0.29232812500004
    c2490     r5745     0.29232812500004
    c2490     r6506     0.29232812500004
    c2490     r6945     -0.609780609130859
    c2491     r689      -10000
    c2492     r5287     -0.6103515625
    c2492     r6765     -0.0213300482177734
    c2493     r3910     -1
    c2493     r3912     1
    c2493     r6282     -0.03125
    c2494     r691      -10000
    c2494     r2189     10000
    c2494     r5909     -0.589021514282227
    c2494     r6065     0.0426600964355466
    c2494     r6086     -0.567691466064453
    c2494     r6437     0.0213300482177736
    c2494     r6480     0.528875919604692
    c2494     r6524     -0.569131973273316
    c2494     r6532     0.0213300482177736
    c2494     r6664     0.10291186033552
    c2494     r6848     0.019073486328125
    c2494     r6883     0.0213300482177734
    c2494     r6886     -0.930105698
    c2494     r6902     0.609479736328125
    c2494     r7056     0.609479736328125
    c2495     r692      -10000
    c2495     r6765     -0.0213300482177734
    c2496     r692      1
    c2496     r3912     1
    c2496     r4027     -1
    c2497     r693      -10000
    c2497     r5175     -0.0846193864
    c2497     r5558     0.135811450800001
    c2497     r6522     0.676955091200002
    c2497     r6844     0.576873779296875
    c2497     r7016     0.576873779296875
    c2497     r7032     0.593140661950878
    c2498     r694      -10000
    c2498     r2192     10000
    c2498     r5175     -0.8307612272
    c2498     r5319     0.576873779296875
    c2498     r5561     -0.033477783203125
    c2498     r5640     -0.033477783203125
    c2498     r6564     -0.033477783203125
    c2498     r6636     -0.0354206032937893
    c2498     r6882     -0.0354206032937893
    c2499     r695      -10000
    c2499     r2193     10000
    c2500     r6025     -0.7229375
    c2500     r6269     -0.968101189
    c2500     r6385     0.6103515625
    c2500     r6414     0.019073486328125
    c2500     r6455     -1
    c2500     r6499     -0.0141049871826172
    c2500     r6563     0.581121724243164
    c2500     r6701     0.587416338500977
    c2501     r697      -10000
    c2501     r5061     0.804923391999999
    c2501     r6380     -0.6103515625
    c2501     r6396     0.804923391999999
    c2501     r6438     -0.0111026000000001
    c2501     r6499     -0.59765856262207
    c2502     r6249     -0.9888974
    c2502     r6383     -0.000197540283203068
    c2502     r6384     -0.0141049871826172
    c2502     r6385     -0.0126929998779297
    c2502     r6414     0.879014635683123
    c2502     r6452     -0.811666015625001
    c2502     r6487     0.898088122011248
    c2502     r6618     0.00697402954101567
    c2503     r3929     1
    c2503     r4061     -1
    c2503     r5415     -0.03125
    c2503     r6249     0.0001
    c2503     r6384     6.103515625e-05
    c2503     r6385     6.103515625e-05
    c2503     r6462     6.103515625e-05
    c2503     r6563     6.103515625e-05
    c2503     r6701     6.103515625e-05
    c2504     r699      -10000
    c2504     r6465     -0.609594970703125
    c2504     r6581     0.131537500000036
    c2504     r6974     -0.6103515625
    c2505     r5107     0.555186081130686
    c2505     r5208     0.662346874999997
    c2505     r6554     -0.00476837158203125
    c2505     r6606     0.662346874999997
    c2505     r6705     -0.00446260762913994
    c2506     r4440     -0.727427040000002
    c2506     r4568     -0.887972460937497
    c2506     r4629     -0.887972460937497
    c2506     r6456     -1
    c2506     r6496     0.013289731652614
    c2506     r6511     -1
    c2506     r6514     0.61038129699707
    c2506     r6517     -0.610361473999024
    c2506     r6750     -0.0265286806794337
    c2506     r6751     -0.6103515625
    c2506     r6979     -0.0138745697021484
    c2506     r6994     0.0555577478027343
    c2507     r6350     -0.582582600097656
    c2507     r6640     -0.800908395013334
    c2507     r6822     -0.6103515625
    c2508     r3421     -1
    c2508     r4055     1
    c2508     r6640     8.39055367669584e-05
    c2509     r703      -10000
    c2509     r2201     10000
    c2509     r5005     0.826835312499995
    c2509     r5107     0.0371535770724388
    c2509     r5836     0.826835312500009
    c2509     r6418     0.568159843749996
    c2509     r6548     0.597432260742187
    c2509     r6724     0.826835312500002
    c2509     r6816     -0.597432260742187
    c2509     r6973     0.0131986779630783
    c2509     r7012     0.0129193017578124
    c2510     r6510     -1
    c2510     r6548     -0.0129193017578125
    c2511     r705      -10000
    c2511     r2203     10000
    c2512     r706      -10000
    c2512     r4500     -0.6103515625
    c2513     r706      1
    c2513     r3342     -1
    c2513     r4188     1
    c2513     r5047     -0.03125
    c2514     r707      -10000
    c2514     r2205     10000
    c2515     r708      -10000
    c2515     r4920     0.93678389
    c2515     r5453     0.392761410727837
    c2515     r6692     0.0625
    c2515     r6755     -0.685615131257435
    c2515     r6791     0.6103515625
    c2515     r6835     -0.9367756151
    c2515     r6998     -0.667585779087987
    c2515     r7003     0.6103515625
    c2516     r709      -10000
    c2516     r6556     -0.03814697265625
    c2517     r709      1
    c2517     r3425     -1
    c2517     r3944     1
    c2518     r710      -10000
    c2518     r2208     10000
    c2519     r711      -10000
    c2519     r2209     10000
    c2519     r5537     -0.6103515625
    c2519     r6162     -0.0799750499999998
    c2519     r6252     -0.6103515625
    c2519     r6432     -0.6103515625
    c2519     r6931     -0.6103515625
    c2519     r6996     0.801383945747719
    c2519     r7001     -0.0488128967285157
    c2520     r2210     10000
    c2520     r5078     -0.6103515625
    c2520     r6316     -0.6103515625
    c2520     r6931     -0.6103515625
    c2520     r6996     -0.0762939453125
    c2521     r3786     -1
    c2521     r4255     1
    c2522     r713      -10000
    c2522     r2211     10000
    c2522     r5633     0.92002495
    c2522     r5692     -0.0488128967285156
    c2522     r5693     -0.07997505
    c2522     r6162     -0.0799750499999998
    c2522     r6558     -0.07997505
    c2522     r6996     -0.0762939453125
    c2522     r7001     -0.6103515625
    c2523     r5633     -0.0799750499999998
    c2524     r3777     1
    c2524     r3778     -1
    c2524     r5693     -0.0001
    c2525     r5537     -0.6103515625
    c2525     r5692     -0.0488128967285156
    c2525     r5693     -0.07997505
    c2525     r6558     -0.07997505
    c2525     r7007     -0.6103515625
    c2526     r3775     -1
    c2526     r3777     1
    c2526     r5692     6.103515625e-05
    c2526     r6252     -6.103515625e-05
    c2526     r6931     -6.103515625e-05
    c2527     r4628     -0.826835312500002
    c2527     r4630     0.618968749999993
    c2527     r5005     -0.826835312500002
    c2527     r6543     0.597432260742187
    c2527     r6554     0.00476837158203125
    c2527     r6576     -0.826835312500002
    c2527     r6724     -0.826835312500002
    c2527     r6961     -0.826835312500002
    c2527     r7012     -0.0258386035156251
    c2528     r6944     -0.000570953369140703
    c2528     r6945     -0.000570953369140703
    c2529     r718      -10000
    c2530     r719      -10000
    c2530     r6870     -0.6103515625
    c2530     r7043     -0.613049340095415
    c2531     r720      -10000
    c2531     r6832     0.607496772888183
    c2531     r7043     -0.613049340095415
    c2532     r2219     10000
    c2532     r4564     -0.196475937499997
    c2533     r2220     10000
    c2533     r5211     -0.196475937500054
    c2533     r7010     0.6103515625
    c2534     r723      -10000
    c2534     r2221     10000
    c2534     r6896     -0.609172119140625
    c2534     r7054     -0.609172119140625
    c2535     r4583     -0.6103515625
    c2536     r3959     1
    c2536     r3975     -1
    c2537     r4634     -1
    c2538     r726      -10000
    c2539     r726      1
    c2539     r3960     1
    c2539     r3969     -1
    c2540     r727      -10000
    c2540     r2225     10000
    c2541     r728      -10000
    c2541     r2226     10000
    c2542     r729      -10000
    c2542     r2227     10000
    c2542     r7030     0.608490356445313
    c2543     r730      -10000
    c2543     r6896     0.609172119140625
    c2544     r731      -10000
    c2544     r2229     10000
    c2544     r7054     0.609172119140625
    c2545     r732      -10000
    c2545     r2230     10000
    c2546     r733      -10000
    c2546     r2231     10000
    c2547     r734      -10000
    c2548     r735      -10000
    c2549     r736      -10000
    c2549     r2234     10000
    c2550     r4634     -1
    c2550     r4684     -0.603875000000016
    c2551     r738      -10000
    c2551     r6859     0.608490356445313
    c2552     r739      -10000
    c2553     r739      1
    c2553     r3967     -1
    c2553     r3972     1
    c2554     r740      -10000
    c2554     r2238     10000
    c2554     r6859     0.608490356445313
    c2554     r7030     0.608490356445313
    c2555     r2239     10000
    c2555     r4804     -0.225303124999982
    c2556     r742      -10000
    c2556     r2240     10000
    c2557     r743      -10000
    c2558     r744      -10000
    c2558     r2242     10000
    c2558     r4811     0.000383742065429793
    c2558     r5211     0.196475937500054
    c2558     r6938     0.606870867919922
    c2558     r7037     0.603006431274414
    c2559     r4474     -0.6103515625
    c2560     r3957     -1
    c2560     r3978     1
    c2561     r746      -10000
    c2561     r2244     10000
    c2562     r747      -10000
    c2563     r747      1
    c2563     r3968     -1
    c2563     r3979     1
    c2563     r4417     0.03125
    c2564     r748      -10000
    c2564     r2246     10000
    c2565     r749      -10000
    c2565     r2247     10000
    c2566     r750      -10000
    c2566     r2248     10000
    c2566     r4890     0.121587500000032
    c2567     r6938     -0.606870867919922
    c2568     r3958     -1
    c2568     r3983     1
    c2568     r6870     6.103515625e-05
    c2569     r4811     -0.60996782043457
    c2570     r4720     0.810431104000003
    c2570     r5379     -0.305175781250001
    c2571     r754      -10000
    c2571     r4904     -0.730826140624998
    c2571     r5158     -0.730826140624998
    c2571     r5211     0.196475937500054
    c2571     r5304     0.30517578125
    c2571     r5379     0.30517578125
    c2571     r5539     0.5
    c2571     r6938     0.000383742065429555
    c2572     r5539     -0.5
    c2572     r6938     -0.00734513122558611
    c2573     r756      -10000
    c2573     r5401     0.42105213281252
    c2574     r757      -10000
    c2574     r4862     0.9953227127
    c2575     r758      -10000
    c2575     r4864     0.607496772888184
    c2576     r759      -10000
    c2576     r4863     0.607496772888184
    c2576     r5401     -0.730826140625027
    c2576     r6927     -0.743582873651629
    c2576     r7087     -0.748351245233574
    c2577     r760      -10000
    c2577     r4434     -0.663219200000015
    c2577     r4495     -0.00259070000000006
    c2577     r6830     0.9974093
    c2578     r761      -10000
    c2578     r2259     10000
    c2579     r762      -10000
    c2579     r2260     10000
    c2579     r5175     -0.0846193864000002
    c2579     r5558     -0.0334273219999999
    c2579     r6065     -0.0426600964355466
    c2579     r6086     0.471532207954509
    c2579     r6436     -0.0213300482177734
    c2579     r6437     0.567691466064453
    c2579     r6522     -0.676955091200002
    c2579     r6524     -0.0206097946133419
    c2579     r6532     -0.0213300482177736
    c2579     r6664     -0.10291186033552
    c2579     r6848     -0.019073486328125
    c2579     r6886     0.930105698
    c2580     r6091     -0.0138844812011719
    c2580     r6710     -0.887972460937497
    c2580     r6749     0.596476992797851
    c2580     r6750     0.0535708464982831
    c2580     r6751     -0.0138844812011718
    c2581     r6019     -0.00507468749998452
    c2581     r6091     -0.0138844812011719
    c2581     r6356     0.0139392303466797
    c2581     r6388     0.610341651000977
    c2581     r6433     0.0138745697021485
    c2581     r6669     0.582582600097656
    c2581     r6747     -0.58244336730957
    c2581     r6808     0.6103515625
    c2581     r6977     -0.319065218200684
    c2581     r6979     0.582582600097656
    c2582     r765      -10000
    c2582     r6553     -0.564766733520508
    c2583     r765      1
    c2583     r3269     -1
    c2583     r4260     1
    c2584     r6308     -0.64038994140625
    c2584     r6410     0.450254077148438
    c2584     r6411     -0.320194970703125
    c2584     r6478     -0.320194970703125
    c2584     r6485     0.6103515625
    c2584     r6541     0.290156591796875
    c2584     r6547     0.217023576900187
    c2584     r6632     0.827375139400187
    c2584     r6684     0.450254077148437
    c2585     r767      -10000
    c2585     r2265     10000
    c2586     r768      -10000
    c2586     r2266     10000
    c2586     r6424     0.510534374999992
    c2586     r6653     -0.560343750000015
    c2586     r6917     -0.608357287597656
    c2587     r769      -10000
    c2587     r2267     10000
    c2588     r770      -10000
    c2588     r4872     0.606168444824219
    c2588     r5516     -0.510534374999992
    c2588     r6653     -0.560343750000015
    c2589     r2269     68.5362000000005
    c2589     r5175     -0.00994637999999995
    c2589     r5558     -0.00994637999999995
    c2589     r5627     -0.0121415771484374
    c2589     r6522     -0.0795710399999996
    c2589     r6871     -0.00199427490234372
    c2589     r7002     -0.00994637999999995
    c2589     r7046     0.00223065979003908
    c2590     r772      -10000
    c2590     r2270     10000
    c2591     r2271     10000
    c2591     r4871     0.00792279999999979
    c2591     r5107     -0.0371535770724388
    c2591     r5111     -0.605515869140625
    c2591     r6565     0.6103515625
    c2591     r6581     -0.131537500000036
    c2591     r6975     -0.00025680108697379
    c2592     r4871     -0.9920772
    c2592     r5107     -0.592339658203125
    c2592     r6785     0.59202429731509
    c2593     r3669     -1
    c2593     r3999     1
    c2593     r4984     0.0256
    c2593     r6785     0.00373620624851763
    c2594     r775      -10000
    c2594     r4630     -0.618968749999993
    c2594     r4984     0.124756479999974
    c2594     r5111     0.605515869140625
    c2594     r6402     -0.651853125000002
    c2594     r6418     -0.0773710937499992
    c2594     r6445     0.592041048069864
    c2594     r6554     0.561955538699571
    c2594     r6565     -0.0231864892578124
    c2594     r6785     0.314219802568442
    c2594     r6974     -0.00513545130684046
    c2594     r7070     0.605258959960937
    c2594     r7085     -0.99951267
    c2595     r776      -10000
    c2595     r4567     0.560343750000015
    c2595     r5516     -0.510534374999992
    c2596     r2275     10000
    c2596     r4567     0.560343750000015
    c2596     r4872     -0.606168444824219
    c2596     r5297     0.560343750000015
    c2596     r6653     0.560343750000015
    c2597     r778      -10000
    c2597     r2276     10000
    c2598     r779      -10000
    c2598     r2277     10000
    c2599     r780      -10000
    c2599     r2278     10000
    c2600     r781      -10000
    c2600     r2279     10000
    c2601     r782      -10000
    c2601     r2280     10000
    c2602     r783      -10000
    c2602     r2281     10000
    c2603     r784      -10000
    c2603     r2282     10000
    c2604     r785      -10000
    c2604     r2283     10000
    c2605     r786      -10000
    c2605     r2284     10000
    c2606     r787      -10000
    c2606     r2285     10000
    c2606     r4764     0.00337449291992198
    c2606     r4774     0.863870187499998
    c2606     r4795     0.863870187499998
    c2606     r4805     0.00337449291992187
    c2606     r4972     0.863870187499998
    c2606     r5254     -0.606977069580078
    c2606     r5731     0.0327430474853518
    c2606     r6015     -0.606977069580078
    c2606     r6559     0.0134541899442738
    c2606     r6638     0.0323883913697332
    c2606     r6756     0.0131640111083986
    c2606     r6810     0.0323883913697332
    c2606     r7017     0.0323883913697332
    c2607     r788      -10000
    c2608     r788      1
    c2608     r3935     -1
    c2608     r4229     1
    c2609     r4990     -0.576873779296875
    c2609     r5561     0.033477783203125
    c2610     r4833     0.94515
    c2610     r5640     -0.033477783203125
    c2610     r6564     -0.033477783203125
    c2610     r6882     -0.0354206032937893
    c2611     r3923     -1
    c2611     r4010     1
    c2611     r4570     -0.0009765625
    c2611     r5640     6.103515625e-05
    c2611     r6564     6.103515625e-05
    c2611     r6882     6.45772165793789e-05
    c2612     r2289     10000
    c2612     r6834     -0.607572473144531
    c2613     r792      -10000
    c2613     r2290     10000
    c2613     r6586     0.508609374999992
    c2613     r6855     -0.608364807128906
    c2613     r6981     0.508609374999992
    c2614     r6382     0.000756591796875039
    c2614     r6386     0.000756591796875039
    c2614     r6448     0.38737500000002
    c2614     r6459     0.000756591796875039
    c2614     r6460     0.000756591796875039
    c2614     r6464     0.000756591796875039
    c2614     r6465     0.000756591796875039
    c2614     r6468     0.000756591796875039
    c2614     r6490     0.00101350097656261
    c2614     r6586     -0.508609374999992
    c2614     r6855     0.608364807128906
    c2614     r6899     -0.609594970703125
    c2614     r6981     0.19368750000001
    c2615     r794      -10000
    c2615     r5080     -0.6103515625
    c2615     r5208     -0.662346874999997
    c2615     r5699     -0.526150000000143
    c2615     r6402     -0.651853125000002
    c2615     r6445     -0.019097089045514
    c2615     r6975     -0.610094761413026
    c2615     r7058     -0.00500300621896318
    c2615     r7070     -0.00509260253906252
    c2616     r794      1
    c2616     r3933     -1
    c2616     r4050     1
    c2616     r5267     -0.03125
    c2616     r6445     6.29175895289511e-05
    c2616     r6459     -6.103515625e-05
    c2616     r6465     -6.103515625e-05
    c2616     r7058     5.6220122564472e-05
    c2617     r5517     0.131537500000036
    c2617     r6382     -0.6103515625
    c2617     r6606     0.662346874999997
    c2618     r5080     -0.6103515625
    c2618     r5699     -0.526150000000143
    c2618     r6459     -0.609594970703125
    c2619     r3924     -1
    c2619     r4050     1
    c2619     r5699     0.0625
    c2620     r797      -10000
    c2620     r7059     -0.0215479054717218
    c2621     r797      1
    c2621     r3420     -1
    c2621     r4047     1
    c2622     r2296     10000
    c2622     r5150     -0.00244940185546871
    c2622     r5206     -0.627046874999991
    c2622     r6444     0.507633893089431
    c2622     r7059     0.614111049346292
    c2623     r4725     -0.559154415999998
    c2623     r5441     0.6103515625
    c2623     r6065     0.6103515625
    c2623     r6086     0.12019907263743
    c2623     r6437     0.06399014465332
    c2623     r6532     0.0213300482177736
    c2623     r6883     0.6103515625
    c2624     r800      -10000
    c2624     r2298     10000
    c2625     r801      -10000
    c2625     r2299     10000
    c2626     r2300     10000
    c2626     r5296     0.00199427490234372
    c2626     r5297     -0.560343750000015
    c2626     r6653     -0.560343750000015
    c2626     r6871     -0.608357287597656
    c2627     r4567     -0.560343750000015
    c2627     r5131     0.510534374999992
    c2627     r5296     -0.6103515625
    c2627     r5516     0.510534374999992
    c2627     r6055     0.510534374999992
    c2627     r6424     0.510534374999992
    c2627     r6526     0.510534374999992
    c2627     r6603     0.510534374999992
    c2627     r6917     0.00199427490234372
    c2628     r804      -10000
    c2628     r2302     10000
    c2628     r5300     -0.000139099121093667
    c2629     r805      -10000
    c2629     r2303     10000
    c2630     r806      -10000
    c2631     r5282     -0.6103515625
    c2631     r5558     0.897615871199999
    c2632     r808      -10000
    c2632     r2306     10000
    c2632     r7046     -0.608399104614258
    c2633     r809      -10000
    c2633     r2307     10000
    c2633     r5583     0.29232812500004
    c2633     r5745     0.29232812500004
    c2633     r6506     0.29232812500004
    c2633     r6944     0.000570953369140703
    c2633     r6945     -0.609780609130859
    c2634     r2308     10000
    c2634     r4685     -0.64038994140625
    c2634     r5090     0.900508154296875
    c2634     r5979     0.6103515625
    c2634     r6441     0.6103515625
    c2635     r4630     -0.618968749999993
    c2635     r5517     0.131537500000036
    c2635     r5699     0.526150000000143
    c2635     r6418     -0.0773710937499992
    c2635     r6445     -0.0185674236098238
    c2635     r6490     0.6103515625
    c2635     r6785     -0.296012148657545
    c2635     r6836     -0.00469969562874338
    c2635     r7058     0.00500300621896318
    c2636     r5034     -0.605176977539063
    c2636     r6581     -0.131537500000036
    c2636     r6681     0.662346874999997
    c2637     r4943     -0.605176977539063
    c2638     r4943     0.605176977539063
    c2638     r5034     0.605176977539063
    c2638     r5208     -0.662346874999997
    c2638     r5932     -0.662346874999997
    c2638     r6224     -0.662346874999997
    c2638     r6565     -0.0231864892578124
    c2638     r6606     -0.662346874999997
    c2638     r6926     0.605176977539063
    c2638     r7058     -0.00500300621896318
    c2639     r815      -10000
    c2639     r5192     0.00673270684814442
    c2639     r6562     -0.606884735895138
    c2639     r6827     -0.603500148376465
    c2639     r6910     0.00673270684814442
    c2639     r7019     0.00673270684814442
    c2639     r7071     -0.609079802978516
    c2640     r5215     -0.6103515625
    c2640     r5861     -0.65114087500001
    c2640     r6051     -0.65114087500001
    c2640     r6138     -1
    c2640     r7066     -0.65114087500001
    c2640     r7071     -0.00127175952148439
    c2641     r3930     -1
    c2641     r4057     1
    c2642     r5517     -0.131537500000036
    c2642     r5699     -0.526150000000143
    c2642     r5946     0.6103515625
    c2642     r6402     -0.651853125000002
    c2642     r6445     -0.0185674236098238
    c2642     r6490     -0.00101350097656261
    c2642     r6974     -0.00513545130684046
    c2642     r6975     -0.00025680108697379
    c2642     r7070     0.605258959960937
    c2643     r818      -10000
    c2643     r5035     -0.000118707275390539
    c2643     r5108     0.605118109130859
    c2643     r5133     -0.714195789062501
    c2643     r6562     -0.00561094677219431
    c2643     r6827     -0.00557965460205079
    c2643     r6853     0.605118109130859
    c2644     r2317     10000
    c2644     r4944     0.60523681640625
    c2644     r5035     -0.610232855224609
    c2644     r7019     -0.00673270684814442
    c2645     r6547     -0.6103515625
    c2645     r6632     -0.6103515625
    c2645     r6761     -0.260118212890625
    c2645     r6803     -0.130059106445313
    c2646     r821      -10000
    c2647     r821      1
    c2647     r3870     -1
    c2647     r4059     1
    c2648     r5192     -0.00673270684814442
    c2648     r6910     0.60523681640625
    c2649     r823      -10000
    c2649     r2321     10000
    c2649     r5745     -0.29232812500004
    c2650     r824      -10000
    c2650     r6518     -0.6103515625
    c2651     r825      -10000
    c2652     r826      -10000
    c2652     r2324     10000
    c2652     r5745     0.29232812500004
    c2653     r2325     10000
    c2653     r4754     -0.828395906250023
    c2653     r5108     -0.605118109130859
    c2653     r5192     0.6103515625
    c2653     r6910     0.6103515625
    c2653     r7019     0.6103515625
    c2654     r2326     10000
    c2654     r4944     -0.60523681640625
    c2654     r6853     -0.605118109130859
    c2654     r6910     -0.00161796075439447
    c2655     r829      -10000
    c2655     r2327     10000
    c2655     r5383     -0.320194970703125
    c2655     r6542     -0.30517578125
    c2655     r6547     0.393327985599813
    c2655     r6625     -0.320194970703125
    c2655     r6632     -0.217023576900187
    c2655     r6761     -0.960584912109375
    c2655     r6803     -0.480292456054687
    c2656     r2328     10000
    c2656     r6029     -0.902719179687502
    c2656     r6373     0.6103515625
    c2656     r6563     0.00677648925781238
    c2656     r6701     0.0126929998779297
    c2656     r6887     -0.812351992187502
    c2657     r5062     -0.804923391999999
    c2657     r6156     -0.9888974
    c2657     r6269     0.979203789
    c2657     r6375     0.6103515625
    c2657     r6401     -0.804923391999999
    c2657     r6451     -0.811666015625001
    c2657     r6462     0.6103515625
    c2658     r2330     10000
    c2658     r5063     -0.827630591999998
    c2658     r5194     -0.604008178710937
    c2658     r6374     0.6103515625
    c2658     r6430     0.015625
    c2659     r5322     -0.908075415410216
    c2659     r6387     -0.908075415410216
    c2659     r6430     -0.015625
    c2660     r2332     10000
    c2660     r5076     0.609915905761719
    c2660     r5458     -0.2230562499999
    c2660     r5498     -0.111528125000007
    c2661     r5497     0.111528125000007
    c2661     r6457     -1
    c2661     r6528     -1
    c2661     r6560     -0.019073486328125
    c2661     r6615     -1
    c2661     r6993     -0.036256456
    c2661     r7008     -0.0524195165901342
    c2662     r4088     -1
    c2662     r4089     1
    c2662     r5128     -0.03125
    c2662     r5497     0.03125
    c2662     r5580     -0.03125
    c2662     r6889     -6.103515625e-05
    c2663     r2334     10000
    c2663     r5255     -0.603575073242187
    c2663     r5786     -0.603575073242187
    c2663     r6179     0.6103515625
    c2663     r6560     0.00584076086495167
    c2664     r2335     10000
    c2664     r5269     -0.114606250000008
    c2665     r5271     -0.114606250000008
    c2666     r5033     -0.604008178710937
    c2666     r5954     0.6103515625
    c2666     r6390     -0.025863456
    c2667     r5275     0.412692187499999
    c2667     r5361     -1
    c2668     r6027     -0.728425312500008
    c2668     r6384     0.6103515625
    c2669     r5982     0.596444115600586
    c2669     r6383     0.6103515625
    c2669     r6450     -0.799023437499997
    c2669     r6463     0.597866821289063
    c2670     r6155     -0.9888974
    c2670     r6438     0.9888974
    c2671     r5056     -0.804923391999999
    c2671     r6381     0.6103515625
    c2671     r6397     -0.804923391999999
    c2672     r2343     10000
    c2672     r5057     -0.804923391999999
    c2672     r5889     -0.603575073242187
    c2672     r6378     0.6103515625
    c2673     r5128     -0.412692187499999
    c2673     r5580     -0.412692187499999
    c2673     r6536     1
    c2673     r6615     -1
    c2674     r5656     -0.114606250000008
    c2674     r6455     1
    c2674     r6536     -1
    c2674     r6563     0.581121724243164
    c2674     r6618     -0.58947008605957
    c2674     r6701     0.587416338500977
    c2675     r5268     -0.114606250000008
    c2675     r6035     -0.229212500000017
    c2675     r6435     -1
    c2675     r6457     -1
    c2675     r6618     0.58947008605957
    c2676     r6024     -0.7229375
    c2676     r6563     0.0292298382568359
    c2676     r6887     -0.0903671875000001
    c2677     r2348     10000
    c2677     r5060     -0.804923391999999
    c2677     r6158     -0.9888974
    c2677     r6376     0.6103515625
    c2677     r6400     -0.804923391999999
    c2678     r2349     10000
    c2678     r5059     -0.804923391999999
    c2678     r6377     0.6103515625
    c2678     r6399     -0.804923391999999
    c2679     r5058     -0.804923391999999
    c2679     r6379     0.6103515625
    c2679     r6398     -0.804923391999999
    c2680     r5137     -0.804923391999999
    c2680     r6247     -0.603575073242188
    c2680     r6372     0.6103515625
    c2680     r6439     0.0177402980626742
    c2680     r7008     -0.0371874291992187
    c2681     r2352     10000
    c2681     r6370     -0.804923391999999
    c2681     r6439     0.775607256198135
    c2681     r6993     -0.025153856
    c2682     r2353     10000
    c2682     r6328     -0.603575073242188
    c2682     r6393     -0.0198090489159281
    c2683     r2354     10000
    c2683     r5270     -0.114606250000008
    c2684     r2355     10000
    c2684     r6333     -0.603575073242187
    c2685     r858      -10000
    c2686     r858      1
    c2686     r4084     -1
    c2686     r4086     1
    c2687     r859      -10000
    c2687     r6355     -0.603575073242187
    c2688     r6179     -0.6103515625
    c2689     r2359     10000
    c2689     r6179     -0.603575073242187
    c2689     r6260     -0.603575073242187
    c2690     r4085     -1
    c2690     r4087     1
    c2690     r6260     6.103515625e-05
    c2690     r6355     6.103515625e-05
    c2691     r5863     -0.0045882263183592
    c2691     r6828     0.599419952392578
    c2692     r863      -10000
    c2693     r4581     -0.6103515625
    c2694     r4890     0.121587500000032
    c2694     r5014     -0.6103515625
    c2694     r5304     0.6103515625
    c2694     r5379     0.6103515625
    c2694     r5539     1
    c2694     r6927     0.0095367431640625
    c2694     r6938     0.011209567871094
    c2694     r7037     0.0150740045166018
    c2694     r7043     0.0078125
    c2694     r7087     0.0095367431640614
    c2695     r4699     -1
    c2696     r867      -10000
    c2697     r5688     0.573131199999999
    c2697     r6307     0.573131199999999
    c2697     r6833     -0.599419952392578
    c2697     r6868     0.01791035
    c2697     r6884     -0.599220592829948
    c2698     r2367     10000
    c2698     r5485     -0.600718726623535
    c2698     r6831     0.0158293053
    c2698     r6863     0.600718726623535
    c2698     r7086     0.664521234287185
    c2699     r870      -10000
    c2700     r871      -10000
    c2700     r5485     0.600718726623535
    c2700     r5519     0.0119979520000015
    c2700     r6863     0.600718726623535
    c2700     r7036     0.600718726623535
    c2700     r7086     -0.664521234287185
    c2701     r5323     0.00863349960000015
    c2701     r5639     -0.9914133674
    c2702     r873      -10000
    c2702     r5811     0.0109316101074219
    c2702     r6134     -0.0045882263183592
    c2702     r7041     -0.6103515625
    c2703     r5491     -0.604008178710937
    c2704     r3444     -1
    c2704     r4096     1
    c2704     r4955     -0.03125
    c2705     r875      -10000
    c2705     r5194     -0.00634338378906252
    c2705     r5255     0.603575073242187
    c2705     r5799     -0.6103515625
    c2705     r5889     0.0067764892578126
    c2705     r6260     0.0067764892578126
    c2705     r6333     0.0067764892578126
    c2705     r6355     0.0067764892578126
    c2706     r876      -10000
    c2706     r4941     0.604008178710937
    c2706     r5322     0.898538672246153
    c2706     r5863     -0.0045882263183592
    c2706     r6134     -0.0045882263183592
    c2706     r7041     -0.0218632202148439
    c2707     r4904     -0.730826140624998
    c2708     r4850     0.0162961362999998
    c2708     r5304     -0.6103515625
    c2708     r5379     -0.6103515625
    c2708     r5539     -1
    c2708     r5733     -0.9678745584
    c2708     r6927     -0.0095367431640625
    c2708     r6938     -0.00772887329101568
    c2708     r7037     -0.00772887329101568
    c2708     r7043     -0.0078125
    c2708     r7087     -0.0095367431640614
    c2709     r5919     0.0179103500000002
    c2709     r6169     -0.6103515625
    c2709     r7052     -0.9641793
    c2710     r880      -10000
    c2711     r881      -10000
    c2711     r2379     10000
    c2711     r5014     0.6103515625
    c2711     r5811     -0.599419952392578
    c2711     r5863     0.0045882263183592
    c2711     r6134     0.0045882263183592
    c2711     r6828     -0.599419952392578
    c2711     r7013     -0.599419952392578
    c2711     r7041     0.0218632202148439
    c2712     r4890     -0.121587500000032
    c2712     r4933     0.0159070563000001
    c2712     r6920     -0.593063545166016
    c2713     r5101     0.0158293053
    c2713     r6863     -0.59108589074707
    c2714     r884      -10000
    c2714     r5598     0.0119979520000015
    c2714     r7057     -0.00968077395064681
    c2715     r5396     -0.9841706947
    c2715     r5403     0.0158293053
    c2715     r5733     0.9841706947
    c2715     r7036     -0.600718726623535
    c2715     r7086     -0.653864784714304
    c2716     r2384     10000
    c2716     r5487     -0.600690121276855
    c2716     r6920     0.60272498638916
    c2717     r5028     0.0158293053
    c2717     r6831     -0.9841706947
    c2717     r7057     -0.595796703962215
    c2718     r5191     0.00863349960000015
    c2718     r5483     -0.9914133674
    c2719     r889      -10000
    c2720     r889      1
    c2720     r3851     -1
    c2720     r4193     1
    c2721     r890      -10000
    c2721     r4895     -0.784625760000001
    c2721     r5021     0.580420465087891
    c2721     r5628     0.580420465087891
    c2721     r5683     -0.0530244343511216
    c2722     r6131     -0.6103515625
    c2723     r3852     -1
    c2723     r4118     1
    c2723     r6131     6.103515625e-05
    c2724     r892      -10000
    c2724     r5165     0.580420465087891
    c2724     r6010     -0.580420465087891
    c2724     r6083     0.089793292236328
    c2725     r4919     0.580420465087891
    c2725     r5959     -0.784625760000001
    c2726     r4823     0.580420465087891
    c2726     r5990     -0.580420465087891
    c2727     r3853     -1
    c2727     r3937     1
    c2727     r5797     6.103515625e-05
    c2728     r895      -10000
    c2728     r6010     -0.0299310974121094
    c2729     r895      1
    c2729     r4120     1
    c2729     r4195     -1
    c2729     r6010     6.103515625e-05
    c2730     r896      -10000
    c2730     r5164     0.95096089
    c2730     r5398     0.580420465087891
    c2730     r5683     0.514121925156156
    c2730     r5797     0.580420465087891
    c2730     r6010     0.580420465087891
    c2730     r6033     -0.957795117187501
    c2730     r6083     0.460696075439453
    c2730     r6109     -0.957795117187501
    c2730     r6131     -0.0299310974121094
    c2731     r6458     -0.6103515625
    c2731     r6594     -0.6103515625
    c2731     r6741     -0.6103515625
    c2731     r6784     -1
    c2731     r6792     -0.0485934519653319
    c2732     r898      -10000
    c2732     r2396     10000
    c2733     r899      -10000
    c2734     r899      1
    c2734     r4128     -1
    c2734     r4130     1
    c2735     r4445     -0.636924093599999
    c2735     r5540     0.0527969045361538
    c2735     r5718     0.663148467036154
    c2735     r5725     0.0527969045361538
    c2735     r6657     -1
    c2735     r6762     0.998059035700758
    c2735     r6784     1
    c2735     r6972     0.636924093599999
    c2736     r5399     0.6103515625
    c2737     r4831     -0.07997505
    c2737     r6856     0.92002495
    c2738     r6358     0.0971868306884769
    c2738     r6482     -0.9203845483
    c2738     r6546     -0.9203845483
    c2738     r6588     -0.6103515625
    c2738     r6667     -0.9203844883
    c2738     r6723     -0.561758110534668
    c2739     r4121     -1
    c2739     r4162     1
    c2739     r6022     -0.03125
    c2739     r6482     0.0001
    c2739     r6502     0.03125
    c2739     r6546     0.0001
    c2739     r6723     6.103515625e-05
    c2739     r6792     -6.103515625e-05
    c2739     r6968     -6.103515625e-05
    c2739     r6972     -0.0008
    c2740     r5100     0.9203845483
    c2740     r6343     -0.59752349312175
    c2740     r6358     0.0485934153442386
    c2740     r6609     -0.636924093599999
    c2740     r6610     0.9203845483
    c2740     r6723     0.6103515625
    c2740     r6968     0.6103515625
    c2740     r6983     0.0796155116999998
    c2741     r6482     -0.9203845483
    c2741     r6546     -0.0796154517000001
    c2741     r6667     -0.9203844883
    c2741     r6784     -0.9203844883
    c2742     r906      -10000
    c2742     r2404     10000
    c2742     r5086     -0.824926720000008
    c2742     r6960     0.824926720000008
    c2743     r4807     -0.6103515625
    c2744     r2406     10000
    c2744     r6873     -0.609640502929687
    c2745     r909      -10000
    c2745     r2407     10000
    c2746     r910      -10000
    c2747     r911      -10000
    c2747     r5114     0.877151140097414
    c2748     r912      -10000
    c2748     r2410     10000
    c2749     r913      -10000
    c2749     r2411     10000
    c2750     r914      -10000
    c2750     r4825     0.91955638
    c2751     r915      -10000
    c2751     r2413     10000
    c2752     r4561     -0.146428125
    c2753     r917      -10000
    c2753     r2415     10000
    c2753     r4947     -0.877151140097414
    c2753     r5114     -0.877239808933423
    c2754     r4588     -1
    c2755     r5337     -0.78100634765625
    c2755     r5692     -0.6103515625
    c2755     r6558     -1
    c2755     r6996     -0.0762939453125
    c2755     r7001     -0.6103515625
    c2755     r7024     -0.6103515625
    c2756     r4921     0.550627276611328
    c2756     r5239     0.997575024414062
    c2756     r5240     -0.0518397644042969
    c2756     r5325     -0.829436230468751
    c2756     r6488     -0.829436230468751
    c2756     r6866     0.550627276611328
    c2756     r7035     -0.501368087559006
    c2757     r4930     -0.90214773
    c2757     r5178     0.0762939453125
    c2757     r5325     0.12615234375
    c2757     r5550     0.605343616522906
    c2757     r6892     0.627097090750495
    c2758     r922      -10000
    c2758     r4854     0.603229370117188
    c2758     r5183     0.603229370117188
    c2758     r5795     0.8739500366
    c2758     r6093     0.00981950407977322
    c2758     r6164     0.790330788459172
    c2758     r6265     0.754834942906214
    c2758     r6344     0.9311405483
    c2758     r6420     0.606038355894324
    c2758     r6545     0.750270627825875
    c2758     r6679     0.809475556105167
    c2758     r6800     0.754834942906214
    c2758     r6997     0.54361586536759
    c2759     r923      -10000
    c2759     r4937     0.603229370117188
    c2760     r924      -10000
    c2760     r2422     10000
    c2761     r925      -10000
    c2761     r2423     10000
    c2761     r6741     -0.0527969045361538
    c2761     r6752     0.805692018445786
    c2761     r6805     -0.0459233884534587
    c2762     r926      -10000
    c2762     r6393     0.03814697265625
    c2762     r6513     -0.6103515625
    c2762     r6993     -0.036256456
    c2763     r2425     10000
    c2763     r4854     -0.603229370117188
    c2763     r4937     -0.603229370117188
    c2763     r5030     -0.603229370117188
    c2764     r928      -10000
    c2764     r5645     0.60378662109375
    c2765     r928      1
    c2765     r4136     -1
    c2765     r4147     1
    c2766     r929      -10000
    c2766     r2427     10000
    c2766     r5030     0.603229370117188
    c2767     r930      -10000
    c2768     r930      1
    c2768     r4141     -1
    c2768     r4147     1
    c2769     r5361     -1
    c2770     r5458     -0.2230562499999
    c2770     r5578     -0.111528125000007
    c2770     r6701     0.587416338500977
    c2771     r933      -10000
    c2772     r933      1
    c2772     r4137     -1
    c2772     r4153     1
    c2773     r934      -10000
    c2773     r2432     10000
    c2773     r4947     -0.877239808933423
    c2773     r5025     -0.60378662109375
    c2773     r5114     -0.877151140097414
    c2773     r5645     -0.60378662109375
    c2774     r5458     0.2230562499999
    c2774     r6528     -1
    c2774     r6560     -0.019073486328125
    c2774     r6697     -0.019073486328125
    c2774     r6805     -0.0459233884534587
    c2774     r6993     -0.036256456
    c2774     r7008     -0.0524195165901339
    c2775     r6393     -0.738463811043384
    c2775     r6439     -0.0382109643936157
    c2775     r6528     -1
    c2775     r6697     -0.03814697265625
    c2775     r6805     0.0229616942267293
    c2775     r6889     0.609545523071289
    c2775     r6993     0.963743544
    c2776     r4182     -1
    c2776     r4183     1
    c2776     r5420     -0.03125
    c2776     r6889     -6.103515625e-05
    c2776     r6993     -0.0003
    c2776     r7008     -0.000121111350807723
    c2777     r2435     10000
    c2777     r5151     -0.609759490966797
    c2777     r6390     -1
    c2777     r6393     -0.0190734863281242
    c2777     r6430     -0.03125
    c2777     r6805     -0.587389868273271
    c2777     r6993     0.036256456
    c2777     r7008     0.0743748583984374
    c2778     r5588     -0.6103515625
    c2779     r4930     0.90214773
    c2779     r4931     -0.6103515625
    c2779     r5178     0.627097090750495
    c2779     r5309     -0.6103515625
    c2779     r5407     -0.12615234375
    c2779     r5475     -0.6103515625
    c2779     r5550     -0.00854564713973383
    c2779     r6892     0.627097090750495
    c2780     Obj       0
    c2781     r3472     -1
    c2781     r4151     1
    c2781     r5680     -0.0009765625
    c2782     r941      -10000
    c2782     r5385     0.575445244323731
    c2782     r5394     -0.0571905117
    c2782     r5462     -0.915047227199999
    c2783     r942      -10000
    c2783     r4857     0.943416595458984
    c2783     r4947     0.877151140097414
    c2784     r6740     -0.60378662109375
    c2785     r3866     1
    c2785     r4155     -1
    c2785     r6963     -0.03125
    c2786     r2442     10000
    c2786     r4857     -0.943416595458984
    c2786     r5252     -0.877239808933393
    c2786     r6740     0.00656494140625008
    c2787     r2443     10000
    c2787     r5540     0.557554657963846
    c2787     r5645     0.60378662109375
    c2787     r5718     -0.0527969045361538
    c2787     r5725     0.557554657963846
    c2787     r6343     0.53502349312175
    c2787     r6481     0.958328545283696
    c2787     r6539     0.918598054866634
    c2787     r6661     -0.635687846672997
    c2787     r6690     0.504757753427692
    c2788     r6113     -0.609759490966797
    c2789     r4143     -1
    c2789     r4157     1
    c2789     r6278     0.03125
    c2790     r5151     -0.000592071533203065
    c2790     r5362     -0.000592071533203065
    c2790     r5422     -0.303140625000026
    c2790     r6393     0.738463811043384
    c2790     r6563     -0.0292298382568359
    c2790     r6861     0.609759490966797
    c2790     r6890     -0.60628125
    c2791     r6107     -0.303140625000026
    c2791     r6113     -0.000592071533203065
    c2791     r6885     0.609759490966797
    c2792     r949      -10000
    c2792     r6872     0.609634460449219
    c2793     r950      -10000
    c2793     r2448     10000
    c2793     r6425     0.6103515625
    c2794     r951      -10000
    c2794     r2449     10000
    c2795     r2450     10000
    c2795     r5362     -0.609759490966797
    c2795     r5458     -0.2230562499999
    c2795     r6439     0.0382109643936157
    c2795     r6560     -0.03814697265625
    c2795     r6697     0.03814697265625
    c2795     r6805     -0.0459233884534586
    c2795     r6993     -0.036256456
    c2795     r7008     -0.0810981128158256
    c2795     r7026     -0.000592071533203065
    c2796     r953      -10000
    c2796     r2451     10000
    c2796     r7026     0.608939239501953
    c2797     r4796     -0.6103515625
    c2797     r6425     -0.6103515625
    c2798     r4129     -1
    c2798     r4164     1
    c2798     r6406     6.103515625e-05
    c2799     r955      -10000
    c2799     r2453     10000
    c2800     r956      -10000
    c2800     r2454     10000
    c2801     r957      -10000
    c2801     r2455     10000
    c2802     r958      -10000
    c2803     r958      1
    c2803     r4166     -1
    c2803     r4167     1
    c2804     r959      -10000
    c2805     r960      -10000
    c2805     r2458     10000
    c2805     r7065     0.609640502929687
    c2806     r961      -10000
    c2806     r2459     10000
    c2807     r962      -10000
    c2807     r2460     10000
    c2808     r963      -10000
    c2808     r2461     10000
    c2808     r7079     0.610155932617187
    c2809     r964      -10000
    c2809     r2462     10000
    c2809     r7065     -0.609640502929687
    c2810     r965      -10000
    c2810     r2463     10000
    c2811     r966      -10000
    c2811     r2464     10000
    c2812     r967      -10000
    c2812     r2465     10000
    c2812     r7024     0.561538665771484
    c2813     r4579     -0.6103515625
    c2813     r7024     0.561538665771484
    c2814     r3785     1
    c2814     r4134     -1
    c2815     r4901     -0.6398004
    c2815     r5008     0.92002495
    c2815     r5170     -0.6398004
    c2815     r5337     -0.78100634765625
    c2815     r5633     -1
    c2815     r5637     -0.07997505
    c2815     r5692     -0.0488128967285157
    c2815     r5693     -0.07997505
    c2815     r5918     -0.78100634765625
    c2815     r6856     -1
    c2815     r6996     -0.0762939453125
    c2815     r7001     -0.0488128967285156
    c2815     r7024     -0.6103515625
    c2816     r4588     -1
    c2816     r4647     -0.29285625
    c2817     r4135     -1
    c2817     r4180     1
    c2817     r5170     -0.0008
    c2818     r971      -10000
    c2818     r4825     0.91955638
    c2819     r972      -10000
    c2819     r4821     0.561252673339844
    c2819     r5337     -0.78100634765625
    c2819     r6937     -1
    c2819     r7024     -0.561538665771484
    c2820     r972      1
    c2820     r4132     -1
    c2820     r4283     1
    c2821     r5164     -0.0490391099999998
    c2821     r5628     0.580420465087891
    c2821     r5683     0.461097490805034
    c2821     r5797     0.580420465087891
    c2821     r5988     0.580420465087891
    c2821     r6083     0.520558270263672
    c2822     r974      -10000
    c2822     r6930     0.609762829589844
    c2823     r975      -10000
    c2823     r2473     10000
    c2823     r5005     -0.826835312499995
    c2823     r5107     -0.0319012617754058
    c2823     r5836     -0.826835312500009
    c2823     r6418     -0.568159843749996
    c2823     r6548     -0.6103515625
    c2823     r6973     -0.0131986779630783
    c2823     r7012     -0.0129193017578124
    c2824     r6816     -0.0129193017578125
    c2825     r977      -10000
    c2825     r6468     -0.609594970703125
    c2825     r6973     -0.6103515625
    c2826     r977      1
    c2826     r3797     -1
    c2826     r4189     1
    c2826     r5826     -0.03125
    c2827     r978      -10000
    c2827     r2476     10000
    c2827     r7077     0.609762829589844
    c2828     r979      -10000
    c2828     r2477     10000
    c2829     r980      -10000
    c2829     r2478     10000
    c2829     r6878     -0.838385318019727
    c2830     r6469     -0.6103515625
    c2831     r3389     1
    c2831     r3390     -1
    c2832     r4830     -0.0632161099999999
    c2832     r4920     -0.0632161099999999
    c2832     r5168     0.93678389
    c2832     r5453     0.908081209195289
    c2832     r6174     0.0106547500000001
    c2832     r6261     -0.0588675159692851
    c2832     r6263     -0.977963223620355
    c2832     r6440     -0.0467433109917812
    c2832     r6493     -0.0495343170402758
    c2832     r6692     0.00901467608472443
    c2832     r6929     0.00948269404251787
    c2833     r6346     -0.926172033125734
    c2833     r6422     1
    c2833     r6423     0.0385840515136719
    c2833     r6431     -0.144502677769517
    c2833     r6700     0.0385534191131592
    c2833     r6791     -0.6103515625
    c2833     r6824     -0.0320809082031248
    c2833     r7003     -0.6103515625
    c2834     r3858     1
    c2834     r3944     -1
    c2834     r6261     9.31210667174636e-05
    c2834     r6346     9.88672033125734e-05
    c2834     r6422     0.0001
    c2834     r6423     6.103515625e-05
    c2834     r6431     0.000114292604978001
    c2834     r6552     0.000104380588267577
    c2834     r6700     6.09866996136888e-05
    c2834     r6824     6.103515625e-05
    c2834     r6835     0.0001
    c2835     r5988     -0.6103515625
    c2836     r4119     1
    c2836     r4194     -1
    c2836     r5988     6.103515625e-05
    c2837     r985      -10000
    c2837     r5308     0.580420465087891
    c2837     r5457     0.580420465087891
    c2837     r5988     -0.0299310974121094
    c2838     r986      -10000
    c2838     r4927     0.9742934
    c2838     r5480     0.9742934
    c2838     r6357     0.0608933375
    c2838     r6847     0.0257065999999999
    c2838     r6878     0.0393413014837942
    c2838     r6904     0.0257065999999999
    c2838     r7048     -0.972900107823554
    c2839     r987      -10000
    c2839     r5320     0.594661499023437
    c2839     r7072     -0.58657996124502
    c2840     r988      -10000
    c2840     r2486     10000
    c2841     r989      -10000
    c2841     r2487     10000
    c2842     r990      -10000
    c2842     r2488     10000
    c2843     r991      -10000
    c2843     r2489     10000
    c2844     r4509     -0.6103515625
    c2845     r3258     -1
    c2845     r3262     1
    c2846     r993      -10000
    c2846     r4509     -0.6103515625
    c2847     r993      1
    c2847     r3261     -1
    c2847     r3262     1
    c2848     r994      -10000
    c2849     r994      1
    c2849     r2996     -1
    c2849     r3224     1
    c2850     r995      -10000
    c2850     r6757     -0.813106203124999
    c2851     r995      1
    c2851     r2997     -1
    c2851     r3002     1
    c2852     r996      -10000
    c2852     r5520     -0.813106203124987
    c2852     r5696     -0.813106203124979
    c2853     r996      1
    c2853     r2999     -1
    c2853     r3002     1
    c2854     Obj       0
    c2855     r2998     -1
    c2855     r3003     1
    c2856     r998      -10000
    c2856     r5520     -0.813106203124987
    c2856     r5696     -0.813106203124979
    c2856     r6757     -0.813106203124999
    c2857     r998      1
    c2857     r3000     -1
    c2857     r3001     1
    c2858     r999      -10000
    c2858     r5089     -0.666096601600003
    c2858     r5163     -0.666096601600002
    c2858     r5231     -0.813106203125002
    c2858     r5299     -0.666096601600001
    c2858     r5520     -0.813106203124987
    c2858     r5696     -0.813106203124979
    c2858     r5906     -0.0254095688476563
    c2858     r6077     -0.813106203125002
    c2858     r6699     -0.813106203124999
    c2858     r6757     -0.813106203124999
    c2858     r7049     -0.915013162297832
    c2859     r999      1
    c2859     r3001     1
    c2859     r3005     -1
    c2859     r5906     6.103515625e-05
    c2859     r7049     0.000488357173027066
    c2860     r1000     -10000
    c2860     r6699     -0.813106203124999
    c2860     r6757     -0.813106203124999
    c2861     r1000     1
    c2861     r3001     1
    c2861     r3002     -1
    c2862     r1001     -10000
    c2862     r6095     -0.121967825836948
    c2862     r6744     -0.125
    c2862     r7049     -0.711705003972637
    c2863     r1001     1
    c2863     r3004     1
    c2863     r3235     -1
    c2863     r5994     6.103515625e-05
    c2863     r6095     7.32319388336948e-05
    c2864     r1002     -10000
    c2864     r6744     -0.125
    c2864     r7049     -0.711705003972637
    c2865     r1002     1
    c2865     r3004     1
    c2865     r3222     -1
    c2866     r1003     -10000
    c2866     r5163     -0.666096601600002
    c2866     r5231     -0.813106203125002
    c2866     r5696     -0.813106203124979
    c2866     r6077     -0.813106203125002
    c2866     r7049     -0.711705003972637
    c2867     r1003     1
    c2867     r3005     -1
    c2867     r3006     1
    c2868     r5696     -0.813106203124979
    c2868     r7049     -0.711705003972637
    c2869     r3006     1
    c2869     r3007     -1
    c2870     r1005     -10000
    c2870     r5163     -0.666096601600002
    c2870     r5231     -0.813106203125002
    c2870     r5299     -0.666096601600001
    c2870     r6077     -0.813106203125002
    c2871     r1005     1
    c2871     r3012     1
    c2871     r3225     -1
    c2872     r1006     -10000
    c2872     r5163     -0.666096601600002
    c2872     r5231     -0.813106203125002
    c2872     r5299     -0.666096601600001
    c2872     r5520     -0.813106203124987
    c2872     r5696     -0.813106203124979
    c2872     r6077     -0.813106203125002
    c2872     r6699     -0.813106203124999
    c2872     r6757     -0.813106203124999
    c2873     r1006     1
    c2873     r3012     1
    c2873     r3217     -1
    c2874     r1007     -10000
    c2874     r5696     -0.81310620312499
    c2874     r6077     -0.813106203125015
    c2875     r1007     1
    c2875     r3217     -1
    c2875     r3219     1
    c2876     r1008     -10000
    c2876     r5696     -0.81310620312499
    c2876     r6077     -0.813106203125015
    c2877     r1008     1
    c2877     r3006     -1
    c2877     r3219     1
    c2878     r1009     -10000
    c2878     r5299     -0.666096601600001
    c2878     r5696     -0.813106203124979
    c2878     r6699     -0.813106203124999
    c2879     r1009     1
    c2879     r3217     -1
    c2879     r3218     1
    c2880     r1010     -10000
    c2880     r5299     -0.666096601600001
    c2880     r5696     -0.813106203124979
    c2880     r6699     -0.813106203124999
    c2881     r1010     1
    c2881     r3218     1
    c2881     r3220     -1
    c2882     r1011     -10000
    c2882     r5089     -0.666096601600003
    c2882     r5299     -0.666096601600001
    c2882     r5696     -0.813106203124979
    c2882     r6699     -0.813106203124999
    c2883     r1011     1
    c2883     r3010     -1
    c2883     r3218     1
    c2883     r5089     0.0032
    c2884     r4934     -0.6103515625
    c2885     r3009     -1
    c2885     r3223     1
    c2885     r5524     -6.103515625e-05
    c2886     r6795     -0.101654079162598
    c2886     r6812     -0.139888760124207
    c2886     r7031     -0.101654079162598
    c2887     r3009     -1
    c2887     r3011     1
    c2888     r6812     -0.139888760124207
    c2888     r7031     -0.101654079162598
    c2889     r3010     -1
    c2889     r3011     1
    c2890     r1015     -10000
    c2890     r6738     -0.101654079162598
    c2890     r6759     -0.139881130729675
    c2890     r6812     -0.139888760124207
    c2890     r7031     -0.101654079162598
    c2891     r1015     1
    c2891     r3011     1
    c2891     r3222     -1
    c2892     r1016     -10000
    c2892     r5696     -0.81310620312499
    c2892     r6077     -0.813106203125015
    c2893     r1016     1
    c2893     r3010     -1
    c2893     r3221     1
    c2894     r5231     -0.813106203125002
    c2894     r5696     -0.81310620312499
    c2894     r6077     -0.813106203125015
    c2894     r6738     -0.101654079162598
    c2894     r6759     -0.139881130729675
    c2894     r6812     -0.139888760124207
    c2894     r7031     -0.101654079162598
    c2895     r3221     1
    c2895     r3222     -1
    c2895     r5231     0.00390625
    c2896     Obj       0
    c2897     r3219     -1
    c2897     r3221     1
    c2898     r2517     270
    c2898     r5456     -0.652396345264352
    c2898     r6695     -0.750798312110558
    c2898     r6838     0.52734375
    c2899     r3205     -1
    c2899     r3206     1
    c2900     Obj       0
    c2901     r3023     -1
    c2901     r3025     1
    c2902     Obj       0
    c2903     r3024     -1
    c2903     r3026     1
    c2904     Obj       0
    c2905     r3025     -1
    c2905     r3026     1
    c2906     r4642     -0.6103515625
    c2907     r3027     1
    c2907     r3028     -1
    c2908     r1024     -10000
    c2909     r1024     1
    c2909     r3025     -1
    c2909     r3027     1
    c2910     r2523     10000
    c2910     r4847     -0.863157875000013
    c2911     r3027     1
    c2911     r3030     -1
    c2912     r4643     -0.6103515625
    c2913     r3026     -1
    c2913     r3028     1
    c2914     r5115     -0.607890147521973
    c2914     r5627     -0.0352923189697265
    c2914     r6745     0.736086592397152
    c2914     r7002     -0.1149170941
    c2915     r3232     1
    c2915     r3233     -1
    c2915     r4879     -0.03125
    c2915     r6584     -0.001953125
    c2916     r1028     -10000
    c2916     r6634     -0.101654079162598
    c2916     r6696     -0.1665500433
    c2916     r7006     -0.6103515625
    c2917     r1028     1
    c2917     r3041     1
    c2917     r3237     -1
    c2918     r6634     -0.101654079162598
    c2919     r3041     1
    c2919     r3239     -1
    c2919     r6696     -0.0001
    c2920     r2528     10000
    c2920     r6939     -0.99911847
    c2920     r7076     0.000538043212890527
    c2921     r4221     1
    c2921     r4274     -1
    c2922     r1031     -10000
    c2922     r7045     -0.0762939453125
    c2923     r1031     1
    c2923     r3048     1
    c2923     r3250     -1
    c2924     r1032     -10000
    c2924     r6849     0.609555770324707
    c2925     r1032     1
    c2925     r3146     1
    c2925     r3150     -1
    c2926     r1033     -10000
    c2926     r6900     -0.590881044555664
    c2927     r1033     1
    c2927     r3213     1
    c2927     r4218     -1
    c2928     r5020     -0.555490613586426
    c2928     r5091     -0.557952028564453
    c2928     r5532     0.508697483337402
    c2928     r5977     0.404118480823189
    c2928     r6081     -0.206233081676811
    c2928     r6150     0.508697483337402
    c2928     r6405     1
    c2928     r6413     -0.203308158325195
    c2928     r6491     0.508697483337402
    c2928     r6691     -0.555490613586426
    c2928     r6696     0.1665500433
    c2928     r6745     -0.812380537709652
    c2928     r6759     0.699993347583806
    c2928     r6781     0.499812205
    c2928     r6793     -0.555490613586426
    c2928     r7006     -0.557952028564453
    c2929     r3040     1
    c2929     r3250     -1
    c2929     r5091     6.103515625e-05
    c2929     r5977     8.16584644176811e-05
    c2929     r6081     8.16584644176811e-05
    c2929     r6413     6.103515625e-05
    c2929     r6691     6.103515625e-05
    c2929     r7006     6.103515625e-05
    c2930     r5532     -0.101654079162598
    c2930     r6491     -0.101654079162598
    c2930     r6527     0.0860056264
    c2930     r6688     0.0860056264
    c2930     r6759     -0.139881130729675
    c2930     r6797     -0.1665500433
    c2931     r3040     1
    c2931     r3041     -1
    c2931     r6150     -6.103515625e-05
    c2932     r5893     -0.6103515625
    c2932     r6633     -0.6103515625
    c2933     r3490     -1
    c2933     r4201     1
    c2934     r1037     -10000
    c2934     r5893     -0.6103515625
    c2934     r6633     -0.6103515625
    c2935     r1037     1
    c2935     r3490     -1
    c2935     r4202     1
    c2936     r5893     -0.6103515625
    c2937     r3490     -1
    c2937     r4203     1
    c2937     r6633     -6.103515625e-05
    c2938     r4999     -0.6103515625
    c2939     r3835     1
    c2939     r4205     -1
    c2939     r5291     -6.103515625e-05
    c2940     r1040     -10000
    c2941     r1040     1
    c2941     r3835     1
    c2941     r3837     -1
    c2942     r1041     -10000
    c2943     r1041     1
    c2943     r3837     -1
    c2943     r4204     1
    c2944     r4651     -0.6103515625
    c2945     r3920     -1
    c2945     r4052     1
    c2945     r4651     6.103515625e-05
    c2945     r6568     -0.03125
    c2945     r6580     -6.103515625e-05
    c2945     r6646     -0.03125
    c2945     r6662     -6.103515625e-05
    c2946     r6512     -0.6103515625
    c2947     r4051     -1
    c2947     r4052     1
    c2947     r4671     -0.03125
    c2947     r6583     6.103515625e-05
    c2947     r6662     -6.103515625e-05
    c2948     r2542     10000
    c2948     r4868     -0.9914909228
    c2949     r3484     -1
    c2949     r3748     1
    c2950     r6140     -0.6103515625
    c2950     r6263     -0.98934525
    c2951     r4232     1
    c2951     r4269     -1
    c2952     r6174     -0.92612914
    c2952     r6440     -0.676920869012365
    c2952     r6493     -0.667804960503273
    c2953     r3430     -1
    c2953     r4232     1
    c2953     r6263     -0.000106825841804308
    c2953     r6824     -6.103515625e-05
    c2954     r4487     -0.6103515625
    c2954     r5148     -0.6103515625
    c2954     r6489     -0.6103515625
    c2955     r3333     -1
    c2955     r4257     1
    c2955     r5813     -6.103515625e-05
    c2955     r6189     -0.03125
    c2956     r4473     -0.6103515625
    c2957     r3314     -1
    c2957     r3316     1
    c2958     r5640     -0.033477783203125
    c2959     r3252     -1
    c2959     r4226     1
    c2959     r4627     0.03125
    c2959     r6564     -6.103515625e-05
    c2960     r4468     -0.6103515625
    c2961     r3259     -1
    c2961     r3263     1
    c2961     r4715     0.03125
    c2962     r1051     -10000
    c2963     r1051     1
    c2963     r3265     1
    c2963     r3790     -1
    c2964     r4464     -1
    c2965     r3265     1
    c2965     r3266     -1
    c2965     r4525     -0.03125
    c2965     r4591     0.03125
    c2966     r5646     -0.00978951818847662
    c2966     r5731     -0.00978951818847662
    c2966     r6084     -0.631376638307498
    c2966     r6559     -0.6103515625
    c2966     r6638     -0.604032879745649
    c2966     r6810     -0.604032879745649
    c2966     r7017     -0.604032879745649
    c2967     r3268     -1
    c2967     r3270     1
    c2967     r6084     6.50450124635623e-05
    c2968     r5510     1
    c2968     r6015     -0.00337449291992198
    c2969     r3268     -1
    c2969     r3269     1
    c2969     r6559     -6.23805752444274e-05
    c2969     r6638     -6.36421271115382e-05
    c2969     r6756     -6.103515625e-05
    c2969     r6810     -6.36421271115382e-05
    c2969     r7017     -6.36421271115382e-05
    c2970     r5603     -0.313264582031248
    c2970     r5646     -0.00978951818847662
    c2970     r5731     -0.00978951818847662
    c2970     r6553     -0.00978951818847651
    c2970     r6798     -0.6103515625
    c2971     r3272     -1
    c2971     r3275     1
    c2972     r4635     -1
    c2972     r4724     -0.57272497265625
    c2972     r5098     -0.572724972656246
    c2972     r5248     0.0290028187403598
    c2973     r3274     -1
    c2973     r3275     1
    c2973     r4706     0.03125
    c2973     r6638     6.36421271115382e-05
    c2973     r6810     6.36421271115382e-05
    c2974     r4635     -1
    c2974     r5248     -0.6103515625
    c2974     r6084     -0.019073486328125
    c2975     r3275     1
    c2975     r3276     -1
    c2975     r6553     -6.103515625e-05
    c2976     r4764     -0.606977069580078
    c2977     r3268     -1
    c2977     r3934     1
    c2978     r4805     -0.606977069580078
    c2978     r5248     -0.0290028187403598
    c2978     r5646     -0.00978951818847662
    c2978     r5731     -0.00978951818847662
    c2979     r3268     -1
    c2979     r3273     1
    c2979     r4805     6.103515625e-05
    c2979     r5248     6.3935438124036e-05
    c2980     r5254     -0.00337449291992198
    c2981     r3273     1
    c2981     r4229     -1
    c2981     r4774     -0.015625
    c2982     r1061     -10000
    c2983     r1061     1
    c2983     r3277     -1
    c2983     r3278     1
    c2984     r1062     -10000
    c2985     r1062     1
    c2985     r3278     -1
    c2985     r3279     1
    c2985     r4983     6.103515625e-05
    c2986     r1063     -10000
    c2987     r1063     1
    c2987     r3279     1
    c2987     r3345     -1
    c2988     r1064     -10000
    c2989     r1064     1
    c2989     r3279     -1
    c2989     r3289     1
    c2989     r5813     6.103515625e-05
    c2989     r6353     6.103515625e-05
    c2990     r2563     10000
    c2990     r5329     0.603883056640625
    c2990     r6403     -0.6103515625
    c2990     r6705     -0.53012302882127
    c2990     r6763     0.603883056640625
    c2990     r6809     -0.00646850585937497
    c2990     r6836     -0.588197427367252
    c2990     r6851     0.603883056640625
    c2990     r7022     -0.019073486328125
    c2991     r3314     1
    c2991     r3320     -1
    c2991     r5418     0.03125
    c2991     r6403     0.00575912023495001
    c2991     r6809     6.103515625e-05
    c2991     r7022     8.9986253671094e-05
    c2992     r4942     -0.6103515625
    c2992     r4998     -0.6103515625
    c2993     r3297     -1
    c2993     r3300     1
    c2994     r1067     -10000
    c2994     r4942     -0.6103515625
    c2994     r4998     -0.6103515625
    c2994     r7005     -0.6103515625
    c2995     r1067     1
    c2995     r3299     -1
    c2995     r3300     1
    c2996     r5610     -0.6103515625
    c2997     r3294     -1
    c2997     r3299     1
    c2997     r4559     0.03125
    c2998     Obj       0
    c2999     r3298     -1
    c2999     r3299     1
    c3000     r1070     -10000
    c3000     r5094     -0.6103515625
    c3001     r1070     1
    c3001     r3291     1
    c3001     r3300     -1
    c3001     r5649     -0.03125
    c3002     r1071     -10000
    c3003     r1071     1
    c3003     r3291     -1
    c3003     r3307     1
    c3004     r1072     -10000
    c3005     r1072     1
    c3005     r3296     -1
    c3005     r3304     1
    c3006     Obj       0
    c3007     r3303     -1
    c3007     r3304     1
    c3008     Obj       0
    c3009     r3301     1
    c3009     r3304     -1
    c3010     r1075     -10000
    c3011     r1075     1
    c3011     r3306     1
    c3011     r3307     -1
    c3012     Obj       0
    c3013     r3305     -1
    c3013     r3306     1
    c3013     r4617     -0.03125
    c3014     r1077     -10000
    c3015     r1077     1
    c3015     r3302     1
    c3015     r3303     -1
    c3016     r1078     -10000
    c3017     r1078     1
    c3017     r3301     -1
    c3017     r3302     1
    c3018     r1079     -10000
    c3018     r5096     -0.6103515625
    c3019     r1079     1
    c3019     r3292     1
    c3019     r3302     -1
    c3019     r5096     6.103515625e-05
    c3020     r1080     -10000
    c3021     r1080     1
    c3021     r3292     1
    c3021     r3305     -1
    c3021     r4648     6.103515625e-05
    c3022     r1081     -10000
    c3023     r1081     1
    c3023     r3305     1
    c3023     r3308     -1
    c3024     r1082     -10000
    c3025     r1082     1
    c3025     r3292     -1
    c3025     r3293     1
    c3025     r5649     0.03125
    c3026     Obj       0
    c3027     r3296     -1
    c3027     r3311     1
    c3028     r2582     10000
    c3028     r6403     -0.6103515625
    c3028     r6763     -0.00646850585937475
    c3028     r6809     -0.00646850585937497
    c3028     r6813     0.603883056640625
    c3028     r7022     -0.0286102294921875
    c3029     r3317     1
    c3029     r3667     -1
    c3030     r1085     -10000
    c3030     r5152     -1
    c3031     r1085     1
    c3031     r3322     -1
    c3031     r3344     1
    c3032     r5152     -1
    c3033     r3342     -1
    c3033     r3344     1
    c3034     r1087     -10000
    c3035     r1087     1
    c3035     r3323     -1
    c3035     r3329     1
    c3036     r1088     -10000
    c3036     r6777     0.00646850585937497
    c3036     r6817     0.603883056640625
    c3036     r6999     -0.827968749999997
    c3037     r1088     1
    c3037     r3325     -1
    c3037     r3329     1
    c3037     r5648     0.03125
    c3037     r6817     6.103515625e-05
    c3038     r6561     -0.00646850585937486
    c3038     r6814     -0.603883056640625
    c3039     r3325     -1
    c3039     r3326     1
    c3039     r5648     0.03125
    c3040     r4694     -0.6103515625
    c3041     r3331     1
    c3041     r3334     -1
    c3041     r6504     -0.03125
    c3042     r1091     -10000
    c3042     r5067     -0.6103515625
    c3043     r1091     1
    c3043     r3330     1
    c3043     r3331     -1
    c3043     r4694     6.103515625e-05
    c3043     r6504     0.03125
    c3044     r1092     -10000
    c3045     r1092     1
    c3045     r3310     -1
    c3045     r3330     1
    c3045     r6348     6.103515625e-05
    c3046     r1093     -10000
    c3047     r1093     1
    c3047     r3330     -1
    c3047     r3337     1
    c3048     r1094     -10000
    c3048     r4836     -0.6103515625
    c3049     r1094     1
    c3049     r3337     1
    c3049     r3338     -1
    c3049     r5067     -6.103515625e-05
    c3050     r1095     -10000
    c3050     r6352     -0.6103515625
    c3051     r1095     1
    c3051     r3336     1
    c3051     r3345     -1
    c3052     Obj       0
    c3053     r3335     -1
    c3053     r3336     1
    c3054     Obj       0
    c3055     r3338     -1
    c3055     r3342     1
    c3056     r1098     -10000
    c3057     r1098     1
    c3057     r3321     1
    c3057     r3339     -1
    c3058     r5074     -0.6103515625
    c3059     r3343     1
    c3059     r4187     -1
    c3060     r1100     -10000
    c3061     r1100     1
    c3061     r3340     -1
    c3061     r3343     1
    c3062     r1101     -10000
    c3063     r1101     1
    c3063     r3321     -1
    c3063     r3792     1
    c3064     r1102     -10000
    c3065     r1102     1
    c3065     r3341     1
    c3065     r3792     -1
    c3066     r1103     -10000
    c3066     r6357     0.0811911166666667
    c3066     r7048     0.0541997843528921
    c3067     r1103     1
    c3067     r3356     -1
    c3067     r3383     1
    c3067     r5478     6.103515625e-05
    c3067     r6349     6.103515625e-05
    c3068     r1104     -10000
    c3068     r6534     -0.6103515625
    c3069     r1104     1
    c3069     r3376     -1
    c3069     r3383     1
    c3069     r4607     -0.03125
    c3070     r6143     -0.6103515625
    c3071     r3373     1
    c3071     r3388     -1
    c3072     r4848     -0.6103515625
    c3072     r7039     -0.577270639433049
    c3073     r3363     1
    c3073     r3383     -1
    c3073     r4848     6.103515625e-05
    c3073     r6538     6.103515625e-05
    c3073     r6544     6.103515625e-05
    c3074     r1107     -10000
    c3075     r1107     1
    c3075     r3349     -1
    c3075     r3367     1
    c3076     r1108     -10000
    c3077     r1108     1
    c3077     r3357     -1
    c3077     r3367     1
    c3078     r1109     -10000
    c3078     r6550     -0.6103515625
    c3079     r1109     1
    c3079     r3350     1
    c3079     r3367     -1
    c3080     r6144     -0.6103515625
    c3080     r6357     -0.0811911166666667
    c3080     r7039     -0.0330809230669505
    c3080     r7048     -0.0541997843528921
    c3081     r3350     1
    c3081     r3363     -1
    c3081     r6144     6.103515625e-05
    c3081     r6357     7.89594079600832e-05
    c3081     r6443     6.103515625e-05
    c3081     r7039     6.43432485566951e-05
    c3081     r7048     0.000105419978435289
    c3082     r1111     -10000
    c3083     r1111     1
    c3083     r3348     -1
    c3083     r3369     1
    c3084     r5808     -0.576570559700624
    c3084     r6538     -0.6103515625
    c3084     r6904     -0.9485868
    c3084     r7072     -0.571225166637748
    c3085     r3364     -1
    c3085     r3384     1
    c3085     r5264     -0.03125
    c3085     r6421     -6.103515625e-05
    c3085     r7072     5.97309430545916e-05
    c3086     r6904     -0.9485868
    c3086     r7039     -0.6103515625
    c3087     r3384     1
    c3087     r3385     -1
    c3087     r6287     -0.03125
    c3088     r1114     -10000
    c3089     r1114     1
    c3089     r3352     1
    c3089     r3365     -1
    c3090     r1115     -10000
    c3091     r1115     1
    c3091     r3351     -1
    c3091     r3352     1
    c3092     r1116     -10000
    c3093     r1116     1
    c3093     r3354     1
    c3093     r3386     -1
    c3094     r1117     -10000
    c3095     r1117     1
    c3095     r3353     -1
    c3095     r3354     1
    c3096     r1118     -10000
    c3097     r1118     1
    c3097     r3362     -1
    c3097     r3377     1
    c3098     r5478     -0.6103515625
    c3098     r6349     -0.6103515625
    c3099     r3376     -1
    c3099     r3377     1
    c3100     r1120     -10000
    c3101     r1120     1
    c3101     r3358     1
    c3101     r3378     -1
    c3102     r1121     -10000
    c3103     r1121     1
    c3103     r3361     -1
    c3103     r3375     1
    c3104     r1122     -10000
    c3105     r1122     1
    c3105     r3374     -1
    c3105     r3375     1
    c3106     Obj       0
    c3107     r3375     1
    c3107     r3379     -1
    c3108     Obj       0
    c3109     r3359     -1
    c3109     r3362     1
    c3110     r1125     -10000
    c3111     r1125     1
    c3111     r3359     -1
    c3111     r3360     1
    c3112     Obj       0
    c3113     r3360     1
    c3113     r3860     -1
    c3114     Obj       0
    c3115     r3361     1
    c3115     r3860     -1
    c3116     r1128     -10000
    c3117     r1128     1
    c3117     r3368     -1
    c3117     r3828     1
    c3118     r1129     -10000
    c3119     r1129     1
    c3119     r3351     -1
    c3119     r3828     1
    c3120     r1130     -10000
    c3121     r1130     1
    c3121     r3361     -1
    c3121     r3386     1
    c3122     r1131     -10000
    c3123     r1131     1
    c3123     r3366     -1
    c3123     r3386     1
    c3124     r1132     -10000
    c3124     r6443     -0.6103515625
    c3125     r1132     1
    c3125     r3369     -1
    c3125     r3370     1
    c3126     r1133     -10000
    c3126     r6443     -0.6103515625
    c3127     r1133     1
    c3127     r3370     -1
    c3127     r3390     1
    c3128     r6349     -0.6103515625
    c3128     r6357     -0.0811911166666667
    c3128     r6443     -0.6103515625
    c3128     r6878     -0.0625
    c3129     r3382     -1
    c3129     r3390     1
    c3130     r1135     -10000
    c3130     r6443     -0.6103515625
    c3131     r1135     1
    c3131     r3371     -1
    c3131     r3382     1
    c3132     r1136     -10000
    c3132     r6443     -0.6103515625
    c3133     r1136     1
    c3133     r3374     -1
    c3133     r3382     1
    c3134     r5478     -0.6103515625
    c3134     r6357     -0.708402962934165
    c3134     r6421     -0.6103515625
    c3134     r6878     -0.838385318019727
    c3134     r7048     -1
    c3135     r3382     1
    c3135     r3385     -1
    c3135     r6357     7.89594079600832e-05
    c3135     r6421     6.103515625e-05
    c3135     r6878     9.00885318019727e-05
    c3136     r1138     -10000
    c3137     r1138     1
    c3137     r3372     -1
    c3137     r3374     1
    c3138     r1139     -10000
    c3138     r5478     -0.6103515625
    c3138     r6349     -0.6103515625
    c3139     r1139     1
    c3139     r3376     -1
    c3139     r3380     1
    c3140     r4994     -0.6103515625
    c3141     r3395     -1
    c3141     r3399     1
    c3142     r4590     -0.6103515625
    c3143     r3398     -1
    c3143     r3399     1
    c3144     r4809     -0.6103515625
    c3144     r5017     -0.6103515625
    c3144     r5449     -0.6103515625
    c3145     r3399     1
    c3145     r3414     -1
    c3146     r4471     -0.6103515625
    c3147     r3730     1
    c3147     r4239     -1
    c3147     r4782     6.103515625e-05
    c3147     r4783     6.103515625e-05
    c3148     r5378     -0.6103515625
    c3149     r3730     1
    c3149     r3759     -1
    c3149     r6415     -6.103515625e-05
    c3150     r6070     -0.6103515625
    c3150     r6415     -0.6103515625
    c3151     r3729     -1
    c3151     r3730     1
    c3152     Obj       0
    c3153     r3423     -1
    c3153     r3492     1
    c3154     Obj       0
    c3155     r3424     -1
    c3155     r3940     1
    c3156     r1148     -10000
    c3156     r6544     -0.6103515625
    c3157     r1148     1
    c3157     r3492     -1
    c3157     r3940     1
    c3158     Obj       0
    c3159     r3425     1
    c3159     r3772     -1
    c3160     r6440     -0.676920869012365
    c3160     r6552     -0.977820535177896
    c3160     r6700     -0.53925813828766
    c3160     r6824     -0.539686602783203
    c3161     r3427     1
    c3161     r3429     -1
    c3161     r6440     7.39420869012366e-05
    c3161     r6585     6.103515625e-05
    c3161     r6589     6.103515625e-05
    c3161     r6591     6.103515625e-05
    c3162     r1151     -10000
    c3162     r5985     -0.6103515625
    c3163     r1151     1
    c3163     r3873     1
    c3163     r4059     -1
    c3163     r6761     -0.0001220703125
    c3163     r6803     -6.103515625e-05
    c3164     r1152     -10000
    c3164     r6011     0.0184650326423645
    c3165     r1152     1
    c3165     r3477     -1
    c3165     r3478     1
    c3165     r4558     0.03125
    c3165     r4626     0.03125
    c3165     r4650     6.103515625e-05
    c3165     r4752     0.03125
    c3165     r5378     6.103515625e-05
    c3165     r5617     6.103515625e-05
    c3165     r6474     6.103515625e-05
    c3165     r6530     6.103515625e-05
    c3165     r7038     6.103515625e-05
    c3166     r5143     -0.6103515625
    c3167     r3478     1
    c3167     r3507     -1
    c3168     r4495     -1
    c3168     r6832     0.607496772888183
    c3168     r6868     -0.01791035
    c3168     r7028     0.599419952392578
    c3169     r3487     1
    c3169     r3952     -1
    c3169     r4640     6.103515625e-05
    c3169     r5127     0.03125
    c3169     r5285     6.103515625e-05
    c3169     r6193     0.03125
    c3169     r6832     6.103515625e-05
    c3169     r6868     0.0001
    c3170     r5844     -0.6103515625
    c3171     r3486     1
    c3171     r3489     -1
    c3172     r4640     -0.6103515625
    c3173     r3486     1
    c3173     r3487     -1
    c3174     r1157     -10000
    c3174     r7029     -0.00476837158203125
    c3175     r1157     1
    c3175     r3491     -1
    c3175     r4090     1
    c3175     r4753     -0.0256
    c3176     r1158     -10000
    c3176     r5083     -0.6103515625
    c3177     r1158     1
    c3177     r3727     1
    c3177     r3761     -1
    c3178     r5082     -0.6103515625
    c3179     r3728     -1
    c3179     r3762     1
    c3180     r4810     -0.6103515625
    c3180     r5443     -0.6103515625
    c3181     r3762     1
    c3181     r4207     -1
    c3181     r4810     6.103515625e-05
    c3181     r5443     6.103515625e-05
    c3182     r4812     -0.6103515625
    c3182     r5159     -0.6103515625
    c3183     r3762     1
    c3183     r4206     -1
    c3183     r4812     6.103515625e-05
    c3183     r5159     6.103515625e-05
    c3183     r5221     -6.103515625e-05
    c3184     r4633     -0.89152184375007
    c3185     r3496     1
    c3185     r3535     -1
    c3186     Obj       0
    c3187     r3485     1
    c3187     r3732     -1
    c3188     r4572     -0.89152184375007
    c3189     r3485     1
    c3189     r3496     -1
    c3190     r1165     -10000
    c3191     r1165     1
    c3191     r3514     -1
    c3191     r4240     1
    c3192     r6658     -0.6103515625
    c3192     r6754     -0.6103515625
    c3192     r6776     -0.6103515625
    c3193     r3628     1
    c3193     r3649     -1
    c3194     r6047     -0.6103515625
    c3194     r6964     -0.365312500000073
    c3195     r3630     1
    c3195     r3639     -1
    c3196     r6011     -0.560367105110766
    c3196     r6474     -0.6103515625
    c3196     r6530     -0.6103515625
    c3197     r3507     1
    c3197     r3757     -1
    c3197     r4736     6.103515625e-05
    c3197     r6474     6.103515625e-05
    c3197     r6530     6.103515625e-05
    c3197     r7038     6.103515625e-05
    c3198     r5463     -0.019470517944336
    c3198     r6417     -0.6103515625
    c3198     r6742     -0.6103515625
    c3198     r6900     -0.019470517944336
    c3199     r3507     1
    c3199     r4225     -1
    c3199     r6900     6.103515625e-05
    c3200     r6011     -0.560367105110766
    c3200     r6417     -0.6103515625
    c3201     r3506     -1
    c3201     r3507     1
    c3201     r6742     -6.103515625e-05
    c3202     r1171     -10000
    c3203     r1171     1
    c3203     r3497     1
    c3203     r3681     -1
    c3203     r4511     6.103515625e-05
    c3204     r1172     -10000
    c3204     r4511     -0.6103515625
    c3205     r1172     1
    c3205     r3497     -1
    c3205     r3725     1
    c3206     r4511     -0.6103515625
    c3207     r3497     -1
    c3207     r3500     1
    c3207     r4750     0.03125
    c3208     r4689     -0.6103515625
    c3209     r3498     1
    c3209     r3501     -1
    c3210     r4776     -0.6103515625
    c3211     r3498     1
    c3211     r3503     -1
    c3212     r1176     -10000
    c3212     r6613     -0.6103515625
    c3213     r1176     1
    c3213     r3498     -1
    c3213     r3505     1
    c3214     r4905     -0.6103515625
    c3215     r3504     -1
    c3215     r3505     1
    c3216     r1178     -10000
    c3216     r4905     -0.6103515625
    c3216     r6613     -0.6103515625
    c3216     r6934     -1
    c3217     r1178     1
    c3217     r3722     -1
    c3217     r3729     1
    c3217     r6613     6.103515625e-05
    c3217     r6934     0.0001
    c3218     r2677     10000
    c3218     r4460     -1
    c3218     r4587     -0.65114087500001
    c3218     r5861     -0.65114087500001
    c3218     r6051     -0.65114087500001
    c3218     r6138     -1
    c3218     r7066     -0.65114087500001
    c3218     r7071     -0.00127175952148439
    c3219     r3931     -1
    c3219     r4058     1
    c3219     r4587     0.03125
    c3219     r5133     -0.0078125
    c3219     r6827     -6.103515625e-05
    c3220     r4502     -0.6103515625
    c3220     r7071     -0.00127175952148439
    c3221     r4057     -1
    c3221     r4058     1
    c3221     r5133     -0.0078125
    c3221     r5198     -0.03125
    c3221     r6827     -6.103515625e-05
    c3222     r4690     -0.6103515625
    c3223     r3402     -1
    c3223     r4269     1
    c3224     r1182     -10000
    c3224     r6440     -0.676920869012365
    c3224     r6493     -0.725688031753273
    c3224     r6592     -0.6103515625
    c3225     r1182     1
    c3225     r3429     -1
    c3225     r4269     1
    c3225     r5363     6.103515625e-05
    c3225     r6440     7.39420869012366e-05
    c3225     r6493     7.83571103003273e-05
    c3226     r6441     -0.160097485351562
    c3226     r6547     -0.217023576900187
    c3226     r6632     -0.434047153800375
    c3226     r6761     -0.900508154296875
    c3226     r6803     -0.6103515625
    c3227     r3267     -1
    c3227     r3795     1
    c3227     r5739     0.03125
    c3227     r6632     8.27375139400187e-05
    c3227     r6761     0.0001220703125
    c3227     r6803     6.103515625e-05
    c3228     r5836     -0.826835312500009
    c3229     r3797     -1
    c3229     r3801     1
    c3230     r6037     -0.6103515625
    c3230     r6460     -0.6103515625
    c3231     r3800     -1
    c3231     r3801     1
    c3232     r5395     -0.6103515625
    c3233     r3802     -1
    c3233     r3804     1
    c3234     r1187     -10000
    c3235     r1187     1
    c3235     r3266     1
    c3235     r3855     -1
    c3235     r4525     0.03125
    c3236     r4505     -1
    c3237     r3815     1
    c3237     r3818     -1
    c3237     r4939     -6.103515625e-05
    c3238     Obj       0
    c3239     r3818     1
    c3239     r3827     -1
    c3240     r1190     -10000
    c3241     r1190     1
    c3241     r3819     -1
    c3241     r3823     1
    c3242     r4510     -0.6103515625
    c3243     r3822     -1
    c3243     r3823     1
    c3244     r1192     -10000
    c3245     r1192     1
    c3245     r3353     1
    c3245     r3828     -1
    c3246     r1193     -10000
    c3247     r1193     1
    c3247     r3830     -1
    c3247     r3833     1
    c3248     r4906     -0.6103515625
    c3249     r3831     1
    c3249     r3833     -1
    c3250     r1195     -10000
    c3251     r1195     1
    c3251     r3832     -1
    c3251     r3834     1
    c3252     r1196     -10000
    c3252     r6138     -1
    c3253     r1196     1
    c3253     r3829     -1
    c3253     r3834     1
    c3254     r1197     -10000
    c3254     r5861     -0.65114087500001
    c3254     r6051     -0.65114087500001
    c3254     r6138     -1
    c3254     r7066     -0.65114087500001
    c3255     r1197     1
    c3255     r3834     -1
    c3255     r3930     1
    c3255     r6562     -6.13774574550614e-05
    c3256     r4460     -1
    c3257     r3930     1
    c3257     r3931     -1
    c3257     r4754     -0.03125
    c3257     r6562     -6.13774574550614e-05
    c3258     r5441     -0.589021514282227
    c3258     r6086     -0.072119443582458
    c3258     r6436     0.589021514282227
    c3258     r6664     0.633284491804314
    c3259     r3841     1
    c3259     r3842     -1
    c3259     r4725     -0.0016
    c3259     r5909     -6.103515625e-05
    c3259     r6524     -5.89741767886658e-05
    c3259     r6765     -6.103515625e-05
    c3259     r6883     -6.103515625e-05
    c3260     Obj       0
    c3261     r3445     -1
    c3261     r3841     1
    c3262     r1201     -10000
    c3262     r6422     -0.0632161099999999
    c3262     r6423     -0.0385840515136719
    c3262     r6431     -0.216754016654275
    c3262     r6692     -0.0625
    c3262     r6700     -0.0385534191131592
    c3262     r6755     -0.0534853239152761
    c3262     r6824     -0.0385840515136718
    c3262     r6835     -0.0632161099999999
    c3262     r6929     -0.0420649109091475
    c3262     r6998     -0.0625
    c3263     r1201     1
    c3263     r3858     -1
    c3263     r3859     1
    c3263     r6431     0.000114292604978001
    c3263     r6929     5.15410025492391e-05
    c3264     r1202     -10000
    c3264     r6174     0.0738708599999996
    c3264     r6261     0.0687893328253637
    c3264     r6263     0.0789131680430819
    c3264     r6346     -0.863672033125734
    c3264     r6431     0.853920694240976
    c3264     r6440     0.0625
    c3264     r6493     0.1157661425
    c3264     r6552     0.0659853474978786
    c3264     r6700     -0.0706088578492288
    c3264     r6824     -0.0706649597167966
    c3265     r1202     1
    c3265     r3856     -1
    c3265     r3859     1
    c3265     r6261     9.31210667174636e-05
    c3265     r6346     9.88672033125734e-05
    c3265     r6431     0.000114292604978001
    c3265     r6552     0.000104380588267577
    c3265     r6700     6.09866996136888e-05
    c3265     r6824     6.103515625e-05
    c3266     r6261     -0.862421334349273
    c3266     r6263     -0.98934525
    c3266     r6346     -0.926172033125734
    c3266     r6431     -0.144502677769517
    c3266     r6552     -0.977820535177896
    c3267     r3859     1
    c3267     r4269     -1
    c3267     r6261     9.31210667174636e-05
    c3267     r6346     9.88672033125734e-05
    c3267     r6431     0.000114292604978001
    c3267     r6552     0.000104380588267577
    c3268     r6761     -0.260118212890625
    c3268     r6803     -0.450254077148438
    c3269     r3870     1
    c3269     r3872     -1
    c3270     Obj       0
    c3271     r3810     1
    c3271     r4280     -1
    c3272     Obj       0
    c3273     r3893     1
    c3273     r3895     -1
    c3274     r4512     -0.6103515625
    c3275     r3893     1
    c3275     r3904     -1
    c3276     r1208     -10000
    c3277     r1208     1
    c3277     r3892     -1
    c3277     r3893     1
    c3278     r4466     -1
    c3279     r3893     -1
    c3279     r3903     1
    c3280     Obj       0
    c3281     r3898     -1
    c3281     r3905     1
    c3282     r1211     -10000
    c3283     r1211     1
    c3283     r3905     1
    c3283     r3906     -1
    c3284     r1212     -10000
    c3285     r1212     1
    c3285     r3915     1
    c3285     r4051     -1
    c3286     r6580     -0.6103515625
    c3286     r6662     0.6103515625
    c3287     r3917     1
    c3287     r3920     -1
    c3287     r6645     0.03125
    c3288     r1214     -10000
    c3288     r6655     -0.6103515625
    c3289     r1214     1
    c3289     r3917     1
    c3289     r3918     -1
    c3290     r1215     -10000
    c3290     r6583     -0.6103515625
    c3290     r6656     -0.6103515625
    c3291     r1215     1
    c3291     r3918     1
    c3291     r4052     -1
    c3292     r6654     -0.6103515625
    c3292     r6732     -0.6103515625
    c3293     r3921     1
    c3293     r4049     -1
    c3294     r6424     -0.510534374999992
    c3294     r6526     -0.510534374999992
    c3294     r6603     -0.510534374999992
    c3294     r6653     0.560343750000015
    c3294     r6733     -0.6103515625
    c3294     r6917     -0.00398854980468755
    c3295     r3922     -1
    c3295     r4048     1
    c3295     r5274     -0.03125
    c3295     r6654     6.103515625e-05
    c3296     r1218     -10000
    c3296     r6445     -0.610608471679687
    c3296     r7058     -0.557198219425757
    c3297     r1218     1
    c3297     r3925     -1
    c3297     r3933     1
    c3298     r1219     -10000
    c3299     r1219     1
    c3299     r3804     -1
    c3299     r3843     1
    c3300     r4484     -0.6103515625
    c3301     r3843     1
    c3301     r3847     -1
    c3302     r1221     -10000
    c3302     r5537     -0.6103515625
    c3302     r6252     -0.6103515625
    c3302     r6558     -0.92002495
    c3302     r6892     -0.550803145437995
    c3303     r1221     1
    c3303     r3778     -1
    c3303     r4184     1
    c3303     r5078     -6.103515625e-05
    c3303     r6931     -6.103515625e-05
    c3304     r6927     -0.00476837158203125
    c3305     r3956     -1
    c3305     r3984     1
    c3306     r1223     -10000
    c3306     r5404     -0.0138745697021484
    c3306     r6345     -0.0138745697021485
    c3306     r6350     -0.0277689624023437
    c3306     r6360     -0.0138745697021485
    c3306     r6640     -0.019073486328125
    c3307     r1223     1
    c3307     r3422     -1
    c3307     r4265     1
    c3307     r5085     -6.103515625e-05
    c3307     r6350     6.103515625e-05
    c3308     r5294     -0.6103515625
    c3308     r5750     0.596476992797852
    c3308     r6030     -0.887972460937497
    c3308     r6091     0.596467081298828
    c3308     r6350     0.582582600097656
    c3308     r6360     -0.0138745697021485
    c3308     r6369     -0.887972460937505
    c3308     r6495     -0.6103515625
    c3308     r6496     -0.01341476724142
    c3308     r6511     -1
    c3308     r6517     0.58259251159668
    c3308     r6521     -0.0277491394042968
    c3308     r6640     -0.019073486328125
    c3308     r6669     0.582582600097656
    c3308     r6713     -0.887972460937497
    c3308     r6739     0.58259251159668
    c3308     r6750     -0.0535708464982829
    c3308     r6807     -0.57205257543362
    c3308     r6808     0.582517939453125
    c3308     r6977     -0.6103515625
    c3308     r6979     -0.0277590509033203
    c3308     r6994     0.554823549194336
    c3308     r7027     -0.0138745697021485
    c3309     r3936     -1
    c3309     r3995     1
    c3309     r5631     6.103515625e-05
    c3309     r6030     0.00390625
    c3309     r6364     -0.03125
    c3309     r6713     0.00390625
    c3309     r7027     6.103515625e-05
    c3310     r1225     -10000
    c3310     r6692     -0.0625
    c3310     r6755     -0.0534853239152761
    c3310     r6998     -0.0625
    c3310     r7003     -0.6103515625
    c3311     r1225     1
    c3311     r3772     -1
    c3311     r4254     1
    c3312     r1226     -10000
    c3313     r1226     1
    c3313     r4165     -1
    c3313     r4273     1
    c3314     r1227     -10000
    c3315     r1227     1
    c3315     r3423     1
    c3315     r3424     -1
    c3316     r5383     -0.320194970703125
    c3316     r6485     -0.275133243143365
    c3316     r6541     -0.160097485351562
    c3316     r6625     -0.320194970703125
    c3317     r3436     1
    c3317     r3873     -1
    c3317     r5985     6.103515625e-05
    c3318     r1229     -10000
    c3319     r1229     1
    c3319     r3811     -1
    c3319     r3939     1
    c3320     r1230     -10000
    c3320     r6868     -1
    c3321     r1230     1
    c3321     r3879     -1
    c3321     r3939     1
    c3321     r6868     0.0001
    c3322     r1231     -10000
    c3322     r6833     0.599419952392578
    c3322     r6884     -0.6103515625
    c3322     r7052     0.9641793
    c3323     r1231     1
    c3323     r3813     1
    c3323     r3877     -1
    c3323     r7052     0.0001
    c3324     r6168     -0.6103515625
    c3325     r3490     1
    c3325     r3814     -1
    c3326     r1233     -10000
    c3327     r1233     1
    c3327     r3819     -1
    c3327     r3862     1
    c3328     Obj       0
    c3329     r3816     -1
    c3329     r3817     1
    c3330     Obj       0
    c3331     r3817     1
    c3331     r3862     -1
    c3332     Obj       0
    c3333     r3815     -1
    c3333     r3863     1
    c3334     Obj       0
    c3335     r3817     -1
    c3335     r3863     1
    c3336     Obj       0
    c3337     r3820     1
    c3337     r3826     -1
    c3338     r4808     -1
    c3339     r3820     1
    c3339     r3821     -1
    c3340     Obj       0
    c3341     r3821     1
    c3341     r3824     -1
    c3342     Obj       0
    c3343     r3821     1
    c3343     r3823     -1
    c3344     r1242     -10000
    c3344     r4508     -0.6103515625
    c3345     r1242     1
    c3345     r3825     -1
    c3345     r3827     1
    c3346     Obj       0
    c3347     r3820     -1
    c3347     r3827     1
    c3348     r5383     -0.900508154296875
    c3349     r3872     1
    c3349     r3873     -1
    c3350     r6411     -0.900508154296875
    c3350     r6478     -0.900508154296875
    c3350     r6542     -0.858268569634541
    c3350     r6761     -0.64038994140625
    c3351     r3871     -1
    c3351     r3872     1
    c3351     r6411     0.0001220703125
    c3351     r6761     0.0001220703125
    c3351     r6803     6.103515625e-05
    c3352     r4762     -0.6103515625
    c3352     r6533     -0.6103515625
    c3353     r3874     1
    c3353     r3875     -1
    c3353     r4802     -6.103515625e-05
    c3353     r5203     -0.03125
    c3354     r4802     -0.6103515625
    c3354     r6535     -0.6103515625
    c3355     r3874     1
    c3355     r3878     -1
    c3355     r4762     -6.103515625e-05
    c3355     r5203     -0.03125
    c3355     r6535     6.103515625e-05
    c3356     r1248     -10000
    c3357     r1248     1
    c3357     r3000     1
    c3357     r3003     -1
    c3358     r5520     -0.813106203124987
    c3358     r5696     -0.813106203124979
    c3358     r5906     -0.584941993652344
    c3358     r6699     -0.813106203124999
    c3358     r6757     -0.813106203124999
    c3358     r7049     -0.609924474975586
    c3359     r3001     -1
    c3359     r3008     1
    c3359     r7049     -0.000488357173027066
    c3360     r1250     -10000
    c3360     r5089     -0.666096601600003
    c3360     r5163     -0.666096601600002
    c3360     r5231     -0.813106203125002
    c3360     r5299     -0.666096601600001
    c3360     r6077     -0.813106203125002
    c3361     r1250     1
    c3361     r3007     -1
    c3361     r3008     1
    c3362     Obj       0
    c3363     r3008     -1
    c3363     r3225     1
    c3364     r1252     -10000
    c3365     r1252     1
    c3365     r3007     1
    c3365     r3012     -1
    c3366     r4934     -0.6103515625
    c3366     r5524     -0.6103515625
    c3366     r5994     -0.6103515625
    c3367     r3004     -1
    c3367     r3013     1
    c3368     r1254     -10000
    c3368     r6738     -0.101654079162598
    c3368     r6744     -0.125
    c3368     r6759     -0.139881130729675
    c3368     r6812     -0.139888760124207
    c3368     r7031     -0.101654079162598
    c3368     r7049     -0.711705003972637
    c3369     r1254     1
    c3369     r3013     1
    c3369     r3223     -1
    c3370     r6702     -0.765876605468744
    c3370     r6787     -0.860304281249997
    c3370     r6869     -0.0095367431640625
    c3371     r3015     1
    c3371     r3050     -1
    c3371     r5042     -0.03125
    c3371     r5124     0.03125
    c3372     r5068     -0.6103515625
    c3373     r3018     1
    c3373     r3050     -1
    c3374     r1257     -10000
    c3375     r1257     1
    c3375     r3033     -1
    c3375     r3047     1
    c3376     Obj       0
    c3377     r3039     -1
    c3377     r3047     1
    c3378     r5447     0.459421449218752
    c3378     r6079     -0.92099334640867
    c3378     r6149     -0.0713518105576792
    c3378     r6426     -0.595266050781255
    c3378     r6427     -0.135844601562505
    c3378     r6428     -0.135844601562505
    c3378     r6551     -0.385548820048253
    c3378     r6623     -0.125835936465373
    c3378     r6726     -0.037350940870857
    c3378     r6804     -0.1380451484375
    c3379     r3145     -1
    c3379     r3177     1
    c3379     r4971     -1
    c3379     r5447     0.00390625
    c3379     r5501     -1
    c3379     r6079     0.00221314362347643
    c3379     r6149     0.000213085425632828
    c3379     r6426     0.00390625
    c3379     r6428     0.00390625
    c3379     r6551     0.00262831262959929
    c3379     r6726     0.0131337086411538
    c3379     r6804     0.0078125
    c3380     Obj       0
    c3381     r2997     1
    c3381     r3224     -1
    c3382     r1261     -10000
    c3383     r1261     1
    c3383     r3220     1
    c3383     r3225     -1
    c3384     r5089     -0.666096601600003
    c3384     r5163     -0.666096601600002
    c3384     r5231     -0.813106203125002
    c3384     r5299     -0.666096601600001
    c3384     r5520     -0.813106203124987
    c3384     r5696     -0.813106203124979
    c3384     r6077     -0.813106203125002
    c3384     r6699     -0.813106203124999
    c3384     r6757     -0.813106203124999
    c3384     r6795     -0.101654079162598
    c3385     r3009     -1
    c3385     r3220     1
    c3386     r1263     -10000
    c3386     r6846     -0.605158033935547
    c3386     r7029     -0.55561808043315
    c3387     r1263     1
    c3387     r3490     -1
    c3387     r3491     1
    c3387     r7029     5.60386452015181e-05
    c3388     r1264     -10000
    c3389     r1264     1
    c3389     r3491     1
    c3389     r4201     -1
    c3389     r6168     -6.103515625e-05
    c3389     r6846     -6.103515625e-05
    c3390     r6168     -0.6103515625
    c3390     r6846     -0.605158033935547
    c3391     r3491     1
    c3391     r4202     -1
    c3392     r1266     -10000
    c3393     r1266     1
    c3393     r3491     1
    c3393     r4203     -1
    c3393     r6168     -6.103515625e-05
    c3393     r6846     -6.103515625e-05
    c3394     r5004     -0.6103515625
    c3395     r3761     -1
    c3395     r4206     1
    c3395     r5004     6.103515625e-05
    c3395     r5082     -6.103515625e-05
    c3396     r5219     -0.6103515625
    c3397     r4206     1
    c3397     r4207     -1
    c3398     Obj       0
    c3399     r4204     -1
    c3399     r4205     1
    c3400     r5084     -0.6103515625
    c3400     r6162     -0.92002495
    c3400     r6931     -0.561538665771484
    c3401     r3774     1
    c3401     r4184     -1
    c3402     r6432     -0.6103515625
    c3403     r3774     1
    c3403     r4255     -1
    c3403     r7001     -6.103515625e-05
    c3404     r6540     -0.6103515625
    c3404     r6636     -0.574930959206211
    c3404     r6844     0.576873779296875
    c3404     r7016     0.576873779296875
    c3405     r3251     1
    c3405     r3253     -1
    c3406     r4570     -0.53564453125
    c3406     r4828     0.576873779296875
    c3406     r4833     -0.0548500000000001
    c3406     r4979     -0.53564453125
    c3406     r4990     -0.033477783203125
    c3406     r5190     0.619184134108648
    c3406     r5319     -0.6103515625
    c3406     r5561     -0.6103515625
    c3406     r5640     -0.6103515625
    c3406     r6359     -0.7806
    c3406     r6564     -0.6103515625
    c3406     r6841     0.576873779296875
    c3406     r6844     -0.6103515625
    c3406     r6882     -0.645772165793789
    c3406     r7016     0.509918212890625
    c3406     r7032     -0.627562463049122
    c3407     r3254     -1
    c3407     r3256     1
    c3407     r5561     6.103515625e-05
    c3407     r6882     6.45772165793789e-05
    c3408     r1274     -10000
    c3409     r1274     1
    c3409     r3256     1
    c3409     r3257     -1
    c3409     r4963     -0.03125
    c3409     r6359     -0.0001
    c3410     r1275     -10000
    c3411     r1275     1
    c3411     r3260     1
    c3411     r3261     -1
    c3412     r1276     -10000
    c3413     r1276     1
    c3413     r3258     1
    c3413     r3259     -1
    c3413     r4675     0.03125
    c3414     r1277     -10000
    c3415     r1277     1
    c3415     r3258     1
    c3415     r3260     -1
    c3416     r5510     -1
    c3416     r5603     -0.313264582031248
    c3416     r5646     -0.00978951818847662
    c3416     r5731     -0.00978951818847662
    c3417     r3272     1
    c3417     r4260     -1
    c3417     r6094     -6.103515625e-05
    c3418     r6094     -0.582664388916016
    c3418     r6553     -0.564766733520508
    c3419     r3270     -1
    c3419     r3272     1
    c3420     r4983     -0.6103515625
    c3421     r3277     1
    c3421     r3338     -1
    c3421     r6353     -6.103515625e-05
    c3422     r4738     -0.6103515625
    c3423     r3295     -1
    c3423     r3296     1
    c3424     r1282     -10000
    c3425     r1282     1
    c3425     r3321     -1
    c3425     r3322     1
    c3426     r1283     -10000
    c3426     r6780     -0.00948620796203613
    c3427     r1283     1
    c3427     r3311     -1
    c3427     r3323     1
    c3428     r2782     10000
    c3428     r5566     0.00646850585937497
    c3428     r6403     0.6103515625
    c3428     r6501     -0.603883056640625
    c3428     r6561     -0.603883056640625
    c3428     r6777     -0.603883056640625
    c3428     r6999     0.827968749999997
    c3428     r7004     0.00953769683837891
    c3428     r7022     0.0095367431640625
    c3429     r3324     -1
    c3429     r3325     1
    c3429     r5566     6.103515625e-05
    c3429     r6501     6.103515625e-05
    c3429     r6561     6.103515625e-05
    c3429     r6777     6.103515625e-05
    c3429     r6780     8.95094165128909e-05
    c3429     r6813     6.103515625e-05
    c3429     r6999     0.0078125
    c3430     r6763     0.00646850585937475
    c3430     r6771     -0.827968749999997
    c3430     r6777     -0.00646850585937497
    c3430     r6780     -0.00948620796203613
    c3430     r6809     -0.00646850585937497
    c3430     r6813     -0.00646850585937497
    c3430     r6814     -0.00646850585937497
    c3430     r6815     -0.00646850585937497
    c3430     r6817     -0.00646850585937497
    c3430     r6999     -0.827968749999997
    c3430     r7004     -0.00953769683837891
    c3431     r3327     -1
    c3431     r3328     1
    c3431     r6500     -6.103515625e-05
    c3431     r6501     -6.103515625e-05
    c3431     r6814     6.103515625e-05
    c3431     r6817     6.103515625e-05
    c3432     r5544     -0.6103515625
    c3432     r6348     -0.6103515625
    c3433     r3331     -1
    c3433     r3333     1
    c3433     r6505     -0.03125
    c3434     r4498     -0.6103515625
    c3435     r3332     -1
    c3435     r3333     1
    c3436     r1288     -10000
    c3437     r1288     1
    c3437     r3334     1
    c3437     r3336     -1
    c3438     r1289     -10000
    c3439     r1289     1
    c3439     r3339     -1
    c3439     r3340     1
    c3440     r1290     -10000
    c3441     r1290     1
    c3441     r3344     -1
    c3441     r3347     1
    c3442     Obj       0
    c3443     r3343     -1
    c3443     r3347     1
    c3444     Obj       0
    c3445     r3346     -1
    c3445     r3347     1
    c3446     r1293     -10000
    c3447     r1293     1
    c3447     r3335     1
    c3447     r3341     -1
    c3448     r4486     -0.6103515625
    c3448     r6353     -0.6103515625
    c3449     r3345     1
    c3449     r4257     -1
    c3450     Obj       0
    c3451     r3345     -1
    c3451     r3346     1
    c3451     r6352     -6.103515625e-05
    c3452     r1296     -10000
    c3452     r5813     -0.6103515625
    c3453     r1296     1
    c3453     r3346     1
    c3453     r3792     -1
    c3454     r1297     -10000
    c3454     r6443     -0.6103515625
    c3455     r1297     1
    c3455     r3348     -1
    c3455     r3349     1
    c3456     Obj       0
    c3457     r3360     -1
    c3457     r3366     1
    c3458     r1299     -10000
    c3459     r1299     1
    c3459     r3362     -1
    c3459     r3365     1
    c3460     r1300     -10000
    c3461     r1300     1
    c3461     r3365     1
    c3461     r3366     -1
    c3462     r6544     -0.6103515625
    c3462     r6878     -0.838385318019727
    c3463     r3363     -1
    c3463     r3364     1
    c3463     r6287     -0.03125
    c3464     r1302     -10000
    c3465     r1302     1
    c3465     r3358     -1
    c3465     r3371     1
    c3466     r1303     -10000
    c3467     r1303     1
    c3467     r3372     1
    c3467     r3373     -1
    c3468     r1304     -10000
    c3469     r1304     1
    c3469     r3377     -1
    c3469     r3378     1
    c3470     r1305     -10000
    c3470     r5445     -0.6103515625
    c3471     r1305     1
    c3471     r3378     -1
    c3471     r3388     1
    c3472     r1306     -10000
    c3473     r1306     1
    c3473     r3379     1
    c3473     r3380     -1
    c3474     r1307     -10000
    c3474     r6416     -0.6103515625
    c3474     r6469     -0.6103515625
    c3475     r1307     1
    c3475     r3387     1
    c3475     r3388     -1
    c3475     r6416     6.103515625e-05
    c3476     r5445     -0.6103515625
    c3476     r6466     -0.6103515625
    c3476     r6878     -0.0625
    c3477     r3387     1
    c3477     r3389     -1
    c3477     r6443     6.103515625e-05
    c3478     r1309     -10000
    c3479     r1309     1
    c3479     r3391     -1
    c3479     r3397     1
    c3480     r4995     -0.6103515625
    c3481     r3395     1
    c3481     r3396     -1
    c3481     r5053     -0.03125
    c3482     r5144     -0.559154415999998
    c3483     r3403     -1
    c3483     r3404     1
    c3483     r5265     -0.0512
    c3483     r5340     0.03125
    c3484     r6486     -0.599149371337891
    c3484     r6532     -0.589021514282226
    c3484     r6736     0.021330048217773
    c3484     r6753     -0.965052849
    c3484     r6886     -0.930105698
    c3485     r3404     1
    c3485     r3841     -1
    c3486     r4563     -0.0415000000000418
    c3486     r6444     0.507633893089431
    c3486     r6903     0.6103515625
    c3487     r3418     1
    c3487     r3449     -1
    c3487     r4670     0.03125
    c3487     r5041     -0.03125
    c3488     r4741     -0.6103515625
    c3489     r3391     1
    c3489     r3392     -1
    c3489     r4959     -0.03125
    c3490     r4917     -0.6103515625
    c3490     r5011     -0.6103515625
    c3490     r5017     -0.6103515625
    c3491     r3399     -1
    c3491     r3413     1
    c3492     r4803     -0.6103515625
    c3492     r4917     -0.6103515625
    c3492     r5017     -0.6103515625
    c3492     r5449     -0.6103515625
    c3493     r3412     1
    c3493     r3413     -1
    c3493     r4749     -0.03125
    c3493     r5011     -6.103515625e-05
    c3493     r5017     6.103515625e-05
    c3494     r2815     10000
    c3494     r6843     -0.598090856933594
    c3494     r7018     -0.603400817871094
    c3495     r3281     -1
    c3495     r3755     1
    c3495     r4605     0.03125
    c3496     r1318     -10000
    c3496     r2816     10000
    c3496     r4851     -0.6103515625
    c3496     r7018     -0.603400817871094
    c3497     r1318     1
    c3497     r3754     -1
    c3497     r3755     1
    c3497     r6728     -0.0256
    c3497     r6729     -0.0256
    c3497     r6730     -0.0256
    c3498     r1319     -10000
    c3498     r6640     -0.019073486328125
    c3499     r1319     1
    c3499     r3422     1
    c3499     r4055     -1
    c3500     r1320     -10000
    c3500     r5399     -0.6103515625
    c3500     r6589     -0.6103515625
    c3501     r1320     1
    c3501     r3426     -1
    c3501     r3784     1
    c3501     r5363     6.103515625e-05
    c3501     r5399     6.103515625e-05
    c3502     r1321     -10000
    c3502     r6556     -0.03814697265625
    c3503     r1321     1
    c3503     r3773     -1
    c3503     r3784     1
    c3504     r1322     -10000
    c3504     r6585     -0.6103515625
    c3505     r1322     1
    c3505     r3426     1
    c3505     r3427     -1
    c3506     r5363     -0.6103515625
    c3506     r6139     -0.6103515625
    c3506     r6590     -0.6103515625
    c3506     r6824     -0.539686602783203
    c3507     r3426     1
    c3507     r3430     -1
    c3508     r5980     0.0571904517000006
    c3508     r6093     -0.793377513581378
    c3508     r6344     1
    c3508     r6672     0.983801267791304
    c3508     r6679     0.0618990081063717
    c3509     r3437     1
    c3509     r3474     -1
    c3509     r6093     8.41503477570771e-05
    c3509     r6679     0.00010823311630947
    c3510     r4644     -0.6103515625
    c3511     r3440     1
    c3511     r3441     -1
    c3512     r4497     -0.6103515625
    c3512     r5172     -0.6103515625
    c3513     r3438     -1
    c3513     r3440     1
    c3513     r4644     -6.103515625e-05
    c3513     r4976     -0.0009765625
    c3513     r4992     -6.103515625e-05
    c3513     r5172     6.103515625e-05
    c3514     r1327     -10000
    c3514     r5680     -0.558500504882812
    c3515     r1327     1
    c3515     r3465     -1
    c3515     r3466     1
    c3515     r4571     -0.0016
    c3515     r5462     -0.0016
    c3516     r4834     -0.9428094883
    c3517     r3466     -1
    c3517     r3472     1
    c3517     r4538     -0.0256
    c3518     r4832     -0.9428094883
    c3519     r3468     -1
    c3519     r3470     1
    c3519     r4537     -0.0256
    c3520     r4462     -1
    c3520     r5642     -0.0303563991921875
    c3521     r3470     1
    c3521     r3473     -1
    c3521     r4537     -0.0256
    c3522     r1331     -10000
    c3522     r4462     -1
    c3522     r5095     -1
    c3523     r1331     1
    c3523     r3467     -1
    c3523     r3468     1
    c3524     r1332     -10000
    c3524     r2830     10000
    c3524     r5980     -0.0571904517000001
    c3524     r6164     -0.0654390403397571
    c3524     r6265     -0.0625
    c3524     r6420     -0.0501797082916725
    c3524     r6676     -0.0571904516999999
    c3524     r6997     -0.0415692390009233
    c3525     r1332     1
    c3525     r3474     -1
    c3525     r4152     1
    c3525     r6344     -0.0001
    c3525     r6672     0.000104347826086957
    c3525     r6679     0.00010823311630947
    c3525     r6711     0.03125
    c3526     r4461     -1
    c3526     r5980     -0.0571904517000004
    c3526     r6676     -0.0571904516999999
    c3527     r3469     -1
    c3527     r4152     1
    c3527     r5980     0.0001
    c3527     r6368     -0.03125
    c3528     r4461     -1
    c3528     r5795     -0.0571904516999997
    c3528     r5980     0.0571904517000001
    c3528     r6265     0.0625
    c3528     r6420     0.0501797082916727
    c3528     r6689     -0.0571904516999999
    c3528     r6800     0.0625
    c3529     r3471     -1
    c3529     r3474     1
    c3529     r6366     0.03125
    c3529     r6420     8.77414092738715e-05
    c3529     r6648     -0.0256
    c3529     r6676     -0.0001
    c3530     r5285     -0.6103515625
    c3531     r3489     -1
    c3531     r4280     1
    c3531     r5127     -0.03125
    c3532     r6168     -0.6103515625
    c3532     r6633     -0.6103515625
    c3533     r3875     -1
    c3533     r4280     1
    c3533     r5893     -6.103515625e-05
    c3533     r6168     6.103515625e-05
    c3533     r7028     -6.103515625e-05
    c3534     r4636     -1
    c3535     r3545     1
    c3535     r3554     -1
    c3536     r1338     -10000
    c3537     r1338     1
    c3537     r3401     -1
    c3537     r3593     1
    c3537     r4602     0.03125
    c3538     r1339     -10000
    c3539     r1339     1
    c3539     r3589     -1
    c3539     r3593     1
    c3540     r1340     -10000
    c3541     r1340     1
    c3541     r3499     1
    c3541     r3627     -1
    c3542     r4465     -1
    c3543     r3499     1
    c3543     r3618     -1
    c3544     r1342     -10000
    c3545     r1342     1
    c3545     r3501     1
    c3545     r3726     -1
    c3545     r4750     0.03125
    c3546     r1343     -10000
    c3547     r1343     1
    c3547     r3502     -1
    c3547     r3503     1
    c3547     r4776     6.103515625e-05
    c3548     r5329     -0.00646850585937497
    c3548     r6813     -0.603883056640625
    c3548     r6851     -0.00646850585937497
    c3549     r3320     -1
    c3549     r3667     1
    c3549     r4408     0.03125
    c3550     r5007     -0.6103515625
    c3550     r5399     -0.6103515625
    c3550     r6683     -0.00258590624997623
    c3551     r3783     1
    c3551     r3784     -1
    c3551     r5129     -0.03125
    c3551     r5204     -0.03125
    c3552     r5399     -0.6103515625
    c3552     r6406     -0.6103515625
    c3553     r3782     -1
    c3553     r3783     1
    c3553     r4703     -0.0256
    c3553     r5399     6.103515625e-05
    c3554     r4840     -1
    c3555     r4187     1
    c3555     r4188     -1
    c3555     r4788     -0.0256
    c3556     r1348     -10000
    c3557     r1348     1
    c3557     r3803     1
    c3557     r3804     -1
    c3558     r1349     -10000
    c3559     r1349     1
    c3559     r3803     1
    c3559     r3806     -1
    c3560     r4488     -0.6103515625
    c3561     r3805     -1
    c3561     r3807     1
    c3562     r4492     -0.6103515625
    c3563     r3807     1
    c3563     r3848     -1
    c3564     r5407     -0.829436230468751
    c3564     r5475     0.558511798095703
    c3565     r3809     1
    c3565     r4272     -1
    c3565     r5118     -0.03125
    c3565     r5407     0.0009765625
    c3565     r5475     6.103515625e-05
    c3566     r1353     -10000
    c3567     r1353     1
    c3567     r3810     -1
    c3567     r3811     1
    c3568     Obj       0
    c3569     r3815     -1
    c3569     r3816     1
    c3570     Obj       0
    c3571     r3816     -1
    c3571     r3819     1
    c3572     r4510     -0.6103515625
    c3573     r3822     -1
    c3573     r3824     1
    c3574     r1357     -10000
    c3574     r4808     -1
    c3575     r1357     1
    c3575     r3824     -1
    c3575     r3826     1
    c3576     r4508     -0.6103515625
    c3576     r4939     -0.6103515625
    c3577     r3825     -1
    c3577     r3826     1
    c3578     r4489     -0.6103515625
    c3579     r3805     1
    c3579     r3845     -1
    c3580     r4507     -0.6103515625
    c3581     r3846     1
    c3581     r3849     -1
    c3582     r1361     -10000
    c3582     r2859     10000
    c3582     r4507     -0.6103515625
    c3583     r1361     1
    c3583     r3433     -1
    c3583     r3846     1
    c3584     r2860     10000
    c3584     r5021     -0.580420465087891
    c3584     r5308     -0.580420465087891
    c3585     r3850     -1
    c3585     r4268     1
    c3585     r4878     -0.0256
    c3585     r4895     -0.0016
    c3585     r5308     6.103515625e-05
    c3586     r4822     -0.580420465087891
    c3586     r6423     0.0385840515136719
    c3586     r6552     0.0659853474978786
    c3587     r3464     1
    c3587     r3854     -1
    c3587     r5135     -0.001953125
    c3588     r5099     -0.6103515625
    c3589     r3779     1
    c3589     r3867     -1
    c3590     r5224     -0.6103515625
    c3591     r3779     1
    c3591     r4156     -1
    c3591     r6962     0.03125
    c3592     r2864     10000
    c3592     r6358     0.513164731811523
    c3592     r6482     0.9203845483
    c3592     r6546     0.9203845483
    c3592     r6610     -0.0796155117000001
    c3592     r6667     -0.0796155117000001
    c3592     r6723     -0.0485934519653319
    c3592     r6741     -0.0527969045361538
    c3592     r6752     -0.0762939453125
    c3592     r6784     -0.0796155116999999
    c3592     r6792     0.561758110534668
    c3592     r6968     -0.0485934519653319
    c3592     r6972     -0.636924093599999
    c3592     r6983     0.8407689766
    c3593     r3869     1
    c3593     r4162     -1
    c3593     r5492     -0.03125
    c3593     r6022     0.03125
    c3593     r6358     6.103515625e-05
    c3593     r6588     6.103515625e-05
    c3593     r6594     6.103515625e-05
    c3593     r6610     0.0001
    c3593     r6667     0.0001
    c3593     r6741     6.63148467036154e-05
    c3593     r6752     9.58279909070786e-05
    c3593     r6968     6.103515625e-05
    c3593     r6972     0.0008
    c3594     r1367     -10000
    c3594     r4485     1
    c3595     r1367     1
    c3595     r3886     -1
    c3595     r3887     1
    c3596     r1368     -10000
    c3596     r5468     -0.6103515625
    c3597     r1368     1
    c3597     r3887     1
    c3597     r3889     -1
    c3598     r1369     -10000
    c3598     r4653     -0.6103515625
    c3598     r5395     0.6103515625
    c3599     r1369     1
    c3599     r3864     1
    c3599     r3888     -1
    c3599     r4734     6.103515625e-05
    c3600     r1370     -10000
    c3600     r5395     -0.6103515625
    c3601     r1370     1
    c3601     r3864     1
    c3601     r3887     -1
    c3601     r5468     -6.103515625e-05
    c3602     r1371     -10000
    c3603     r1371     1
    c3603     r3889     -1
    c3603     r4040     1
    c3604     Obj       0
    c3605     r3897     -1
    c3605     r3898     1
    c3606     Obj       0
    c3607     r3899     1
    c3607     r3905     -1
    c3608     r1374     -10000
    c3609     r1374     1
    c3609     r3902     -1
    c3609     r3904     1
    c3609     r4512     6.103515625e-05
    c3610     r6883     0.6103515625
    c3611     r3911     1
    c3611     r4027     -1
    c3612     r6086     -0.024039814527486
    c3613     r3911     1
    c3613     r3912     -1
    c3613     r5125     -0.03125
    c3614     r4837     -0.6103515625
    c3615     r3907     1
    c3615     r4056     -1
    c3616     r1378     -10000
    c3617     r1378     1
    c3617     r3863     -1
    c3617     r3907     1
    c3618     r6065     -0.567691466064453
    c3618     r6765     -0.0213300482177734
    c3618     r6883     -0.567691466064453
    c3619     r3910     1
    c3619     r4027     -1
    c3620     r5304     -0.30517578125
    c3620     r6927     -0.00476837158203125
    c3620     r7087     -0.0047683715820307
    c3621     r3983     -1
    c3621     r4091     1
    c3621     r4890     -0.03125
    c3621     r7010     -6.103515625e-05
    c3622     r6055     -0.510534374999992
    c3622     r6735     -0.6103515625
    c3623     r3921     -1
    c3623     r3922     1
    c3624     r6026     -0.7229375
    c3624     r6040     0.608939575195313
    c3625     r3927     1
    c3625     r4073     -1
    c3625     r6040     -6.103515625e-05
    c3626     r1383     -10000
    c3626     r6533     -0.6103515625
    c3626     r6633     -0.6103515625
    c3626     r6868     -0.98208965
    c3626     r7028     -0.599419952392578
    c3627     r1383     1
    c3627     r3879     -1
    c3627     r3953     1
    c3627     r6633     6.103515625e-05
    c3628     r1384     -10000
    c3628     r5893     -0.6103515625
    c3628     r6533     -0.6103515625
    c3628     r6633     -0.6103515625
    c3629     r1384     1
    c3629     r3940     -1
    c3629     r3953     1
    c3629     r5127     0.03125
    c3629     r5893     6.103515625e-05
    c3629     r6633     6.103515625e-05
    c3630     r6168     -0.6103515625
    c3630     r6535     -0.6103515625
    c3631     r3878     -1
    c3631     r3953     1
    c3631     r6168     6.103515625e-05
    c3632     r2884     10000
    c3632     r4686     -1
    c3632     r6510     -1
    c3632     r6548     -0.0129193017578125
    c3632     r6579     -0.826835312500002
    c3632     r6959     -0.826835312500002
    c3632     r6973     -0.0131986779630783
    c3632     r6974     0.00513545130684046
    c3632     r6975     0.00025680108697379
    c3632     r7012     0.597432260742188
    c3632     r7070     0.00509260253906252
    c3633     r3951     -1
    c3633     r4030     1
    c3633     r6581     -0.03125
    c3633     r6959     0.00390625
    c3633     r6973     6.23550240463078e-05
    c3633     r6975     6.10094761413026e-05
    c3634     r5759     -0.6103515625
    c3634     r6533     -0.6103515625
    c3634     r7029     -0.00476837158203125
    c3635     r3878     1
    c3635     r4090     -1
    c3636     r5631     -0.0138745697021485
    c3636     r6456     -1
    c3636     r6495     -0.0112021911621094
    c3637     r3995     -1
    c3637     r3996     1
    c3637     r5294     6.103515625e-05
    c3637     r6364     0.03125
    c3637     r6369     0.00390625
    c3637     r6495     6.103515625e-05
    c3637     r6521     0.0001220703125
    c3637     r6807     5.7205257543362e-05
    c3637     r6979     6.103515625e-05
    c3638     r1389     -10000
    c3638     r6410     -0.6103515625
    c3638     r6485     -0.275133243143365
    c3638     r6542     -0.30517578125
    c3638     r6761     -0.320194970703125
    c3638     r6803     0.160097485351562
    c3639     r1389     1
    c3639     r3997     1
    c3639     r4046     -1
    c3639     r4529     -0.03125
    c3639     r5985     6.103515625e-05
    c3640     r1390     -10000
    c3641     r1390     1
    c3641     r3984     -1
    c3641     r4099     1
    c3642     r6477     0.561758147155762
    c3642     r6582     -1
    c3642     r6760     -0.636924093599999
    c3643     r4123     -1
    c3643     r4125     1
    c3643     r5138     -0.03125
    c3643     r6575     0.03125
    c3643     r6667     -0.0001
    c3643     r6760     0.0008
    c3643     r6963     0.03125
    c3643     r6972     -0.0008
    c3644     r5633     0.92002495
    c3644     r6856     -1
    c3644     r6937     0.913072955249746
    c3645     r4124     -1
    c3645     r4126     1
    c3645     r5170     0.0008
    c3645     r5918     0.0009765625
    c3645     r6937     0.000108692704475025
    c3646     r5073     -0.629882981875534
    c3646     r6492     -0.0385840515136718
    c3646     r6556     -0.0381419799246557
    c3646     r6587     -0.603848419189453
    c3646     r6692     -0.783571103003263
    c3646     r6755     -0.160455971745828
    c3646     r6929     -0.51541002549239
    c3646     r6998     -0.783571103003263
    c3647     r4186     1
    c3647     r4232     -1
    c3647     r5132     -0.0078125
    c3647     r6139     -6.103515625e-05
    c3648     r6346     -0.0625
    c3648     r6422     -0.0632161099999999
    c3648     r6423     -0.0385840515136719
    c3648     r6431     -0.0722513388847585
    c3648     r6492     -0.0385840515136718
    c3648     r6552     -0.0659853474978786
    c3648     r6556     -0.0381419799246557
    c3648     r6587     0.00650314331054691
    c3648     r6692     -0.0625
    c3648     r6700     -0.0385534191131592
    c3648     r6755     -0.0534853239152761
    c3648     r6824     -0.0385840515136718
    c3648     r6998     -0.0625
    c3649     r3858     -1
    c3649     r4186     1
    c3650     r1395     -10000
    c3650     r6541     -0.320194970703125
    c3651     r1395     1
    c3651     r3267     1
    c3651     r4228     -1
    c3651     r5576     -0.03125
    c3651     r6632     -8.27375139400187e-05
    c3652     r4650     -0.6103515625
    c3652     r5617     -0.6103515625
    c3653     r4218     1
    c3653     r4225     -1
    c3653     r4752     -0.03125
    c3654     r1397     -10000
    c3654     r5463     0.590881044555664
    c3654     r6011     -0.0184650326423645
    c3654     r6900     -0.0389410358886718
    c3655     r1397     1
    c3655     r4239     1
    c3655     r4275     -1
    c3655     r4471     6.103515625e-05
    c3656     r5349     0.807468796875
    c3656     r6361     -0.0290790003662109
    c3656     r6391     -0.6103515625
    c3656     r6461     -0.6103515625
    c3656     r6531     -0.781255398437494
    c3656     r6682     -0.52734375
    c3656     r7021     -1
    c3657     r3046     1
    c3657     r3647     -1
    c3657     r6361     6.103515625e-05
    c3657     r6531     0.00390625
    c3657     r6651     -0.03125
    c3657     r6658     -6.103515625e-05
    c3657     r6717     -6.103515625e-05
    c3657     r6754     -6.103515625e-05
    c3657     r7021     0.0001
    c3658     r1399     -10000
    c3658     r7049     -0.711705003972637
    c3659     r1399     1
    c3659     r3005     1
    c3659     r3235     -1
    c3660     r1400     -10000
    c3660     r6757     -0.813106203124999
    c3661     r1400     1
    c3661     r2998     -1
    c3661     r2999     1
    c3662     r5565     0.578749843200684
    c3662     r5904     -0.0121312013549805
    c3662     r6716     -0.87478360546875
    c3662     r6727     0.0121312013549804
    c3663     r3021     -1
    c3663     r3031     1
    c3663     r5565     -6.103515625e-05
    c3663     r5904     6.103515625e-05
    c3664     r5627     -0.851925213867188
    c3664     r5814     -0.59822036114502
    c3664     r5999     -0.0121312013549804
    c3664     r7002     -0.6978971352
    c3665     r3031     1
    c3665     r3249     -1
    c3665     r5049     -0.03125
    c3665     r6806     -6.103515625e-05
    c3666     r1403     -10000
    c3666     r2901     10000
    c3666     r5097     0.0201121040512414
    c3666     r5565     0.0316017192993163
    c3666     r5904     0.0316017192993163
    c3666     r6268     -0.578749843200684
    c3666     r6498     -0.578749843200684
    c3666     r6555     -0.940562071770509
    c3666     r6857     -0.578749843200684
    c3666     r6900     0.0194705179443359
    c3667     r1403     1
    c3667     r3014     1
    c3667     r3195     -1
    c3667     r4482     6.103515625e-05
    c3667     r5565     6.103515625e-05
    c3667     r6268     6.103515625e-05
    c3667     r6498     6.103515625e-05
    c3667     r6555     9.59635558098634e-05
    c3667     r6707     0.03125
    c3667     r6857     6.103515625e-05
    c3668     r5369     -0.94402437119993
    c3668     r5507     0.52734375
    c3668     r5706     0.0114639945652174
    c3668     r6149     -0.645302300639882
    c3668     r6479     0.52734375
    c3668     r6549     0.683639014225297
    c3668     r6694     0.52734375
    c3668     r7078     0.00143299932065217
    c3669     r3178     1
    c3669     r3200     -1
    c3669     r5582     -1
    c3669     r6479     -0.00390625
    c3669     r6694     -0.00390625
    c3670     r2903     10000
    c3670     r6182     -0.7177734375
    c3670     r6852     0.60211181640625
    c3671     r3201     -1
    c3671     r3202     1
    c3671     r4701     -0.03125
    c3672     r5570     -0.6103515625
    c3672     r6912     -0.6103515625
    c3673     r3203     -1
    c3673     r3204     1
    c3674     r5136     -0.747082035475351
    c3674     r5367     0.995257037330941
    c3674     r5894     0.533573770882267
    c3674     r6523     0.303843953124994
    c3674     r6670     0.283274289361644
    c3674     r6693     0.00474756176757799
    c3674     r6877     0.00474756176757799
    c3674     r6948     0.00285224548979076
    c3674     r6969     0.303843953124994
    c3674     r7015     0.00721200108212183
    c3674     r7021     0.00777840519999979
    c3674     r7047     0.00474756176757802
    c3674     r7064     -0.00695472883667025
    c3675     r3059     -1
    c3675     r3207     1
    c3675     r6670     0.00364180422693394
    c3675     r7015     9.27182487500392e-05
    c3676     r5405     -0.6103515625
    c3677     r3208     -1
    c3677     r3209     1
    c3678     r4450     -0.893246906250034
    c3679     r3210     -1
    c3679     r3211     1
    c3680     r6857     -0.515546404602051
    c3681     r3019     1
    c3681     r3213     -1
    c3681     r4707     -0.03125
    c3682     r5463     -0.019470517944336
    c3683     r3213     -1
    c3683     r3215     1
    c3683     r6011     -5.78832137753131e-05
    c3683     r6474     -6.103515625e-05
    c3684     r5627     -0.851925213867188
    c3684     r7002     -0.6978971352
    c3685     r3238     1
    c3685     r3239     -1
    c3686     r5319     0.576873779296875
    c3686     r6537     -0.6103515625
    c3686     r6636     -0.6103515625
    c3686     r6841     -0.576873779296875
    c3686     r6844     0.576873779296875
    c3686     r6882     -0.6103515625
    c3686     r7016     -0.54339599609375
    c3687     r3255     1
    c3687     r3256     -1
    c3687     r5319     6.103515625e-05
    c3688     r1414     -10000
    c3688     r2912     10000
    c3689     r1414     1
    c3689     r3289     -1
    c3689     r3290     1
    c3690     r2913     10000
    c3691     r3297     -1
    c3691     r3298     1
    c3692     r2914     10000
    c3692     r4648     -0.6103515625
    c3693     r3307     -1
    c3693     r3308     1
    c3694     r2915     10000
    c3694     r4780     -0.6103515625
    c3695     r3406     1
    c3695     r4148     -1
    c3696     r2916     10000
    c3696     r5309     0.558511798095703
    c3696     r5550     -0.0476409375862978
    c3696     r7035     0.501368087559006
    c3697     r3405     -1
    c3697     r3406     1
    c3697     r5119     -0.03125
    c3697     r5550     6.61530201248938e-05
    c3697     r7035     6.72799219169098e-05
    c3698     r1419     -10000
    c3698     r2917     10000
    c3699     r1419     1
    c3699     r3432     1
    c3699     r3844     -1
    c3699     r4948     0.03125
    c3700     r1420     -10000
    c3700     r2918     10000
    c3701     r1420     1
    c3701     r3434     1
    c3701     r3798     -1
    c3702     r2919     10000
    c3702     r4941     -0.604008178710937
    c3702     r5322     0.0095367431640625
    c3702     r6387     0.0095367431640625
    c3702     r6430     0.588509265737728
    c3703     r3443     -1
    c3703     r3444     1
    c3703     r4708     -0.03125
    c3703     r6362     0.03125
    c3703     r6430     -6.04134265737728e-05
    c3704     r2920     10000
    c3704     r6886     -0.930105698
    c3705     r3445     -1
    c3705     r3446     1
    c3706     r2921     10000
    c3706     r6848     -0.545780865745698
    c3707     r3446     1
    c3707     r4047     -1
    c3707     r4519     0.03125
    c3707     r6675     -6.103515625e-05
    c3707     r6736     -6.103515625e-05
    c3708     r2922     10000
    c3708     r5245     -0.605158033935547
    c3708     r6168     0.6103515625
    c3709     r3484     1
    c3709     r3491     -1
    c3709     r5245     6.103515625e-05
    c3709     r6168     6.103515625e-05
    c3709     r6846     6.103515625e-05
    c3710     r2923     10000
    c3710     r4453     -0.813093734375002
    c3711     r3485     -1
    c3711     r3731     1
    c3712     r2924     10000
    c3712     r4759     -0.6103515625
    c3712     r6846     -0.0051935285644531
    c3713     r3493     1
    c3713     r4090     -1
    c3713     r6168     6.103515625e-05
    c3713     r6846     6.103515625e-05
    c3714     r1427     -10000
    c3714     r2925     10000
    c3715     r1427     1
    c3715     r3725     -1
    c3715     r3726     1
    c3715     r4689     6.103515625e-05
    c3716     r1428     -10000
    c3716     r2926     10000
    c3717     r1428     1
    c3717     r3727     -1
    c3717     r3728     1
    c3718     r2927     10000
    c3718     r4456     -0.364221250000014
    c3719     r3733     -1
    c3719     r3734     1
    c3720     r2928     10000
    c3720     r5352     -0.6103515625
    c3721     r3737     -1
    c3721     r4251     1
    c3722     r2929     10000
    c3722     r4637     -0.6103515625
    c3723     r3738     -1
    c3723     r3739     1
    c3724     r1432     -10000
    c3724     r2930     10000
    c3724     r5002     -0.6103515625
    c3724     r5601     -0.6103515625
    c3725     r1432     1
    c3725     r3740     -1
    c3725     r3741     1
    c3725     r4578     6.103515625e-05
    c3725     r5002     6.103515625e-05
    c3726     r1433     -10000
    c3726     r2931     10000
    c3726     r6195     0.125
    c3727     r1433     1
    c3727     r3742     -1
    c3727     r3743     1
    c3728     r2932     10000
    c3728     r5353     -0.6103515625
    c3729     r3745     -1
    c3729     r3746     1
    c3729     r4713     0.03125
    c3730     r2933     10000
    c3730     r4797     -0.6103515625
    c3731     r3751     1
    c3731     r3761     -1
    c3732     r2934     10000
    c3732     r6162     0.0799750499999998
    c3732     r6432     -0.6103515625
    c3732     r6840     -0.550627276611328
    c3732     r7035     -0.444224377022308
    c3733     r3789     1
    c3733     r4184     -1
    c3733     r5120     -0.03125
    c3733     r6432     6.103515625e-05
    c3734     r1437     -10000
    c3734     r2935     10000
    c3734     r5861     -0.65114087500001
    c3734     r6051     -0.65114087500001
    c3734     r7066     -0.65114087500001
    c3734     r7071     -0.00127175952148439
    c3735     r1437     1
    c3735     r3829     -1
    c3735     r3830     1
    c3736     r1438     -10000
    c3736     r2936     10000
    c3736     r6138     -1
    c3737     r1438     1
    c3737     r3831     -1
    c3737     r3832     1
    c3738     r2937     10000
    c3738     r5214     -0.6103515625
    c3739     r3836     1
    c3739     r3837     -1
    c3740     r4734     -0.6103515625
    c3741     r3864     -1
    c3741     r3865     1
    c3742     r6307     -0.573131199999999
    c3742     r6868     -1
    c3743     r3486     -1
    c3743     r3879     1
    c3743     r5285     -6.103515625e-05
    c3743     r6193     -0.03125
    c3743     r6307     0.0032
    c3743     r6868     0.0001
    c3744     r5583     -0.29232812500004
    c3745     r3880     1
    c3745     r3909     -1
    c3746     r2941     10000
    c3746     r5909     -0.0213300482177734
    c3746     r6065     0.6103515625
    c3746     r6086     0.12019907263743
    c3746     r6436     0.6103515625
    c3746     r6437     0.0853201928710937
    c3746     r6883     0.589021514282227
    c3747     r3842     1
    c3747     r3911     -1
    c3747     r5051     -0.03125
    c3747     r5122     0.03125
    c3747     r6065     -6.103515625e-05
    c3747     r6436     -6.103515625e-05
    c3748     r5216     -0.6103515625
    c3748     r6660     -0.6103515625
    c3749     r3915     -1
    c3749     r3916     1
    c3750     r4646     -0.6103515625
    c3751     r3271     -1
    c3751     r4051     1
    c3751     r5217     -6.103515625e-05
    c3751     r6665     -6.103515625e-05
    c3752     r5699     -0.526150000000143
    c3753     r3924     -1
    c3753     r3925     1
    c3753     r5699     0.0625
    c3754     r5248     0.6103515625
    c3754     r5646     0.600562044311523
    c3754     r5731     0.0229535292968752
    c3755     r3934     -1
    c3755     r3935     1
    c3755     r5646     -6.103515625e-05
    c3755     r5731     -6.103515625e-05
    c3756     Obj       0
    c3757     r3464     -1
    c3757     r3938     1
    c3758     r4822     -0.0299310974121094
    c3759     r3937     -1
    c3759     r3938     1
    c3759     r4823     6.103515625e-05
    c3759     r4919     6.103515625e-05
    c3759     r5092     6.103515625e-05
    c3759     r5165     6.103515625e-05
    c3759     r5990     6.103515625e-05
    c3759     r6010     6.103515625e-05
    c3759     r6083     6.103515625e-05
    c3759     r6109     0.001953125
    c3759     r6131     6.103515625e-05
    c3759     r6423     6.103515625e-05
    c3759     r6552     0.000104380588267577
    c3759     r6700     6.09866996136888e-05
    c3759     r6929     5.15410025492391e-05
    c3760     r1450     -10000
    c3761     r1450     1
    c3761     r3948     -1
    c3761     r3949     1
    c3762     r4686     -1
    c3763     r3950     -1
    c3763     r4190     1
    c3764     r1452     -10000
    c3764     r6922     0.609911517333984
    c3765     r1452     1
    c3765     r3994     1
    c3765     r4261     -1
    c3766     r6036     -0.6103515625
    c3766     r6464     -0.609594970703125
    c3767     r3800     1
    c3767     r4050     -1
    c3767     r5343     -0.03125
    c3767     r5494     0.03125
    c3767     r6104     -0.03125
    c3768     r1454     -10000
    c3768     r6055     0.510534374999992
    c3768     r6526     0.510534374999992
    c3768     r6603     0.510534374999992
    c3768     r6734     -0.6103515625
    c3768     r7046     -0.608399104614258
    c3769     r1454     1
    c3769     r4048     -1
    c3769     r4049     1
    c3770     r4467     -1
    c3771     r3393     -1
    c3771     r3394     1
    c3772     r1456     -10000
    c3773     r1456     1
    c3773     r3411     -1
    c3773     r3763     1
    c3774     r1457     -10000
    c3774     r4917     0.6103515625
    c3774     r5011     -0.6103515625
    c3774     r5017     0.6103515625
    c3774     r5449     0.6103515625
    c3775     r1457     1
    c3775     r3415     -1
    c3775     r3416     1
    c3776     r1458     -10000
    c3776     r4736     -0.6103515625
    c3776     r4782     -0.6103515625
    c3776     r7038     -0.6103515625
    c3777     r1458     1
    c3777     r3756     -1
    c3777     r3757     1
    c3778     r4491     -1
    c3779     r3758     -1
    c3779     r3759     1
    c3780     r1460     -10000
    c3781     r1460     1
    c3781     r3312     1
    c3781     r3760     -1
    c3782     r5082     -0.6103515625
    c3782     r5442     -0.6103515625
    c3783     r3761     -1
    c3783     r4207     1
    c3783     r5442     6.103515625e-05
    c3784     r4481     -0.6103515625
    c3785     r3765     1
    c3785     r3766     -1
    c3785     r4514     -0.0256
    c3786     r5540     -0.6103515625
    c3786     r6343     0.0625000000000001
    c3786     r6582     -1
    c3786     r6657     -1
    c3787     r3769     1
    c3787     r3770     -1
    c3787     r6569     -0.03125
    c3787     r6956     -0.03125
    c3787     r6968     -6.103515625e-05
    c3788     r6791     -0.6103515625
    c3788     r6835     -0.0632243848999998
    c3789     r3773     1
    c3789     r4254     -1
    c3789     r6835     0.0001
    c3790     r5633     -0.0799750499999998
    c3790     r5948     -0.6103515625
    c3790     r6432     -0.6103515625
    c3790     r7001     -0.561538665771484
    c3791     r3775     1
    c3791     r3776     -1
    c3792     r1466     -10000
    c3793     r1466     1
    c3793     r3808     -1
    c3793     r3855     1
    c3794     r1467     -10000
    c3795     r1467     1
    c3795     r3259     -1
    c3795     r3790     1
    c3795     r4773     0.03125
    c3795     r5045     0.03125
    c3796     r1468     -10000
    c3797     r1468     1
    c3797     r3856     1
    c3797     r3857     -1
    c3798     r4478     -0.6103515625
    c3799     r3428     1
    c3799     r3494     -1
    c3799     r5338     -0.03125
    c3800     Obj       0
    c3801     r3490     -1
    c3801     r3875     1
    c3802     r1471     -10000
    c3802     r5085     -0.6103515625
    c3802     r6360     -0.0138745697021485
    c3803     r1471     1
    c3803     r4053     -1
    c3803     r4054     1
    c3803     r6350     -6.103515625e-05
    c3803     r6822     6.103515625e-05
    c3804     r5097     -0.0201121040512414
    c3804     r6347     0.0121312013549804
    c3804     r6442     -0.6103515625
    c3804     r6806     -0.59822036114502
    c3804     r6900     -0.0194705179443359
    c3805     r3021     1
    c3805     r3022     -1
    c3805     r4881     0.03125
    c3805     r5097     6.30463666551241e-05
    c3805     r5814     -6.103515625e-05
    c3805     r5999     -6.103515625e-05
    c3805     r6900     6.103515625e-05
    c3805     r6905     -6.103515625e-05
    c3806     Obj       0
    c3807     r3023     -1
    c3807     r3024     1
    c3808     r1474     -10000
    c3808     r4494     -0.999986492
    c3808     r6530     -0.6103515625
    c3808     r7038     -0.6103515625
    c3809     r1474     1
    c3809     r3214     1
    c3809     r3215     -1
    c3810     r1475     -10000
    c3810     r6411     -0.320194970703125
    c3811     r1475     1
    c3811     r3264     1
    c3811     r3790     -1
    c3812     r1476     -10000
    c3813     r1476     1
    c3813     r3282     1
    c3813     r3290     -1
    c3814     r1477     -10000
    c3814     r6174     0.0738708599999996
    c3814     r6440     -0.0625
    c3814     r6493     -0.05788307125
    c3814     r6552     -0.0659853474978786
    c3814     r6591     -0.6103515625
    c3814     r6700     -0.0706088578492288
    c3814     r6824     -0.0706649597167966
    c3815     r1477     1
    c3815     r3428     -1
    c3815     r3429     1
    c3815     r4478     6.103515625e-05
    c3815     r6552     0.000104380588267577
    c3815     r6700     6.09866996136888e-05
    c3815     r6824     6.103515625e-05
    c3816     r1478     -10000
    c3817     r1478     1
    c3817     r3357     1
    c3817     r3492     -1
    c3818     r4729     -0.6103515625
    c3819     r3493     -1
    c3819     r3749     1
    c3819     r4759     6.103515625e-05
    c3820     r1480     -10000
    c3821     r1480     1
    c3821     r3500     -1
    c3821     r3502     1
    c3822     r4490     -1
    c3822     r6933     -0.998609163
    c3823     r3504     1
    c3823     r3722     -1
    c3824     r5617     -0.6103515625
    c3824     r6070     -0.6103515625
    c3825     r3505     -1
    c3825     r3758     1
    c3826     r1483     -10000
    c3826     r5378     -0.6103515625
    c3827     r1483     1
    c3827     r3506     1
    c3827     r3729     -1
    c3827     r5378     6.103515625e-05
    c3828     r4783     -0.6103515625
    c3829     r3730     -1
    c3829     r3756     1
    c3829     r6417     -6.103515625e-05
    c3829     r6742     -6.103515625e-05
    c3830     r1485     -10000
    c3831     r1485     1
    c3831     r3766     1
    c3831     r4233     -1
    c3831     r4481     6.103515625e-05
    c3832     r5015     -1
    c3832     r5980     -0.9428095483
    c3832     r6093     -0.841503477570771
    c3832     r6344     0.8739500366
    c3832     r6494     0.505632644592285
    c3832     r6676     -0.9428095483
    c3832     r6748     0.43542282577821
    c3832     r6811     -0.9428095483
    c3833     r3765     -1
    c3833     r3768     1
    c3834     r6358     -0.6103515625
    c3834     r6546     -0.8407690966
    c3834     r6610     -0.9203844883
    c3835     r3769     -1
    c3835     r4185     1
    c3835     r6358     6.103515625e-05
    c3835     r6569     0.03125
    c3836     r5725     -0.6103515625
    c3836     r6358     0.0485934153442386
    c3836     r6690     -0.6103515625
    c3837     r3770     1
    c3837     r4253     -1
    c3837     r6956     0.03125
    c3838     r2987     10000
    c3838     r6692     0.0625
    c3838     r6755     0.0534853239152761
    c3838     r6835     -1
    c3838     r6992     0.6103515625
    c3839     r3771     -1
    c3839     r3772     1
    c3840     r5537     -0.6103515625
    c3840     r6252     -0.6103515625
    c3840     r6931     -0.561538665771484
    c3841     r3776     1
    c3841     r4255     -1
    c3841     r5948     6.103515625e-05
    c3841     r6432     -6.103515625e-05
    c3842     r6343     -0.66002349312175
    c3842     r6481     -0.882030785273931
    c3842     r6539     -0.918598114750176
    c3842     r6610     1
    c3843     r3780     -1
    c3843     r4253     1
    c3843     r6481     9.58328545283696e-05
    c3844     r1492     -10000
    c3844     r4831     0.92002495
    c3844     r4932     0.92002495
    c3844     r5693     -0.92002495
    c3844     r6162     -0.0799750499999998
    c3844     r6931     -0.0488128967285155
    c3844     r6937     1
    c3844     r6996     -0.0762939453125
    c3844     r7001     -0.6103515625
    c3844     r7024     0.561538665771484
    c3845     r1492     1
    c3845     r3777     -1
    c3845     r3788     1
    c3845     r5170     0.0008
    c3845     r5537     6.103515625e-05
    c3845     r5637     0.0001
    c3845     r5693     0.0001
    c3845     r5918     0.0009765625
    c3845     r6252     6.103515625e-05
    c3845     r6432     6.103515625e-05
    c3845     r6931     6.103515625e-05
    c3845     r6996     9.53971836372719e-05
    c3845     r7001     6.103515625e-05
    c3846     r1493     -10000
    c3847     r1493     1
    c3847     r3368     -1
    c3847     r3814     1
    c3848     r1494     -10000
    c3848     r4512     -0.6103515625
    c3849     r1494     1
    c3849     r3904     -1
    c3849     r3906     1
    c3850     r4838     -0.6103515625
    c3851     r3862     -1
    c3851     r4056     1
    c3852     r1496     -10000
    c3852     r6884     0.599220592829948
    c3852     r7041     0.588488342285156
    c3853     r1496     1
    c3853     r3877     1
    c3853     r3939     -1
    c3853     r6884     6.21482532170052e-05
    c3854     r4586     -0.6103515625
    c3855     r3874     -1
    c3855     r3882     1
    c3855     r4762     6.103515625e-05
    c3855     r4802     6.103515625e-05
    c3855     r5203     0.03125
    c3855     r6168     6.103515625e-05
    c3855     r6533     6.103515625e-05
    c3856     r3019     1
    c3856     r3020     -1
    c3856     r4371     -0.03125
    c3856     r6011     5.78832137753131e-05
    c3856     r6714     0.001953125
    c3856     r6900     -6.103515625e-05
    c3857     r3014     1
    c3857     r3022     -1
    c3857     r6442     -6.103515625e-05
    c3857     r6706     -0.03125
    c3857     r6716     -0.00390625
    c3857     r6727     -6.103515625e-05
    c3858     r3037     -1
    c3858     r3047     1
    c3859     r3037     -1
    c3859     r3039     1
    c3859     r5032     -0.0064
    c3860     r1512     1
    c3860     r3030     -1
    c3860     r3036     1
    c3860     r4847     -0.0078125
    c3860     r5032     0.0064
    c3861     r1515     1
    c3861     r3034     -1
    c3861     r3036     1
    c3861     r4313     -0.03125
    c3861     r4847     0.0078125
    c3861     r5032     0.0064
    c3862     r3038     -1
    c3862     r3234     1
    c3863     r1519     1
    c3863     r3033     1
    c3863     r3036     -1
    c3863     r4631     -0.0064
    c3863     r4847     -0.0078125
    c3864     r3245     1
    c3864     r3248     -1
    c3864     r4296     -0.03125
    c3864     r5020     6.103515625e-05
    c3864     r5087     -0.0009765625
    c3864     r6529     6.103515625e-05
    c3864     r6793     -6.103515625e-05
    c3865     r3214     1
    c3865     r3249     -1
    c3865     r4556     -0.03125
    c3866     r3044     -1
    c3866     r3199     1
    c3866     r4436     -0.0256
    c3866     r4612     0.03125
    c3866     r6918     6.103515625e-05
    c3867     r3141     1
    c3867     r3143     -1
    c3867     r4330     -0.0256
    c3868     r3142     1
    c3868     r3144     -1
    c3868     r4323     -0.03125
    c3869     r3163     1
    c3869     r3172     -1
    c3869     r4292     -0.0256
    c3870     r3162     1
    c3870     r3164     -1
    c3870     r4293     -0.03125
    c3871     r3168     1
    c3871     r3170     -1
    c3871     r4291     -0.03125
    c3872     r3169     1
    c3872     r3171     -1
    c3872     r4352     -0.0256
    c3873     r3184     -1
    c3873     r3646     1
    c3873     r4290     -0.0256
    c3873     r6774     0.03125
    c3874     r1699     1
    c3874     r3198     -1
    c3874     r3625     1
    c3874     r4518     -0.03125
    c3874     r4639     6.103515625e-05
    c3875     r2996     -1
    c3875     r2998     1
    c3875     r5906     -6.103515625e-05
    c3875     r7049     -0.000488357173027066
    c3876     r3237     -1
    c3876     r3238     1
    c3876     r6081     -8.16584644176811e-05
    c3876     r6413     -6.103515625e-05
    c3876     r7006     -6.103515625e-05
    c3877     r1732     1
    c3877     r3226     1
    c3877     r4220     -1
    c3878     r3252     -1
    c3878     r3255     1
    c3878     r5640     -6.103515625e-05
    c3879     r3871     1
    c3879     r4228     -1
    c3880     r3271     -1
    c3880     r3916     1
    c3880     r4646     -6.103515625e-05
    c3880     r6665     6.103515625e-05
    c3881     r3294     1
    c3881     r3295     -1
    c3881     r4738     -6.103515625e-05
    c3882     r3313     -1
    c3882     r3320     1
    c3882     r5418     -0.03125
    c3882     r5574     0.03125
    c3883     r3313     -1
    c3883     r3328     1
    c3884     r3317     1
    c3884     r3319     -1
    c3884     r4951     -0.03125
    c3885     r3397     1
    c3885     r3398     -1
    c3885     r4590     -6.103515625e-05
    c3885     r4887     0.03125
    c3886     r3412     1
    c3886     r3414     -1
    c3886     r4749     -0.03125
    c3886     r5017     -6.103515625e-05
    c3887     r3421     -1
    c3887     r4265     1
    c3887     r6823     6.103515625e-05
    c3888     r3381     -1
    c3888     r3384     1
    c3888     r5055     -0.00390625
    c3888     r6349     6.103515625e-05
    c3888     r7048     0.000105419978435289
    c3889     r3431     -1
    c3889     r3849     1
    c3889     r4424     -0.03125
    c3889     r4543     -0.03125
    c3890     r3431     -1
    c3890     r3433     1
    c3890     r4424     -0.03125
    c3891     r3438     -1
    c3891     r3439     1
    c3891     r4497     -6.103515625e-05
    c3891     r4976     -0.0009765625
    c3891     r4992     -6.103515625e-05
    c3892     r3439     -1
    c3892     r3441     1
    c3892     r5473     -5.84042810005303e-05
    c3893     r3465     -1
    c3893     r4151     1
    c3894     r3945     1
    c3894     r4196     -1
    c3894     r4830     -0.0001
    c3894     r6174     -0.0001
    c3894     r6261     -9.31210667174636e-05
    c3894     r6346     -9.88672033125734e-05
    c3894     r6423     -6.103515625e-05
    c3894     r6431     -0.000114292604978001
    c3894     r6440     -7.39420869012366e-05
    c3894     r6493     -7.83571103003273e-05
    c3894     r6552     -0.000104380588267577
    c3894     r6700     -6.09866996136888e-05
    c3894     r6824     -6.103515625e-05
    c3894     r6835     -0.0001
    c3894     r6929     -5.15410025492391e-05
    c3895     r3457     -1
    c3895     r3463     1
    c3895     r6423     -6.103515625e-05
    c3895     r6440     -7.39420869012366e-05
    c3895     r6552     -0.000104380588267577
    c3895     r6700     -6.09866996136888e-05
    c3896     r1830     1
    c3896     r3469     1
    c3896     r3471     -1
    c3896     r6648     -0.0256
    c3896     r6676     -0.0001
    c3896     r6712     -0.03125
    c3897     r3467     1
    c3897     r3473     -1
    c3897     r4406     -0.03125
    c3898     r3619     1
    c3898     r3633     -1
    c3898     r4343     -0.0256
    c3899     r3590     1
    c3899     r3601     -1
    c3899     r4305     -0.0256
    c3899     r4709     -0.0256
    c3899     r5652     0.03125
    c3900     r3515     1
    c3900     r3516     -1
    c3900     r4349     -0.0256
    c3901     r3744     1
    c3901     r4252     -1
    c3901     r6949     -0.03125
    c3901     r6964     -0.0625
    c3901     r6965     -0.0625
    c3902     r3735     1
    c3902     r3736     -1
    c3902     r4376     -0.03125
    c3903     r1961     1
    c3903     r3592     1
    c3903     r3604     -1
    c3903     r4289     -0.03125
    c3904     r3559     1
    c3904     r3608     -1
    c3904     r4370     -0.03125
    c3904     r5601     6.103515625e-05
    c3904     r5687     -6.103515625e-05
    c3905     r3620     1
    c3905     r3634     -1
    c3905     r4347     -0.03125
    c3906     r3621     1
    c3906     r3635     -1
    c3906     r4351     -0.0256
    c3907     r3622     1
    c3907     r3636     -1
    c3907     r4345     -0.03125
    c3908     r3623     1
    c3908     r3637     -1
    c3908     r4344     -0.03125
    c3909     r3624     1
    c3909     r3638     -1
    c3909     r4342     -0.03125
    c3910     r3631     1
    c3910     r3640     -1
    c3910     r4332     -0.03125
    c3911     r3629     1
    c3911     r3650     -1
    c3911     r4335     -0.03125
    c3912     r3626     1
    c3912     r3666     -1
    c3912     r4314     -0.03125
    c3913     r3326     1
    c3913     r3327     -1
    c3913     r5329     -6.103515625e-05
    c3914     r3750     1
    c3914     r3752     -1
    c3914     r4885     -0.03125
    c3915     r3750     1
    c3915     r3753     -1
    c3915     r4757     -0.0078125
    c3915     r4885     -0.03125
    c3916     r3752     1
    c3916     r3753     -1
    c3916     r4757     -0.0078125
    c3916     r5321     -6.103515625e-05
    c3917     r3761     -1
    c3917     r3836     1
    c3917     r4889     -0.03125
    c3917     r5083     -6.103515625e-05
    c3917     r5291     -6.103515625e-05
    c3918     r2108     1
    c3918     r3767     -1
    c3918     r4140     1
    c3918     r4312     -0.03125
    c3918     r5795     0.0001
    c3918     r6164     0.000114423017120107
    c3918     r6265     0.000109283976856577
    c3918     r6344     0.0001
    c3918     r6420     8.77414092738715e-05
    c3918     r6545     0.000118429033183437
    c3918     r6679     0.00010823311630947
    c3918     r6800     0.000109283976856577
    c3918     r6997     7.2685628046759e-05
    c3919     r3781     -1
    c3919     r4122     1
    c3919     r4667     0.03125
    c3919     r5007     6.103515625e-05
    c3919     r5129     0.03125
    c3919     r5204     0.03125
    c3919     r5399     6.103515625e-05
    c3919     r6976     6.103515625e-05
    c3920     r2116     1
    c3920     r3787     -1
    c3920     r4131     1
    c3920     r4319     -0.03125
    c3920     r5633     0.0001
    c3920     r5693     0.0001
    c3921     r3793     1
    c3921     r3794     -1
    c3921     r4311     -0.0256
    c3921     r4541     0.03125
    c3921     r6308     0.000244140625
    c3921     r6411     0.0001220703125
    c3921     r6632     8.27375139400187e-05
    c3922     r3405     1
    c3922     r3796     -1
    c3922     r4369     -0.03125
    c3922     r4606     0.03125
    c3923     r3797     1
    c3923     r3799     -1
    c3924     r3798     -1
    c3924     r3833     1
    c3924     r5425     -0.03125
    c3925     r3798     -1
    c3925     r3844     1
    c3925     r4906     -6.103515625e-05
    c3925     r4986     6.103515625e-05
    c3926     r3941     -1
    c3926     r4282     1
    c3926     r5383     -0.0001220703125
    c3926     r6441     -6.103515625e-05
    c3926     r6761     -0.0001220703125
    c3926     r6803     -6.103515625e-05
    c3927     r3274     1
    c3927     r4230     -1
    c3927     r4706     -0.03125
    c3927     r5000     6.103515625e-05
    c3927     r5098     0.001953125
    c3927     r5603     -0.001953125
    c3927     r6638     -6.36421271115382e-05
    c3927     r6756     6.103515625e-05
    c3927     r6790     0.001953125
    c3927     r6906     -0.001953125
    c3928     r3276     1
    c3928     r4230     -1
    c3928     r4724     -0.001953125
    c3928     r6638     -6.36421271115382e-05
    c3928     r6810     -6.36421271115382e-05
    c3928     r7017     -6.36421271115382e-05
    c3929     r2139     1
    c3929     r3837     1
    c3929     r4115     -1
    c3929     r4765     -0.0256
    c3929     r5214     6.103515625e-05
    c3929     r5436     6.103515625e-05
    c3929     r5519     -0.0256
    c3929     r5598     -0.0256
    c3930     r3332     -1
    c3930     r3344     1
    c3930     r4498     -6.103515625e-05
    c3930     r5148     -6.103515625e-05
    c3930     r6489     -6.103515625e-05
    c3931     r3891     1
    c3931     r3894     -1
    c3931     r4388     -0.03125
    c3932     r3896     -1
    c3932     r3903     1
    c3932     r4320     -0.03125
    c3933     r3861     -1
    c3933     r3865     1
    c3934     r3883     -1
    c3934     r3890     1
    c3934     r4327     -0.03125
    c3934     r4557     -0.03125
    c3934     r6944     -6.103515625e-05
    c3935     r3806     1
    c3935     r3847     -1
    c3935     r4484     -6.103515625e-05
    c3935     r4798     -0.03125
    c3936     r3845     1
    c3936     r3848     -1
    c3936     r4492     -6.103515625e-05
    c3936     r4544     -0.03125
    c3937     r3868     -1
    c3937     r4142     1
    c3937     r5654     -0.03125
    c3937     r6439     -0.00016276364411835
    c3937     r6752     9.58279909070786e-05
    c3938     r3910     1
    c3938     r3912     -1
    c3938     r5125     -0.03125
    c3939     r3912     -1
    c3939     r4027     1
    c3939     r5125     -0.03125
    c3940     r3929     -1
    c3940     r4061     1
    c3940     r6373     6.103515625e-05
    c3940     r6375     6.103515625e-05
    c3940     r6376     6.103515625e-05
    c3940     r6377     6.103515625e-05
    c3940     r6380     6.103515625e-05
    c3940     r6383     6.103515625e-05
    c3940     r6414     9.17161608339373e-05
    c3940     r6449     -0.03125
    c3940     r6452     0.00390625
    c3940     r6487     9.17161608339373e-05
    c3941     r3421     1
    c3941     r4055     -1
    c3941     r5085     -6.103515625e-05
    c3941     r6360     -6.103515625e-05
    c3941     r6822     6.103515625e-05
    c3942     r3342     1
    c3942     r4188     -1
    c3942     r5074     -6.103515625e-05
    c3943     r3425     1
    c3943     r3944     -1
    c3943     r6492     -6.103515625e-05
    c3944     r2210     1
    c3944     r3786     1
    c3944     r4255     -1
    c3944     r4310     -0.03125
    c3944     r5078     6.103515625e-05
    c3944     r6316     6.103515625e-05
    c3944     r6931     6.103515625e-05
    c3944     r6996     9.53971836372719e-05
    c3945     r3777     -1
    c3945     r3778     1
    c3945     r5692     -6.103515625e-05
    c3946     r3775     1
    c3946     r3777     -1
    c3946     r5693     0.0001
    c3947     r3959     -1
    c3947     r3975     1
    c3948     r3960     -1
    c3948     r3969     1
    c3949     r3967     1
    c3949     r3972     -1
    c3949     r4338     -0.03125
    c3950     r3957     1
    c3950     r3978     -1
    c3951     r3968     1
    c3951     r3979     -1
    c3951     r4348     -0.0256
    c3952     r3958     1
    c3952     r3983     -1
    c3952     r4890     -0.03125
    c3952     r6938     6.103515625e-05
    c3953     r3269     1
    c3953     r4260     -1
    c3953     r5603     -0.001953125
    c3953     r6094     -6.103515625e-05
    c3953     r6906     -0.001953125
    c3954     r3669     1
    c3954     r3999     -1
    c3954     r4696     -0.0256
    c3954     r4697     -0.0256
    c3954     r6508     -0.0256
    c3955     r3935     1
    c3955     r4229     -1
    c3955     r4785     -0.03125
    c3955     r4795     -0.015625
    c3955     r4805     -6.103515625e-05
    c3956     r3923     1
    c3956     r4010     -1
    c3957     r3933     1
    c3957     r4050     -1
    c3957     r5208     0.0078125
    c3957     r6036     -6.103515625e-05
    c3957     r6037     -6.103515625e-05
    c3957     r6104     -0.03125
    c3957     r6402     0.0078125
    c3957     r6460     -6.103515625e-05
    c3957     r6464     -6.103515625e-05
    c3957     r6468     -6.103515625e-05
    c3958     r3924     1
    c3958     r4050     -1
    c3958     r5699     -0.0625
    c3958     r6036     -6.103515625e-05
    c3958     r6037     -6.103515625e-05
    c3958     r6104     -0.03125
    c3958     r6460     -6.103515625e-05
    c3958     r6464     -6.103515625e-05
    c3958     r6468     -6.103515625e-05
    c3959     r3420     1
    c3959     r4047     -1
    c3960     r3930     1
    c3960     r4057     -1
    c3960     r4502     -6.103515625e-05
    c3960     r5198     -0.03125
    c3961     r3870     1
    c3961     r4059     -1
    c3961     r5383     -0.0001220703125
    c3961     r5985     -6.103515625e-05
    c3962     r4088     1
    c3962     r4089     -1
    c3962     r5116     -0.03125
    c3962     r5578     -0.03125
    c3963     r4084     1
    c3963     r4086     -1
    c3963     r4322     -0.0256
    c3963     r4358     0.03125
    c3963     r4616     0.03125
    c3964     r2359     1
    c3964     r4085     1
    c3964     r4087     -1
    c3964     r4354     -0.03125
    c3964     r6179     6.103515625e-05
    c3965     r3444     1
    c3965     r4096     -1
    c3966     r3851     1
    c3966     r4193     -1
    c3966     r5308     -6.103515625e-05
    c3966     r5628     -6.103515625e-05
    c3966     r5683     -5.40634142331716e-05
    c3967     r3852     1
    c3967     r4118     -1
    c3967     r6131     -6.103515625e-05
    c3968     r3853     1
    c3968     r3937     -1
    c3968     r4295     -0.0256
    c3968     r4823     6.103515625e-05
    c3968     r5959     -0.0016
    c3969     r4120     -1
    c3969     r4195     1
    c3969     r5398     -6.103515625e-05
    c3969     r6010     -6.103515625e-05
    c3970     r4128     1
    c3970     r4130     -1
    c3971     r4121     1
    c3971     r4162     -1
    c3971     r6358     6.103515625e-05
    c3971     r6458     6.103515625e-05
    c3971     r6503     0.03125
    c3971     r6513     6.103515625e-05
    c3971     r6723     -6.103515625e-05
    c3971     r6983     -0.0001
    c3972     r4136     1
    c3972     r4147     -1
    c3972     r4316     -0.03125
    c3973     r4141     1
    c3973     r4147     -1
    c3973     r4306     -0.03125
    c3974     r4137     1
    c3974     r4153     -1
    c3974     r5025     -6.103515625e-05
    c3975     r4182     1
    c3975     r4183     -1
    c3975     r4517     -0.03125
    c3975     r4789     0.03125
    c3975     r5137     0.0064
    c3975     r6370     0.0064
    c3975     r6371     0.00321671566294248
    c3975     r6396     0.0064
    c3975     r6397     0.0064
    c3975     r6398     0.0064
    c3975     r6399     0.0064
    c3975     r6400     0.0064
    c3975     r6401     0.0064
    c3975     r6439     0.00016276364411835
    c3975     r6528     0.00795106722404723
    c3975     r6560     0.00010521428971505
    c3975     r6697     0.000151654571991859
    c3975     r6805     6.33313256726729e-05
    c3975     r6889     6.103515625e-05
    c3975     r6993     0.0003
    c3975     r7008     0.000121111350807723
    c3976     r3472     1
    c3976     r4151     -1
    c3977     r3866     -1
    c3977     r4155     1
    c3977     r5252     -8.86688360098604e-05
    c3977     r6962     -0.03125
    c3978     r4143     1
    c3978     r4157     -1
    c3978     r6107     -0.03125
    c3978     r6872     -6.103515625e-05
    c3978     r6885     -6.103515625e-05
    c3978     r7026     -6.103515625e-05
    c3979     r4129     1
    c3979     r4164     -1
    c3979     r5039     -0.0256
    c3979     r6425     6.103515625e-05
    c3979     r6976     6.103515625e-05
    c3980     r4166     1
    c3980     r4167     -1
    c3980     r4333     -0.0256
    c3981     r3785     -1
    c3981     r4134     1
    c3981     r4521     -0.03125
    c3981     r7024     6.103515625e-05
    c3982     r4135     1
    c3982     r4180     -1
    c3982     r4346     -0.0256
    c3982     r4539     0.03125
    c3982     r5170     0.0008
    c3983     r4132     1
    c3983     r4283     -1
    c3983     r4298     -0.0256
    c3983     r4821     6.103515625e-05
    c3983     r4901     -0.0008
    c3984     r3797     1
    c3984     r4189     -1
    c3984     r5736     0.03125
    c3985     r3389     -1
    c3985     r3390     1
    c3985     r6469     6.103515625e-05
    c3986     r3858     -1
    c3986     r3944     1
    c3986     r6261     -9.31210667174636e-05
    c3986     r6346     -9.88672033125734e-05
    c3986     r6431     -0.000114292604978001
    c3986     r6552     -0.000104380588267577
    c3986     r6700     -6.09866996136888e-05
    c3986     r6824     -6.103515625e-05
    c3986     r6835     -0.0001
    c3987     r4119     -1
    c3987     r4194     1
    c3987     r5628     -6.103515625e-05
    c3987     r5988     -6.103515625e-05
    c3988     r3258     1
    c3988     r3262     -1
    c3988     r4554     -0.03125
    c3989     r3261     1
    c3989     r3262     -1
    c3989     r4397     -0.0256
    c3989     r4554     -0.03125
    c3990     r2996     1
    c3990     r3224     -1
    c3990     r6699     -0.00390625
    c3990     r6757     -0.00390625
    c3990     r7049     -0.000488357173027066
    c3991     r2997     1
    c3991     r3002     -1
    c3992     r2999     1
    c3992     r3002     -1
    c3992     r5906     -6.103515625e-05
    c3992     r7049     -0.000488357173027066
    c3993     r2998     1
    c3993     r3003     -1
    c3993     r5906     -6.103515625e-05
    c3993     r7049     -0.000488357173027066
    c3994     r3000     1
    c3994     r3001     -1
    c3994     r5906     -6.103515625e-05
    c3994     r7049     -0.000488357173027066
    c3995     r3001     -1
    c3995     r3005     1
    c3995     r4717     -0.03125
    c3995     r5906     -6.103515625e-05
    c3995     r6095     -7.32319388336948e-05
    c3995     r7049     -0.000488357173027066
    c3996     r3001     -1
    c3996     r3002     1
    c3997     r3004     -1
    c3997     r3235     1
    c3997     r4536     -0.0256
    c3997     r4717     -0.03125
    c3997     r6095     -7.32319388336948e-05
    c3997     r6704     -6.103515625e-05
    c3998     r3004     -1
    c3998     r3222     1
    c3998     r5994     -6.103515625e-05
    c3998     r6095     -7.32319388336948e-05
    c3998     r6704     -6.103515625e-05
    c3999     r3005     1
    c3999     r3006     -1
    c3999     r4717     -0.03125
    c3999     r6095     -7.32319388336948e-05
    c4000     r3006     -1
    c4000     r3007     1
    c4000     r5520     -0.00390625
    c4000     r6699     -0.00390625
    c4000     r6757     -0.00390625
    c4001     r3012     -1
    c4001     r3225     1
    c4001     r5089     -0.0032
    c4002     r3012     -1
    c4002     r3217     1
    c4003     r3217     1
    c4003     r3219     -1
    c4003     r5231     -0.00390625
    c4004     r3006     1
    c4004     r3219     -1
    c4004     r5163     -0.0032
    c4004     r5231     -0.00390625
    c4004     r7049     -0.000488357173027066
    c4005     r3217     1
    c4005     r3218     -1
    c4005     r5089     -0.0032
    c4006     r3218     -1
    c4006     r3220     1
    c4006     r5089     -0.0032
    c4006     r5163     -0.0032
    c4006     r5231     -0.00390625
    c4006     r5520     -0.00390625
    c4006     r6077     -0.00390625
    c4006     r6757     -0.00390625
    c4007     r3010     1
    c4007     r3218     -1
    c4007     r5089     -0.0032
    c4008     r3009     1
    c4008     r3223     -1
    c4009     r3009     1
    c4009     r3011     -1
    c4010     r3010     1
    c4010     r3011     -1
    c4011     r3011     -1
    c4011     r3222     1
    c4011     r6738     -6.103515625e-05
    c4011     r6759     -8.39874478313481e-05
    c4012     r3010     1
    c4012     r3221     -1
    c4012     r5231     -0.00390625
    c4013     r3221     -1
    c4013     r3222     1
    c4013     r5231     -0.00390625
    c4013     r6738     -6.103515625e-05
    c4013     r6759     -8.39874478313481e-05
    c4013     r6812     -8.39920286734662e-05
    c4013     r7031     -6.103515625e-05
    c4014     r3219     1
    c4014     r3221     -1
    c4015     r2517     1
    c4015     r3205     1
    c4015     r3206     -1
    c4015     r4435     -1
    c4016     r3023     1
    c4016     r3025     -1
    c4017     r3024     1
    c4017     r3026     -1
    c4018     r3025     1
    c4018     r3026     -1
    c4019     r3027     -1
    c4019     r3028     1
    c4019     r4643     -6.103515625e-05
    c4020     r3025     1
    c4020     r3027     -1
    c4021     r2523     1
    c4021     r3027     -1
    c4021     r3030     1
    c4021     r4598     -0.0256
    c4022     r3026     1
    c4022     r3028     -1
    c4022     r4642     -6.103515625e-05
    c4023     r3232     -1
    c4023     r3233     1
    c4023     r6574     -0.03125
    c4023     r6745     8.88674483022152e-05
    c4024     r3041     -1
    c4024     r3237     1
    c4024     r5627     -0.0001220703125
    c4024     r6239     -0.0001
    c4024     r6826     -6.103515625e-05
    c4024     r7002     -0.0001
    c4025     r3041     -1
    c4025     r3239     1
    c4025     r6081     -8.16584644176811e-05
    c4025     r6413     -6.103515625e-05
    c4026     r2528     1
    c4026     r4221     -1
    c4026     r4274     1
    c4026     r4475     -0.03125
    c4027     r3048     -1
    c4027     r3250     1
    c4027     r4294     -0.03125
    c4028     r3146     -1
    c4028     r3150     1
    c4028     r4307     -0.0256
    c4028     r6849     6.103515625e-05
    c4029     r3213     -1
    c4029     r4218     1
    c4029     r6011     -5.78832137753131e-05
    c4030     r3040     -1
    c4030     r3250     1
    c4030     r4391     -0.0256
    c4030     r4449     -0.0008
    c4030     r5532     6.103515625e-05
    c4030     r6081     -8.16584644176811e-05
    c4030     r6150     6.103515625e-05
    c4030     r6491     6.103515625e-05
    c4030     r6759     8.39874478313481e-05
    c4031     r3040     -1
    c4031     r3041     1
    c4031     r6471     -0.0001
    c4032     r3490     1
    c4032     r4201     -1
    c4032     r6168     -6.103515625e-05
    c4033     r3490     1
    c4033     r4202     -1
    c4033     r6168     -6.103515625e-05
    c4033     r6535     -6.103515625e-05
    c4034     r3490     1
    c4034     r4203     -1
    c4034     r6168     -6.103515625e-05
    c4034     r7029     -5.60386452015181e-05
    c4035     r3835     -1
    c4035     r4205     1
    c4035     r5126     -0.03125
    c4036     r3835     -1
    c4036     r3837     1
    c4036     r4889     -0.03125
    c4036     r5052     -0.03125
    c4036     r5126     -0.03125
    c4037     r3837     1
    c4037     r4204     -1
    c4037     r4889     -0.03125
    c4037     r4999     -6.103515625e-05
    c4037     r5291     -6.103515625e-05
    c4038     r3920     1
    c4038     r4052     -1
    c4038     r4651     -6.103515625e-05
    c4038     r6583     -6.103515625e-05
    c4039     r4051     1
    c4039     r4052     -1
    c4039     r5217     -6.103515625e-05
    c4039     r6568     0.03125
    c4039     r6660     -6.103515625e-05
    c4039     r6665     -6.103515625e-05
    c4040     r2542     1
    c4040     r3484     1
    c4040     r3748     -1
    c4040     r4373     -0.0256
    c4040     r4432     -0.0256
    c4040     r4438     -0.0064
    c4040     r4705     0.03125
    c4040     r4894     -0.0256
    c4041     r4232     -1
    c4041     r4269     1
    c4041     r5073     -6.29882981875534e-05
    c4041     r5132     -0.0078125
    c4041     r6139     -6.103515625e-05
    c4041     r6261     -9.31210667174636e-05
    c4041     r6666     -0.0078125
    c4041     r6671     -0.00390625
    c4041     r6929     -5.15410025492391e-05
    c4042     r3430     1
    c4042     r4232     -1
    c4042     r5073     -6.29882981875534e-05
    c4042     r5132     -0.0078125
    c4042     r6261     -9.31210667174636e-05
    c4042     r6552     -0.000104380588267577
    c4042     r6666     -0.0078125
    c4042     r6671     -0.00390625
    c4042     r6700     -6.09866996136888e-05
    c4042     r6929     -5.15410025492391e-05
    c4043     r3333     1
    c4043     r4257     -1
    c4043     r4486     -6.103515625e-05
    c4043     r5544     -6.103515625e-05
    c4044     r3314     1
    c4044     r3316     -1
    c4044     r4599     -0.03125
    c4045     r3252     1
    c4045     r4226     -1
    c4045     r5190     -6.95478079421149e-05
    c4045     r6359     -0.0001
    c4045     r6636     -6.45772165793789e-05
    c4046     r3259     1
    c4046     r3263     -1
    c4046     r4364     -0.03125
    c4047     r3265     -1
    c4047     r3790     1
    c4047     r4591     -0.03125
    c4047     r4773     0.03125
    c4047     r5045     0.03125
    c4048     r3265     -1
    c4048     r3266     1
    c4049     r3268     1
    c4049     r3270     -1
    c4049     r4972     -0.015625
    c4049     r5000     -6.103515625e-05
    c4049     r6756     -6.103515625e-05
    c4049     r6798     -6.103515625e-05
    c4050     r3268     1
    c4050     r3269     -1
    c4050     r4972     -0.015625
    c4051     r3272     1
    c4051     r3275     -1
    c4051     r6559     -6.23805752444274e-05
    c4051     r6638     -6.36421271115382e-05
    c4051     r6810     -6.36421271115382e-05
    c4051     r7017     -6.36421271115382e-05
    c4052     r3274     1
    c4052     r3275     -1
    c4052     r4724     0.001953125
    c4052     r5248     6.3935438124036e-05
    c4052     r5603     -0.001953125
    c4052     r6638     -6.36421271115382e-05
    c4052     r6810     -6.36421271115382e-05
    c4052     r6906     -0.001953125
    c4053     r3275     -1
    c4053     r3276     1
    c4053     r5000     -6.103515625e-05
    c4053     r5098     -0.001953125
    c4053     r6084     -6.50450124635623e-05
    c4053     r6638     -6.36421271115382e-05
    c4053     r6756     -6.103515625e-05
    c4053     r6790     -0.001953125
    c4053     r7017     -6.36421271115382e-05
    c4054     r3268     1
    c4054     r3934     -1
    c4054     r4774     -0.015625
    c4054     r4785     0.03125
    c4055     r3268     1
    c4055     r3273     -1
    c4055     r4795     -0.015625
    c4055     r4805     -6.103515625e-05
    c4055     r5248     -6.3935438124036e-05
    c4056     r3273     -1
    c4056     r4229     1
    c4056     r4764     -6.103515625e-05
    c4057     r3277     1
    c4057     r3278     -1
    c4058     r3278     1
    c4058     r3279     -1
    c4058     r4619     -0.03125
    c4059     r3279     -1
    c4059     r3345     1
    c4059     r4619     -0.03125
    c4060     r3279     1
    c4060     r3289     -1
    c4060     r5339     -0.03125
    c4060     r6352     6.103515625e-05
    c4061     r2563     1
    c4061     r3314     -1
    c4061     r3320     1
    c4061     r4601     -0.0256
    c4061     r5329     6.103515625e-05
    c4061     r6763     6.103515625e-05
    c4061     r6851     6.103515625e-05
    c4062     r3297     1
    c4062     r3300     -1
    c4063     r3299     1
    c4063     r3300     -1
    c4064     r3294     1
    c4064     r3299     -1
    c4064     r4559     -0.03125
    c4065     r3298     1
    c4065     r3299     -1
    c4065     r7005     -6.103515625e-05
    c4066     r3291     -1
    c4066     r3300     1
    c4067     r3291     1
    c4067     r3307     -1
    c4067     r4942     -6.103515625e-05
    c4068     r3296     1
    c4068     r3304     -1
    c4069     r3303     1
    c4069     r3304     -1
    c4070     r3301     -1
    c4070     r3304     1
    c4071     r3306     -1
    c4071     r3307     1
    c4071     r4998     -6.103515625e-05
    c4071     r5094     -6.103515625e-05
    c4071     r5096     -6.103515625e-05
    c4072     r3305     1
    c4072     r3306     -1
    c4072     r4648     -6.103515625e-05
    c4073     r3302     -1
    c4073     r3303     1
    c4073     r4668     -0.03125
    c4074     r3301     1
    c4074     r3302     -1
    c4074     r4668     -0.03125
    c4075     r3292     -1
    c4075     r3302     1
    c4075     r4668     0.03125
    c4075     r5096     -6.103515625e-05
    c4076     r3292     -1
    c4076     r3305     1
    c4076     r4617     0.03125
    c4077     r3305     -1
    c4077     r3308     1
    c4077     r5094     -6.103515625e-05
    c4077     r5096     -6.103515625e-05
    c4078     r3292     1
    c4078     r3293     -1
    c4078     r5096     6.103515625e-05
    c4079     r3296     1
    c4079     r3311     -1
    c4080     r2582     1
    c4080     r3317     -1
    c4080     r3667     1
    c4080     r6403     0.00575912023495001
    c4080     r6763     6.103515625e-05
    c4080     r6809     6.103515625e-05
    c4080     r7022     8.9986253671094e-05
    c4081     r3322     1
    c4081     r3344     -1
    c4082     r3342     1
    c4082     r3344     -1
    c4083     r3323     1
    c4083     r3329     -1
    c4083     r4439     -0.03125
    c4084     r3325     1
    c4084     r3329     -1
    c4084     r4439     -0.03125
    c4084     r5648     -0.03125
    c4085     r3325     1
    c4085     r3326     -1
    c4085     r6771     -0.0078125
    c4085     r6815     -6.103515625e-05
    c4085     r6851     -6.103515625e-05
    c4086     r3331     -1
    c4086     r3334     1
    c4086     r6348     -6.103515625e-05
    c4086     r6489     -6.103515625e-05
    c4086     r6505     -0.03125
    c4087     r3330     -1
    c4087     r3331     1
    c4087     r6489     6.103515625e-05
    c4087     r6505     0.03125
    c4088     r3310     1
    c4088     r3330     -1
    c4088     r5067     6.103515625e-05
    c4089     r3330     1
    c4089     r3337     -1
    c4089     r4836     6.103515625e-05
    c4090     r3337     -1
    c4090     r3338     1
    c4090     r6348     -6.103515625e-05
    c4091     r3336     -1
    c4091     r3345     1
    c4091     r5813     -6.103515625e-05
    c4091     r6353     -6.103515625e-05
    c4092     r3335     1
    c4092     r3336     -1
    c4093     r3338     1
    c4093     r3342     -1
    c4094     r3321     -1
    c4094     r3339     1
    c4095     r3343     -1
    c4095     r4187     1
    c4095     r4788     -0.0256
    c4095     r4840     -0.0001
    c4095     r5074     6.103515625e-05
    c4096     r3340     1
    c4096     r3343     -1
    c4097     r3321     1
    c4097     r3792     -1
    c4098     r3341     -1
    c4098     r3792     1
    c4099     r3356     1
    c4099     r3383     -1
    c4099     r4356     -0.03125
    c4099     r4607     0.03125
    c4099     r4848     6.103515625e-05
    c4099     r6144     6.103515625e-05
    c4099     r6357     7.89594079600832e-05
    c4099     r6534     6.103515625e-05
    c4099     r7048     0.000105419978435289
    c4100     r3376     1
    c4100     r3383     -1
    c4101     r3373     -1
    c4101     r3388     1
    c4101     r5445     -6.103515625e-05
    c4102     r3363     -1
    c4102     r3383     1
    c4102     r4607     -0.03125
    c4102     r4848     -6.103515625e-05
    c4102     r6550     6.103515625e-05
    c4102     r7039     6.43432485566951e-05
    c4103     r3349     1
    c4103     r3367     -1
    c4103     r6544     -6.103515625e-05
    c4104     r3357     1
    c4104     r3367     -1
    c4105     r3350     -1
    c4105     r3367     1
    c4105     r6538     -6.103515625e-05
    c4106     r3350     -1
    c4106     r3363     1
    c4106     r6144     -6.103515625e-05
    c4106     r6357     -7.89594079600832e-05
    c4106     r6443     -6.103515625e-05
    c4106     r6534     -6.103515625e-05
    c4106     r7039     -6.43432485566951e-05
    c4106     r7048     -0.000105419978435289
    c4107     r3348     1
    c4107     r3369     -1
    c4108     r3364     1
    c4108     r3384     -1
    c4108     r6538     6.103515625e-05
    c4109     r3384     -1
    c4109     r3385     1
    c4109     r7072     -5.97309430545916e-05
    c4110     r3352     -1
    c4110     r3365     1
    c4111     r3351     1
    c4111     r3352     -1
    c4112     r3354     -1
    c4112     r3386     1
    c4113     r3353     1
    c4113     r3354     -1
    c4114     r3362     1
    c4114     r3377     -1
    c4115     r3376     1
    c4115     r3377     -1
    c4115     r4848     -6.103515625e-05
    c4115     r6144     -6.103515625e-05
    c4115     r6357     -7.89594079600832e-05
    c4115     r7048     -0.000105419978435289
    c4116     r3358     -1
    c4116     r3378     1
    c4117     r3361     1
    c4117     r3375     -1
    c4118     r3374     1
    c4118     r3375     -1
    c4119     r3375     -1
    c4119     r3379     1
    c4120     r3359     1
    c4120     r3362     -1
    c4121     r3359     1
    c4121     r3360     -1
    c4122     r3360     -1
    c4122     r3860     1
    c4123     r3361     -1
    c4123     r3860     1
    c4124     r3368     1
    c4124     r3828     -1
    c4125     r3351     1
    c4125     r3828     -1
    c4126     r3361     1
    c4126     r3386     -1
    c4127     r3366     1
    c4127     r3386     -1
    c4128     r3369     1
    c4128     r3370     -1
    c4128     r5657     -0.03125
    c4129     r3370     1
    c4129     r3390     -1
    c4129     r6143     -6.103515625e-05
    c4129     r6367     -0.03125
    c4129     r6416     -6.103515625e-05
    c4129     r6421     -6.103515625e-05
    c4129     r6878     -9.00885318019727e-05
    c4130     r3382     1
    c4130     r3390     -1
    c4131     r3371     1
    c4131     r3382     -1
    c4131     r5657     -0.03125
    c4131     r6349     -6.103515625e-05
    c4131     r6357     -7.89594079600832e-05
    c4131     r6878     -9.00885318019727e-05
    c4132     r3374     1
    c4132     r3382     -1
    c4132     r5657     -0.03125
    c4132     r6349     -6.103515625e-05
    c4132     r6357     -7.89594079600832e-05
    c4132     r6416     -6.103515625e-05
    c4132     r6421     -6.103515625e-05
    c4132     r6443     -6.103515625e-05
    c4132     r6878     -9.00885318019727e-05
    c4133     r3382     -1
    c4133     r3385     1
    c4133     r5264     -0.03125
    c4133     r5808     -6.07820559700624e-05
    c4133     r6357     -7.89594079600832e-05
    c4133     r6421     -6.103515625e-05
    c4133     r6878     -9.00885318019727e-05
    c4133     r7048     -0.000105419978435289
    c4134     r3372     1
    c4134     r3374     -1
    c4135     r3376     1
    c4135     r3380     -1
    c4135     r4848     -6.103515625e-05
    c4135     r6144     -6.103515625e-05
    c4135     r6357     -7.89594079600832e-05
    c4135     r7048     -0.000105419978435289
    c4136     r3395     1
    c4136     r3399     -1
    c4136     r4431     -0.03125
    c4136     r4794     0.03125
    c4136     r4995     -6.103515625e-05
    c4137     r3398     1
    c4137     r3399     -1
    c4137     r4714     -0.03125
    c4137     r4741     -6.103515625e-05
    c4137     r4794     0.03125
    c4138     r3399     -1
    c4138     r3414     1
    c4138     r5011     -6.103515625e-05
    c4138     r5017     6.103515625e-05
    c4139     r3730     -1
    c4139     r4239     1
    c4139     r4381     -0.03125
    c4139     r5378     6.103515625e-05
    c4139     r5617     6.103515625e-05
    c4139     r6070     6.103515625e-05
    c4139     r6415     6.103515625e-05
    c4140     r3730     -1
    c4140     r3759     1
    c4140     r4768     -0.03125
    c4140     r4782     -6.103515625e-05
    c4140     r4783     -6.103515625e-05
    c4141     r3729     1
    c4141     r3730     -1
    c4141     r4782     -6.103515625e-05
    c4141     r4783     -6.103515625e-05
    c4142     r3423     1
    c4142     r3492     -1
    c4142     r6544     -6.103515625e-05
    c4143     r3424     1
    c4143     r3940     -1
    c4144     r3492     1
    c4144     r3940     -1
    c4145     r3425     -1
    c4145     r3772     1
    c4146     r3427     -1
    c4146     r3429     1
    c4146     r6174     -0.0001
    c4146     r6440     -7.39420869012365e-05
    c4146     r6493     -7.83571103003273e-05
    c4146     r6571     0.03125
    c4146     r6590     6.103515625e-05
    c4146     r6592     6.103515625e-05
    c4147     r3873     -1
    c4147     r4059     1
    c4147     r5985     6.103515625e-05
    c4148     r3477     1
    c4148     r3478     -1
    c4148     r4380     -0.03125
    c4148     r5143     6.103515625e-05
    c4148     r6011     5.78832137753131e-05
    c4148     r6417     6.103515625e-05
    c4148     r6742     6.103515625e-05
    c4149     r3478     -1
    c4149     r3507     1
    c4150     r3487     -1
    c4150     r3952     1
    c4150     r4434     -0.0256
    c4150     r5844     6.103515625e-05
    c4150     r7028     6.103515625e-05
    c4151     r3486     -1
    c4151     r3489     1
    c4151     r6193     -0.03125
    c4152     r3486     -1
    c4152     r3487     1
    c4153     r3491     1
    c4153     r4090     -1
    c4154     r3727     -1
    c4154     r3761     1
    c4154     r5272     -0.03125
    c4155     r3728     1
    c4155     r3762     -1
    c4155     r4810     -6.103515625e-05
    c4155     r4812     -6.103515625e-05
    c4155     r5004     -6.103515625e-05
    c4155     r5083     -6.103515625e-05
    c4155     r5272     0.03125
    c4155     r5442     -6.103515625e-05
    c4155     r5443     -6.103515625e-05
    c4156     r3762     -1
    c4156     r4207     1
    c4156     r4810     -6.103515625e-05
    c4156     r4812     -6.103515625e-05
    c4156     r5004     -6.103515625e-05
    c4156     r5159     -6.103515625e-05
    c4156     r5344     -0.03125
    c4156     r5443     -6.103515625e-05
    c4157     r3762     -1
    c4157     r4206     1
    c4157     r4810     -6.103515625e-05
    c4157     r4812     -6.103515625e-05
    c4157     r5159     -6.103515625e-05
    c4157     r5219     -6.103515625e-05
    c4157     r5344     -0.03125
    c4158     r3496     -1
    c4158     r3535     1
    c4159     r3485     -1
    c4159     r3732     1
    c4160     r3485     -1
    c4160     r3496     1
    c4161     r3514     1
    c4161     r4240     -1
    c4161     r4341     -0.03125
    c4162     r3628     -1
    c4162     r3649     1
    c4162     r6647     -0.03125
    c4162     r6659     -6.103515625e-05
    c4162     r6663     -6.103515625e-05
    c4162     r6668     -8.13802083333333e-05
    c4163     r3630     -1
    c4163     r3639     1
    c4163     r4384     -0.03125
    c4164     r3507     -1
    c4164     r3757     1
    c4164     r4558     -0.03125
    c4164     r4626     -0.03125
    c4164     r5378     -6.103515625e-05
    c4164     r6474     -6.103515625e-05
    c4164     r6530     -6.103515625e-05
    c4164     r7038     -6.103515625e-05
    c4165     r3507     -1
    c4165     r4225     1
    c4165     r4558     -0.03125
    c4165     r4626     -0.03125
    c4165     r5378     -6.103515625e-05
    c4165     r6900     -6.103515625e-05
    c4166     r3506     1
    c4166     r3507     -1
    c4166     r4558     -0.03125
    c4166     r4752     -0.03125
    c4166     r6474     -6.103515625e-05
    c4166     r6530     -6.103515625e-05
    c4166     r7038     -6.103515625e-05
    c4167     r3497     -1
    c4167     r3681     1
    c4167     r4297     -0.03125
    c4167     r4418     0.03125
    c4167     r4618     0.03125
    c4167     r4750     0.03125
    c4167     r4792     0.03125
    c4168     r3497     1
    c4168     r3725     -1
    c4168     r4418     -0.03125
    c4169     r3497     1
    c4169     r3500     -1
    c4169     r4418     -0.03125
    c4169     r4792     -0.03125
    c4170     r3498     -1
    c4170     r3501     1
    c4170     r4665     -0.03125
    c4171     r3498     -1
    c4171     r3503     1
    c4171     r4767     -0.03125
    c4172     r3498     1
    c4172     r3505     -1
    c4173     r3504     1
    c4173     r3505     -1
    c4173     r5050     -0.03125
    c4174     r3722     1
    c4174     r3729     -1
    c4174     r4420     -0.03125
    c4174     r5050     -0.03125
    c4174     r5378     6.103515625e-05
    c4174     r5617     6.103515625e-05
    c4174     r6613     -6.103515625e-05
    c4174     r6934     -0.0001
    c4175     r2677     1
    c4175     r3931     1
    c4175     r4058     -1
    c4175     r4587     -0.03125
    c4175     r6562     -6.13774574550614e-05
    c4176     r4057     1
    c4176     r4058     -1
    c4176     r4754     -0.03125
    c4176     r5215     -6.103515625e-05
    c4176     r6562     -6.13774574550614e-05
    c4177     r3402     1
    c4177     r4269     -1
    c4178     r3429     1
    c4178     r4269     -1
    c4178     r4614     -0.03125
    c4178     r6440     -7.39420869012366e-05
    c4178     r6493     -7.83571103003273e-05
    c4178     r6592     6.103515625e-05
    c4179     r3267     1
    c4179     r3795     -1
    c4179     r4303     -0.03125
    c4180     r3797     1
    c4180     r3801     -1
    c4180     r5494     -0.03125
    c4180     r5826     0.03125
    c4180     r5836     0.00390625
    c4181     r3800     1
    c4181     r3801     -1
    c4181     r5080     -6.103515625e-05
    c4181     r5416     -0.03125
    c4182     r3802     1
    c4182     r3804     -1
    c4182     r4302     -0.0256
    c4182     r4888     0.03125
    c4182     r4949     -0.0256
    c4183     r3266     -1
    c4183     r3855     1
    c4183     r4367     -0.03125
    c4184     r3815     -1
    c4184     r3818     1
    c4185     r3818     -1
    c4185     r3827     1
    c4186     r3819     1
    c4186     r3823     -1
    c4186     r4808     -0.0001
    c4187     r3822     1
    c4187     r3823     -1
    c4187     r4411     -0.03125
    c4188     r3353     -1
    c4188     r3828     1
    c4189     r3830     1
    c4189     r3833     -1
    c4190     r3831     -1
    c4190     r3833     1
    c4190     r7066     -0.03125
    c4191     r3832     1
    c4191     r3834     -1
    c4191     r5861     -0.03125
    c4191     r6827     -6.103515625e-05
    c4192     r3829     1
    c4192     r3834     -1
    c4192     r6827     -6.103515625e-05
    c4193     r3834     1
    c4193     r3930     -1
    c4194     r3930     -1
    c4194     r3931     1
    c4194     r4587     -0.03125
    c4195     r3841     -1
    c4195     r3842     1
    c4195     r5122     0.03125
    c4195     r6065     -6.103515625e-05
    c4196     r3445     1
    c4196     r3841     -1
    c4197     r3858     1
    c4197     r3859     -1
    c4197     r4956     -0.0256
    c4197     r6422     0.0001
    c4197     r6431     -0.000114292604978001
    c4198     r3856     1
    c4198     r3859     -1
    c4198     r4366     -0.03125
    c4198     r6174     0.0001
    c4198     r6263     0.000106825841804308
    c4198     r6440     7.39420869012365e-05
    c4198     r6493     7.83571103003273e-05
    c4199     r3859     -1
    c4199     r4269     1
    c4199     r4956     -0.0256
    c4199     r6261     -9.31210667174636e-05
    c4199     r6346     -9.88672033125734e-05
    c4199     r6423     -6.103515625e-05
    c4199     r6431     -0.000228585209956002
    c4199     r6552     -0.000104380588267577
    c4199     r6700     -6.09866996136888e-05
    c4200     r3870     -1
    c4200     r3872     1
    c4201     r3810     -1
    c4201     r4280     1
    c4201     r7028     -6.103515625e-05
    c4202     r3893     -1
    c4202     r3895     1
    c4203     r3893     -1
    c4203     r3904     1
    c4203     r4396     -0.0256
    c4204     r3892     1
    c4204     r3893     -1
    c4204     r4389     -0.03125
    c4205     r3893     1
    c4205     r3903     -1
    c4205     r4374     -0.0256
    c4206     r3898     1
    c4206     r3905     -1
    c4207     r3905     -1
    c4207     r3906     1
    c4208     r3915     -1
    c4208     r4051     1
    c4208     r5217     -6.103515625e-05
    c4208     r6665     -6.103515625e-05
    c4209     r3917     -1
    c4209     r3920     1
    c4209     r4651     -6.103515625e-05
    c4209     r4671     -0.03125
    c4209     r6655     6.103515625e-05
    c4209     r6656     6.103515625e-05
    c4210     r3917     -1
    c4210     r3918     1
    c4210     r6645     -0.03125
    c4211     r3918     -1
    c4211     r4052     1
    c4211     r4671     -0.03125
    c4211     r6568     -0.03125
    c4211     r6646     -0.03125
    c4211     r6662     -6.103515625e-05
    c4212     r3921     -1
    c4212     r4049     1
    c4212     r6424     -0.0078125
    c4212     r6642     -0.03125
    c4212     r6653     -0.015625
    c4212     r6732     6.103515625e-05
    c4213     r3922     1
    c4213     r4048     -1
    c4213     r6642     0.03125
    c4213     r6653     0.015625
    c4213     r6733     6.103515625e-05
    c4213     r7046     -6.103515625e-05
    c4214     r3925     1
    c4214     r3933     -1
    c4214     r6402     -0.0078125
    c4214     r6465     -6.103515625e-05
    c4214     r6975     -6.10094761413026e-05
    c4214     r7070     -6.103515625e-05
    c4215     r3804     1
    c4215     r3843     -1
    c4215     r4674     -0.03125
    c4216     r3843     -1
    c4216     r3847     1
    c4216     r4674     -0.03125
    c4217     r3778     1
    c4217     r4184     -1
    c4217     r5084     -6.103515625e-05
    c4218     r3956     1
    c4218     r3984     -1
    c4218     r4378     -0.03125
    c4218     r4663     0.03125
    c4219     r3422     1
    c4219     r4265     -1
    c4219     r6186     0.03125
    c4220     r3936     1
    c4220     r3995     -1
    c4220     r4440     -0.0032
    c4220     r6345     -6.103515625e-05
    c4220     r6365     -0.03125
    c4220     r6388     -6.103515625e-05
    c4220     r6496     -5.90124545996312e-05
    c4220     r6521     -0.0001220703125
    c4220     r6713     -0.00390625
    c4220     r6750     -0.000116701433279395
    c4221     r3772     1
    c4221     r4254     -1
    c4221     r6683     -0.03125
    c4222     r4165     1
    c4222     r4273     -1
    c4222     r4286     -0.03125
    c4223     r3423     -1
    c4223     r3424     1
    c4224     r3436     -1
    c4224     r3873     1
    c4224     r5927     0.03125
    c4224     r6308     -0.000244140625
    c4224     r6411     -0.0001220703125
    c4224     r6478     -0.0001220703125
    c4225     r3811     1
    c4225     r3939     -1
    c4225     r4975     -0.03125
    c4225     r6307     -0.0032
    c4225     r6868     -0.0001
    c4226     r3879     1
    c4226     r3939     -1
    c4226     r4975     -0.03125
    c4226     r5127     0.03125
    c4226     r5966     -0.0032
    c4227     r3813     -1
    c4227     r3877     1
    c4227     r4355     -0.03125
    c4227     r6833     6.103515625e-05
    c4228     r3490     -1
    c4228     r3814     1
    c4228     r5893     -6.103515625e-05
    c4228     r6633     -6.103515625e-05
    c4229     r3819     1
    c4229     r3862     -1
    c4230     r3816     1
    c4230     r3817     -1
    c4231     r3817     -1
    c4231     r3862     1
    c4232     r3815     1
    c4232     r3863     -1
    c4233     r3817     1
    c4233     r3863     -1
    c4234     r3820     -1
    c4234     r3826     1
    c4235     r3820     -1
    c4235     r3821     1
    c4235     r4505     -0.0001
    c4236     r3821     -1
    c4236     r3824     1
    c4237     r3821     -1
    c4237     r3823     1
    c4238     r3825     1
    c4238     r3827     -1
    c4238     r4410     -0.03125
    c4239     r3820     1
    c4239     r3827     -1
    c4239     r4939     -6.103515625e-05
    c4240     r3872     -1
    c4240     r3873     1
    c4240     r5985     -6.103515625e-05
    c4240     r6761     -0.0001220703125
    c4240     r6803     -6.103515625e-05
    c4241     r3871     1
    c4241     r3872     -1
    c4241     r4702     0.03125
    c4241     r5419     -0.03125
    c4241     r5576     0.03125
    c4241     r5927     -0.03125
    c4241     r6411     -0.0001220703125
    c4241     r6541     -6.103515625e-05
    c4241     r6542     -0.000116344435088454
    c4241     r6547     -8.27375139400187e-05
    c4241     r6625     -0.0001220703125
    c4241     r6632     -8.27375139400187e-05
    c4241     r6761     -0.000244140625
    c4241     r6803     -0.0001220703125
    c4242     r3874     -1
    c4242     r3875     1
    c4242     r6535     -6.103515625e-05
    c4243     r3874     -1
    c4243     r3878     1
    c4244     r3000     -1
    c4244     r3003     1
    c4245     r3001     1
    c4245     r3008     -1
    c4245     r6757     -0.00390625
    c4246     r3007     1
    c4246     r3008     -1
    c4246     r5163     -0.0032
    c4246     r5231     -0.00390625
    c4246     r6077     -0.00390625
    c4247     r3008     1
    c4247     r3225     -1
    c4248     r3007     -1
    c4248     r3012     1
    c4248     r5299     -0.0032
    c4249     r3004     1
    c4249     r3013     -1
    c4249     r4716     -0.03125
    c4249     r6795     -6.103515625e-05
    c4250     r3013     -1
    c4250     r3223     1
    c4250     r4716     -0.03125
    c4250     r6095     -7.32319388336948e-05
    c4250     r6704     -6.103515625e-05
    c4250     r6795     -6.103515625e-05
    c4251     r3015     -1
    c4251     r3050     1
    c4252     r3018     -1
    c4252     r3050     1
    c4252     r4372     -0.03125
    c4252     r4551     0.03125
    c4252     r4769     -0.03125
    c4253     r3033     1
    c4253     r3047     -1
    c4254     r3039     1
    c4254     r3047     -1
    c4254     r5032     -0.0064
    c4255     r3145     1
    c4255     r3177     -1
    c4255     r4977     -0.03125
    c4255     r5278     -1
    c4255     r6309     -0.001953125
    c4255     r6428     -0.00390625
    c4255     r6623     0.000836896509066478
    c4256     r2997     -1
    c4256     r3224     1
    c4257     r3220     -1
    c4257     r3225     1
    c4258     r3009     1
    c4258     r3220     -1
    c4259     r3490     1
    c4259     r3491     -1
    c4259     r4753     -0.0256
    c4259     r6535     -6.103515625e-05
    c4259     r7029     -5.60386452015181e-05
    c4260     r3491     -1
    c4260     r4201     1
    c4260     r4753     -0.0256
    c4260     r5893     -6.103515625e-05
    c4260     r6535     -6.103515625e-05
    c4260     r6633     -6.103515625e-05
    c4260     r7029     -5.60386452015181e-05
    c4261     r3491     -1
    c4261     r4202     1
    c4261     r4753     -0.0256
    c4261     r5893     -6.103515625e-05
    c4261     r6633     -6.103515625e-05
    c4261     r7029     -5.60386452015181e-05
    c4262     r3491     -1
    c4262     r4203     1
    c4262     r4753     -0.0256
    c4262     r5893     -6.103515625e-05
    c4262     r6535     -6.103515625e-05
    c4262     r6633     -6.103515625e-05
    c4263     r3761     1
    c4263     r4206     -1
    c4263     r5004     -6.103515625e-05
    c4263     r5221     -6.103515625e-05
    c4263     r5442     -6.103515625e-05
    c4263     r5443     -6.103515625e-05
    c4264     r4206     -1
    c4264     r4207     1
    c4264     r5004     -6.103515625e-05
    c4264     r5221     -6.103515625e-05
    c4264     r5443     -6.103515625e-05
    c4265     r4204     1
    c4265     r4205     -1
    c4265     r5052     -0.03125
    c4266     r3774     -1
    c4266     r4184     1
    c4266     r5537     -6.103515625e-05
    c4266     r6252     -6.103515625e-05
    c4266     r6892     -7.79684981375495e-05
    c4267     r3774     -1
    c4267     r4255     1
    c4267     r5426     -0.03125
    c4267     r6316     -6.103515625e-05
    c4267     r6996     -9.53971836372719e-05
    c4267     r7007     -6.103515625e-05
    c4268     r3251     -1
    c4268     r3253     1
    c4268     r4387     -0.0256
    c4268     r6507     -0.0256
    c4268     r6636     6.45772165793789e-05
    c4268     r6844     6.103515625e-05
    c4268     r7016     6.103515625e-05
    c4269     r3254     1
    c4269     r3256     -1
    c4269     r4301     -0.0256
    c4270     r3256     -1
    c4270     r3257     1
    c4270     r4963     0.03125
    c4271     r3260     -1
    c4271     r3261     1
    c4271     r4526     -0.03125
    c4272     r3258     -1
    c4272     r3259     1
    c4272     r4675     -0.03125
    c4272     r4715     -0.03125
    c4272     r4957     0.03125
    c4273     r3258     -1
    c4273     r3260     1
    c4273     r4397     -0.0256
    c4273     r4526     0.03125
    c4274     r3272     -1
    c4274     r4260     1
    c4274     r5000     -6.103515625e-05
    c4274     r6084     -6.50450124635623e-05
    c4274     r6756     -6.103515625e-05
    c4274     r6798     -6.103515625e-05
    c4275     r3270     1
    c4275     r3272     -1
    c4275     r5603     -0.001953125
    c4275     r6906     -0.001953125
    c4276     r3277     -1
    c4276     r3338     1
    c4276     r6352     -6.103515625e-05
    c4277     r3295     1
    c4277     r3296     -1
    c4277     r4559     -0.03125
    c4277     r4737     -6.103515625e-05
    c4278     r3321     1
    c4278     r3322     -1
    c4279     r3311     1
    c4279     r3323     -1
    c4280     r2782     1
    c4280     r3324     1
    c4280     r3325     -1
    c4280     r4317     -0.03125
    c4280     r6501     -6.103515625e-05
    c4280     r6561     -6.103515625e-05
    c4280     r6813     -6.103515625e-05
    c4281     r3327     1
    c4281     r3328     -1
    c4281     r6814     -6.103515625e-05
    c4281     r6817     -6.103515625e-05
    c4282     r3331     1
    c4282     r3333     -1
    c4282     r4694     -6.103515625e-05
    c4282     r5148     -6.103515625e-05
    c4282     r6489     -6.103515625e-05
    c4282     r6504     -0.03125
    c4283     r3332     1
    c4283     r3333     -1
    c4283     r4499     -6.103515625e-05
    c4283     r5152     -0.0001
    c4284     r3334     -1
    c4284     r3336     1
    c4285     r3339     1
    c4285     r3340     -1
    c4286     r3344     1
    c4286     r3347     -1
    c4286     r5152     -0.0001
    c4287     r3343     1
    c4287     r3347     -1
    c4288     r3346     1
    c4288     r3347     -1
    c4288     r5813     -6.103515625e-05
    c4289     r3335     -1
    c4289     r3341     1
    c4290     r3345     -1
    c4290     r4257     1
    c4290     r4487     -6.103515625e-05
    c4290     r6189     -0.03125
    c4290     r6352     -6.103515625e-05
    c4291     r3345     1
    c4291     r3346     -1
    c4291     r6353     -6.103515625e-05
    c4292     r3346     -1
    c4292     r3792     1
    c4293     r3348     1
    c4293     r3349     -1
    c4294     r3360     1
    c4294     r3366     -1
    c4295     r3362     1
    c4295     r3365     -1
    c4296     r3365     -1
    c4296     r3366     1
    c4297     r3363     1
    c4297     r3364     -1
    c4297     r6144     -6.103515625e-05
    c4297     r6534     -6.103515625e-05
    c4297     r6538     -6.103515625e-05
    c4298     r3358     1
    c4298     r3371     -1
    c4298     r6416     -6.103515625e-05
    c4298     r6421     -6.103515625e-05
    c4298     r6443     -6.103515625e-05
    c4299     r3372     -1
    c4299     r3373     1
    c4300     r3377     1
    c4300     r3378     -1
    c4301     r3378     1
    c4301     r3388     -1
    c4301     r6143     -6.103515625e-05
    c4302     r3379     -1
    c4302     r3380     1
    c4303     r3387     -1
    c4303     r3388     1
    c4303     r4430     -0.03125
    c4303     r6416     -6.103515625e-05
    c4303     r6466     -6.103515625e-05
    c4303     r6467     -6.103515625e-05
    c4304     r3387     -1
    c4304     r3389     1
    c4304     r4430     -0.03125
    c4304     r5657     0.03125
    c4304     r6367     0.03125
    c4304     r6421     6.103515625e-05
    c4304     r6443     6.103515625e-05
    c4305     r3391     1
    c4305     r3397     -1
    c4305     r4959     -0.03125
    c4305     r5003     -6.103515625e-05
    c4306     r3395     -1
    c4306     r3396     1
    c4306     r4993     -6.103515625e-05
    c4306     r4994     -6.103515625e-05
    c4307     r3403     1
    c4307     r3404     -1
    c4308     r3404     -1
    c4308     r3841     1
    c4308     r4961     0.03125
    c4308     r5340     -0.03125
    c4308     r6736     6.103515625e-05
    c4308     r6848     5.45780865745698e-05
    c4308     r6886     0.0001
    c4309     r3418     -1
    c4309     r3449     1
    c4309     r4386     -0.03125
    c4309     r4563     0.03125
    c4310     r3391     -1
    c4310     r3392     1
    c4311     r3399     1
    c4311     r3413     -1
    c4311     r4803     -6.103515625e-05
    c4311     r4809     -6.103515625e-05
    c4311     r5017     6.103515625e-05
    c4312     r3412     -1
    c4312     r3413     1
    c4312     r5017     -6.103515625e-05
    c4313     r2815     1
    c4313     r3281     1
    c4313     r3755     -1
    c4313     r4287     -0.0256
    c4313     r4658     -0.0256
    c4313     r4721     -0.0256
    c4313     r7018     6.103515625e-05
    c4314     r2816     1
    c4314     r3754     1
    c4314     r3755     -1
    c4314     r5081     -0.0256
    c4314     r6731     -0.0256
    c4314     r7018     6.103515625e-05
    c4315     r3422     -1
    c4315     r4055     1
    c4316     r3426     1
    c4316     r3784     -1
    c4316     r4712     -0.03125
    c4316     r5399     -6.103515625e-05
    c4316     r6572     -0.03125
    c4316     r6590     -6.103515625e-05
    c4316     r6683     -0.03125
    c4317     r3773     1
    c4317     r3784     -1
    c4317     r4712     -0.03125
    c4317     r5399     -6.103515625e-05
    c4317     r6492     -6.103515625e-05
    c4318     r3426     -1
    c4318     r3427     1
    c4318     r4614     -0.03125
    c4318     r6571     -0.03125
    c4319     r3426     -1
    c4319     r3430     1
    c4319     r6140     -6.103515625e-05
    c4319     r6589     -6.103515625e-05
    c4320     r3437     -1
    c4320     r3474     1
    c4320     r4382     -0.03125
    c4320     r5980     0.0001
    c4320     r6344     0.0001
    c4321     r3440     -1
    c4321     r3441     1
    c4321     r5172     -6.103515625e-05
    c4321     r5473     -5.84042810005303e-05
    c4322     r3438     1
    c4322     r3440     -1
    c4322     r5172     -6.103515625e-05
    c4323     r3465     1
    c4323     r3466     -1
    c4323     r4538     -0.0256
    c4323     r4834     -0.0001
    c4323     r5394     -0.0001
    c4324     r3466     1
    c4324     r3472     -1
    c4324     r4571     -0.0016
    c4324     r5680     -0.0009765625
    c4325     r3468     1
    c4325     r3470     -1
    c4325     r5095     -0.0001
    c4326     r3470     -1
    c4326     r3473     1
    c4326     r5234     -6.103515625e-05
    c4327     r3467     1
    c4327     r3468     -1
    c4327     r4406     -0.03125
    c4327     r4832     -0.0001
    c4328     r2830     1
    c4328     r3474     1
    c4328     r4152     -1
    c4328     r6712     0.03125
    c4329     r3469     1
    c4329     r4152     -1
    c4329     r6368     0.03125
    c4330     r3471     1
    c4330     r3474     -1
    c4330     r6164     -0.000114423017120107
    c4330     r6366     -0.03125
    c4330     r6420     -8.77414092738715e-05
    c4330     r6545     -0.000118429033183437
    c4330     r6649     -0.03125
    c4330     r6679     -0.00010823311630947
    c4331     r3489     1
    c4331     r4280     -1
    c4332     r3875     1
    c4332     r4280     -1
    c4332     r6168     -6.103515625e-05
    c4333     r3545     -1
    c4333     r3554     1
    c4333     r4285     -0.0256
    c4333     r4550     0.03125
    c4333     r4597     -0.0256
    c4334     r3401     1
    c4334     r3593     -1
    c4334     r4523     -0.03125
    c4335     r3589     1
    c4335     r3593     -1
    c4335     r4602     -0.03125
    c4335     r4655     0.03125
    c4336     r3499     -1
    c4336     r3627     1
    c4336     r4321     -0.0256
    c4337     r3499     -1
    c4337     r3618     1
    c4337     r4361     -0.03125
    c4338     r3501     -1
    c4338     r3726     1
    c4338     r4433     -0.0256
    c4339     r3502     1
    c4339     r3503     -1
    c4339     r4433     -0.0256
    c4339     r4767     0.03125
    c4340     r3320     1
    c4340     r3667     -1
    c4340     r5418     -0.03125
    c4340     r6403     -0.00575912023495001
    c4340     r6809     -6.103515625e-05
    c4340     r7022     -8.9986253671094e-05
    c4341     r3783     -1
    c4341     r3784     1
    c4341     r4712     0.03125
    c4341     r5129     0.03125
    c4341     r5399     6.103515625e-05
    c4341     r6425     6.103515625e-05
    c4341     r6572     0.03125
    c4341     r6683     0.03125
    c4341     r6976     6.103515625e-05
    c4342     r3782     1
    c4342     r3783     -1
    c4342     r5007     6.103515625e-05
    c4342     r5129     0.03125
    c4342     r5204     0.03125
    c4343     r4187     -1
    c4343     r4188     1
    c4343     r4500     -6.103515625e-05
    c4344     r3803     -1
    c4344     r3804     1
    c4344     r4548     -0.03125
    c4345     r3803     -1
    c4345     r3806     1
    c4345     r4548     -0.03125
    c4345     r4798     -0.03125
    c4346     r3805     1
    c4346     r3807     -1
    c4346     r4413     -0.03125
    c4346     r4489     -6.103515625e-05
    c4347     r3807     -1
    c4347     r3848     1
    c4347     r4413     -0.03125
    c4347     r4493     -6.103515625e-05
    c4348     r3809     -1
    c4348     r4272     1
    c4348     r5407     -0.0009765625
    c4349     r3810     1
    c4349     r3811     -1
    c4349     r5966     -0.0032
    c4349     r7028     -6.103515625e-05
    c4350     r3815     1
    c4350     r3816     -1
    c4351     r3816     1
    c4351     r3819     -1
    c4352     r3822     1
    c4352     r3824     -1
    c4352     r4411     -0.03125
    c4353     r3824     1
    c4353     r3826     -1
    c4353     r4505     -0.0001
    c4354     r3825     1
    c4354     r3826     -1
    c4354     r4410     -0.03125
    c4355     r3805     -1
    c4355     r3845     1
    c4355     r4488     -6.103515625e-05
    c4355     r4544     -0.03125
    c4356     r3846     -1
    c4356     r3849     1
    c4356     r4403     -0.03125
    c4356     r4543     -0.03125
    c4357     r2859     1
    c4357     r3433     1
    c4357     r3846     -1
    c4357     r4403     -0.03125
    c4358     r2860     1
    c4358     r3850     1
    c4358     r4268     -1
    c4358     r5021     6.103515625e-05
    c4359     r3464     -1
    c4359     r3854     1
    c4360     r3779     -1
    c4360     r3867     1
    c4361     r3779     -1
    c4361     r4156     1
    c4361     r6962     -0.03125
    c4362     r2864     1
    c4362     r3869     -1
    c4362     r4162     1
    c4362     r6482     0.0001
    c4362     r6546     0.0001
    c4362     r6723     6.103515625e-05
    c4362     r6784     0.0001
    c4362     r6792     6.103515625e-05
    c4362     r6983     0.0001
    c4363     r3886     1
    c4363     r3887     -1
    c4363     r4331     -0.03125
    c4363     r5837     0.03125
    c4364     r3887     -1
    c4364     r3889     1
    c4365     r3864     -1
    c4365     r3888     1
    c4365     r4611     -0.03125
    c4365     r5395     6.103515625e-05
    c4365     r5468     6.103515625e-05
    c4366     r3864     -1
    c4366     r3887     1
    c4366     r4734     -6.103515625e-05
    c4366     r5837     -0.03125
    c4367     r3889     1
    c4367     r4040     -1
    c4368     r3897     1
    c4368     r3898     -1
    c4369     r3899     -1
    c4369     r3905     1
    c4370     r3902     1
    c4370     r3904     -1
    c4370     r4318     -0.03125
    c4371     r3911     -1
    c4371     r4027     1
    c4371     r6065     -6.103515625e-05
    c4372     r3911     -1
    c4372     r3912     1
    c4372     r6065     -6.103515625e-05
    c4372     r6883     -6.103515625e-05
    c4373     r3907     -1
    c4373     r4056     1
    c4373     r4838     -6.103515625e-05
    c4374     r3863     1
    c4374     r3907     -1
    c4375     r3910     -1
    c4375     r4027     1
    c4375     r5287     -6.103515625e-05
    c4375     r6282     -0.03125
    c4376     r3983     1
    c4376     r4091     -1
    c4376     r4353     -0.03125
    c4377     r3921     1
    c4377     r3922     -1
    c4377     r6735     6.103515625e-05
    c4378     r3927     -1
    c4378     r4073     1
    c4378     r6026     0.03125
    c4378     r6040     0.0001220703125
    c4379     r3879     1
    c4379     r3953     -1
    c4379     r5893     -6.103515625e-05
    c4379     r6633     -6.103515625e-05
    c4380     r3940     1
    c4380     r3953     -1
    c4380     r5127     -0.03125
    c4380     r5893     -6.103515625e-05
    c4380     r6633     -6.103515625e-05
    c4381     r3878     1
    c4381     r3953     -1
    c4381     r5127     -0.03125
    c4381     r6168     -6.103515625e-05
    c4382     r2884     1
    c4382     r3951     1
    c4382     r4030     -1
    c4382     r6402     -0.0078125
    c4382     r6961     0.00390625
    c4382     r6974     6.1548701380684e-05
    c4382     r7012     6.103515625e-05
    c4383     r3878     -1
    c4383     r4090     1
    c4383     r5759     6.103515625e-05
    c4384     r3995     1
    c4384     r3996     -1
    c4384     r4568     -0.00390625
    c4384     r5404     -6.103515625e-05
    c4384     r6365     0.03125
    c4384     r6388     6.103515625e-05
    c4384     r6521     -0.0001220703125
    c4384     r6979     -6.103515625e-05
    c4385     r3997     -1
    c4385     r4046     1
    c4385     r6761     0.0001220703125
    c4385     r6803     6.103515625e-05
    c4386     r3984     1
    c4386     r4099     -1
    c4386     r4604     -0.0256
    c4387     r4123     1
    c4387     r4125     -1
    c4387     r6022     0.03125
    c4387     r6477     6.103515625e-05
    c4387     r6575     -0.03125
    c4387     r6760     -0.0008
    c4387     r6963     -0.03125
    c4387     r6972     0.0008
    c4388     r4124     1
    c4388     r4126     -1
    c4388     r5633     0.0001
    c4388     r5668     -0.0256
    c4389     r4186     -1
    c4389     r4232     1
    c4389     r6140     -6.103515625e-05
    c4389     r6929     5.15410025492391e-05
    c4390     r3858     1
    c4390     r4186     -1
    c4390     r6587     6.103515625e-05
    c4390     r6666     -0.0078125
    c4390     r6671     -0.00390625
    c4390     r6692     8.46071103003263e-05
    c4390     r6998     8.46071103003263e-05
    c4391     r3267     -1
    c4391     r4228     1
    c4391     r5739     0.03125
    c4392     r4218     -1
    c4392     r4225     1
    c4393     r4239     -1
    c4393     r4275     1
    c4393     r4334     -0.03125
    c4393     r4381     0.03125
    c4394     r3046     -1
    c4394     r3647     1
    c4394     r4893     -0.03125
    c4394     r5349     0.00390625
    c4394     r6516     -6.103515625e-05
    c4394     r6593     -6.103515625e-05
    c4394     r6647     -0.03125
    c4394     r6708     -0.03125
    c4394     r6737     0.0032286767807064
    c4394     r6776     -6.103515625e-05
    c4395     r3005     -1
    c4395     r3235     1
    c4395     r4536     -0.0256
    c4395     r6704     -6.103515625e-05
    c4395     r6744     -7.50525172634404e-05
    c4396     r2998     1
    c4396     r2999     -1
    c4396     r6699     -0.00390625
    c4397     r3021     1
    c4397     r3031     -1
    c4397     r4556     -0.03125
    c4397     r5049     0.03125
    c4397     r5565     6.103515625e-05
    c4397     r5904     -6.103515625e-05
    c4397     r5999     -6.103515625e-05
    c4397     r6716     0.00390625
    c4397     r6727     6.103515625e-05
    c4398     r3031     -1
    c4398     r3249     1
    c4398     r4494     -0.0001
    c4399     r2901     1
    c4399     r3014     -1
    c4399     r3195     1
    c4399     r4881     0.03125
    c4399     r5097     6.30463666551241e-05
    c4399     r5604     -0.0256
    c4399     r5904     6.103515625e-05
    c4399     r6706     0.03125
    c4399     r6825     -0.0256
    c4399     r6900     6.103515625e-05
    c4399     r7009     -0.0256
    c4400     r3178     -1
    c4400     r3200     1
    c4400     r5665     1
    c4400     r5706     0.00057319972826087
    c4400     r6479     0.00390625
    c4400     r6694     0.00390625
    c4400     r7078     7.16499660326087e-05
    c4401     r2903     1
    c4401     r3201     1
    c4401     r3202     -1
    c4401     r6182     0.00048828125
    c4402     r3203     1
    c4402     r3204     -1
    c4402     r4515     -0.03125
    c4402     r4593     0.03125
    c4403     r3059     1
    c4403     r3207     -1
    c4403     r4284     -0.0256
    c4403     r4728     -0.0256
    c4403     r5136     0.0511805189748131
    c4403     r5210     -0.0256
    c4403     r5367     0.0127951297437033
    c4403     r5894     0.00342984041820218
    c4403     r6523     0.00390625
    c4403     r6948     6.31515315405316e-05
    c4403     r6969     0.00390625
    c4403     r7047     6.103515625e-05
    c4404     r3208     1
    c4404     r3209     -1
    c4404     r4625     -0.03125
    c4404     r7061     -6.103515625e-05
    c4405     r3210     1
    c4405     r3211     -1
    c4406     r3019     -1
    c4406     r3213     1
    c4406     r6225     6.103515625e-05
    c4406     r6474     6.103515625e-05
    c4406     r6530     6.103515625e-05
    c4406     r7038     6.103515625e-05
    c4407     r3213     1
    c4407     r3215     -1
    c4407     r6900     -6.103515625e-05
    c4408     r3238     -1
    c4408     r3239     1
    c4409     r3255     -1
    c4409     r3256     1
    c4409     r6564     -6.103515625e-05
    c4409     r6841     6.103515625e-05
    c4409     r6844     6.103515625e-05
    c4409     r7016     6.103515625e-05
    c4410     r2912     1
    c4410     r3289     1
    c4410     r3290     -1
    c4410     r4513     -0.03125
    c4410     r4619     0.03125
    c4410     r5339     0.03125
    c4411     r2913     1
    c4411     r3297     1
    c4411     r3298     -1
    c4412     r2914     1
    c4412     r3307     1
    c4412     r3308     -1
    c4412     r4617     -0.03125
    c4412     r4998     -6.103515625e-05
    c4413     r2915     1
    c4413     r3406     -1
    c4413     r4148     1
    c4414     r2916     1
    c4414     r3405     1
    c4414     r3406     -1
    c4414     r5309     6.103515625e-05
    c4415     r2917     1
    c4415     r3432     -1
    c4415     r3844     1
    c4415     r4337     -0.03125
    c4415     r4986     6.103515625e-05
    c4415     r5425     0.03125
    c4416     r2918     1
    c4416     r3434     -1
    c4416     r3798     1
    c4416     r4304     -0.0256
    c4416     r4906     6.103515625e-05
    c4416     r5425     0.03125
    c4417     r2919     1
    c4417     r3443     1
    c4417     r3444     -1
    c4417     r4941     6.103515625e-05
    c4417     r5954     6.103515625e-05
    c4417     r6363     0.03125
    c4417     r6374     6.103515625e-05
    c4417     r6430     6.04134265737728e-05
    c4418     r2920     1
    c4418     r3445     1
    c4418     r3446     -1
    c4418     r4519     -0.03125
    c4418     r4961     0.03125
    c4419     r2921     1
    c4419     r3446     -1
    c4419     r4047     1
    c4419     r4443     -0.0016
    c4419     r5144     -0.0016
    c4419     r5898     -0.0001
    c4419     r6444     -5.45780865745681e-05
    c4419     r7059     -6.16585468489889e-05
    c4420     r2922     1
    c4420     r3484     -1
    c4420     r3491     1
    c4420     r4705     -0.03125
    c4420     r5245     -6.103515625e-05
    c4420     r6846     -6.103515625e-05
    c4421     r2923     1
    c4421     r3485     1
    c4421     r3731     -1
    c4422     r2924     1
    c4422     r3493     -1
    c4422     r4090     1
    c4422     r4742     -0.03125
    c4422     r5759     6.103515625e-05
    c4422     r5893     6.103515625e-05
    c4422     r6535     6.103515625e-05
    c4422     r6633     6.103515625e-05
    c4423     r2925     1
    c4423     r3725     1
    c4423     r3726     -1
    c4423     r4618     -0.03125
    c4423     r4665     0.03125
    c4423     r4792     -0.03125
    c4424     r2926     1
    c4424     r3727     1
    c4424     r3728     -1
    c4424     r5159     -6.103515625e-05
    c4424     r5219     -6.103515625e-05
    c4424     r5344     -0.03125
    c4425     r2927     1
    c4425     r3733     1
    c4425     r3734     -1
    c4426     r2928     1
    c4426     r3737     1
    c4426     r4251     -1
    c4426     r4527     0.03125
    c4426     r4594     -0.03125
    c4427     r2929     1
    c4427     r3738     1
    c4427     r3739     -1
    c4427     r4592     -0.03125
    c4427     r4732     6.103515625e-05
    c4428     r2930     1
    c4428     r3740     1
    c4428     r3741     -1
    c4428     r4326     -0.0256
    c4428     r4516     0.03125
    c4429     r2931     1
    c4429     r3742     1
    c4429     r3743     -1
    c4429     r4962     -0.03125
    c4429     r6195     0.03125
    c4430     r2932     1
    c4430     r3745     1
    c4430     r3746     -1
    c4430     r4660     -0.03125
    c4430     r4770     -0.03125
    c4430     r5040     -0.03125
    c4431     r2933     1
    c4431     r3751     -1
    c4431     r3761     1
    c4432     r2934     1
    c4432     r3789     -1
    c4432     r4184     1
    c4432     r6162     0.0001
    c4432     r7007     6.103515625e-05
    c4432     r7035     6.72799219169098e-05
    c4433     r2935     1
    c4433     r3829     1
    c4433     r3830     -1
    c4434     r2936     1
    c4434     r3831     1
    c4434     r3832     -1
    c4434     r6051     -0.03125
    c4434     r7071     -6.103515625e-05
    c4435     r2937     1
    c4435     r3836     -1
    c4435     r3837     1
    c4435     r4999     -6.103515625e-05
    c4435     r5052     -0.03125
    c4435     r5126     -0.03125
    c4435     r5417     -0.03125
    c4436     r3864     1
    c4436     r3865     -1
    c4436     r5395     -6.103515625e-05
    c4437     r3486     1
    c4437     r3879     -1
    c4437     r5844     -6.103515625e-05
    c4437     r7028     -6.103515625e-05
    c4438     r3880     -1
    c4438     r3909     1
    c4438     r5655     -0.0256
    c4439     r2941     1
    c4439     r3842     -1
    c4439     r3911     1
    c4439     r6065     6.103515625e-05
    c4439     r6086     6.87890538701883e-05
    c4439     r6436     6.103515625e-05
    c4439     r6437     6.103515625e-05
    c4439     r6524     -5.89741767886658e-05
    c4439     r6532     -6.103515625e-05
    c4440     r3915     1
    c4440     r3916     -1
    c4441     r3271     1
    c4441     r4051     -1
    c4441     r5216     -6.103515625e-05
    c4442     r3924     1
    c4442     r3925     -1
    c4442     r5208     -0.0078125
    c4442     r5267     -0.03125
    c4442     r5699     -0.0625
    c4443     r3934     1
    c4443     r3935     -1
    c4443     r5646     6.103515625e-05
    c4443     r5731     6.103515625e-05
    c4444     r3464     1
    c4444     r3938     -1
    c4445     r3937     1
    c4445     r3938     -1
    c4446     r3948     1
    c4446     r3949     -1
    c4446     r4379     -0.03125
    c4447     r3950     1
    c4447     r4190     -1
    c4447     r5005     -0.00390625
    c4447     r6576     -0.00390625
    c4447     r7012     -6.103515625e-05
    c4448     r3994     -1
    c4448     r4261     1
    c4448     r4804     -0.03125
    c4448     r6922     6.103515625e-05
    c4449     r3800     -1
    c4449     r4050     1
    c4449     r5267     -0.03125
    c4449     r5341     -0.03125
    c4449     r5416     0.03125
    c4449     r5517     -0.03125
    c4449     r5699     -0.0625
    c4449     r6459     -6.103515625e-05
    c4449     r6465     -6.103515625e-05
    c4449     r6490     -6.103515625e-05
    c4449     r6606     -0.0078125
    c4450     r4048     1
    c4450     r4049     -1
    c4450     r5274     -0.03125
    c4450     r6734     6.103515625e-05
    c4450     r7046     6.103515625e-05
    c4451     r3393     1
    c4451     r3394     -1
    c4451     r4385     -0.0256
    c4452     r3411     1
    c4452     r3763     -1
    c4452     r4324     -0.0256
    c4453     r3415     1
    c4453     r3416     -1
    c4453     r4336     -0.0256
    c4454     r3756     1
    c4454     r3757     -1
    c4454     r4650     -6.103515625e-05
    c4454     r4752     -0.03125
    c4454     r5617     -6.103515625e-05
    c4455     r3758     1
    c4455     r3759     -1
    c4455     r4490     -0.0001
    c4455     r4768     0.03125
    c4455     r4786     0.03125
    c4455     r6933     -0.0001
    c4456     r3312     -1
    c4456     r3760     1
    c4456     r4325     -0.03125
    c4457     r3761     1
    c4457     r4207     -1
    c4457     r5219     -6.103515625e-05
    c4457     r5442     -6.103515625e-05
    c4458     r3765     -1
    c4458     r3766     1
    c4459     r3769     -1
    c4459     r3770     1
    c4459     r4368     -0.0256
    c4459     r4445     -0.0008
    c4459     r6022     0.03125
    c4459     r6570     -0.03125
    c4459     r6609     -0.0008
    c4459     r6723     -6.103515625e-05
    c4459     r6760     -0.0008
    c4459     r6792     -6.103515625e-05
    c4459     r6955     -0.03125
    c4459     r6983     -0.0001
    c4460     r3773     -1
    c4460     r4254     1
    c4460     r6572     -0.03125
    c4460     r6835     -0.0001
    c4461     r3775     -1
    c4461     r3776     1
    c4461     r5426     -0.03125
    c4461     r5925     -0.03125
    c4461     r6996     -9.53971836372719e-05
    c4462     r3808     1
    c4462     r3855     -1
    c4462     r4288     -0.03125
    c4462     r4367     0.03125
    c4463     r3259     1
    c4463     r3790     -1
    c4463     r4715     -0.03125
    c4463     r4773     -0.03125
    c4464     r3856     -1
    c4464     r3857     1
    c4464     r4340     -0.03125
    c4464     r4366     0.03125
    c4465     r3428     -1
    c4465     r3494     1
    c4466     r3490     1
    c4466     r3875     -1
    c4467     r4053     1
    c4467     r4054     -1
    c4467     r6186     0.03125
    c4467     r6823     6.103515625e-05
    c4468     r3021     -1
    c4468     r3022     1
    c4468     r5388     -6.103515625e-05
    c4468     r6714     -0.001953125
    c4468     r6715     -0.001953125
    c4468     r6727     -6.103515625e-05
    c4469     r3023     1
    c4469     r3024     -1
    c4470     r3214     -1
    c4470     r3215     1
    c4470     r5627     -0.0001220703125
    c4470     r7002     -0.0001
    c4471     r3264     -1
    c4471     r3790     1
    c4471     r4350     -0.03125
    c4471     r4773     0.03125
    c4471     r5045     0.03125
    c4472     r3282     -1
    c4472     r3290     1
    c4472     r4390     -0.03125
    c4472     r4513     0.03125
    c4473     r3428     1
    c4473     r3429     -1
    c4473     r4357     -0.03125
    c4473     r4614     0.03125
    c4473     r5363     6.103515625e-05
    c4473     r6174     0.0001
    c4473     r6440     7.39420869012365e-05
    c4473     r6493     7.83571103003273e-05
    c4473     r6591     6.103515625e-05
    c4474     r3357     -1
    c4474     r3492     1
    c4475     r3493     1
    c4475     r3749     -1
    c4475     r4704     -0.03125
    c4475     r4742     0.03125
    c4476     r3500     1
    c4476     r3502     -1
    c4476     r4618     -0.03125
    c4477     r3504     -1
    c4477     r3722     1
    c4477     r4420     -0.03125
    c4477     r4491     -0.0001
    c4477     r6934     -0.0001
    c4478     r3505     1
    c4478     r3758     -1
    c4478     r4786     -0.03125
    c4478     r6613     -6.103515625e-05
    c4479     r3506     -1
    c4479     r3729     1
    c4479     r4626     -0.03125
    c4479     r4650     -6.103515625e-05
    c4479     r5378     -6.103515625e-05
    c4479     r5617     -6.103515625e-05
    c4480     r3730     1
    c4480     r3756     -1
    c4480     r6070     -6.103515625e-05
    c4480     r6415     -6.103515625e-05
    c4481     r3766     -1
    c4481     r4233     1
    c4481     r4308     -0.03125
    c4482     r3765     1
    c4482     r3768     -1
    c4482     r4967     -0.0256
    c4483     r3769     1
    c4483     r4185     -1
    c4483     r4362     -0.03125
    c4483     r6358     -6.103515625e-05
    c4483     r6570     0.03125
    c4483     r6588     6.103515625e-05
    c4484     r3770     -1
    c4484     r4253     1
    c4484     r4377     -0.03125
    c4484     r6358     6.103515625e-05
    c4484     r6955     0.03125
    c4485     r2987     1
    c4485     r3771     1
    c4485     r3772     -1
    c4485     r6835     0.0001
    c4486     r3776     -1
    c4486     r4255     1
    c4486     r5078     -6.103515625e-05
    c4486     r5925     0.03125
    c4486     r6931     -6.103515625e-05
    c4487     r3780     1
    c4487     r4253     -1
    c4487     r4377     0.03125
    c4487     r6667     -0.0001
    c4487     r6784     -0.0001
    c4487     r6788     -0.0001
    c4488     r3777     1
    c4488     r3788     -1
    c4488     r4448     -0.0008
    c4488     r5426     0.03125
    c4488     r5537     6.103515625e-05
    c4488     r5637     -0.0001
    c4488     r5693     -0.0001
    c4488     r5918     -0.0009765625
    c4488     r6162     0.0001
    c4488     r6252     6.103515625e-05
    c4488     r6432     6.103515625e-05
    c4488     r7007     6.103515625e-05
    c4488     r7024     6.103515625e-05
    c4489     r3368     1
    c4489     r3814     -1
    c4490     r3904     1
    c4490     r3906     -1
    c4490     r4396     -0.0256
    c4491     r3862     1
    c4491     r4056     -1
    c4491     r4837     -6.103515625e-05
    c4492     r3877     -1
    c4492     r3939     1
    c4492     r4975     0.03125
    c4492     r6434     -0.0032
    c4493     r3874     1
    c4493     r3882     -1
    c4493     r4661     -0.0256
    c4493     r5893     6.103515625e-05
    c4493     r6535     6.103515625e-05
    c4493     r6633     6.103515625e-05
    c4494     Obj       -86.3
    c4494     r4276     -1
    c4494     r5089     0.0032
    c4494     r5163     0.0032
    c4494     r5231     0.00390625
    c4494     r5299     0.0032
    c4494     r5520     0.00390625
    c4494     r5696     0.00390625
    c4494     r6077     0.00390625
    c4494     r6699     0.00390625
    c4494     r6757     0.00390625
    c4494     r7049     0.000488357173027066
    c4495     r3234     -1
    c4495     r6874     -6.103515625e-05
    c4496     r4274     -1
    c4496     r4631     -0.0064
    c4496     r7076     -6.103515625e-05
    c4497     Obj       -4
    c4497     r3241     -1
    c4497     r5801     -0.0001
    c4497     r6092     -6.45915125781014e-05
    c4497     r6178     -0.0001
    c4498     r4224     -1
    c4498     r5801     -0.0001
    c4498     r6092     -6.45915125781014e-05
    c4498     r6178     -0.0001
    c4499     r3212     -1
    c4499     r5463     -6.103515625e-05
    c4499     r5565     -6.103515625e-05
    c4499     r6011     -5.78832137753131e-05
    c4499     r6268     -6.103515625e-05
    c4499     r6498     -6.103515625e-05
    c4499     r6857     -6.103515625e-05
    c4499     r6900     -6.103515625e-05
    c4500     Obj       -65.7
    c4500     r4276     -1
    c4500     r5089     0.0032
    c4500     r5163     0.0032
    c4500     r5231     0.00390625
    c4500     r5299     0.0032
    c4500     r5520     0.00390625
    c4500     r5696     0.00390625
    c4500     r6077     0.00390625
    c4500     r6699     0.00390625
    c4500     r6757     0.00390625
    c4500     r7049     0.000488357173027066
    c4501     r4276     -1
    c4501     r4479     -0.00321678596117403
    c4501     r5906     -6.103515625e-05
    c4501     r7049     -0.000488357173027066
    c4502     Obj       -2.769
    c4502     r3244     -1
    c4502     r5020     -6.103515625e-05
    c4502     r6354     -6.103515625e-05
    c4502     r6758     -0.000136246297338497
    c4503     Obj       -2.35
    c4503     r3245     -1
    c4503     r5020     -6.103515625e-05
    c4503     r6354     -6.103515625e-05
    c4503     r6529     -6.103515625e-05
    c4503     r6758     -0.000136246297338497
    c4504     Obj       -48.57
    c4504     r4208     -1
    c4504     r6095     -7.32319388336948e-05
    c4504     r6354     -6.103515625e-05
    c4504     r6759     -8.39874478313481e-05
    c4504     r6812     -8.39920286734662e-05
    c4505     r4220     -1
    c4505     r5801     -0.0001
    c4505     r6178     -0.0001
    c4505     r6354     -6.103515625e-05
    c4506     r3233     -1
    c4506     r7006     -6.103515625e-05
    c4507     Obj       -4.602
    c4507     r3241     -1
    c4507     r5801     -0.0001
    c4507     r6092     -6.45915125781014e-05
    c4507     r6178     -0.0001
    c4508     Obj       2.941
    c4508     r3936     -1
    c4508     r4839     -0.0001
    c4508     r5265     -0.0512
    c4508     r5294     -6.103515625e-05
    c4508     r6356     -6.103515625e-05
    c4508     r6360     -6.103515625e-05
    c4508     r6388     -6.103515625e-05
    c4508     r6433     -6.103515625e-05
    c4508     r6640     -8.39055367669584e-05
    c4508     r6675     -6.103515625e-05
    c4508     r6739     -0.0001220703125
    c4508     r6749     -6.103515625e-05
    c4508     r6753     -0.0001
    c4508     r6807     -5.7205257543362e-05
    c4508     r6886     -0.0001
    c4509     r4280     -1
    c4510     Obj       45
    c4510     r3752     -1
    c4511     r3835     -1
    c4511     r5214     -6.103515625e-05
    c4511     r5436     -6.103515625e-05
    c4512     r4234     -1
    c4513     r3464     -1
    c4513     r4830     -0.0001
    c4513     r5092     -6.103515625e-05
    c4513     r5168     -0.0001
    c4513     r6174     -0.0001
    c4513     r6261     -9.31210667174636e-05
    c4513     r6263     -0.000106825841804308
    c4513     r6346     -9.88672033125734e-05
    c4513     r6422     -0.0001
    c4513     r6423     -6.103515625e-05
    c4513     r6431     -0.000114292604978001
    c4513     r6440     -7.39420869012366e-05
    c4513     r6492     -6.103515625e-05
    c4513     r6493     -7.83571103003273e-05
    c4513     r6552     -0.000104380588267577
    c4513     r6556     -6.03358541432804e-05
    c4513     r6692     -8.46071103003263e-05
    c4513     r6700     -6.09866996136888e-05
    c4513     r6755     -8.46071103003263e-05
    c4513     r6824     -6.103515625e-05
    c4513     r6835     -0.0001
    c4513     r6929     -5.15410025492391e-05
    c4513     r6998     -8.46071103003263e-05
    c4514     r3984     -1
    c4515     Obj       1.222
    c4515     r4044     -1
    c4516     r4052     -1
    c4516     r6583     -6.103515625e-05
    c4517     Obj       -9.14
    c4517     r4260     -1
    c4517     r5603     -0.001953125
    c4517     r5646     -6.103515625e-05
    c4517     r5731     -6.103515625e-05
    c4517     r6094     -6.103515625e-05
    c4517     r6906     -0.001953125
    c4518     r4282     -1
    c4518     r4685     -0.000244140625
    c4518     r5162     -0.0001220703125
    c4518     r5969     -0.000244140625
    c4518     r6308     -0.000244140625
    c4518     r6411     -0.0001220703125
    c4518     r6478     -0.0001220703125
    c4518     r6542     -0.000116344435088454
    c4518     r6547     -8.27375139400187e-05
    c4518     r6625     -0.0001220703125
    c4518     r6632     -8.27375139400187e-05
    c4518     r6684     -6.103515625e-05
    c4519     Obj       -18.225
    c4519     r4095     -1
    c4519     r5688     -0.0032
    c4519     r5863     -6.103515625e-05
    c4519     r5966     -0.0032
    c4519     r6016     -6.103515625e-05
    c4519     r6134     -6.103515625e-05
    c4519     r6307     -0.0032
    c4519     r6434     -0.0032
    c4519     r6868     -0.0001
    c4519     r6884     -6.21482532170052e-05
    c4519     r7028     -6.103515625e-05
    c4520     r4272     -1
    c4520     r5239     -0.0001220703125
    c4520     r5309     -6.103515625e-05
    c4520     r6866     -6.103515625e-05
    c4520     r7035     -6.72799219169098e-05
    c4521     r4283     -1
    c4521     r4448     -0.0008
    c4521     r4831     -0.0001
    c4521     r4901     -0.0008
    c4521     r4932     -0.0001
    c4521     r5637     -0.0001
    c4521     r5692     -6.103515625e-05
    c4521     r5693     -0.0001
    c4521     r5918     -0.0009765625
    c4521     r6558     -0.0001
    c4521     r6856     -0.0001
    c4521     r6931     -6.103515625e-05
    c4521     r6937     -0.000108692704475025
    c4521     r6996     -9.53971836372719e-05
    c4521     r7001     -6.103515625e-05
RHS
    RHS_V     r1508     10000
    RHS_V     r1512     10000
    RHS_V     r1513     10000
    RHS_V     r1514     10000
    RHS_V     r1515     10000
    RHS_V     r1518     10000
    RHS_V     r1519     10000
    RHS_V     r1525     10000
    RHS_V     r1531     10000
    RHS_V     r1540     10000
    RHS_V     r1541     10000
    RHS_V     r1542     10000
    RHS_V     r1543     10000
    RHS_V     r1544     10000
    RHS_V     r1545     10000
    RHS_V     r1546     10000
    RHS_V     r1549     10000
    RHS_V     r1550     10000
    RHS_V     r1552     10000
    RHS_V     r1553     10000
    RHS_V     r1554     10000
    RHS_V     r1556     10000
    RHS_V     r1557     10000
    RHS_V     r1559     10000
    RHS_V     r1564     10000
    RHS_V     r1568     10000
    RHS_V     r1569     10000
    RHS_V     r1572     10000
    RHS_V     r1573     10000
    RHS_V     r1574     10000
    RHS_V     r1575     10000
    RHS_V     r1576     10000
    RHS_V     r1577     10000
    RHS_V     r1578     10000
    RHS_V     r1579     10000
    RHS_V     r1583     10000
    RHS_V     r1588     10000
    RHS_V     r1589     10000
    RHS_V     r1590     10000
    RHS_V     r1599     10000
    RHS_V     r1600     10000
    RHS_V     r1601     10000
    RHS_V     r1602     10000
    RHS_V     r1603     10000
    RHS_V     r1604     10000
    RHS_V     r1605     10000
    RHS_V     r1612     10000
    RHS_V     r1613     10000
    RHS_V     r1614     10000
    RHS_V     r1615     10000
    RHS_V     r1616     10000
    RHS_V     r1617     10000
    RHS_V     r1618     10000
    RHS_V     r1619     10000
    RHS_V     r1620     10000
    RHS_V     r1621     10000
    RHS_V     r1622     10000
    RHS_V     r1623     10000
    RHS_V     r1624     10000
    RHS_V     r1626     10000
    RHS_V     r1627     10000
    RHS_V     r1628     10000
    RHS_V     r1629     10000
    RHS_V     r1635     10000
    RHS_V     r1636     10000
    RHS_V     r1640     10000
    RHS_V     r1646     10000
    RHS_V     r1649     270
    RHS_V     r1651     10000
    RHS_V     r1656     10000
    RHS_V     r1661     10000
    RHS_V     r1667     10000
    RHS_V     r1671     10000
    RHS_V     r1672     10000
    RHS_V     r1676     10000
    RHS_V     r1687     10000
    RHS_V     r1688     10000
    RHS_V     r1689     10000
    RHS_V     r1690     10000
    RHS_V     r1692     10000
    RHS_V     r1694     10000
    RHS_V     r1695     10000
    RHS_V     r1696     10000
    RHS_V     r1698     10000
    RHS_V     r1699     10000
    RHS_V     r1703     10000
    RHS_V     r1708     10000
    RHS_V     r1709     10000
    RHS_V     r1710     10000
    RHS_V     r1712     10000
    RHS_V     r1713     10000
    RHS_V     r1714     10000
    RHS_V     r1716     10000
    RHS_V     r1717     10000
    RHS_V     r1719     10000
    RHS_V     r1720     10000
    RHS_V     r1721     10000
    RHS_V     r1722     10000
    RHS_V     r1723     10000
    RHS_V     r1727     10000
    RHS_V     r1728     10000
    RHS_V     r1730     10000
    RHS_V     r1732     10000
    RHS_V     r1733     10000
    RHS_V     r1734     10000
    RHS_V     r1735     10000
    RHS_V     r1737     10000
    RHS_V     r1739     10000
    RHS_V     r1742     10000
    RHS_V     r1745     10000
    RHS_V     r1746     10000
    RHS_V     r1747     10000
    RHS_V     r1748     10000
    RHS_V     r1749     10000
    RHS_V     r1750     10000
    RHS_V     r1752     10000
    RHS_V     r1753     10000
    RHS_V     r1754     10000
    RHS_V     r1756     10000
    RHS_V     r1760     10000
    RHS_V     r1762     10000
    RHS_V     r1763     10000
    RHS_V     r1765     10000
    RHS_V     r1766     10000
    RHS_V     r1768     10000
    RHS_V     r1771     10000
    RHS_V     r1772     10000
    RHS_V     r1773     10000
    RHS_V     r1774     10000
    RHS_V     r1775     10000
    RHS_V     r1776     10000
    RHS_V     r1778     10000
    RHS_V     r1779     10000
    RHS_V     r1780     10000
    RHS_V     r1782     10000
    RHS_V     r1783     10000
    RHS_V     r1785     10000
    RHS_V     r1787     10000
    RHS_V     r1788     10000
    RHS_V     r1792     10000
    RHS_V     r1795     10000
    RHS_V     r1796     10000
    RHS_V     r1799     10000
    RHS_V     r1809     10000
    RHS_V     r1814     10000
    RHS_V     r1816     10000
    RHS_V     r1818     10000
    RHS_V     r1822     10000
    RHS_V     r1829     10000
    RHS_V     r1830     10000
    RHS_V     r1833     10000
    RHS_V     r1835     10000
    RHS_V     r1840     10000
    RHS_V     r1842     10000
    RHS_V     r1844     10000
    RHS_V     r1845     10000
    RHS_V     r1847     10000
    RHS_V     r1848     10000
    RHS_V     r1849     10000
    RHS_V     r1850     10000
    RHS_V     r1851     10000
    RHS_V     r1853     10000
    RHS_V     r1854     10000
    RHS_V     r1855     10000
    RHS_V     r1856     10000
    RHS_V     r1858     10000
    RHS_V     r1859     10000
    RHS_V     r1862     10000
    RHS_V     r1863     10000
    RHS_V     r1864     10000
    RHS_V     r1866     10000
    RHS_V     r1867     10000
    RHS_V     r1868     10000
    RHS_V     r1869     10000
    RHS_V     r1871     10000
    RHS_V     r1872     10000
    RHS_V     r1873     10000
    RHS_V     r1874     10000
    RHS_V     r1875     10000
    RHS_V     r1876     10000
    RHS_V     r1877     10000
    RHS_V     r1879     10000
    RHS_V     r1880     10000
    RHS_V     r1881     10000
    RHS_V     r1882     10000
    RHS_V     r1883     10000
    RHS_V     r1884     10000
    RHS_V     r1885     10000
    RHS_V     r1886     10000
    RHS_V     r1887     10000
    RHS_V     r1888     10000
    RHS_V     r1889     10000
    RHS_V     r1892     10000
    RHS_V     r1896     10000
    RHS_V     r1897     10000
    RHS_V     r1898     10000
    RHS_V     r1899     10000
    RHS_V     r1901     10000
    RHS_V     r1904     10000
    RHS_V     r1905     10000
    RHS_V     r1906     10000
    RHS_V     r1909     10000
    RHS_V     r1912     10000
    RHS_V     r1913     10000
    RHS_V     r1914     10000
    RHS_V     r1915     10000
    RHS_V     r1916     10000
    RHS_V     r1917     10000
    RHS_V     r1918     10000
    RHS_V     r1919     10000
    RHS_V     r1920     10000
    RHS_V     r1921     10000
    RHS_V     r1922     10000
    RHS_V     r1923     10000
    RHS_V     r1925     10000
    RHS_V     r1926     10000
    RHS_V     r1927     10000
    RHS_V     r1928     10000
    RHS_V     r1929     10000
    RHS_V     r1930     10000
    RHS_V     r1931     10000
    RHS_V     r1935     10000
    RHS_V     r1936     10000
    RHS_V     r1937     10000
    RHS_V     r1938     10000
    RHS_V     r1939     10000
    RHS_V     r1940     10000
    RHS_V     r1941     10000
    RHS_V     r1942     10000
    RHS_V     r1954     10000
    RHS_V     r1961     10000
    RHS_V     r1964     10000
    RHS_V     r1966     10000
    RHS_V     r1971     10000
    RHS_V     r1976     10000
    RHS_V     r1978     10000
    RHS_V     r1979     10000
    RHS_V     r1982     10000
    RHS_V     r1985     10000
    RHS_V     r1986     10000
    RHS_V     r1991     10000
    RHS_V     r1994     10000
    RHS_V     r1995     10000
    RHS_V     r1998     10000
    RHS_V     r2002     10000
    RHS_V     r2012     10000
    RHS_V     r2017     10000
    RHS_V     r2021     10000
    RHS_V     r2032     10000
    RHS_V     r2033     10000
    RHS_V     r2034     10000
    RHS_V     r2035     10000
    RHS_V     r2036     10000
    RHS_V     r2037     10000
    RHS_V     r2039     10000
    RHS_V     r2041     10000
    RHS_V     r2043     10000
    RHS_V     r2045     10000
    RHS_V     r2046     10000
    RHS_V     r2048     10000
    RHS_V     r2056     10000
    RHS_V     r2057     10000
    RHS_V     r2058     10000
    RHS_V     r2059     10000
    RHS_V     r2060     10000
    RHS_V     r2061     10000
    RHS_V     r2062     10000
    RHS_V     r2063     10000
    RHS_V     r2064     10000
    RHS_V     r2065     10000
    RHS_V     r2066     10000
    RHS_V     r2067     10000
    RHS_V     r2068     10000
    RHS_V     r2069     10000
    RHS_V     r2071     10000
    RHS_V     r2072     10000
    RHS_V     r2073     10000
    RHS_V     r2074     10000
    RHS_V     r2075     10000
    RHS_V     r2076     10000
    RHS_V     r2080     10000
    RHS_V     r2081     10000
    RHS_V     r2082     10000
    RHS_V     r2083     10000
    RHS_V     r2084     10000
    RHS_V     r2085     10000
    RHS_V     r2088     10000
    RHS_V     r2089     10000
    RHS_V     r2090     10000
    RHS_V     r2095     10000
    RHS_V     r2096     10000
    RHS_V     r2098     10000
    RHS_V     r2101     10000
    RHS_V     r2102     10000
    RHS_V     r2103     10000
    RHS_V     r2105     10000
    RHS_V     r2106     10000
    RHS_V     r2108     10000
    RHS_V     r2112     10000
    RHS_V     r2113     10000
    RHS_V     r2116     10000
    RHS_V     r2119     10000
    RHS_V     r2123     10000
    RHS_V     r2125     10000
    RHS_V     r2129     10000
    RHS_V     r2135     10000
    RHS_V     r2138     10000
    RHS_V     r2139     10000
    RHS_V     r2140     10000
    RHS_V     r2141     10000
    RHS_V     r2144     10000
    RHS_V     r2145     10000
    RHS_V     r2147     10000
    RHS_V     r2149     10000
    RHS_V     r2150     10000
    RHS_V     r2151     10000
    RHS_V     r2152     10000
    RHS_V     r2153     10000
    RHS_V     r2157     10000
    RHS_V     r2159     10000
    RHS_V     r2162     10000
    RHS_V     r2163     10000
    RHS_V     r2164     10000
    RHS_V     r2166     10000
    RHS_V     r2167     10000
    RHS_V     r2169     10000
    RHS_V     r2175     10000
    RHS_V     r2177     10000
    RHS_V     r2178     10000
    RHS_V     r2179     10000
    RHS_V     r2182     10000
    RHS_V     r2183     10000
    RHS_V     r2184     10000
    RHS_V     r2186     10000
    RHS_V     r2189     10000
    RHS_V     r2192     10000
    RHS_V     r2193     10000
    RHS_V     r2201     10000
    RHS_V     r2203     10000
    RHS_V     r2205     10000
    RHS_V     r2208     10000
    RHS_V     r2209     10000
    RHS_V     r2210     10000
    RHS_V     r2211     10000
    RHS_V     r2219     10000
    RHS_V     r2220     10000
    RHS_V     r2221     10000
    RHS_V     r2225     10000
    RHS_V     r2226     10000
    RHS_V     r2227     10000
    RHS_V     r2229     10000
    RHS_V     r2230     10000
    RHS_V     r2231     10000
    RHS_V     r2234     10000
    RHS_V     r2238     10000
    RHS_V     r2239     10000
    RHS_V     r2240     10000
    RHS_V     r2242     10000
    RHS_V     r2244     10000
    RHS_V     r2246     10000
    RHS_V     r2247     10000
    RHS_V     r2248     10000
    RHS_V     r2259     10000
    RHS_V     r2260     10000
    RHS_V     r2265     10000
    RHS_V     r2266     10000
    RHS_V     r2267     10000
    RHS_V     r2269     68.5362000000005
    RHS_V     r2270     10000
    RHS_V     r2271     10000
    RHS_V     r2275     10000
    RHS_V     r2276     10000
    RHS_V     r2277     10000
    RHS_V     r2278     10000
    RHS_V     r2279     10000
    RHS_V     r2280     10000
    RHS_V     r2281     10000
    RHS_V     r2282     10000
    RHS_V     r2283     10000
    RHS_V     r2284     10000
    RHS_V     r2285     10000
    RHS_V     r2289     10000
    RHS_V     r2290     10000
    RHS_V     r2296     10000
    RHS_V     r2298     10000
    RHS_V     r2299     10000
    RHS_V     r2300     10000
    RHS_V     r2302     10000
    RHS_V     r2303     10000
    RHS_V     r2306     10000
    RHS_V     r2307     10000
    RHS_V     r2308     10000
    RHS_V     r2317     10000
    RHS_V     r2321     10000
    RHS_V     r2324     10000
    RHS_V     r2325     10000
    RHS_V     r2326     10000
    RHS_V     r2327     10000
    RHS_V     r2328     10000
    RHS_V     r2330     10000
    RHS_V     r2332     10000
    RHS_V     r2334     10000
    RHS_V     r2335     10000
    RHS_V     r2343     10000
    RHS_V     r2348     10000
    RHS_V     r2349     10000
    RHS_V     r2352     10000
    RHS_V     r2353     10000
    RHS_V     r2354     10000
    RHS_V     r2355     10000
    RHS_V     r2359     10000
    RHS_V     r2367     10000
    RHS_V     r2379     10000
    RHS_V     r2384     10000
    RHS_V     r2396     10000
    RHS_V     r2404     10000
    RHS_V     r2406     10000
    RHS_V     r2407     10000
    RHS_V     r2410     10000
    RHS_V     r2411     10000
    RHS_V     r2413     10000
    RHS_V     r2415     10000
    RHS_V     r2422     10000
    RHS_V     r2423     10000
    RHS_V     r2425     10000
    RHS_V     r2427     10000
    RHS_V     r2432     10000
    RHS_V     r2435     10000
    RHS_V     r2442     10000
    RHS_V     r2443     10000
    RHS_V     r2448     10000
    RHS_V     r2449     10000
    RHS_V     r2450     10000
    RHS_V     r2451     10000
    RHS_V     r2453     10000
    RHS_V     r2454     10000
    RHS_V     r2455     10000
    RHS_V     r2458     10000
    RHS_V     r2459     10000
    RHS_V     r2460     10000
    RHS_V     r2461     10000
    RHS_V     r2462     10000
    RHS_V     r2463     10000
    RHS_V     r2464     10000
    RHS_V     r2465     10000
    RHS_V     r2473     10000
    RHS_V     r2476     10000
    RHS_V     r2477     10000
    RHS_V     r2478     10000
    RHS_V     r2486     10000
    RHS_V     r2487     10000
    RHS_V     r2488     10000
    RHS_V     r2489     10000
    RHS_V     r2517     270
    RHS_V     r2523     10000
    RHS_V     r2528     10000
    RHS_V     r2542     10000
    RHS_V     r2563     10000
    RHS_V     r2582     10000
    RHS_V     r2677     10000
    RHS_V     r2782     10000
    RHS_V     r2815     10000
    RHS_V     r2816     10000
    RHS_V     r2830     10000
    RHS_V     r2859     10000
    RHS_V     r2860     10000
    RHS_V     r2864     10000
    RHS_V     r2884     10000
    RHS_V     r2901     10000
    RHS_V     r2903     10000
    RHS_V     r2912     10000
    RHS_V     r2913     10000
    RHS_V     r2914     10000
    RHS_V     r2915     10000
    RHS_V     r2916     10000
    RHS_V     r2917     10000
    RHS_V     r2918     10000
    RHS_V     r2919     10000
    RHS_V     r2920     10000
    RHS_V     r2921     10000
    RHS_V     r2922     10000
    RHS_V     r2923     10000
    RHS_V     r2924     10000
    RHS_V     r2925     10000
    RHS_V     r2926     10000
    RHS_V     r2927     10000
    RHS_V     r2928     10000
    RHS_V     r2929     10000
    RHS_V     r2930     10000
    RHS_V     r2931     10000
    RHS_V     r2932     10000
    RHS_V     r2933     10000
    RHS_V     r2934     10000
    RHS_V     r2935     10000
    RHS_V     r2936     10000
    RHS_V     r2937     10000
    RHS_V     r2941     10000
    RHS_V     r2987     10000
    RHS_V     r3029     28.965897
    RHS_V     r3045     -0.28167
    RHS_V     r3059     -14.597
    RHS_V     r3061     -3.9304
    RHS_V     r3062     -6.156
    RHS_V     r3067     -0.13784
    RHS_V     r3072     -1.472842
    RHS_V     r3075     -4.924471
    RHS_V     r3081     -0.14675
    RHS_V     r3086     -8.4808
    RHS_V     r3091     -0.052951
    RHS_V     r3094     -2.0369
    RHS_V     r3125     -2.397
    RHS_V     r3133     -0.575331
    RHS_V     r3135     -0.30572
    RHS_V     r3140     -0.065443
    RHS_V     r3144     -1.266
    RHS_V     r3148     -4.34985
    RHS_V     r3150     -13.038259
    RHS_V     r3172     -28.55625
    RHS_V     r3183     -12.501
    RHS_V     r3193     -0.54359
    RHS_V     r3196     -8.9018
    RHS_V     r3210     -0.027651
    RHS_V     r3212     -319.004966
    RHS_V     r3236     -25.187
    RHS_V     r3240     -7.013534
    RHS_V     r3249     -0.13508
    RHS_V     r3327     -105.98
    RHS_V     r3447     -1.328
    RHS_V     r3450     -0.47107
    RHS_V     r3451     -7.9027
    RHS_V     r3452     -29.938
    RHS_V     r3453     -1.0594
    RHS_V     r3454     -179.63
    RHS_V     r3456     -77.436
    RHS_V     r3457     -141.77
    RHS_V     r3458     -40.131
    RHS_V     r3459     -41.158
    RHS_V     r3483     -2.1245
    RHS_V     r3517     -19.779
    RHS_V     r3522     -5.6008
    RHS_V     r3526     -0.22674
    RHS_V     r3538     -13.485859
    RHS_V     r3544     -9.2153
    RHS_V     r3574     -8.03195
    RHS_V     r3579     -0.47976
    RHS_V     r3581     -0.78326
    RHS_V     r3582     -0.45958
    RHS_V     r3599     -6.170526
    RHS_V     r3606     -3.0659
    RHS_V     r3612     -3.6565
    RHS_V     r3671     -17.661
    RHS_V     r3672     -10.466
    RHS_V     r3674     -1.2293
    RHS_V     r3675     -3.644
    RHS_V     r3684     -0.72854
    RHS_V     r3685     -5.443059
    RHS_V     r3686     -0.40515
    RHS_V     r3702     -57.109
    RHS_V     r3703     -5.4914
    RHS_V     r3704     -2.1915
    RHS_V     r3709     -2.6654
    RHS_V     r3716     -26.026126
    RHS_V     r3743     -4
    RHS_V     r3752     -100.44
    RHS_V     r3923     -548.5
    RHS_V     r3926     -0.17561
    RHS_V     r3931     -20.836508
    RHS_V     r3936     -282.82095
    RHS_V     r3950     -211.66984
    RHS_V     r3952     -25.907
    RHS_V     r3970     -19.324
    RHS_V     r3973     -30.494
    RHS_V     r3985     -6.28723
    RHS_V     r3989     -7.1218
    RHS_V     r3993     -13.744073
    RHS_V     r3998     -79.228
    RHS_V     r4011     -0.5856
    RHS_V     r4012     -32.551
    RHS_V     r4013     -12.396
    RHS_V     r4015     -2.2541
    RHS_V     r4016     -0.64534
    RHS_V     r4020     -0.66765
    RHS_V     r4023     -35.862
    RHS_V     r4024     -0.68513
    RHS_V     r4026     -1.6922
    RHS_V     r4028     -0.96073
    RHS_V     r4031     -4.2092
    RHS_V     r4033     -18.625
    RHS_V     r4034     -66.1554
    RHS_V     r4037     -1.9449
    RHS_V     r4041     -5.0143
    RHS_V     r4044     -152.7
    RHS_V     r4058     -5.672161
    RHS_V     r4065     -204.55
    RHS_V     r4066     -3.2365
    RHS_V     r4069     -13.20615
    RHS_V     r4072     -23.134
    RHS_V     r4080     -3.6674
    RHS_V     r4096     -103.93
    RHS_V     r4106     -3.8908
    RHS_V     r4107     -0.77751
    RHS_V     r4108     -0.46867
    RHS_V     r4109     -71.958057
    RHS_V     r4116     -33.64807
    RHS_V     r4144     -116.69
    RHS_V     r4154     -107.56
    RHS_V     r4158     -11.749
    RHS_V     r4161     -9.7005
    RHS_V     r4163     -1.69
    RHS_V     r4171     -3.2052
    RHS_V     r4175     -11.65
    RHS_V     r4179     -4.6857
    RHS_V     r4186     -106.5475
    RHS_V     r4208     -188.437187
    RHS_V     r4209     -5.2759
    RHS_V     r4210     -2.0011
    RHS_V     r4212     -3.3935
    RHS_V     r4214     -25.458332
    RHS_V     r4219     -40.327823
    RHS_V     r4221     -8.8153
    RHS_V     r4222     -15.328
    RHS_V     r4223     -198.757603
    RHS_V     r4224     -32.8
    RHS_V     r4227     -6.1468
    RHS_V     r4229     -55.287692
    RHS_V     r4230     -293.235186
    RHS_V     r4231     -9.6458
    RHS_V     r4234     -535.064117
    RHS_V     r4235     -36.841
    RHS_V     r4238     -14.284
    RHS_V     r4240     -1.6058
    RHS_V     r4245     -56.963772
    RHS_V     r4247     -13.441
    RHS_V     r4248     -0.46737
    RHS_V     r4249     -114.6
    RHS_V     r4250     -12.516
    RHS_V     r4252     -5.845
    RHS_V     r4254     -0.082749
    RHS_V     r4259     -2.279
    RHS_V     r4260     -160.391466
    RHS_V     r4261     -7.2097
    RHS_V     r4262     -0.10686
    RHS_V     r4263     -0.14693
    RHS_V     r4264     -9.3545
    RHS_V     r4265     -0.16239
    RHS_V     r4266     -7.096
    RHS_V     r4267     -52.218256
    RHS_V     r4268     -490.3911
    RHS_V     r4270     -3.5689
    RHS_V     r4271     -978.5227
    RHS_V     r4272     -336.44
    RHS_V     r4276     -1690.381512
    RHS_V     r4277     1.5423
    RHS_V     r4278     3.7559
    RHS_V     r4299     312.5
    RHS_V     r4300     312.5
    RHS_V     r4358     312.5
    RHS_V     r4359     312.5
    RHS_V     r4363     312.5
    RHS_V     r4375     312.5
    RHS_V     r4392     312.5
    RHS_V     r4393     312.5
    RHS_V     r4394     312.5
    RHS_V     r4395     312.5
    RHS_V     r4398     312.5
    RHS_V     r4399     312.5
    RHS_V     r4400     312.5
    RHS_V     r4401     312.5
    RHS_V     r4402     312.5
    RHS_V     r4404     312.5
    RHS_V     r4405     312.5
    RHS_V     r4407     312.5
    RHS_V     r4408     312.5
    RHS_V     r4409     312.5
    RHS_V     r4412     312.5
    RHS_V     r4415     312.5
    RHS_V     r4416     312.5
    RHS_V     r4417     312.5
    RHS_V     r4419     312.5
    RHS_V     r4421     312.5
    RHS_V     r4423     312.5
    RHS_V     r4425     312.5
    RHS_V     r4426     312.5
    RHS_V     r4427     312.5
    RHS_V     r4428     312.5
    RHS_V     r4431     312.5
    RHS_V     r4432     -0.452121599999998
    RHS_V     r4433     0.356054271999994
    RHS_V     r4438     -0.544580940800003
    RHS_V     r4442     78.125
    RHS_V     r4446     3.456
    RHS_V     r4447     7.24567905185185
    RHS_V     r4448     -0.64354896
    RHS_V     r4449     -0.6880450112
    RHS_V     r4460     -1
    RHS_V     r4461     -1
    RHS_V     r4462     -1
    RHS_V     r4475     -0.275478125000006
    RHS_V     r4479     0.58917103747459
    RHS_V     r4485     2
    RHS_V     r4494     1.35079999998844e-05
    RHS_V     r4495     -0.00259070000000006
    RHS_V     r4534     312.5
    RHS_V     r4535     1
    RHS_V     r4539     312.5
    RHS_V     r4540     312.5
    RHS_V     r4541     312.5
    RHS_V     r4542     312.5
    RHS_V     r4545     312.5
    RHS_V     r4546     312.5
    RHS_V     r4547     312.5
    RHS_V     r4549     312.5
    RHS_V     r4550     312.5
    RHS_V     r4551     312.5
    RHS_V     r4552     312.5
    RHS_V     r4553     312.5
    RHS_V     r4555     312.5
    RHS_V     r4556     -0.00422125000000051
    RHS_V     r4557     312.5
    RHS_V     r4559     312.5
    RHS_V     r4560     0.125
    RHS_V     r4562     0.164871875000017
    RHS_V     r4563     312.4585
    RHS_V     r4564     -0.196475937499997
    RHS_V     r4565     512.13506304
    RHS_V     r4567     156.25
    RHS_V     r4570     -0.53564453125
    RHS_V     r4571     -0.9150472272
    RHS_V     r4572     0.734665624999956
    RHS_V     r4573     270
    RHS_V     r4574     244.541668
    RHS_V     r4575     244.541668
    RHS_V     r4588     -1
    RHS_V     r4605     312.5
    RHS_V     r4606     312.5
    RHS_V     r4608     312.5
    RHS_V     r4609     312.5
    RHS_V     r4610     312.5
    RHS_V     r4612     312.5
    RHS_V     r4613     312.5
    RHS_V     r4615     312.5
    RHS_V     r4616     312.5
    RHS_V     r4620     512
    RHS_V     r4621     512
    RHS_V     r4623     -0.0936063999999988
    RHS_V     r4627     312.5
    RHS_V     r4630     78.125
    RHS_V     r4631     0.769539148799994
    RHS_V     r4633     0.734665624999956
    RHS_V     r4634     -1
    RHS_V     r4635     -1
    RHS_V     r4645     0.6103515625
    RHS_V     r4649     2
    RHS_V     r4667     312.5
    RHS_V     r4669     312.5
    RHS_V     r4670     312.5
    RHS_V     r4672     512
    RHS_V     r4673     512
    RHS_V     r4675     312.5
    RHS_V     r4680     312.5
    RHS_V     r4681     -0.545522534400007
    RHS_V     r4684     -0.603875000000016
    RHS_V     r4685     -0.64038994140625
    RHS_V     r4686     -1
    RHS_V     r4692     78.125
    RHS_V     r4696     0.124756479999974
    RHS_V     r4697     0.0932864000000109
    RHS_V     r4699     2
    RHS_V     r4711     0.0147209374999875
    RHS_V     r4713     312.5
    RHS_V     r4720     256.810431104
    RHS_V     r4722     256.82492672
    RHS_V     r4724     -0.57272497265625
    RHS_V     r4726     39.0625
    RHS_V     r4727     1.22116776562499
    RHS_V     r4728     -0.320025600000008
    RHS_V     r4741     0.6103515625
    RHS_V     r4747     312.5
    RHS_V     r4750     312.5
    RHS_V     r4751     312.5
    RHS_V     r4753     -0.452121599999998
    RHS_V     r4754     -0.828395906250023
    RHS_V     r4756     256
    RHS_V     r4757     0.784687500000004
    RHS_V     r4764     0.00337449291992198
    RHS_V     r4773     312.5
    RHS_V     r4775     -0.281669999999991
    RHS_V     r4789     312.5
    RHS_V     r4790     312.5
    RHS_V     r4791     312.5
    RHS_V     r4793     -0.0625343749999843
    RHS_V     r4794     625
    RHS_V     r4809     0.6103515625
    RHS_V     r4811     0.000383742065429793
    RHS_V     r4816     0.9428095483
    RHS_V     r4817     0.57769387713623
    RHS_V     r4818     0.95096089
    RHS_V     r4819     625
    RHS_V     r4820     0.92002495
    RHS_V     r4821     0.561252673339844
    RHS_V     r4822     -0.0299310974121094
    RHS_V     r4823     0.6103515625
    RHS_V     r4825     1.83911276
    RHS_V     r4828     0.576873779296875
    RHS_V     r4829     1.8856190966
    RHS_V     r4830     1.87356778
    RHS_V     r4831     0.83958133
    RHS_V     r4833     0.94515
    RHS_V     r4839     0.959502849
    RHS_V     r4841     1
    RHS_V     r4842     0.98208965
    RHS_V     r4847     78.125
    RHS_V     r4849     0.605625244140625
    RHS_V     r4850     0.0162961362999998
    RHS_V     r4854     0.6103515625
    RHS_V     r4857     0.943416595458984
    RHS_V     r4862     0.9953227127
    RHS_V     r4863     0.607496772888184
    RHS_V     r4864     0.607496772888184
    RHS_V     r4870     0.98854
    RHS_V     r4871     0.00792279999999979
    RHS_V     r4872     0.6103515625
    RHS_V     r4880     312.5
    RHS_V     r4881     312.5
    RHS_V     r4882     312.5
    RHS_V     r4887     625
    RHS_V     r4888     625
    RHS_V     r4890     312.5
    RHS_V     r4901     -0.64354896
    RHS_V     r4903     0.00302317932128904
    RHS_V     r4904     155.519173859375
    RHS_V     r4906     0.6103515625
    RHS_V     r4914     0.57769387713623
    RHS_V     r4915     0.9141486036
    RHS_V     r4917     1.220703125
    RHS_V     r4918     0.6103515625
    RHS_V     r4919     0.6103515625
    RHS_V     r4920     1.93678389
    RHS_V     r4921     0.550627276611328
    RHS_V     r4922     0.9428095483
    RHS_V     r4924     0.4776204453125
    RHS_V     r4926     1.19077202758789
    RHS_V     r4927     1.9742934
    RHS_V     r4928     1.9742934
    RHS_V     r4930     0.90214773
    RHS_V     r4931     0.550627276611328
    RHS_V     r4932     0.83958133
    RHS_V     r4933     0.0159070563000001
    RHS_V     r4935     312.4585
    RHS_V     r4937     0.6103515625
    RHS_V     r4941     0.6103515625
    RHS_V     r4943     0.6103515625
    RHS_V     r4944     0.6103515625
    RHS_V     r4947     0.886688360098634
    RHS_V     r4948     312.5
    RHS_V     r4957     312.5
    RHS_V     r4960     312.5
    RHS_V     r4961     625
    RHS_V     r4962     -0.125
    RHS_V     r4963     312.5
    RHS_V     r4972     0.863870187499998
    RHS_V     r4976     -0.522522965820312
    RHS_V     r4979     9.22998046875
    RHS_V     r4981     312.5
    RHS_V     r4984     256
    RHS_V     r4986     0.6103515625
    RHS_V     r4992     0.6103515625
    RHS_V     r5005     39.0625
    RHS_V     r5007     0.6103515625
    RHS_V     r5008     0.92002495
    RHS_V     r5009     625
    RHS_V     r5010     1
    RHS_V     r5014     1.220703125
    RHS_V     r5017     1.220703125
    RHS_V     r5019     1.18211907348633
    RHS_V     r5020     0.555490613586426
    RHS_V     r5021     0.6103515625
    RHS_V     r5022     0.0109637451171875
    RHS_V     r5023     0.6103515625
    RHS_V     r5024     0.6103515625
    RHS_V     r5028     0.0158293053
    RHS_V     r5029     0.9914909228
    RHS_V     r5030     0.6103515625
    RHS_V     r5032     128
    RHS_V     r5033     0.6103515625
    RHS_V     r5034     0.605176977539063
    RHS_V     r5045     312.5
    RHS_V     r5046     312.5
    RHS_V     r5047     312.5
    RHS_V     r5051     312.5
    RHS_V     r5053     625
    RHS_V     r5056     63.195076608
    RHS_V     r5057     63.195076608
    RHS_V     r5058     63.195076608
    RHS_V     r5059     63.195076608
    RHS_V     r5060     63.195076608
    RHS_V     r5061     64
    RHS_V     r5062     63.195076608
    RHS_V     r5063     63.172369408
    RHS_V     r5064     -1
    RHS_V     r5065     135.000000000001
    RHS_V     r5073     -0.00487756185845145
    RHS_V     r5074     0.6103515625
    RHS_V     r5075     0.527343750000003
    RHS_V     r5076     0.609915905761719
    RHS_V     r5077     625
    RHS_V     r5078     0.6103515625
    RHS_V     r5079     312.652290625
    RHS_V     r5083     0.6103515625
    RHS_V     r5086     255.17507328
    RHS_V     r5087     -0.556053991210938
    RHS_V     r5088     0.9139943736
    RHS_V     r5089     5.3292208384
    RHS_V     r5090     0.900508154296875
    RHS_V     r5091     0.557952028564453
    RHS_V     r5092     0.601698608398437
    RHS_V     r5093     1.18804540301514
    RHS_V     r5095     -0.0571904517
    RHS_V     r5097     1.24081522905124
    RHS_V     r5098     3.5527136788005e-15
    RHS_V     r5100     0.9203845483
    RHS_V     r5101     0.0158293053
    RHS_V     r5102     0.604008178710937
    RHS_V     r5104     0.00347679272460932
    RHS_V     r5105     0.98854
    RHS_V     r5106     0.98854
    RHS_V     r5107     1.22708520877572
    RHS_V     r5108     0.6103515625
    RHS_V     r5109     1
    RHS_V     r5110     0.605501112670898
    RHS_V     r5111     0.605515869140625
    RHS_V     r5112     0.673141077269325
    RHS_V     r5114     0.886688360098634
    RHS_V     r5121     512
    RHS_V     r5122     312.5
    RHS_V     r5123     312.5
    RHS_V     r5127     312.5
    RHS_V     r5128     -0.412692187499999
    RHS_V     r5129     625
    RHS_V     r5130     -0.192828937499996
    RHS_V     r5131     0.510534374999992
    RHS_V     r5132     -0.604968749999998
    RHS_V     r5136     -0.747082035475346
    RHS_V     r5137     127.94631984
    RHS_V     r5150     0.6103515625
    RHS_V     r5158     77.7595869296875
    RHS_V     r5162     0.900508154296875
    RHS_V     r5163     5.3292208384
    RHS_V     r5164     1.90192178
    RHS_V     r5165     0.6103515625
    RHS_V     r5168     1.93678389
    RHS_V     r5170     23.3601996
    RHS_V     r5175     2.00685362
    RHS_V     r5177     0.6103515625
    RHS_V     r5178     1.48307601743849
    RHS_V     r5183     0.6103515625
    RHS_V     r5187     0.0051935285644531
    RHS_V     r5190     1.3146622135298
    RHS_V     r5191     0.00863349960000015
    RHS_V     r5192     1.220703125
    RHS_V     r5194     0.604008178710937
    RHS_V     r5201     312.5
    RHS_V     r5204     312.5
    RHS_V     r5208     77.462653125
    RHS_V     r5210     0.373683200000016
    RHS_V     r5211     312.5
    RHS_V     r5218     1.220703125
    RHS_V     r5221     0.6103515625
    RHS_V     r5222     1.729802688
    RHS_V     r5231     6.50539653125
    RHS_V     r5239     2.05776024169922
    RHS_V     r5240     0.558511798095703
    RHS_V     r5242     4.98368277655441
    RHS_V     r5245     0.0051935285644531
    RHS_V     r5248     1.24970594374036
    RHS_V     r5251     1.23234537166371
    RHS_V     r5252     0.877151140097383
    RHS_V     r5255     0.603575073242187
    RHS_V     r5258     1.35666592555453
    RHS_V     r5265     -2.84160000000006
    RHS_V     r5268     -0.114606250000008
    RHS_V     r5269     -0.114606250000008
    RHS_V     r5270     -0.114606250000008
    RHS_V     r5271     -0.114606250000008
    RHS_V     r5277     511.8420345344
    RHS_V     r5280     0.591238732799989
    RHS_V     r5292     312.4585
    RHS_V     r5293     2
    RHS_V     r5294     0.593079630126953
    RHS_V     r5296     0.00199427490234372
    RHS_V     r5297     156.25
    RHS_V     r5299     5.3292208384
    RHS_V     r5302     0.630173832012965
    RHS_V     r5304     96.7044867336474
    RHS_V     r5308     0.580420465087891
    RHS_V     r5309     0.530092608642578
    RHS_V     r5314     0.605625244140625
    RHS_V     r5317     0.618713446044922
    RHS_V     r5319     1.18722534179688
    RHS_V     r5320     0.594661499023437
    RHS_V     r5321     0.6103515625
    RHS_V     r5322     0.908075415410216
    RHS_V     r5323     0.00863349960000015
    RHS_V     r5325     18.7018137695312
    RHS_V     r5329     0.603883056640625
    RHS_V     r5337     8.2036123046875
    RHS_V     r5343     312.5
    RHS_V     r5345     312.5
    RHS_V     r5349     40.397312546875
    RHS_V     r5361     -1
    RHS_V     r5363     0.6103515625
    RHS_V     r5367     0.995257037330941
    RHS_V     r5369     -0.94402437119993
    RHS_V     r5371     1.05688804687501
    RHS_V     r5374     1.0557877734375
    RHS_V     r5376     1.0173949666748
    RHS_V     r5378     0.6103515625
    RHS_V     r5379     96.7044867336582
    RHS_V     r5383     0.58031318359375
    RHS_V     r5384     1.22116776562499
    RHS_V     r5385     1.18579680682373
    RHS_V     r5386     4.0208986719546
    RHS_V     r5388     0.59822036114502
    RHS_V     r5393     624.990828125
    RHS_V     r5395     0.6103515625
    RHS_V     r5398     1.19077202758789
    RHS_V     r5399     1.8310546875
    RHS_V     r5401     77.8152259921875
    RHS_V     r5402     1.08083900017217
    RHS_V     r5403     0.0158293053
    RHS_V     r5404     0.6103515625
    RHS_V     r5407     8.81003642578125
    RHS_V     r5408     0.594661499023437
    RHS_V     r5421     511.93176576
    RHS_V     r5425     625
    RHS_V     r5426     312.5
    RHS_V     r5439     0.835623065599975
    RHS_V     r5441     1.24203317321777
    RHS_V     r5447     2.05476222656251
    RHS_V     r5449     1.220703125
    RHS_V     r5450     1.220703125
    RHS_V     r5453     1.87744161226038
    RHS_V     r5456     1.0768484254456
    RHS_V     r5457     1.19077202758789
    RHS_V     r5458     624.77694375
    RHS_V     r5462     15.0849527728
    RHS_V     r5463     0.590881044555664
    RHS_V     r5468     0.6103515625
    RHS_V     r5469     -0.97304202240008
    RHS_V     r5473     0.552792810005303
    RHS_V     r5475     0.550627276611328
    RHS_V     r5478     0.6103515625
    RHS_V     r5480     0.9742934
    RHS_V     r5482     0.6103515625
    RHS_V     r5483     0.00863349960000015
    RHS_V     r5485     0.600718726623535
    RHS_V     r5487     0.602772441833496
    RHS_V     r5488     0.0095367431640625
    RHS_V     r5490     1.35680207239975
    RHS_V     r5498     -0.111528125000007
    RHS_V     r5499     312.5
    RHS_V     r5507     0.52734375
    RHS_V     r5512     -1
    RHS_V     r5516     156.25
    RHS_V     r5517     312.6315375
    RHS_V     r5520     6.50539653125001
    RHS_V     r5522     0.508697483337402
    RHS_V     r5532     0.6103515625
    RHS_V     r5536     9999.947049
    RHS_V     r5537     1.8310546875
    RHS_V     r5538     39.0625
    RHS_V     r5539     158.440631064426
    RHS_V     r5540     1.27350002953615
    RHS_V     r5546     0.64794297397813
    RHS_V     r5550     1.25832817063211
    RHS_V     r5558     3.00685362
    RHS_V     r5561     1.220703125
    RHS_V     r5563     0.6103515625
    RHS_V     r5565     1.18910140570068
    RHS_V     r5566     0.616820068359375
    RHS_V     r5574     312.5
    RHS_V     r5577     312.5
    RHS_V     r5578     -0.111528125000007
    RHS_V     r5580     -0.412692187499999
    RHS_V     r5583     312.5
    RHS_V     r5584     3.33333333333333
    RHS_V     r5585     3.33333333333333
    RHS_V     r5587     312.34611028125
    RHS_V     r5595     39.756324015625
    RHS_V     r5596     1.22015980224609
    RHS_V     r5599     283.038259
    RHS_V     r5600     0.610368754272461
    RHS_V     r5603     -0.885989554687502
    RHS_V     r5604     0.0139159039999868
    RHS_V     r5613     19.53125
    RHS_V     r5617     0.6103515625
    RHS_V     r5627     0.00836623535156246
    RHS_V     r5628     1.19077202758789
    RHS_V     r5631     0.6103515625
    RHS_V     r5633     2.8400499
    RHS_V     r5637     1.83958133
    RHS_V     r5639     0.00863349960000015
    RHS_V     r5640     0.6103515625
    RHS_V     r5642     0.530794884282887
    RHS_V     r5643     0.6103515625
    RHS_V     r5645     1.82448974609375
    RHS_V     r5646     1.19133457043457
    RHS_V     r5648     312.5
    RHS_V     r5649     312.5
    RHS_V     r5652     312.5
    RHS_V     r5656     -0.114606250000008
    RHS_V     r5657     312.5
    RHS_V     r5662     1024.22788608
    RHS_V     r5664     511.8420345344
    RHS_V     r5674     312.34611028125
    RHS_V     r5680     -0.558500504882812
    RHS_V     r5683     1.51585355829291
    RHS_V     r5686     -1
    RHS_V     r5688     95.4268688
    RHS_V     r5692     1.07397844238281
    RHS_V     r5693     1.83958133
    RHS_V     r5694     1.8310546875
    RHS_V     r5696     6.50539653125001
    RHS_V     r5699     625
    RHS_V     r5702     19.53125
    RHS_V     r5704     0.938249020156315
    RHS_V     r5706     6.59752887228261
    RHS_V     r5708     5.7319972826087
    RHS_V     r5718     1.27350002953615
    RHS_V     r5725     1.27350002953615
    RHS_V     r5726     1.21370849609375
    RHS_V     r5731     1.22407761791992
    RHS_V     r5733     1.000466831
    RHS_V     r5736     312.5
    RHS_V     r5739     312.5
    RHS_V     r5744     511.7635474944
    RHS_V     r5745     625.292328125
    RHS_V     r5748     312.4539736875
    RHS_V     r5750     0.6103515625
    RHS_V     r5759     0.6103515625
    RHS_V     r5787     92.3810519999985
    RHS_V     r5795     2.0688595117
    RHS_V     r5797     1.80112359008789
    RHS_V     r5801     1.0141517852032
    RHS_V     r5802     0.893500761599995
    RHS_V     r5805     0.6103515625
    RHS_V     r5808     0.654695559700624
    RHS_V     r5811     1.22529135131836
    RHS_V     r5813     0.6103515625
    RHS_V     r5824     312.5
    RHS_V     r5826     312.5
    RHS_V     r5836     77.2981646875
    RHS_V     r5837     625
    RHS_V     r5847     312.2891018125
    RHS_V     r5848     312.5
    RHS_V     r5861     -0.65114087500001
    RHS_V     r5863     1.20518328857422
    RHS_V     r5871     2.9990763574
    RHS_V     r5889     0.0067764892578126
    RHS_V     r5893     0.6103515625
    RHS_V     r5894     1.32926432219385
    RHS_V     r5898     1.0040131
    RHS_V     r5901     64
    RHS_V     r5904     1.20857192364502
    RHS_V     r5906     -0.00152587890625
    RHS_V     r5909     0.6103515625
    RHS_V     r5918     17.9646614257813
    RHS_V     r5919     2.98208965
    RHS_V     r5924     312.5
    RHS_V     r5946     0.6103515625
    RHS_V     r5954     0.6103515625
    RHS_V     r5969     1.80101630859375
    RHS_V     r5972     511.8420345344
    RHS_V     r5977     1.56293841452257
    RHS_V     r5979     1.06060563964844
    RHS_V     r5980     2
    RHS_V     r5982     0.596444115600586
    RHS_V     r5985     0.6103515625
    RHS_V     r5988     0.580420465087891
    RHS_V     r5990     0.0299310974121094
    RHS_V     r5999     0.59822036114502
    RHS_V     r6010     0.640282659912109
    RHS_V     r6011     0.578832137753131
    RHS_V     r6016     -0.0109316101074219
    RHS_V     r6022     312.5
    RHS_V     r6026     -0.7229375
    RHS_V     r6028     511.7635474944
    RHS_V     r6029     -0.902719179687502
    RHS_V     r6033     18.5734548828125
    RHS_V     r6035     -0.229212500000017
    RHS_V     r6040     0.608939575195313
    RHS_V     r6044     0.6103515625
    RHS_V     r6051     -0.65114087500001
    RHS_V     r6055     156.760534375
    RHS_V     r6065     2.44140625
    RHS_V     r6067     0.450254077148438
    RHS_V     r6077     6.50539653124998
    RHS_V     r6079     5.76999687589248
    RHS_V     r6081     0.746353770345763
    RHS_V     r6083     2.35161295776367
    RHS_V     r6084     0.631376638307498
    RHS_V     r6086     2.11175124516062
    RHS_V     r6091     0.596467081298828
    RHS_V     r6092     1.23847110368158
    RHS_V     r6093     0.164016900127726
    RHS_V     r6094     -0.00978951818847651
    RHS_V     r6095     0.596551941947623
    RHS_V     r6107     -0.303140625000026
    RHS_V     r6109     19.53125
    RHS_V     r6131     0.6103515625
    RHS_V     r6134     1.20518328857422
    RHS_V     r6138     -1
    RHS_V     r6143     0.6103515625
    RHS_V     r6149     2.65696665955683
    RHS_V     r6150     1.0173949666748
    RHS_V     r6162     1.92002495
    RHS_V     r6164     2.36725147326345
    RHS_V     r6168     1.220703125
    RHS_V     r6170     1.41136135801908
    RHS_V     r6174     3
    RHS_V     r6178     1.0141517852032
    RHS_V     r6179     0.6103515625
    RHS_V     r6182     4.8828125
    RHS_V     r6186     312.5
    RHS_V     r6195     312.625
    RHS_V     r6218     0.986765199218747
    RHS_V     r6224     78.125
    RHS_V     r6225     0.6103515625
    RHS_V     r6239     0.9139943736
    RHS_V     r6252     1.8310546875
    RHS_V     r6257     6.58606487771739
    RHS_V     r6260     0.0067764892578126
    RHS_V     r6261     2.66597515272926
    RHS_V     r6263     2.14789886246581
    RHS_V     r6265     2.32343194996133
    RHS_V     r6268     1.18910140570068
    RHS_V     r6269     1
    RHS_V     r6278     312.5
    RHS_V     r6284     312.5
    RHS_V     r6299     312.4539736875
    RHS_V     r6303     -0.166587499999991
    RHS_V     r6307     31.4268688
    RHS_V     r6308     1.80101630859375
    RHS_V     r6309     0.52734375
    RHS_V     r6312     0.557952028564453
    RHS_V     r6316     0.6103515625
    RHS_V     r6333     0.0067764892578126
    RHS_V     r6336     6.58606487771739
    RHS_V     r6343     1.4450469862435
    RHS_V     r6344     3.011669
    RHS_V     r6345     0.6103515625
    RHS_V     r6346     1.05117203312573
    RHS_V     r6347     0.6103515625
    RHS_V     r6349     0.6103515625
    RHS_V     r6350     0.582582600097656
    RHS_V     r6354     1.45973020794678
    RHS_V     r6355     0.0067764892578126
    RHS_V     r6356     0.607028771972656
    RHS_V     r6357     1.64008149670166
    RHS_V     r6358     1.8310546875
    RHS_V     r6359     1
    RHS_V     r6360     -0.0172620208740235
    RHS_V     r6361     0.610368754272461
    RHS_V     r6366     312.5
    RHS_V     r6367     312.5
    RHS_V     r6368     312.5
    RHS_V     r6370     127.94631984
    RHS_V     r6371     64.3073329758088
    RHS_V     r6372     0.6103515625
    RHS_V     r6373     0.6103515625
    RHS_V     r6374     0.6103515625
    RHS_V     r6375     0.6103515625
    RHS_V     r6376     0.6103515625
    RHS_V     r6377     0.6103515625
    RHS_V     r6378     0.6103515625
    RHS_V     r6379     0.6103515625
    RHS_V     r6381     0.6103515625
    RHS_V     r6383     0.610154022216797
    RHS_V     r6384     0.6103515625
    RHS_V     r6385     0.6103515625
    RHS_V     r6386     0.000756591796875039
    RHS_V     r6387     0.0095367431640625
    RHS_V     r6388     0.606954199829102
    RHS_V     r6389     312.5
    RHS_V     r6390     1
    RHS_V     r6392     0.6103515625
    RHS_V     r6393     3.79062873720876
    RHS_V     r6396     128.751243232
    RHS_V     r6397     127.94631984
    RHS_V     r6398     127.94631984
    RHS_V     r6399     127.94631984
    RHS_V     r6400     127.94631984
    RHS_V     r6401     127.94631984
    RHS_V     r6402     76.82129375
    RHS_V     r6403     115.182404699
    RHS_V     r6404     78.125
    RHS_V     r6406     0.6103515625
    RHS_V     r6407     1.220703125
    RHS_V     r6408     0.557952028564453
    RHS_V     r6410     0.450254077148438
    RHS_V     r6411     0.900508154296875
    RHS_V     r6412     41.3363685632609
    RHS_V     r6413     1.57525286071777
    RHS_V     r6414     0.898088122011248
    RHS_V     r6416     0.6103515625
    RHS_V     r6418     19.45387890625
    RHS_V     r6419     1.45523873279998
    RHS_V     r6420     2.7428402924925
    RHS_V     r6421     0.6103515625
    RHS_V     r6422     3.87356778
    RHS_V     r6423     1.21205017089844
    RHS_V     r6424     156.760534375
    RHS_V     r6425     1.8310546875
    RHS_V     r6426     1.584231796875
    RHS_V     r6429     6.58606487771739
    RHS_V     r6430     1.78115279721318
    RHS_V     r6431     3.06752145491624
    RHS_V     r6432     1.8310546875
    RHS_V     r6433     0.606964111328125
    RHS_V     r6436     2.39874615356445
    RHS_V     r6437     2.56938653930664
    RHS_V     r6438     0.9888974
    RHS_V     r6439     4.08956176928969
    RHS_V     r6440     2.17151929604531
    RHS_V     r6441     1.67095720214844
    RHS_V     r6442     0.6103515625
    RHS_V     r6443     1.8310546875
    RHS_V     r6444     1.05560503202744
    RHS_V     r6445     1.22121694335937
    RHS_V     r6448     0.38737500000002
    RHS_V     r6451     -0.811666015625001
    RHS_V     r6452     -0.811666015625001
    RHS_V     r6453     39.58984375
    RHS_V     r6454     40.4254871280316
    RHS_V     r6456     -1
    RHS_V     r6457     -1
    RHS_V     r6459     0.000756591796875039
    RHS_V     r6462     0.6103515625
    RHS_V     r6463     0.6103515625
    RHS_V     r6465     0.000756591796875039
    RHS_V     r6466     0.6103515625
    RHS_V     r6467     0.6103515625
    RHS_V     r6469     0.6103515625
    RHS_V     r6470     1.220703125
    RHS_V     r6471     0.9139943736
    RHS_V     r6472     625
    RHS_V     r6473     -0.118003046399991
    RHS_V     r6474     0.6103515625
    RHS_V     r6475     0.557952028564453
    RHS_V     r6476     0.888207234374996
    RHS_V     r6477     0.561758147155762
    RHS_V     r6478     0.900508154296875
    RHS_V     r6479     1.0557877734375
    RHS_V     r6480     2.75156215480753
    RHS_V     r6481     1.91665709056739
    RHS_V     r6482     1
    RHS_V     r6483     0.91552734375
    RHS_V     r6484     1.01097361637984
    RHS_V     r6485     0.6103515625
    RHS_V     r6486     0.0112021911621093
    RHS_V     r6487     0.898088122011248
    RHS_V     r6488     18.7018137695312
    RHS_V     r6489     0.6103515625
    RHS_V     r6490     1.220703125
    RHS_V     r6491     1.0173949666748
    RHS_V     r6492     1.18211907348633
    RHS_V     r6493     2.29283023775982
    RHS_V     r6494     1.220703125
    RHS_V     r6495     0.607669272460938
    RHS_V     r6496     1.77037363798893
    RHS_V     r6497     2.47854233424888
    RHS_V     r6498     0.641953281799316
    RHS_V     r6506     312.792328125
    RHS_V     r6510     -1
    RHS_V     r6511     -1
    RHS_V     r6513     0.6103515625
    RHS_V     r6514     0.610361473999023
    RHS_V     r6515     0.6103515625
    RHS_V     r6517     0.610341651000976
    RHS_V     r6518     0.6103515625
    RHS_V     r6519     1
    RHS_V     r6520     0.6103515625
    RHS_V     r6521     1.19297380859375
    RHS_V     r6522     16.05482896
    RHS_V     r6523     1.10351953124999
    RHS_V     r6524     0.589741767886658
    RHS_V     r6525     1.220703125
    RHS_V     r6526     78.635534375
    RHS_V     r6527     1
    RHS_V     r6528     159.021344480945
    RHS_V     r6529     0.575598188049316
    RHS_V     r6530     0.6103515625
    RHS_V     r6531     39.0636002734375
    RHS_V     r6532     1.85238473571777
    RHS_V     r6535     0.6103515625
    RHS_V     r6539     1.91665709056739
    RHS_V     r6541     0.290156591796875
    RHS_V     r6542     2.02171292051908
    RHS_V     r6543     0.6103515625
    RHS_V     r6545     2.51786041665143
    RHS_V     r6546     1
    RHS_V     r6547     2.26510184130037
    RHS_V     r6548     0.597432260742187
    RHS_V     r6549     1.36870440327383
    RHS_V     r6550     0.6103515625
    RHS_V     r6551     3.79278932733342
    RHS_V     r6552     3.18260495952651
    RHS_V     r6554     0.566723910281602
    RHS_V     r6555     0.959635558098634
    RHS_V     r6556     1.16857011020936
    RHS_V     r6557     0.616820068359375
    RHS_V     r6558     1.75960628
    RHS_V     r6559     0.623805752444274
    RHS_V     r6560     2.12335928062913
    RHS_V     r6561     0.6103515625
    RHS_V     r6562     0.00127889188328201
    RHS_V     r6563     1.80182484924316
    RHS_V     r6564     0.6103515625
    RHS_V     r6565     1.19751663574219
    RHS_V     r6573     625
    RHS_V     r6575     312.5
    RHS_V     r6577     39.326171875
    RHS_V     r6578     32.648
    RHS_V     r6581     312.5
    RHS_V     r6582     -1
    RHS_V     r6586     156.25
    RHS_V     r6587     0.00650314331054691
    RHS_V     r6588     0.6103515625
    RHS_V     r6591     0.6103515625
    RHS_V     r6592     0.6103515625
    RHS_V     r6594     0.6103515625
    RHS_V     r6596     0.6103515625
    RHS_V     r6603     156.760534375
    RHS_V     r6606     78.787346875
    RHS_V     r6610     1.9203845483
    RHS_V     r6615     -1
    RHS_V     r6618     0.6103515625
    RHS_V     r6623     5.87975377257967
    RHS_V     r6625     0.58031318359375
    RHS_V     r6630     0.596683068664551
    RHS_V     r6632     3.09247698070056
    RHS_V     r6633     0.6103515625
    RHS_V     r6634     0.557857894042969
    RHS_V     r6636     0.681192769087579
    RHS_V     r6638     0.617759160134395
    RHS_V     r6640     0.815325124050892
    RHS_V     r6653     312.5
    RHS_V     r6657     -1
    RHS_V     r6660     0.6103515625
    RHS_V     r6661     7.34878443893307
    RHS_V     r6662     0.6103515625
    RHS_V     r6664     1.36948084394415
    RHS_V     r6666     -0.832402343750005
    RHS_V     r6668     0.824788411458333
    RHS_V     r6669     1.19293416259766
    RHS_V     r6670     37.8929729812477
    RHS_V     r6671     -0.718685546875001
    RHS_V     r6672     2.02727952866087
    RHS_V     r6673     624.91670625
    RHS_V     r6674     0.6103515625
    RHS_V     r6675     3.02704031311035
    RHS_V     r6676     -0.0571904516999999
    RHS_V     r6677     0.6103515625
    RHS_V     r6679     3.44532030088524
    RHS_V     r6680     312.5
    RHS_V     r6681     77.9794921875
    RHS_V     r6682     39.0625
    RHS_V     r6683     -0.00258590624997623
    RHS_V     r6684     0.450254077148437
    RHS_V     r6686     0.6103515625
    RHS_V     r6687     78.6703495859375
    RHS_V     r6688     1
    RHS_V     r6689     0.9428095483
    RHS_V     r6690     1.16790622046385
    RHS_V     r6691     0.575598188049316
    RHS_V     r6692     3.33079908809778
    RHS_V     r6693     0.648450501220703
    RHS_V     r6694     1.0557877734375
    RHS_V     r6695     1.23927116712444
    RHS_V     r6696     1.6668999134
    RHS_V     r6697     3.07123841249344
    RHS_V     r6699     6.50539653125
    RHS_V     r6700     1.89156376185566
    RHS_V     r6701     1.79110075012207
    RHS_V     r6702     9.9117158203125
    RHS_V     r6703     0.6103515625
    RHS_V     r6704     0.508697483337402
    RHS_V     r6705     0.000260646639137974
    RHS_V     r6709     312.5
    RHS_V     r6711     312.5
    RHS_V     r6712     312.5
    RHS_V     r6714     0.623056574218751
    RHS_V     r6716     38.1877163945313
    RHS_V     r6721     39.0625
    RHS_V     r6722     625
    RHS_V     r6723     0.6103515625
    RHS_V     r6724     39.0625
    RHS_V     r6725     7.98447228560607
    RHS_V     r6726     5.51757015964899
    RHS_V     r6727     1.220703125
    RHS_V     r6732     0.6103515625
    RHS_V     r6733     0.6103515625
    RHS_V     r6734     0.6103515625
    RHS_V     r6735     0.6103515625
    RHS_V     r6736     3.07308786071777
    RHS_V     r6737     32.7226391724593
    RHS_V     r6739     0.57581760925293
    RHS_V     r6740     0.6103515625
    RHS_V     r6741     1.27350002953615
    RHS_V     r6744     0.625525172634404
    RHS_V     r6745     0.812380537709652
    RHS_V     r6746     0.578261723632812
    RHS_V     r6747     1.220703125
    RHS_V     r6748     1.08009261721078
    RHS_V     r6749     0.593099453125
    RHS_V     r6750     1.72361244244336
    RHS_V     r6752     2.72225183658736
    RHS_V     r6753     -0.00555000000000017
    RHS_V     r6754     0.6103515625
    RHS_V     r6755     1.90608350166763
    RHS_V     r6756     0.6103515625
    RHS_V     r6757     6.50539653125
    RHS_V     r6758     2.34143162734949
    RHS_V     r6759     1.38416033675496
    RHS_V     r6761     1.48082133789062
    RHS_V     r6762     1.99611807140152
    RHS_V     r6763     1.220703125
    RHS_V     r6764     0.6103515625
    RHS_V     r6765     0.6103515625
    RHS_V     r6768     1026
    RHS_V     r6769     512
    RHS_V     r6770     39.326171875
    RHS_V     r6771     -0.827968749999997
    RHS_V     r6774     312.5
    RHS_V     r6777     0.00646850585937497
    RHS_V     r6778     2500
    RHS_V     r6779     -0.000129321289062512
    RHS_V     r6780     0.895094165128908
    RHS_V     r6781     5.31157742055129
    RHS_V     r6784     1
    RHS_V     r6785     37.6580746338339
    RHS_V     r6786     312.5
    RHS_V     r6787     40.007726765625
    RHS_V     r6788     1
    RHS_V     r6790     0.57272497265625
    RHS_V     r6791     1.220703125
    RHS_V     r6792     0.6103515625
    RHS_V     r6797     0.1665500433
    RHS_V     r6800     2.32343194996133
    RHS_V     r6803     1.220703125
    RHS_V     r6804     3.16406250000001
    RHS_V     r6805     3.79987954036038
    RHS_V     r6807     0.828751633973156
    RHS_V     r6808     1.19286950195312
    RHS_V     r6809     1.20776611328125
    RHS_V     r6810     0.636421271115382
    RHS_V     r6812     0.684204304996805
    RHS_V     r6813     0.603883056640625
    RHS_V     r6815     -0.00646850585937497
    RHS_V     r6817     1.21423461914063
    RHS_V     r6818     0.6103515625
    RHS_V     r6819     0.0017446228637696
    RHS_V     r6820     0.611786456298828
    RHS_V     r6821     0.6103515625
    RHS_V     r6822     0.6103515625
    RHS_V     r6823     0.6103515625
    RHS_V     r6824     1.8310546875
    RHS_V     r6825     0.0139159039999868
    RHS_V     r6826     0.557628652099609
    RHS_V     r6828     1.20977151489258
    RHS_V     r6829     0.6103515625
    RHS_V     r6830     0.9974093
    RHS_V     r6831     0.0158293053
    RHS_V     r6832     1.21784833538818
    RHS_V     r6833     0.599419952392578
    RHS_V     r6834     0.6103515625
    RHS_V     r6835     2.0632243849
    RHS_V     r6836     0.000289077431054053
    RHS_V     r6837     4.88939368206522
    RHS_V     r6838     0.52734375
    RHS_V     r6839     4.88939368206522
    RHS_V     r6840     0.6103515625
    RHS_V     r6841     1.220703125
    RHS_V     r6843     1.220703125
    RHS_V     r6844     1.76409912109375
    RHS_V     r6845     0.0095367431640625
    RHS_V     r6846     0.6103515625
    RHS_V     r6847     1.0257066
    RHS_V     r6848     2.70983084240036
    RHS_V     r6849     0.609555770324707
    RHS_V     r6850     1.98854
    RHS_V     r6851     0.603883056640625
    RHS_V     r6852     0.6103515625
    RHS_V     r6853     0.6103515625
    RHS_V     r6854     0.6103515625
    RHS_V     r6855     0.608364807128906
    RHS_V     r6856     1.83958133
    RHS_V     r6857     0.641953281799316
    RHS_V     r6858     0.00823974609375
    RHS_V     r6859     1.21698071289063
    RHS_V     r6860     0.610227239990234
    RHS_V     r6861     0.609759490966797
    RHS_V     r6862     0.673141077269325
    RHS_V     r6863     1.21107028912354
    RHS_V     r6864     1.35680207239975
    RHS_V     r6865     0.00285562500000003
    RHS_V     r6866     1.08860440673828
    RHS_V     r6867     1.21911461633301
    RHS_V     r6868     0.98208965
    RHS_V     r6869     0.548164842468184
    RHS_V     r6870     0.6103515625
    RHS_V     r6871     0.00418311767578125
    RHS_V     r6872     0.609634460449219
    RHS_V     r6874     -0.00871448974609375
    RHS_V     r6875     1.32233340158936
    RHS_V     r6876     4.98317521338203
    RHS_V     r6877     0.598497863037109
    RHS_V     r6878     0.940226619503522
    RHS_V     r6879     1.83401059570312
    RHS_V     r6880     0.6103515625
    RHS_V     r6881     1.19626522790527
    RHS_V     r6882     1.25612372829379
    RHS_V     r6883     3.0517578125
    RHS_V     r6884     0.6103515625
    RHS_V     r6885     0.609759490966797
    RHS_V     r6886     1.959502849
    RHS_V     r6887     -0.902719179687502
    RHS_V     r6888     0.9969621747
    RHS_V     r6889     0.609545523071289
    RHS_V     r6890     624.39371875
    RHS_V     r6891     0.664933453830745
    RHS_V     r6892     1.48307601743849
    RHS_V     r6893     0.608918536865234
    RHS_V     r6894     0.99923435
    RHS_V     r6895     0.0167608333740233
    RHS_V     r6896     0.6103515625
    RHS_V     r6897     0.609416015625
    RHS_V     r6898     1.22057880249023
    RHS_V     r6900     1.18176208911133
    RHS_V     r6902     0.6103515625
    RHS_V     r6903     0.6103515625
    RHS_V     r6904     1.0257066
    RHS_V     r6905     1.20702638653564
    RHS_V     r6906     -0.885989554687502
    RHS_V     r6907     0.0173736198730469
    RHS_V     r6908     0.6103515625
    RHS_V     r6909     0.69263807752336
    RHS_V     r6910     1.8310546875
    RHS_V     r6911     1.21911154064941
    RHS_V     r6912     0.618872649780273
    RHS_V     r6914     0.609587646484375
    RHS_V     r6915     0.609813519287109
    RHS_V     r6916     0.609994812011719
    RHS_V     r6917     0.612345837402344
    RHS_V     r6918     1.220703125
    RHS_V     r6919     18.837425984375
    RHS_V     r6920     1.2131240043335
    RHS_V     r6921     0.6103515625
    RHS_V     r6922     0.609911517333984
    RHS_V     r6926     0.6103515625
    RHS_V     r6927     1.51100760521341
    RHS_V     r6928     1.08833987652909
    RHS_V     r6929     2.48162220863885
    RHS_V     r6930     0.6103515625
    RHS_V     r6931     1.78195579833984
    RHS_V     r6932     0.6103515625
    RHS_V     r6933     0.0013908370000002
    RHS_V     r6934     0.00385421260000007
    RHS_V     r6935     0.609974943481445
    RHS_V     r6937     1.91256365384439
    RHS_V     r6938     1.83453538208008
    RHS_V     r6940     1.21972266235352
    RHS_V     r6941     0.99963435
    RHS_V     r6942     0.99963435
    RHS_V     r6943     0.99963435
    RHS_V     r6944     0.6103515625
    RHS_V     r6947     0.609923490356445
    RHS_V     r6948     0.0225946108445805
    RHS_V     r6953     312.5
    RHS_V     r6954     312.5
    RHS_V     r6957     0.278181249999989
    RHS_V     r6960     256
    RHS_V     r6962     312.5
    RHS_V     r6963     312.5
    RHS_V     r6964     -0.365312500000073
    RHS_V     r6965     624.6346875
    RHS_V     r6966     0.6103515625
    RHS_V     r6967     1.76729729270282
    RHS_V     r6968     0.6103515625
    RHS_V     r6969     39.366343953125
    RHS_V     r6970     2
    RHS_V     r6971     511.8420345344
    RHS_V     r6972     8.6369240936
    RHS_V     r6973     0.623550240463078
    RHS_V     r6974     0.61548701380684
    RHS_V     r6975     0.609837960326052
    RHS_V     r6976     1.8310546875
    RHS_V     r6978     0.9139943736
    RHS_V     r6979     0.90164781829834
    RHS_V     r6980     1.220703125
    RHS_V     r6981     156.4436875
    RHS_V     r6982     0.6103515625
    RHS_V     r6983     1
    RHS_V     r6992     0.6103515625
    RHS_V     r6993     4.963743544
    RHS_V     r6994     0.61038129699707
    RHS_V     r6995     1.60749659960938
    RHS_V     r6996     4.38794245271772
    RHS_V     r6997     1.50376352948426
    RHS_V     r6998     1.9331275299218
    RHS_V     r6999     77.29703125
    RHS_V     r7000     0.0295007615999908
    RHS_V     r7001     1.68433000488281
    RHS_V     r7002     0.9208479936
    RHS_V     r7003     1.220703125
    RHS_V     r7004     0.00953769683837891
    RHS_V     r7006     0.557952028564453
    RHS_V     r7007     1.220703125
    RHS_V     r7008     2.4459679365189
    RHS_V     r7009     0.0139159039999868
    RHS_V     r7010     0.6103515625
    RHS_V     r7011     0.6103515625
    RHS_V     r7012     1.20778382324219
    RHS_V     r7013     1.20977151489258
    RHS_V     r7014     0.6103515625
    RHS_V     r7015     0.945752381336144
    RHS_V     r7016     2.37445068359375
    RHS_V     r7017     0.617759160134395
    RHS_V     r7018     0.617302307128906
    RHS_V     r7019     1.220703125
    RHS_V     r7020     0.0095367431640625
    RHS_V     r7021     0.9734076976
    RHS_V     r7022     1.80926181658594
    RHS_V     r7023     0.609555770324707
    RHS_V     r7024     1.78224179077148
    RHS_V     r7025     0.6103515625
    RHS_V     r7026     0.608939239501953
    RHS_V     r7027     0.6103515625
    RHS_V     r7028     0.599419952392578
    RHS_V     r7029     0.560386452015181
    RHS_V     r7030     1.21884191894531
    RHS_V     r7032     1.220703125
    RHS_V     r7033     0.6103515625
    RHS_V     r7034     0.6103515625
    RHS_V     r7035     1.42855898216864
    RHS_V     r7036     0.600718726623535
    RHS_V     r7037     1.83839981872559
    RHS_V     r7038     0.6103515625
    RHS_V     r7039     0.693053870167377
    RHS_V     r7040     0.6103515625
    RHS_V     r7041     1.77639663696289
    RHS_V     r7042     0.0092218680138505
    RHS_V     r7043     1.23781743019083
    RHS_V     r7044     1.21218203771973
    RHS_V     r7045     0.736086592397152
    RHS_V     r7046     0.00195245788574216
    RHS_V     r7047     0.00474756176757802
    RHS_V     r7048     2.18969924523512
    RHS_V     r7049     4.9729588041842
    RHS_V     r7050     1.21246337890625
    RHS_V     r7051     0.6103515625
    RHS_V     r7052     2
    RHS_V     r7053     0.610009716796875
    RHS_V     r7054     0.6103515625
    RHS_V     r7055     0.609416015625
    RHS_V     r7056     0.6103515625
    RHS_V     r7057     0.615273585161321
    RHS_V     r7058     0.56220122564472
    RHS_V     r7059     1.84728198632607
    RHS_V     r7060     1.41542122146111
    RHS_V     r7061     0.6103515625
    RHS_V     r7062     0.0108410002441406
    RHS_V     r7063     0.6103515625
    RHS_V     r7064     35.3579260259357
    RHS_V     r7065     0.609640502929687
    RHS_V     r7066     -0.65114087500001
    RHS_V     r7067     0.6103515625
    RHS_V     r7068     18.837425984375
    RHS_V     r7069     0.6103515625
    RHS_V     r7070     1.21561052246094
    RHS_V     r7071     -0.00127175952148439
    RHS_V     r7072     0.0107294693008963
    RHS_V     r7073     0.0189363462880413
    RHS_V     r7074     0.6103515625
    RHS_V     r7075     0.6103515625
    RHS_V     r7076     0.610889605712891
    RHS_V     r7077     0.6103515625
    RHS_V     r7078     0.824691109035326
    RHS_V     r7079     0.610155932617187
    RHS_V     r7080     0.609994812011719
    RHS_V     r7081     1
    RHS_V     r7082     0.6103515625
    RHS_V     r7083     1.0177618948
    RHS_V     r7084     511.93176576
    RHS_V     r7086     1.34203415729482
    RHS_V     r7087     1.51100760521324
BOUNDS
 UP BOUND     c0        10000
 UP BOUND     c1        10000
 UP BOUND     c2        10000
 UP BOUND     c3        10000
 UP BOUND     c4        10000
 UP BOUND     c5        10000
 UP BOUND     c6        10000
 UP BOUND     c7        10000
 UP BOUND     c8        10000
 UP BOUND     c9        10000
 UP BOUND     c10       10000
 UP BOUND     c11       10000
 UP BOUND     c12       10000
 UP BOUND     c13       10000
 UP BOUND     c14       10000
 UP BOUND     c15       10000
 UP BOUND     c16       10000
 UP BOUND     c17       10000
 UP BOUND     c18       10000
 UP BOUND     c19       10000
 UP BOUND     c20       10000
 UP BOUND     c21       10000
 UP BOUND     c22       10000
 UP BOUND     c23       10000
 UP BOUND     c24       10000
 UP BOUND     c25       10000
 UP BOUND     c26       10000
 UP BOUND     c27       10000
 UP BOUND     c28       10000
 UP BOUND     c29       10000
 UP BOUND     c30       10000
 UP BOUND     c31       10000
 UP BOUND     c32       10000
 UP BOUND     c33       10000
 UP BOUND     c34       10000
 UP BOUND     c35       10000
 UP BOUND     c36       10000
 UP BOUND     c37       10000
 UP BOUND     c38       10000
 UP BOUND     c39       10000
 UP BOUND     c40       10000
 UP BOUND     c41       10000
 FX BOUND     c42       0
 UP BOUND     c43       10000
 UP BOUND     c44       10000
 UP BOUND     c45       10000
 UP BOUND     c46       10000
 UP BOUND     c47       10000
 UP BOUND     c48       10000
 UP BOUND     c49       10000
 UP BOUND     c50       10000
 UP BOUND     c51       10000
 UP BOUND     c52       10000
 UP BOUND     c53       10000
 UP BOUND     c54       10000
 UP BOUND     c55       10000
 UP BOUND     c56       10000
 UP BOUND     c57       10000
 UP BOUND     c58       10000
 UP BOUND     c59       10000
 UP BOUND     c60       10000
 UP BOUND     c61       10000
 UP BOUND     c62       10000
 UP BOUND     c63       10000
 UP BOUND     c64       10000
 UP BOUND     c65       10000
 UP BOUND     c66       10000
 UP BOUND     c67       10000
 UP BOUND     c68       10000
 UP BOUND     c69       10000
 UP BOUND     c70       10000
 UP BOUND     c71       10000
 UP BOUND     c72       10000
 UP BOUND     c73       10000
 UP BOUND     c74       10000
 UP BOUND     c75       10000
 UP BOUND     c76       10000
 UP BOUND     c77       10000
 FX BOUND     c78       0
 UP BOUND     c79       52.0379990000008
 UP BOUND     c80       10000
 UP BOUND     c81       10000
 UP BOUND     c82       10000
 UP BOUND     c83       10000
 UP BOUND     c84       10000
 UP BOUND     c85       10000
 UP BOUND     c86       10000
 UP BOUND     c87       10000
 UP BOUND     c88       10000
 UP BOUND     c89       10000
 UP BOUND     c90       10000
 UP BOUND     c91       10000
 UP BOUND     c92       10000
 UP BOUND     c93       10000
 UP BOUND     c94       10000
 UP BOUND     c95       10000
 UP BOUND     c96       10000
 UP BOUND     c97       10000
 UP BOUND     c98       10000
 UP BOUND     c99       10000
 UP BOUND     c100      10000
 UP BOUND     c101      10000
 UP BOUND     c102      10000
 UP BOUND     c103      10000
 UP BOUND     c104      10000
 UP BOUND     c105      10000
 UP BOUND     c106      10000
 UP BOUND     c107      10000
 UP BOUND     c108      10000
 UP BOUND     c109      10000
 UP BOUND     c110      10000
 UP BOUND     c111      10000
 UP BOUND     c112      10000
 UP BOUND     c113      10000
 UP BOUND     c114      10000
 UP BOUND     c115      10000
 UP BOUND     c116      10000
 UP BOUND     c117      10000
 UP BOUND     c118      10000
 UP BOUND     c119      10000
 UP BOUND     c120      10000
 UP BOUND     c121      10000
 UP BOUND     c122      10000
 UP BOUND     c123      10000
 UP BOUND     c124      10000
 UP BOUND     c125      10000
 UP BOUND     c126      10000
 UP BOUND     c127      10000
 UP BOUND     c128      10000
 UP BOUND     c129      10000
 UP BOUND     c130      10000
 UP BOUND     c131      10000
 UP BOUND     c132      10000
 UP BOUND     c133      10000
 UP BOUND     c134      10000
 UP BOUND     c135      10000
 UP BOUND     c136      10000
 UP BOUND     c137      10000
 FX BOUND     c138      0
 UP BOUND     c139      10000
 UP BOUND     c140      10000
 UP BOUND     c141      10000
 UP BOUND     c142      10000
 UP BOUND     c143      10000
 UP BOUND     c144      10000
 UP BOUND     c145      10000
 UP BOUND     c146      10000
 UP BOUND     c147      10000
 UP BOUND     c148      10000
 UP BOUND     c149      10000
 UP BOUND     c150      10000
 UP BOUND     c151      10000
 UP BOUND     c152      10000
 UP BOUND     c153      10000
 UP BOUND     c154      10000
 UP BOUND     c155      10000
 UP BOUND     c156      10000
 UP BOUND     c157      10000
 UP BOUND     c158      10000
 UP BOUND     c159      10000
 UP BOUND     c160      10000
 UP BOUND     c161      10000
 UP BOUND     c162      10000
 UP BOUND     c163      10000
 UP BOUND     c164      10000
 UP BOUND     c165      10000
 UP BOUND     c166      10000
 UP BOUND     c167      10000
 UP BOUND     c168      10000
 UP BOUND     c169      10000
 UP BOUND     c170      10000
 UP BOUND     c171      10000
 UP BOUND     c172      10000
 UP BOUND     c173      10000
 UP BOUND     c174      10000
 UP BOUND     c175      10000
 UP BOUND     c176      10000
 UP BOUND     c177      10000
 UP BOUND     c178      10000
 UP BOUND     c179      10000
 UP BOUND     c180      10000
 UP BOUND     c181      10000
 UP BOUND     c182      10000
 UP BOUND     c183      10000
 UP BOUND     c184      10000
 UP BOUND     c185      10000
 UP BOUND     c186      10000
 UP BOUND     c187      10000
 UP BOUND     c188      10000
 FX BOUND     c189      0
 UP BOUND     c190      10000
 UP BOUND     c191      10000
 UP BOUND     c192      10000
 UP BOUND     c193      10000
 FX BOUND     c194      0
 UP BOUND     c195      10000
 UP BOUND     c196      10000
 UP BOUND     c197      10000
 UP BOUND     c198      10000
 UP BOUND     c199      10000
 UP BOUND     c200      10000
 FX BOUND     c201      0
 UP BOUND     c202      10000
 UP BOUND     c203      10000
 UP BOUND     c204      10000
 UP BOUND     c205      10000
 UP BOUND     c206      10000
 UP BOUND     c207      10000
 UP BOUND     c208      10000
 UP BOUND     c209      10000
 UP BOUND     c210      10000
 UP BOUND     c211      10000
 FX BOUND     c212      0
 UP BOUND     c213      10000
 UP BOUND     c214      10000
 UP BOUND     c215      10000
 UP BOUND     c216      10000
 UP BOUND     c217      10000
 UP BOUND     c218      10000
 UP BOUND     c219      10000
 UP BOUND     c220      10000
 UP BOUND     c221      10000
 UP BOUND     c222      10000
 UP BOUND     c223      10000
 UP BOUND     c224      10000
 UP BOUND     c225      10000
 UP BOUND     c226      10000
 UP BOUND     c227      10000
 UP BOUND     c228      10000
 UP BOUND     c229      10000
 UP BOUND     c230      10000
 UP BOUND     c231      10000
 UP BOUND     c232      10000
 UP BOUND     c233      10000
 UP BOUND     c234      10000
 UP BOUND     c235      10000
 UP BOUND     c236      10000
 UP BOUND     c237      10000
 UP BOUND     c238      10000
 UP BOUND     c239      10000
 UP BOUND     c240      10000
 FX BOUND     c241      68.5362
 UP BOUND     c242      10000
 UP BOUND     c243      10000
 UP BOUND     c244      10000
 UP BOUND     c245      10000
 UP BOUND     c246      10000
 UP BOUND     c247      10000
 UP BOUND     c248      10000
 UP BOUND     c249      10000
 UP BOUND     c250      10000
 UP BOUND     c251      10000
 UP BOUND     c252      10000
 UP BOUND     c253      10000
 UP BOUND     c254      10000
 UP BOUND     c255      10000
 UP BOUND     c256      10000
 UP BOUND     c257      10000
 UP BOUND     c258      10000
 UP BOUND     c259      10000
 UP BOUND     c260      10000
 UP BOUND     c261      10000
 UP BOUND     c262      10000
 UP BOUND     c263      10000
 UP BOUND     c264      10000
 UP BOUND     c265      10000
 UP BOUND     c266      10000
 UP BOUND     c267      10000
 UP BOUND     c268      10000
 UP BOUND     c269      10000
 UP BOUND     c270      10000
 UP BOUND     c271      10000
 UP BOUND     c272      10000
 UP BOUND     c273      10000
 UP BOUND     c274      10000
 UP BOUND     c275      10000
 UP BOUND     c276      10000
 UP BOUND     c277      10000
 UP BOUND     c278      10000
 UP BOUND     c279      10000
 UP BOUND     c280      10000
 UP BOUND     c281      10000
 UP BOUND     c282      10000
 UP BOUND     c283      10000
 UP BOUND     c284      10000
 UP BOUND     c285      10000
 UP BOUND     c286      10000
 UP BOUND     c287      10000
 UP BOUND     c288      10000
 UP BOUND     c289      10000
 UP BOUND     c290      10000
 UP BOUND     c291      10000
 UP BOUND     c292      10000
 FX BOUND     c293      0
 UP BOUND     c294      10000
 UP BOUND     c295      10000
 UP BOUND     c296      10000
 UP BOUND     c297      10000
 UP BOUND     c298      10000
 UP BOUND     c299      10000
 UP BOUND     c300      10000
 UP BOUND     c301      10000
 UP BOUND     c302      10000
 UP BOUND     c303      10000
 UP BOUND     c304      10000
 UP BOUND     c305      10000
 UP BOUND     c306      10000
 UP BOUND     c307      10000
 UP BOUND     c308      10000
 UP BOUND     c309      10000
 UP BOUND     c310      10000
 UP BOUND     c311      10000
 UP BOUND     c312      10000
 UP BOUND     c313      10000
 UP BOUND     c314      10000
 UP BOUND     c315      10000
 UP BOUND     c316      10000
 UP BOUND     c317      10000
 UP BOUND     c318      10000
 UP BOUND     c319      10000
 UP BOUND     c320      10000
 UP BOUND     c321      10000
 UP BOUND     c322      10000
 UP BOUND     c323      10000
 UP BOUND     c324      10000
 FX BOUND     c325      0
 UP BOUND     c326      10000
 UP BOUND     c327      10000
 UP BOUND     c328      10000
 UP BOUND     c329      10000
 UP BOUND     c330      10000
 UP BOUND     c331      10000
 UP BOUND     c332      10000
 UP BOUND     c333      10000
 UP BOUND     c334      10000
 UP BOUND     c335      10000
 UP BOUND     c336      10000
 FX BOUND     c337      0
 UP BOUND     c338      10000
 UP BOUND     c339      10000
 UP BOUND     c340      10000
 UP BOUND     c341      10000
 UP BOUND     c342      10000
 UP BOUND     c343      10000
 UP BOUND     c344      10000
 UP BOUND     c345      10000
 UP BOUND     c346      10000
 UP BOUND     c347      10000
 UP BOUND     c348      10000
 UP BOUND     c349      10000
 UP BOUND     c350      10000
 UP BOUND     c351      10000
 UP BOUND     c352      10000
 UP BOUND     c353      10000
 UP BOUND     c354      10000
 UP BOUND     c355      10000
 UP BOUND     c356      10000
 UP BOUND     c357      10000
 UP BOUND     c358      10000
 UP BOUND     c359      10000
 UP BOUND     c360      10000
 UP BOUND     c361      10000
 FX BOUND     c362      0
 UP BOUND     c363      10000
 UP BOUND     c364      10000
 UP BOUND     c365      10000
 UP BOUND     c366      10000
 UP BOUND     c367      10000
 UP BOUND     c368      10000
 UP BOUND     c369      10000
 UP BOUND     c370      10000
 UP BOUND     c371      10000
 UP BOUND     c372      10000
 UP BOUND     c373      10000
 UP BOUND     c374      10000
 UP BOUND     c375      10000
 UP BOUND     c376      10000
 UP BOUND     c377      10000
 UP BOUND     c378      10000
 UP BOUND     c379      10000
 UP BOUND     c380      10000
 UP BOUND     c381      10000
 UP BOUND     c382      10000
 UP BOUND     c383      10000
 UP BOUND     c384      10000
 UP BOUND     c385      10000
 UP BOUND     c386      10000
 UP BOUND     c387      10000
 UP BOUND     c388      10000
 UP BOUND     c389      10000
 UP BOUND     c390      10000
 UP BOUND     c391      10000
 UP BOUND     c392      10000
 UP BOUND     c393      10000
 UP BOUND     c394      10000
 UP BOUND     c395      10000
 UP BOUND     c396      10000
 UP BOUND     c397      10000
 UP BOUND     c398      10000
 UP BOUND     c399      10000
 UP BOUND     c400      10000
 UP BOUND     c401      10000
 FX BOUND     c402      0
 UP BOUND     c403      10000
 UP BOUND     c404      10000
 UP BOUND     c405      10000
 UP BOUND     c406      10000
 UP BOUND     c407      10000
 UP BOUND     c408      10000
 UP BOUND     c409      10000
 UP BOUND     c410      10000
 UP BOUND     c411      10000
 UP BOUND     c412      10000
 UP BOUND     c413      10000
 UP BOUND     c414      10000
 UP BOUND     c415      10000
 UP BOUND     c416      10000
 UP BOUND     c417      10000
 UP BOUND     c418      10000
 UP BOUND     c419      10000
 UP BOUND     c420      10000
 UP BOUND     c421      10000
 UP BOUND     c422      10000
 UP BOUND     c423      10000
 UP BOUND     c424      10000
 UP BOUND     c425      10000
 UP BOUND     c426      10000
 UP BOUND     c427      10000
 UP BOUND     c428      10000
 UP BOUND     c429      10000
 UP BOUND     c430      10000
 UP BOUND     c431      10000
 UP BOUND     c432      10000
 UP BOUND     c433      270
 UP BOUND     c434      10000
 UP BOUND     c435      10000
 UP BOUND     c436      10000
 FX BOUND     c437      110.484208
 UP BOUND     c438      10000
 UP BOUND     c439      10000
 FX BOUND     c440      119.299507999999
 UP BOUND     c441      10000
 FX BOUND     c442      0
 UP BOUND     c443      10000
 UP BOUND     c444      177.618948
 UP BOUND     c445      206.430342
 UP BOUND     c446      206.712012
 UP BOUND     c447      10000
 UP BOUND     c448      206.712012
 UP BOUND     c449      10000
 UP BOUND     c450      10000
 UP BOUND     c451      10000
 UP BOUND     c452      10000
 UP BOUND     c453      135
 UP BOUND     c454      10000
 UP BOUND     c455      10000
 UP BOUND     c456      10000
 UP BOUND     c457      10000
 UP BOUND     c458      10000
 UP BOUND     c459      10000
 UP BOUND     c460      10000
 UP BOUND     c461      10000
 UP BOUND     c462      10000
 UP BOUND     c463      10000
 UP BOUND     c464      10000
 UP BOUND     c465      10000
 UP BOUND     c466      10000
 UP BOUND     c467      10000
 UP BOUND     c468      10000
 UP BOUND     c469      10000
 UP BOUND     c470      10000
 UP BOUND     c471      177.618948
 UP BOUND     c472      10000
 UP BOUND     c473      10000
 UP BOUND     c474      10000
 UP BOUND     c475      274.609493999999
 UP BOUND     c476      10000
 UP BOUND     c477      10000
 UP BOUND     c478      10000
 UP BOUND     c479      10000
 UP BOUND     c480      10000
 UP BOUND     c481      10000
 UP BOUND     c482      10000
 UP BOUND     c483      10000
 UP BOUND     c484      10000
 UP BOUND     c485      10000
 UP BOUND     c486      10000
 UP BOUND     c487      10000
 UP BOUND     c488      10000
 UP BOUND     c489      10000
 UP BOUND     c490      10000
 UP BOUND     c491      10000
 UP BOUND     c492      10000
 UP BOUND     c493      10000
 UP BOUND     c494      10000
 UP BOUND     c495      10000
 UP BOUND     c496      10000
 UP BOUND     c497      10000
 UP BOUND     c498      10000
 UP BOUND     c499      10000
 UP BOUND     c500      10000
 UP BOUND     c501      10000
 UP BOUND     c502      10000
 UP BOUND     c503      10000
 UP BOUND     c504      10000
 UP BOUND     c505      10000
 FX BOUND     c506      0
 FX BOUND     c507      0
 UP BOUND     c508      10000
 UP BOUND     c509      10000
 UP BOUND     c510      10000
 UP BOUND     c511      10000
 UP BOUND     c512      135
 UP BOUND     c513      10000
 UP BOUND     c514      10000
 UP BOUND     c515      139.609493999999
 UP BOUND     c516      139.609493999999
 UP BOUND     c517      139.609493999999
 UP BOUND     c518      10000
 UP BOUND     c519      10000
 UP BOUND     c520      10000
 UP BOUND     c521      10000
 UP BOUND     c522      10000
 UP BOUND     c523      10000
 UP BOUND     c524      10000
 UP BOUND     c525      10000
 FX BOUND     c526      0
 UP BOUND     c527      10000
 UP BOUND     c528      10000
 UP BOUND     c529      10000
 UP BOUND     c530      10000
 UP BOUND     c531      10000
 UP BOUND     c532      10000
 UP BOUND     c533      10000
 UP BOUND     c534      10000
 UP BOUND     c535      10000
 UP BOUND     c536      10000
 UP BOUND     c537      10000
 UP BOUND     c538      10000
 UP BOUND     c539      10000
 UP BOUND     c540      10000
 UP BOUND     c541      10000
 UP BOUND     c542      10000
 UP BOUND     c543      10000
 UP BOUND     c544      10000
 UP BOUND     c545      10000
 UP BOUND     c546      10000
 UP BOUND     c547      10000
 UP BOUND     c548      10000
 UP BOUND     c549      10000
 FX BOUND     c550      0
 FX BOUND     c551      0
 FX BOUND     c552      0
 UP BOUND     c553      10000
 UP BOUND     c554      10000
 UP BOUND     c555      295.458332
 UP BOUND     c556      287.388109
 UP BOUND     c557      10000
 FX BOUND     c558      13.038259
 UP BOUND     c559      13.0382590000008
 UP BOUND     c560      270
 UP BOUND     c561      270
 UP BOUND     c562      10000
 FX BOUND     c563      10000
 UP BOUND     c564      270
 UP BOUND     c565      270
 UP BOUND     c566      270
 UP BOUND     c567      287.388109
 UP BOUND     c568      10000
 FX BOUND     c569      0
 UP BOUND     c570      10000
 UP BOUND     c571      10000
 UP BOUND     c572      10000
 UP BOUND     c573      10000
 UP BOUND     c574      10000
 UP BOUND     c575      327.215947999998
 FX BOUND     c576      0
 FX BOUND     c577      0
 UP BOUND     c578      10000
 UP BOUND     c579      10000
 UP BOUND     c580      10000
 FX BOUND     c581      0
 UP BOUND     c582      10000
 FX BOUND     c583      0
 FX BOUND     c584      0
 UP BOUND     c585      10000
 UP BOUND     c586      10000
 UP BOUND     c587      324.042233
 UP BOUND     c588      295.458332
 UP BOUND     c589      28.5839010000011
 UP BOUND     c590      295.458332
 UP BOUND     c591      324.042233000001
 UP BOUND     c592      287.388109000001
 UP BOUND     c593      135
 UP BOUND     c594      471.820848
 UP BOUND     c595      476.430342
 UP BOUND     c596      206.712012
 UP BOUND     c597      206.712012
 UP BOUND     c598      417.500999999996
 UP BOUND     c599      10000
 UP BOUND     c600      10000
 UP BOUND     c601      10000
 UP BOUND     c602      10000
 UP BOUND     c603      10000
 UP BOUND     c604      10000
 UP BOUND     c605      10000
 UP BOUND     c606      10000
 UP BOUND     c607      10000
 UP BOUND     c608      10000
 UP BOUND     c609      10000
 UP BOUND     c610      10000
 FX BOUND     c611      139.450105
 UP BOUND     c612      10000
 UP BOUND     c613      10000
 UP BOUND     c614      10000
 UP BOUND     c615      146.583412
 UP BOUND     c616      10000
 UP BOUND     c617      10000
 UP BOUND     c618      10000
 UP BOUND     c619      10000
 UP BOUND     c620      10000
 UP BOUND     c621      10000
 UP BOUND     c622      10000
 UP BOUND     c623      10000
 UP BOUND     c624      10000
 UP BOUND     c625      10000
 UP BOUND     c626      10000
 UP BOUND     c627      10000
 UP BOUND     c628      10000
 UP BOUND     c629      10000
 UP BOUND     c630      10000
 UP BOUND     c631      10000
 UP BOUND     c632      10000
 UP BOUND     c633      10000
 UP BOUND     c634      10000
 UP BOUND     c635      10000
 UP BOUND     c636      10000
 UP BOUND     c637      10000
 UP BOUND     c638      10000
 UP BOUND     c639      10000
 UP BOUND     c640      10000
 UP BOUND     c641      10000
 UP BOUND     c642      10000
 UP BOUND     c643      10000
 UP BOUND     c644      10000
 UP BOUND     c645      10000
 UP BOUND     c646      10000
 UP BOUND     c647      10000
 UP BOUND     c648      10000
 UP BOUND     c649      10000
 UP BOUND     c650      10000
 UP BOUND     c651      10000
 UP BOUND     c652      10000
 UP BOUND     c653      10000
 UP BOUND     c654      10000
 UP BOUND     c655      10000
 UP BOUND     c656      10000
 UP BOUND     c657      10000
 UP BOUND     c658      10000
 UP BOUND     c659      10000
 UP BOUND     c660      10000
 UP BOUND     c661      10000
 UP BOUND     c662      10000
 UP BOUND     c663      10000
 UP BOUND     c664      10000
 UP BOUND     c665      10000
 UP BOUND     c666      10000
 UP BOUND     c667      10000
 UP BOUND     c668      10000
 UP BOUND     c669      10000
 UP BOUND     c670      10000
 UP BOUND     c671      10000
 UP BOUND     c672      10000
 UP BOUND     c673      10000
 UP BOUND     c674      10000
 UP BOUND     c675      10000
 UP BOUND     c676      10000
 UP BOUND     c677      10000
 UP BOUND     c678      10000
 UP BOUND     c679      10000
 UP BOUND     c680      10000
 UP BOUND     c681      10000
 UP BOUND     c682      10000
 UP BOUND     c683      10000
 UP BOUND     c684      10000
 UP BOUND     c685      10000
 UP BOUND     c686      10000
 UP BOUND     c687      10000
 UP BOUND     c688      10000
 UP BOUND     c689      10000
 UP BOUND     c690      10000
 UP BOUND     c691      10000
 UP BOUND     c692      10000
 UP BOUND     c693      10000
 UP BOUND     c694      10000
 UP BOUND     c695      10000
 UP BOUND     c696      10000
 UP BOUND     c697      10000
 UP BOUND     c698      10000
 UP BOUND     c699      10000
 UP BOUND     c700      10000
 UP BOUND     c701      10000
 UP BOUND     c702      10000
 UP BOUND     c703      10000
 UP BOUND     c704      10000
 UP BOUND     c705      10000
 UP BOUND     c706      10000
 UP BOUND     c707      10000
 UP BOUND     c708      10000
 UP BOUND     c709      5227.564535
 UP BOUND     c710      5228.623935
 UP BOUND     c711      10000
 UP BOUND     c712      10000
 UP BOUND     c713      10000
 UP BOUND     c714      10000
 UP BOUND     c715      10000
 UP BOUND     c716      10000
 UP BOUND     c717      10000
 UP BOUND     c718      10000
 UP BOUND     c719      10000
 UP BOUND     c720      10000
 UP BOUND     c721      10000
 UP BOUND     c722      10000
 UP BOUND     c723      10000
 UP BOUND     c724      10000
 UP BOUND     c725      10000
 UP BOUND     c726      10000
 UP BOUND     c727      10000
 UP BOUND     c728      5.82754000000074
 FX BOUND     c729      0
 LO BOUND     c730      19.779
 UP BOUND     c730      21.3847999999994
 UP BOUND     c731      10000
 UP BOUND     c732      10000
 UP BOUND     c733      10000
 UP BOUND     c734      10000
 UP BOUND     c735      10000
 UP BOUND     c736      10000
 LO BOUND     c737      19.779
 UP BOUND     c737      21.3847999999994
 LO BOUND     c738      19.779
 UP BOUND     c738      21.3847999999994
 LO BOUND     c739      19.779
 UP BOUND     c739      21.3847999999994
 LO BOUND     c740      19.779
 UP BOUND     c740      21.3847999999994
 LO BOUND     c741      19.779
 UP BOUND     c741      21.3847999999994
 LO BOUND     c742      19.779
 UP BOUND     c742      21.3847999999994
 FX BOUND     c743      1.60579999999966
 UP BOUND     c744      10000
 UP BOUND     c745      10000
 FX BOUND     c746      21.3847999999997
 LO BOUND     c747      19.779
 UP BOUND     c747      21.3847999999994
 UP BOUND     c748      10000
 UP BOUND     c749      10000
 UP BOUND     c750      10000
 UP BOUND     c751      10000
 UP BOUND     c752      10000
 UP BOUND     c753      10000
 UP BOUND     c754      10000
 UP BOUND     c755      5.82754000000074
 UP BOUND     c756      5.82754000000074
 UP BOUND     c757      5.82754000000074
 LO BOUND     c758      13.485859
 UP BOUND     c758      19.3133990000005
 LO BOUND     c759      13.485859
 UP BOUND     c759      19.3133990000005
 LO BOUND     c760      13.485859
 UP BOUND     c760      19.3133990000005
 LO BOUND     c761      22.701159
 UP BOUND     c761      28.5286990000011
 LO BOUND     c762      22.701159
 UP BOUND     c762      28.5286990000011
 LO BOUND     c763      22.701159
 UP BOUND     c763      28.5286990000011
 LO BOUND     c764      22.701159
 UP BOUND     c764      28.5286990000005
 LO BOUND     c765      22.701159
 UP BOUND     c765      28.5286990000011
 UP BOUND     c766      10000
 UP BOUND     c767      5.82754000000074
 UP BOUND     c768      5.82754000000074
 UP BOUND     c769      5.82754000000074
 LO BOUND     c770      13.485859
 UP BOUND     c770      19.3133990000007
 LO BOUND     c771      13.485859
 UP BOUND     c771      19.3133990000007
 LO BOUND     c772      13.485859
 UP BOUND     c772      19.3133990000006
 LO BOUND     c773      13.485859
 UP BOUND     c773      19.3133990000005
 LO BOUND     c774      13.485859
 UP BOUND     c774      19.3133990000005
 UP BOUND     c775      10000
 UP BOUND     c776      10000
 UP BOUND     c777      10000
 UP BOUND     c778      10000
 UP BOUND     c779      10000
 UP BOUND     c780      10000
 UP BOUND     c781      10000
 UP BOUND     c782      10000
 UP BOUND     c783      10000
 UP BOUND     c784      10000
 UP BOUND     c785      10000
 UP BOUND     c786      10000
 UP BOUND     c787      10000
 UP BOUND     c788      10000
 UP BOUND     c789      10000
 UP BOUND     c790      10000
 UP BOUND     c791      10000
 UP BOUND     c792      10000
 UP BOUND     c793      10000
 UP BOUND     c794      10000
 UP BOUND     c795      10000
 UP BOUND     c796      10000
 UP BOUND     c797      10000
 UP BOUND     c798      10000
 UP BOUND     c799      10000
 UP BOUND     c800      10000
 UP BOUND     c801      10000
 UP BOUND     c802      10000
 UP BOUND     c803      10000
 UP BOUND     c804      10000
 UP BOUND     c805      10000
 UP BOUND     c806      10000
 UP BOUND     c807      10000
 UP BOUND     c808      10000
 UP BOUND     c809      10000
 UP BOUND     c810      10000
 UP BOUND     c811      10000
 UP BOUND     c812      10000
 UP BOUND     c813      10000
 UP BOUND     c814      10000
 UP BOUND     c815      10000
 UP BOUND     c816      10000
 UP BOUND     c817      10000
 UP BOUND     c818      10000
 UP BOUND     c819      10000
 UP BOUND     c820      10000
 UP BOUND     c821      10000
 UP BOUND     c822      10000
 UP BOUND     c823      10000
 UP BOUND     c824      10000
 UP BOUND     c825      10000
 UP BOUND     c826      10000
 UP BOUND     c827      10000
 UP BOUND     c828      10000
 UP BOUND     c829      10000
 UP BOUND     c830      10000
 UP BOUND     c831      10000
 UP BOUND     c832      10000
 UP BOUND     c833      10000
 UP BOUND     c834      10000
 UP BOUND     c835      10000
 UP BOUND     c836      10000
 UP BOUND     c837      10000
 UP BOUND     c838      10000
 UP BOUND     c839      10000
 UP BOUND     c840      10000
 UP BOUND     c841      10000
 UP BOUND     c842      10000
 UP BOUND     c843      10000
 UP BOUND     c844      10000
 UP BOUND     c845      10000
 UP BOUND     c846      10000
 UP BOUND     c847      10000
 UP BOUND     c848      10000
 UP BOUND     c849      10000
 UP BOUND     c850      10000
 UP BOUND     c851      10000
 UP BOUND     c852      10000
 UP BOUND     c853      10000
 UP BOUND     c854      10000
 UP BOUND     c855      10000
 UP BOUND     c856      10000
 UP BOUND     c857      10000
 UP BOUND     c858      10000
 UP BOUND     c859      10000
 UP BOUND     c860      10000
 UP BOUND     c861      10000
 UP BOUND     c862      10000
 UP BOUND     c863      10000
 UP BOUND     c864      10000
 UP BOUND     c865      10000
 UP BOUND     c866      10000
 UP BOUND     c867      10000
 UP BOUND     c868      10000
 UP BOUND     c869      10000
 UP BOUND     c870      10000
 UP BOUND     c871      10000
 UP BOUND     c872      10000
 UP BOUND     c873      10000
 UP BOUND     c874      10000
 UP BOUND     c875      10000
 UP BOUND     c876      10000
 UP BOUND     c877      10000
 UP BOUND     c878      10000
 UP BOUND     c879      10000
 UP BOUND     c880      10000
 UP BOUND     c881      10000
 UP BOUND     c882      10000
 UP BOUND     c883      10000
 UP BOUND     c884      10000
 UP BOUND     c885      10000
 UP BOUND     c886      10000
 UP BOUND     c887      10000
 UP BOUND     c888      10000
 UP BOUND     c889      10000
 UP BOUND     c890      10000
 UP BOUND     c891      10000
 UP BOUND     c892      10000
 UP BOUND     c893      10000
 UP BOUND     c894      10000
 UP BOUND     c895      10000
 UP BOUND     c896      10000
 UP BOUND     c897      10000
 UP BOUND     c898      10000
 UP BOUND     c899      10000
 UP BOUND     c900      10000
 UP BOUND     c901      10000
 FX BOUND     c902      0
 UP BOUND     c903      10000
 UP BOUND     c904      10000
 UP BOUND     c905      10000
 UP BOUND     c906      10000
 UP BOUND     c907      10000
 UP BOUND     c908      10000
 UP BOUND     c909      10000
 UP BOUND     c910      10000
 UP BOUND     c911      10000
 UP BOUND     c912      10000
 UP BOUND     c913      10000
 UP BOUND     c914      10000
 UP BOUND     c915      10000
 UP BOUND     c916      10000
 UP BOUND     c917      10000
 UP BOUND     c918      10000
 UP BOUND     c919      10000
 UP BOUND     c920      10000
 UP BOUND     c921      10000
 FX BOUND     c922      0
 UP BOUND     c923      10000
 UP BOUND     c924      10000
 UP BOUND     c925      10000
 UP BOUND     c926      10000
 UP BOUND     c927      10000
 UP BOUND     c928      10000
 UP BOUND     c929      10000
 UP BOUND     c930      10000
 UP BOUND     c931      10000
 UP BOUND     c932      10000
 UP BOUND     c933      10000
 UP BOUND     c934      10000
 UP BOUND     c935      10000
 UP BOUND     c936      10000
 UP BOUND     c937      10000
 UP BOUND     c938      52.0379990000008
 FX BOUND     c939      52.0379990000001
 UP BOUND     c940      10000
 UP BOUND     c941      10000
 UP BOUND     c942      10000
 UP BOUND     c943      10000
 UP BOUND     c944      10000
 UP BOUND     c945      10000
 UP BOUND     c946      10000
 UP BOUND     c947      10000
 UP BOUND     c948      10000
 UP BOUND     c949      10000
 UP BOUND     c950      10000
 UP BOUND     c951      10000
 UP BOUND     c952      10000
 UP BOUND     c953      10000
 UP BOUND     c954      10000
 UP BOUND     c955      10000
 UP BOUND     c956      10000
 UP BOUND     c957      10000
 UP BOUND     c958      10000
 UP BOUND     c959      10000
 UP BOUND     c960      10000
 UP BOUND     c961      10000
 UP BOUND     c962      10000
 UP BOUND     c963      10000
 UP BOUND     c964      10000
 UP BOUND     c965      10000
 UP BOUND     c966      10000
 UP BOUND     c967      10000
 UP BOUND     c968      10000
 UP BOUND     c969      10000
 UP BOUND     c970      10000
 UP BOUND     c971      10000
 UP BOUND     c972      10000
 UP BOUND     c973      10000
 FX BOUND     c974      0
 UP BOUND     c975      10000
 UP BOUND     c976      10000
 FX BOUND     c977      0
 UP BOUND     c978      10000
 UP BOUND     c979      10000
 UP BOUND     c980      10000
 UP BOUND     c981      10000
 UP BOUND     c982      10000
 UP BOUND     c983      10000
 UP BOUND     c984      10000
 UP BOUND     c985      10000
 UP BOUND     c986      10000
 UP BOUND     c987      10000
 UP BOUND     c988      10000
 UP BOUND     c989      10000
 UP BOUND     c990      10000
 UP BOUND     c991      10000
 FX BOUND     c992      0
 UP BOUND     c993      10000
 UP BOUND     c994      10000
 UP BOUND     c995      10000
 UP BOUND     c996      10000
 UP BOUND     c997      10000
 UP BOUND     c998      10000
 UP BOUND     c999      10000
 UP BOUND     c1000     10000
 UP BOUND     c1001     10000
 UP BOUND     c1002     10000
 UP BOUND     c1003     10000
 UP BOUND     c1004     10000
 UP BOUND     c1005     10000
 UP BOUND     c1006     10000
 UP BOUND     c1007     10000
 UP BOUND     c1008     10000
 UP BOUND     c1009     10000
 UP BOUND     c1010     10000
 UP BOUND     c1011     10000
 UP BOUND     c1012     10000
 UP BOUND     c1013     10000
 UP BOUND     c1014     10000
 UP BOUND     c1015     10000
 UP BOUND     c1016     10000
 UP BOUND     c1017     10000
 UP BOUND     c1018     10000
 UP BOUND     c1019     10000
 UP BOUND     c1020     10000
 UP BOUND     c1021     10000
 UP BOUND     c1022     10000
 UP BOUND     c1023     10000
 UP BOUND     c1024     10000
 UP BOUND     c1025     10000
 UP BOUND     c1026     10000
 UP BOUND     c1027     10000
 UP BOUND     c1028     10000
 UP BOUND     c1029     10000
 UP BOUND     c1030     10000
 UP BOUND     c1031     10000
 UP BOUND     c1032     10000
 UP BOUND     c1033     10000
 UP BOUND     c1034     10000
 UP BOUND     c1035     10000
 UP BOUND     c1036     10000
 UP BOUND     c1037     10000
 UP BOUND     c1038     10000
 UP BOUND     c1039     10000
 UP BOUND     c1040     10000
 UP BOUND     c1041     10000
 UP BOUND     c1042     10000
 UP BOUND     c1043     10000
 UP BOUND     c1044     10000
 UP BOUND     c1045     10000
 UP BOUND     c1046     10000
 UP BOUND     c1047     10000
 UP BOUND     c1048     10000
 FX BOUND     c1049     10000
 UP BOUND     c1050     10000
 UP BOUND     c1051     10000
 UP BOUND     c1052     10000
 UP BOUND     c1053     10000
 UP BOUND     c1054     10000
 UP BOUND     c1055     10000
 UP BOUND     c1056     10000
 UP BOUND     c1057     10000
 UP BOUND     c1058     10000
 FX BOUND     c1059     0
 UP BOUND     c1060     10000
 UP BOUND     c1061     10000
 UP BOUND     c1062     10000
 UP BOUND     c1063     10000
 UP BOUND     c1064     10000
 UP BOUND     c1065     10000
 UP BOUND     c1066     10000
 UP BOUND     c1067     10000
 UP BOUND     c1068     10000
 UP BOUND     c1069     10000
 UP BOUND     c1070     10000
 UP BOUND     c1071     10000
 UP BOUND     c1072     10000
 UP BOUND     c1073     10000
 UP BOUND     c1074     10000
 UP BOUND     c1075     10000
 UP BOUND     c1076     10000
 UP BOUND     c1077     10000
 UP BOUND     c1078     10000
 UP BOUND     c1079     10000
 UP BOUND     c1080     10000
 UP BOUND     c1081     10000
 UP BOUND     c1082     10000
 UP BOUND     c1083     10000
 UP BOUND     c1084     10000
 UP BOUND     c1085     10000
 UP BOUND     c1086     10000
 UP BOUND     c1087     10000
 UP BOUND     c1088     10000
 UP BOUND     c1089     10000
 UP BOUND     c1090     10000
 UP BOUND     c1091     10000
 UP BOUND     c1092     10000
 UP BOUND     c1093     10000
 UP BOUND     c1094     10000
 UP BOUND     c1095     10000
 UP BOUND     c1096     10000
 UP BOUND     c1097     10000
 UP BOUND     c1098     10000
 UP BOUND     c1099     10000
 UP BOUND     c1100     10000
 FX BOUND     c1101     0
 UP BOUND     c1102     10000
 UP BOUND     c1103     10000
 UP BOUND     c1104     10000
 UP BOUND     c1105     10000
 UP BOUND     c1106     10000
 UP BOUND     c1107     10000
 UP BOUND     c1108     10000
 UP BOUND     c1109     10000
 UP BOUND     c1110     10000
 UP BOUND     c1111     10000
 UP BOUND     c1112     10000
 UP BOUND     c1113     10000
 UP BOUND     c1114     10000
 UP BOUND     c1115     10000
 UP BOUND     c1116     10000
 UP BOUND     c1117     10000
 UP BOUND     c1118     10000
 UP BOUND     c1119     10000
 UP BOUND     c1120     10000
 UP BOUND     c1121     10000
 UP BOUND     c1122     10000
 UP BOUND     c1123     10000
 UP BOUND     c1124     10000
 UP BOUND     c1125     10000
 UP BOUND     c1126     10000
 UP BOUND     c1127     10000
 UP BOUND     c1128     10000
 UP BOUND     c1129     10000
 UP BOUND     c1130     10000
 UP BOUND     c1131     10000
 UP BOUND     c1132     10000
 UP BOUND     c1133     10000
 UP BOUND     c1134     10000
 UP BOUND     c1135     10000
 UP BOUND     c1136     10000
 UP BOUND     c1137     10000
 UP BOUND     c1138     10000
 UP BOUND     c1139     10000
 UP BOUND     c1140     10000
 UP BOUND     c1141     10000
 UP BOUND     c1142     10000
 FX BOUND     c1143     0
 UP BOUND     c1144     10000
 UP BOUND     c1145     10000
 UP BOUND     c1146     10000
 FX BOUND     c1147     0
 UP BOUND     c1148     10000
 UP BOUND     c1149     10000
 UP BOUND     c1150     10000
 UP BOUND     c1151     10000
 UP BOUND     c1152     10000
 UP BOUND     c1153     10000
 UP BOUND     c1154     10000
 UP BOUND     c1155     10000
 UP BOUND     c1156     10000
 UP BOUND     c1157     10000
 UP BOUND     c1158     10000
 UP BOUND     c1159     10000
 UP BOUND     c1160     10000
 UP BOUND     c1161     10000
 UP BOUND     c1162     10000
 UP BOUND     c1163     10000
 UP BOUND     c1164     10000
 UP BOUND     c1165     10000
 UP BOUND     c1166     10000
 UP BOUND     c1167     10000
 UP BOUND     c1168     10000
 UP BOUND     c1169     10000
 UP BOUND     c1170     10000
 UP BOUND     c1171     10000
 UP BOUND     c1172     10000
 UP BOUND     c1173     10000
 UP BOUND     c1174     10000
 UP BOUND     c1175     10000
 UP BOUND     c1176     10000
 UP BOUND     c1177     10000
 UP BOUND     c1178     10000
 UP BOUND     c1179     10000
 UP BOUND     c1180     10000
 UP BOUND     c1181     10000
 UP BOUND     c1182     10000
 FX BOUND     c1183     0
 UP BOUND     c1184     10000
 UP BOUND     c1185     10000
 UP BOUND     c1186     10000
 UP BOUND     c1187     10000
 UP BOUND     c1188     10000
 UP BOUND     c1189     10000
 UP BOUND     c1190     10000
 UP BOUND     c1191     10000
 UP BOUND     c1192     10000
 UP BOUND     c1193     10000
 UP BOUND     c1194     10000
 UP BOUND     c1195     10000
 UP BOUND     c1196     10000
 UP BOUND     c1197     10000
 UP BOUND     c1198     10000
 UP BOUND     c1199     10000
 UP BOUND     c1200     10000
 UP BOUND     c1201     10000
 UP BOUND     c1202     10000
 UP BOUND     c1203     10000
 UP BOUND     c1204     10000
 UP BOUND     c1205     10000
 UP BOUND     c1206     10000
 UP BOUND     c1207     10000
 UP BOUND     c1208     10000
 UP BOUND     c1209     10000
 UP BOUND     c1210     10000
 UP BOUND     c1211     10000
 UP BOUND     c1212     10000
 UP BOUND     c1213     10000
 UP BOUND     c1214     10000
 UP BOUND     c1215     10000
 UP BOUND     c1216     10000
 UP BOUND     c1217     10000
 UP BOUND     c1218     10000
 FX BOUND     c1219     0
 UP BOUND     c1220     10000
 UP BOUND     c1221     10000
 FX BOUND     c1222     0
 UP BOUND     c1223     10000
 UP BOUND     c1224     10000
 UP BOUND     c1225     10000
 UP BOUND     c1226     10000
 UP BOUND     c1227     10000
 UP BOUND     c1228     10000
 UP BOUND     c1229     10000
 UP BOUND     c1230     10000
 UP BOUND     c1231     10000
 UP BOUND     c1232     10000
 UP BOUND     c1233     10000
 UP BOUND     c1234     10000
 UP BOUND     c1235     10000
 UP BOUND     c1236     10000
 UP BOUND     c1237     10000
 UP BOUND     c1238     10000
 UP BOUND     c1239     10000
 UP BOUND     c1240     10000
 UP BOUND     c1241     10000
 UP BOUND     c1242     10000
 UP BOUND     c1243     10000
 UP BOUND     c1244     10000
 UP BOUND     c1245     10000
 UP BOUND     c1246     10000
 UP BOUND     c1247     10000
 UP BOUND     c1248     10000
 UP BOUND     c1249     10000
 UP BOUND     c1250     10000
 UP BOUND     c1251     10000
 UP BOUND     c1252     10000
 UP BOUND     c1253     10000
 UP BOUND     c1254     10000
 UP BOUND     c1255     10000
 UP BOUND     c1256     10000
 UP BOUND     c1257     10000
 UP BOUND     c1258     10000
 UP BOUND     c1259     10000
 UP BOUND     c1260     10000
 UP BOUND     c1261     10000
 FX BOUND     c1262     0
 UP BOUND     c1263     10000
 FX BOUND     c1264     0
 UP BOUND     c1265     10000
 UP BOUND     c1266     10000
 UP BOUND     c1267     10000
 UP BOUND     c1268     10000
 UP BOUND     c1269     10000
 UP BOUND     c1270     10000
 UP BOUND     c1271     10000
 UP BOUND     c1272     10000
 UP BOUND     c1273     10000
 UP BOUND     c1274     10000
 UP BOUND     c1275     10000
 UP BOUND     c1276     10000
 UP BOUND     c1277     10000
 UP BOUND     c1278     10000
 UP BOUND     c1279     10000
 UP BOUND     c1280     10000
 UP BOUND     c1281     10000
 UP BOUND     c1282     10000
 UP BOUND     c1283     10000
 UP BOUND     c1284     10000
 UP BOUND     c1285     10000
 UP BOUND     c1286     10000
 UP BOUND     c1287     10000
 UP BOUND     c1288     10000
 UP BOUND     c1289     10000
 UP BOUND     c1290     10000
 UP BOUND     c1291     10000
 UP BOUND     c1292     10000
 UP BOUND     c1293     270
 UP BOUND     c1294     10000
 UP BOUND     c1295     10000
 UP BOUND     c1296     10000
 UP BOUND     c1297     129.055791999999
 UP BOUND     c1298     10000
 UP BOUND     c1299     10000
 UP BOUND     c1300     1092.661
 UP BOUND     c1301     10000
 UP BOUND     c1302     85.2123519999996
 UP BOUND     c1303     10000
 UP BOUND     c1304     92.3810519999985
 UP BOUND     c1305     135.281670000001
 UP BOUND     c1306     135.000000000001
 UP BOUND     c1307     10000
 UP BOUND     c1308     135.000000000001
 UP BOUND     c1309     10000
 UP BOUND     c1310     10000
 UP BOUND     c1311     10000
 UP BOUND     c1312     10000
 UP BOUND     c1313     139.609493999999
 UP BOUND     c1314     10000
 UP BOUND     c1315     10000
 UP BOUND     c1316     10000
 UP BOUND     c1317     10000
 UP BOUND     c1318     10000
 UP BOUND     c1319     10000
 UP BOUND     c1320     10000
 UP BOUND     c1321     10000
 UP BOUND     c1322     10000
 UP BOUND     c1323     10000
 UP BOUND     c1324     10000
 UP BOUND     c1325     10000
 UP BOUND     c1326     10000
 UP BOUND     c1327     10000
 UP BOUND     c1328     10000
 UP BOUND     c1329     10000
 UP BOUND     c1330     10000
 UP BOUND     c1331     92.3810519999983
 UP BOUND     c1332     10000
 UP BOUND     c1333     10000
 UP BOUND     c1334     10000
 UP BOUND     c1335     139.609493999999
 UP BOUND     c1336     10000
 UP BOUND     c1337     10000
 UP BOUND     c1338     10000
 UP BOUND     c1339     10000
 FX BOUND     c1340     0
 UP BOUND     c1341     10000
 UP BOUND     c1342     10000
 UP BOUND     c1343     10000
 UP BOUND     c1344     10000
 UP BOUND     c1345     10000
 FX BOUND     c1346     0
 UP BOUND     c1347     10000
 UP BOUND     c1348     10000
 UP BOUND     c1349     10000
 UP BOUND     c1350     10000
 UP BOUND     c1351     10000
 UP BOUND     c1352     10000
 UP BOUND     c1353     10000
 UP BOUND     c1354     10000
 UP BOUND     c1355     10000
 UP BOUND     c1356     10000
 UP BOUND     c1357     10000
 UP BOUND     c1358     10000
 UP BOUND     c1359     10000
 UP BOUND     c1360     10000
 UP BOUND     c1361     10000
 UP BOUND     c1362     10000
 UP BOUND     c1363     10000
 UP BOUND     c1364     10000
 UP BOUND     c1365     10000
 LO BOUND     c1366     0.065433001
 UP BOUND     c1366     85.2123519999996
 UP BOUND     c1367     81.089442999985
 UP BOUND     c1368     10000
 UP BOUND     c1369     10000
 UP BOUND     c1370     10000
 UP BOUND     c1371     10000
 UP BOUND     c1372     135
 UP BOUND     c1373     10000
 UP BOUND     c1374     10000
 UP BOUND     c1375     134.999999999999
 UP BOUND     c1376     134.999999999999
 UP BOUND     c1377     134.999999999999
 UP BOUND     c1378     10000
 UP BOUND     c1379     10000
 UP BOUND     c1380     10000
 UP BOUND     c1381     10000
 UP BOUND     c1382     10000
 UP BOUND     c1383     10000
 UP BOUND     c1384     10000
 UP BOUND     c1385     10000
 UP BOUND     c1386     85.2123519999996
 UP BOUND     c1387     10000
 UP BOUND     c1388     10000
 UP BOUND     c1389     10000
 UP BOUND     c1390     10000
 UP BOUND     c1391     10000
 UP BOUND     c1392     10000
 UP BOUND     c1393     10000
 UP BOUND     c1394     10000
 UP BOUND     c1395     10000
 UP BOUND     c1396     10000
 UP BOUND     c1397     10000
 UP BOUND     c1398     10000
 UP BOUND     c1399     10000
 UP BOUND     c1400     10000
 UP BOUND     c1401     10000
 UP BOUND     c1402     10000
 UP BOUND     c1403     10000
 UP BOUND     c1404     10000
 UP BOUND     c1405     10000
 UP BOUND     c1406     10000
 UP BOUND     c1407     10000
 UP BOUND     c1408     10000
 UP BOUND     c1409     10000
 UP BOUND     c1410     85.2123519999996
 LO BOUND     c1411     0.0654230020000024
 UP BOUND     c1411     85.2123519999996
 UP BOUND     c1412     81.023999999985
 UP BOUND     c1413     10000
 UP BOUND     c1414     10000
 UP BOUND     c1415     244.541668
 UP BOUND     c1416     270
 UP BOUND     c1417     10000
 FX BOUND     c1418     0
 UP BOUND     c1419     13.0382590000008
 UP BOUND     c1420     283.038259
 UP BOUND     c1421     287.388109
 UP BOUND     c1422     10000
 UP BOUND     c1423     10000
 UP BOUND     c1424     270
 UP BOUND     c1425     270
 UP BOUND     c1426     270
 UP BOUND     c1427     270
 UP BOUND     c1428     10000
 UP BOUND     c1429     10000
 UP BOUND     c1430     10000
 UP BOUND     c1431     10000
 UP BOUND     c1432     10000
 UP BOUND     c1433     10000
 UP BOUND     c1434     10000
 UP BOUND     c1435     77.7840519999979
 UP BOUND     c1436     10000
 UP BOUND     c1437     10000
 UP BOUND     c1438     10000
 UP BOUND     c1439     10000
 UP BOUND     c1440     10000
 UP BOUND     c1441     10000
 UP BOUND     c1442     10000
 UP BOUND     c1443     10000
 UP BOUND     c1444     10000
 UP BOUND     c1445     10000
 UP BOUND     c1446     10000
 UP BOUND     c1447     270
 UP BOUND     c1448     244.541668
 FX BOUND     c1449     0
 UP BOUND     c1450     244.541668
 UP BOUND     c1451     273.125569000001
 UP BOUND     c1452     270
 UP BOUND     c1453     135
 UP BOUND     c1454     270.281670000001
 UP BOUND     c1455     270.281670000001
 UP BOUND     c1456     135.281670000001
 UP BOUND     c1457     135.000000000001
 UP BOUND     c1458     77.7840519999979
 UP BOUND     c1459     10000
 UP BOUND     c1460     10000
 UP BOUND     c1461     10000
 UP BOUND     c1462     10000
 UP BOUND     c1463     10000
 UP BOUND     c1464     10000
 UP BOUND     c1465     10000
 UP BOUND     c1466     10000
 UP BOUND     c1467     10000
 UP BOUND     c1468     10000
 UP BOUND     c1469     10000
 UP BOUND     c1470     10000
 FX BOUND     c1471     0
 UP BOUND     c1472     10000
 UP BOUND     c1473     10000
 UP BOUND     c1474     10000
 UP BOUND     c1475     475.155188
 UP BOUND     c1476     10000
 UP BOUND     c1477     10000
 UP BOUND     c1478     10000
 UP BOUND     c1479     10000
 UP BOUND     c1480     10000
 UP BOUND     c1481     10000
 UP BOUND     c1482     10000
 UP BOUND     c1483     10000
 UP BOUND     c1484     10000
 UP BOUND     c1485     10000
 UP BOUND     c1486     10000
 UP BOUND     c1487     10000
 UP BOUND     c1488     10000
 UP BOUND     c1489     10000
 UP BOUND     c1490     10000
 UP BOUND     c1491     10000
 UP BOUND     c1492     10000
 UP BOUND     c1493     10000
 UP BOUND     c1494     10000
 UP BOUND     c1495     10000
 UP BOUND     c1496     10000
 UP BOUND     c1497     10000
 UP BOUND     c1498     10000
 UP BOUND     c1499     10000
 UP BOUND     c1500     10000
 UP BOUND     c1501     10000
 UP BOUND     c1502     10000
 UP BOUND     c1503     10000
 UP BOUND     c1504     10000
 UP BOUND     c1505     10000
 UP BOUND     c1506     10000
 UP BOUND     c1507     10000
 UP BOUND     c1508     10000
 UP BOUND     c1509     10000
 UP BOUND     c1510     10000
 UP BOUND     c1511     10000
 UP BOUND     c1512     10000
 UP BOUND     c1513     10000
 UP BOUND     c1514     10000
 UP BOUND     c1515     10000
 UP BOUND     c1516     10000
 UP BOUND     c1517     10000
 UP BOUND     c1518     10000
 UP BOUND     c1519     10000
 UP BOUND     c1520     10000
 UP BOUND     c1521     10000
 UP BOUND     c1522     10000
 UP BOUND     c1523     10000
 UP BOUND     c1524     10000
 FX BOUND     c1525     0
 UP BOUND     c1526     10000
 UP BOUND     c1527     10000
 UP BOUND     c1528     10000
 UP BOUND     c1529     10000
 UP BOUND     c1530     10000
 UP BOUND     c1531     10000
 FX BOUND     c1532     0
 UP BOUND     c1533     10000
 UP BOUND     c1534     10000
 UP BOUND     c1535     10000
 UP BOUND     c1536     10000
 UP BOUND     c1537     10000
 UP BOUND     c1538     10000
 UP BOUND     c1539     10000
 UP BOUND     c1540     10000
 UP BOUND     c1541     10000
 UP BOUND     c1542     10000
 UP BOUND     c1543     10000
 UP BOUND     c1544     10000
 UP BOUND     c1545     10000
 UP BOUND     c1546     10000
 UP BOUND     c1547     10000
 UP BOUND     c1548     10000
 UP BOUND     c1549     10000
 UP BOUND     c1550     10000
 UP BOUND     c1551     10000
 UP BOUND     c1552     10000
 UP BOUND     c1553     10000
 UP BOUND     c1554     10000
 UP BOUND     c1555     10000
 UP BOUND     c1556     10000
 UP BOUND     c1557     10000
 UP BOUND     c1558     10000
 UP BOUND     c1559     10000
 UP BOUND     c1560     10000
 UP BOUND     c1561     10000
 FX BOUND     c1562     0
 UP BOUND     c1563     10000
 UP BOUND     c1564     10000
 UP BOUND     c1565     10000
 UP BOUND     c1566     10000
 UP BOUND     c1567     10000
 UP BOUND     c1568     10000
 UP BOUND     c1569     10000
 UP BOUND     c1570     10000
 UP BOUND     c1571     10000
 UP BOUND     c1572     10000
 UP BOUND     c1573     10000
 UP BOUND     c1574     10000
 UP BOUND     c1575     10000
 UP BOUND     c1576     10000
 UP BOUND     c1577     10000
 UP BOUND     c1578     10000
 UP BOUND     c1579     10000
 UP BOUND     c1580     10000
 UP BOUND     c1581     10000
 UP BOUND     c1582     10000
 UP BOUND     c1583     10000
 UP BOUND     c1584     10000
 UP BOUND     c1585     10000
 UP BOUND     c1586     10000
 UP BOUND     c1587     10000
 FX BOUND     c1588     0
 LO BOUND     c1589     21.9035
 UP BOUND     c1589     23.5092999999994
 FX BOUND     c1590     0
 UP BOUND     c1591     10000
 UP BOUND     c1592     10000
 UP BOUND     c1593     10000
 UP BOUND     c1594     10000
 UP BOUND     c1595     10000
 UP BOUND     c1596     10000
 FX BOUND     c1597     0
 FX BOUND     c1598     0
 FX BOUND     c1599     0
 FX BOUND     c1600     0
 FX BOUND     c1601     0
 FX BOUND     c1602     0
 FX BOUND     c1603     0
 UP BOUND     c1604     10000
 FX BOUND     c1605     0
 FX BOUND     c1606     0
 FX BOUND     c1607     0
 UP BOUND     c1608     10000
 UP BOUND     c1609     10000
 UP BOUND     c1610     10000
 UP BOUND     c1611     10000
 UP BOUND     c1612     10000
 UP BOUND     c1613     10000
 UP BOUND     c1614     10000
 FX BOUND     c1615     0
 FX BOUND     c1616     0
 FX BOUND     c1617     0
 FX BOUND     c1618     0
 FX BOUND     c1619     0
 FX BOUND     c1620     0
 FX BOUND     c1621     0
 FX BOUND     c1622     0
 FX BOUND     c1623     0
 FX BOUND     c1624     0
 FX BOUND     c1625     0
 UP BOUND     c1626     10000
 FX BOUND     c1627     0
 FX BOUND     c1628     0
 FX BOUND     c1629     0
 FX BOUND     c1630     0
 FX BOUND     c1631     0
 FX BOUND     c1632     0
 FX BOUND     c1633     0
 FX BOUND     c1634     0
 UP BOUND     c1635     10000
 UP BOUND     c1636     10000
 UP BOUND     c1637     10000
 UP BOUND     c1638     10000
 UP BOUND     c1639     10000
 UP BOUND     c1640     10000
 UP BOUND     c1641     10000
 UP BOUND     c1642     10000
 UP BOUND     c1643     10000
 UP BOUND     c1644     10000
 UP BOUND     c1645     10000
 UP BOUND     c1646     10000
 UP BOUND     c1647     10000
 UP BOUND     c1648     10000
 UP BOUND     c1649     10000
 UP BOUND     c1650     10000
 UP BOUND     c1651     10000
 UP BOUND     c1652     10000
 UP BOUND     c1653     10000
 UP BOUND     c1654     10000
 UP BOUND     c1655     10000
 UP BOUND     c1656     10000
 UP BOUND     c1657     10000
 UP BOUND     c1658     10000
 UP BOUND     c1659     10000
 UP BOUND     c1660     10000
 UP BOUND     c1661     10000
 UP BOUND     c1662     10000
 UP BOUND     c1663     10000
 UP BOUND     c1664     10000
 UP BOUND     c1665     10000
 UP BOUND     c1666     10000
 UP BOUND     c1667     10000
 UP BOUND     c1668     10000
 UP BOUND     c1669     10000
 UP BOUND     c1670     10000
 UP BOUND     c1671     10000
 UP BOUND     c1672     10000
 UP BOUND     c1673     10000
 UP BOUND     c1674     10000
 UP BOUND     c1675     10000
 UP BOUND     c1676     10000
 UP BOUND     c1677     10000
 UP BOUND     c1678     10000
 UP BOUND     c1679     10000
 UP BOUND     c1680     10000
 UP BOUND     c1681     10000
 UP BOUND     c1682     10000
 UP BOUND     c1683     10000
 UP BOUND     c1684     10000
 UP BOUND     c1685     10000
 UP BOUND     c1686     10000
 UP BOUND     c1687     10000
 UP BOUND     c1688     10000
 UP BOUND     c1689     10000
 UP BOUND     c1690     10000
 UP BOUND     c1691     10000
 UP BOUND     c1692     10000
 UP BOUND     c1693     10000
 UP BOUND     c1694     10000
 UP BOUND     c1695     10000
 UP BOUND     c1696     10000
 UP BOUND     c1697     10000
 UP BOUND     c1698     10000
 UP BOUND     c1699     10000
 UP BOUND     c1700     10000
 UP BOUND     c1701     10000
 UP BOUND     c1702     10000
 UP BOUND     c1703     10000
 UP BOUND     c1704     10000
 UP BOUND     c1705     10000
 UP BOUND     c1706     10000
 UP BOUND     c1707     10000
 UP BOUND     c1708     10000
 UP BOUND     c1709     10000
 UP BOUND     c1710     10000
 UP BOUND     c1711     10000
 UP BOUND     c1712     10000
 UP BOUND     c1713     10000
 UP BOUND     c1714     10000
 UP BOUND     c1715     10000
 UP BOUND     c1716     10000
 UP BOUND     c1717     10000
 UP BOUND     c1718     10000
 UP BOUND     c1719     10000
 UP BOUND     c1720     1
 UP BOUND     c1721     1
 UP BOUND     c1722     1
 UP BOUND     c1723     1
 UP BOUND     c1724     1
 UP BOUND     c1725     1
 UP BOUND     c1726     1
 UP BOUND     c1727     1
 UP BOUND     c1728     10000
 UP BOUND     c1729     1
 UP BOUND     c1730     1
 UP BOUND     c1731     10000
 UP BOUND     c1732     1
 UP BOUND     c1733     1
 FX BOUND     c1734     0
 UP BOUND     c1735     1
 UP BOUND     c1736     10000
 UP BOUND     c1737     1
 UP BOUND     c1738     1
 UP BOUND     c1739     10000
 UP BOUND     c1740     1
 UP BOUND     c1741     1
 UP BOUND     c1742     1
 UP BOUND     c1743     10000
 UP BOUND     c1744     1
 UP BOUND     c1745     1
 FX BOUND     c1746     0
 UP BOUND     c1747     1
 UP BOUND     c1748     1
 UP BOUND     c1749     10000
 FX BOUND     c1750     0
 UP BOUND     c1751     1
 UP BOUND     c1752     1
 UP BOUND     c1753     1
 UP BOUND     c1754     1
 UP BOUND     c1755     1
 UP BOUND     c1756     1
 UP BOUND     c1757     1
 UP BOUND     c1758     1
 UP BOUND     c1759     1
 UP BOUND     c1760     10000
 UP BOUND     c1761     1
 UP BOUND     c1762     10000
 UP BOUND     c1763     1
 UP BOUND     c1764     1
 UP BOUND     c1765     1
 UP BOUND     c1766     1
 UP BOUND     c1767     1
 UP BOUND     c1768     1
 UP BOUND     c1769     1
 UP BOUND     c1770     1
 UP BOUND     c1771     1
 UP BOUND     c1772     1
 UP BOUND     c1773     1
 UP BOUND     c1774     1
 UP BOUND     c1775     1
 UP BOUND     c1776     1
 UP BOUND     c1777     1
 UP BOUND     c1778     1
 UP BOUND     c1779     1
 UP BOUND     c1780     1
 UP BOUND     c1781     1
 UP BOUND     c1782     1
 UP BOUND     c1783     1
 UP BOUND     c1784     1
 UP BOUND     c1785     1
 UP BOUND     c1786     1
 UP BOUND     c1787     1
 UP BOUND     c1788     1
 UP BOUND     c1789     1
 UP BOUND     c1790     1
 UP BOUND     c1791     1
 UP BOUND     c1792     1
 UP BOUND     c1793     1
 UP BOUND     c1794     1
 UP BOUND     c1795     1
 UP BOUND     c1796     1
 UP BOUND     c1797     1
 UP BOUND     c1798     1
 UP BOUND     c1799     1
 UP BOUND     c1800     1
 UP BOUND     c1801     1
 UP BOUND     c1802     1
 UP BOUND     c1803     1
 UP BOUND     c1804     1
 UP BOUND     c1805     1
 UP BOUND     c1806     1
 UP BOUND     c1807     1
 UP BOUND     c1808     1
 UP BOUND     c1809     1
 UP BOUND     c1810     1
 UP BOUND     c1811     1
 UP BOUND     c1812     1
 UP BOUND     c1813     1
 UP BOUND     c1814     1
 UP BOUND     c1815     1
 UP BOUND     c1816     1
 UP BOUND     c1817     1
 FX BOUND     c1818     0
 FX BOUND     c1819     0
 UP BOUND     c1820     1
 UP BOUND     c1821     1
 UP BOUND     c1822     1
 UP BOUND     c1823     1
 UP BOUND     c1824     1
 UP BOUND     c1825     1
 UP BOUND     c1826     1
 UP BOUND     c1827     1
 UP BOUND     c1828     1
 UP BOUND     c1829     274.609493999997
 UP BOUND     c1830     1
 UP BOUND     c1831     1
 UP BOUND     c1832     1
 UP BOUND     c1833     1
 UP BOUND     c1834     1
 UP BOUND     c1835     1
 UP BOUND     c1836     1
 UP BOUND     c1837     1
 UP BOUND     c1838     1
 UP BOUND     c1839     1
 FX BOUND     c1840     0
 UP BOUND     c1841     1
 UP BOUND     c1842     1
 UP BOUND     c1843     1
 UP BOUND     c1844     1
 UP BOUND     c1845     1
 UP BOUND     c1846     1
 UP BOUND     c1847     1
 UP BOUND     c1848     1
 UP BOUND     c1849     1
 UP BOUND     c1850     1
 UP BOUND     c1851     1
 UP BOUND     c1852     1
 UP BOUND     c1853     1
 UP BOUND     c1854     1
 UP BOUND     c1855     1
 UP BOUND     c1856     1
 UP BOUND     c1857     1
 UP BOUND     c1858     1
 UP BOUND     c1859     1
 UP BOUND     c1860     1
 UP BOUND     c1861     1
 UP BOUND     c1862     1
 UP BOUND     c1863     1
 FX BOUND     c1864     0
 FX BOUND     c1865     0
 FX BOUND     c1866     0
 UP BOUND     c1867     1
 UP BOUND     c1868     10000
 UP BOUND     c1869     1
 FX BOUND     c1870     0
 UP BOUND     c1871     1
 UP BOUND     c1872     10000
 UP BOUND     c1873     1
 UP BOUND     c1874     1
 UP BOUND     c1875     1
 FX BOUND     c1876     1
 FX BOUND     c1877     1
 UP BOUND     c1878     1
 UP BOUND     c1879     1
 UP BOUND     c1880     1
 UP BOUND     c1881     1
 UP BOUND     c1882     1
 UP BOUND     c1883     1
 UP BOUND     c1884     1
 UP BOUND     c1885     1
 UP BOUND     c1886     1
 UP BOUND     c1887     1
 UP BOUND     c1888     1
 UP BOUND     c1889     1
 UP BOUND     c1890     1
 UP BOUND     c1891     1
 UP BOUND     c1892     1
 UP BOUND     c1893     1
 FX BOUND     c1894     0
 FX BOUND     c1895     0
 UP BOUND     c1896     1
 FX BOUND     c1897     0
 UP BOUND     c1898     10000
 UP BOUND     c1899     1
 UP BOUND     c1900     1
 FX BOUND     c1901     0
 UP BOUND     c1902     1
 UP BOUND     c1903     10000
 UP BOUND     c1904     1
 FX BOUND     c1905     0
 FX BOUND     c1906     0
 UP BOUND     c1907     1
 FX BOUND     c1908     10000
 UP BOUND     c1909     1
 UP BOUND     c1910     1
 UP BOUND     c1911     1
 UP BOUND     c1912     10000
 UP BOUND     c1913     1
 UP BOUND     c1914     1
 FX BOUND     c1915     1
 UP BOUND     c1916     1
 UP BOUND     c1917     1
 UP BOUND     c1918     1
 UP BOUND     c1919     1
 UP BOUND     c1920     1
 UP BOUND     c1921     1
 UP BOUND     c1922     1
 UP BOUND     c1923     1
 UP BOUND     c1924     1
 UP BOUND     c1925     1
 UP BOUND     c1926     10000
 UP BOUND     c1927     1
 UP BOUND     c1928     1
 UP BOUND     c1929     1
 UP BOUND     c1930     1
 UP BOUND     c1931     1
 UP BOUND     c1932     1
 UP BOUND     c1933     1
 UP BOUND     c1934     1
 UP BOUND     c1935     1
 UP BOUND     c1936     1
 UP BOUND     c1937     1
 UP BOUND     c1938     1
 UP BOUND     c1939     1
 UP BOUND     c1940     10000
 UP BOUND     c1941     1
 UP BOUND     c1942     1
 UP BOUND     c1943     1
 UP BOUND     c1944     1
 UP BOUND     c1945     1
 UP BOUND     c1946     1
 UP BOUND     c1947     10000
 UP BOUND     c1948     1
 UP BOUND     c1949     1
 UP BOUND     c1950     1
 UP BOUND     c1951     1
 UP BOUND     c1952     1
 UP BOUND     c1953     1
 UP BOUND     c1954     1
 UP BOUND     c1955     1
 UP BOUND     c1956     1
 UP BOUND     c1957     1
 UP BOUND     c1958     1
 UP BOUND     c1959     1
 UP BOUND     c1960     1
 UP BOUND     c1961     1
 UP BOUND     c1962     1
 UP BOUND     c1963     1
 UP BOUND     c1964     1
 UP BOUND     c1965     1
 UP BOUND     c1966     1
 UP BOUND     c1967     1
 FX BOUND     c1968     0
 UP BOUND     c1969     1
 UP BOUND     c1970     1
 UP BOUND     c1971     1
 UP BOUND     c1972     1
 UP BOUND     c1973     1
 UP BOUND     c1974     1
 UP BOUND     c1975     1
 UP BOUND     c1976     10000
 UP BOUND     c1977     1
 UP BOUND     c1978     1
 UP BOUND     c1979     1
 UP BOUND     c1980     1
 UP BOUND     c1981     10000
 UP BOUND     c1982     1
 UP BOUND     c1983     1
 UP BOUND     c1984     1
 UP BOUND     c1985     1
 UP BOUND     c1986     1
 UP BOUND     c1987     10000
 UP BOUND     c1988     1
 UP BOUND     c1989     1
 FX BOUND     c1990     0
 UP BOUND     c1991     1
 UP BOUND     c1992     1
 UP BOUND     c1993     1
 UP BOUND     c1994     1
 UP BOUND     c1995     1
 UP BOUND     c1996     1
 UP BOUND     c1997     1
 UP BOUND     c1998     1
 UP BOUND     c1999     1
 UP BOUND     c2000     1
 UP BOUND     c2001     1
 UP BOUND     c2002     1
 FX BOUND     c2003     0
 UP BOUND     c2004     1
 UP BOUND     c2005     1
 UP BOUND     c2006     10000
 UP BOUND     c2007     1
 UP BOUND     c2008     10000
 UP BOUND     c2009     1
 UP BOUND     c2010     1
 UP BOUND     c2011     1
 UP BOUND     c2012     10000
 UP BOUND     c2013     1
 UP BOUND     c2014     1
 UP BOUND     c2015     1
 UP BOUND     c2016     1
 UP BOUND     c2017     1
 UP BOUND     c2018     1
 UP BOUND     c2019     1
 UP BOUND     c2020     1
 UP BOUND     c2021     1
 UP BOUND     c2022     1
 UP BOUND     c2023     1
 UP BOUND     c2024     1
 UP BOUND     c2025     1
 UP BOUND     c2026     1
 UP BOUND     c2027     1
 UP BOUND     c2028     1
 UP BOUND     c2029     10000
 UP BOUND     c2030     1
 UP BOUND     c2031     1
 UP BOUND     c2032     1
 UP BOUND     c2033     1
 UP BOUND     c2034     1
 UP BOUND     c2035     1
 UP BOUND     c2036     1
 UP BOUND     c2037     10000
 UP BOUND     c2038     1
 UP BOUND     c2039     1
 UP BOUND     c2040     1
 UP BOUND     c2041     1
 UP BOUND     c2042     1
 UP BOUND     c2043     1
 UP BOUND     c2044     1
 FX BOUND     c2045     0
 UP BOUND     c2046     1
 UP BOUND     c2047     1
 UP BOUND     c2048     1
 UP BOUND     c2049     10000
 UP BOUND     c2050     1
 UP BOUND     c2051     1
 UP BOUND     c2052     1
 UP BOUND     c2053     10000
 UP BOUND     c2054     1
 FX BOUND     c2055     0
 UP BOUND     c2056     1
 UP BOUND     c2057     1
 UP BOUND     c2058     1
 UP BOUND     c2059     1
 UP BOUND     c2060     1
 FX BOUND     c2061     0
 FX BOUND     c2062     0
 UP BOUND     c2063     1
 FX BOUND     c2064     0
 FX BOUND     c2065     0
 UP BOUND     c2066     1
 UP BOUND     c2067     1
 UP BOUND     c2068     1
 FX BOUND     c2069     0
 FX BOUND     c2070     0
 UP BOUND     c2071     1
 UP BOUND     c2072     1
 UP BOUND     c2073     1
 UP BOUND     c2074     1
 UP BOUND     c2075     1
 UP BOUND     c2076     1
 UP BOUND     c2077     1
 UP BOUND     c2078     1
 UP BOUND     c2079     1
 UP BOUND     c2080     1
 UP BOUND     c2081     1
 UP BOUND     c2082     1
 UP BOUND     c2083     1
 UP BOUND     c2084     1
 UP BOUND     c2085     10000
 UP BOUND     c2086     1
 FX BOUND     c2087     0
 FX BOUND     c2088     0
 UP BOUND     c2089     1
 UP BOUND     c2090     1
 UP BOUND     c2091     1
 UP BOUND     c2092     1
 UP BOUND     c2093     10000
 UP BOUND     c2094     1
 UP BOUND     c2095     1
 UP BOUND     c2096     10000
 UP BOUND     c2097     1
 UP BOUND     c2098     1
 UP BOUND     c2099     1
 UP BOUND     c2100     1
 UP BOUND     c2101     10000
 UP BOUND     c2102     1
 UP BOUND     c2103     1
 UP BOUND     c2104     10000
 UP BOUND     c2105     1
 UP BOUND     c2106     1
 UP BOUND     c2107     1
 FX BOUND     c2108     1
 FX BOUND     c2109     0
 FX BOUND     c2110     1
 UP BOUND     c2111     1
 UP BOUND     c2112     1
 UP BOUND     c2113     1
 UP BOUND     c2114     1
 UP BOUND     c2115     1
 UP BOUND     c2116     1
 FX BOUND     c2117     1
 FX BOUND     c2118     1
 FX BOUND     c2119     1
 FX BOUND     c2120     1
 FX BOUND     c2121     1
 FX BOUND     c2122     1
 FX BOUND     c2123     1
 UP BOUND     c2124     1
 UP BOUND     c2125     1
 UP BOUND     c2126     1
 UP BOUND     c2127     10000
 FX BOUND     c2128     1
 FX BOUND     c2129     1
 UP BOUND     c2130     1
 UP BOUND     c2131     1
 UP BOUND     c2132     1
 UP BOUND     c2133     1
 UP BOUND     c2134     1
 UP BOUND     c2135     1
 UP BOUND     c2136     1
 FX BOUND     c2137     1
 FX BOUND     c2138     1
 FX BOUND     c2139     1
 FX BOUND     c2140     1
 FX BOUND     c2141     1
 FX BOUND     c2142     1
 FX BOUND     c2143     1
 FX BOUND     c2144     1
 FX BOUND     c2145     1
 FX BOUND     c2146     1
 FX BOUND     c2147     1
 UP BOUND     c2148     1
 FX BOUND     c2149     1
 FX BOUND     c2150     1
 FX BOUND     c2151     1
 FX BOUND     c2152     1
 FX BOUND     c2153     1
 FX BOUND     c2154     1
 FX BOUND     c2155     1
 FX BOUND     c2156     1
 UP BOUND     c2157     1
 UP BOUND     c2158     1
 UP BOUND     c2159     1
 UP BOUND     c2160     1
 UP BOUND     c2161     1
 UP BOUND     c2162     1
 UP BOUND     c2163     1
 UP BOUND     c2164     1
 UP BOUND     c2165     1
 UP BOUND     c2166     1
 UP BOUND     c2167     1
 UP BOUND     c2168     1
 UP BOUND     c2169     1
 UP BOUND     c2170     1
 UP BOUND     c2171     1
 UP BOUND     c2172     1
 UP BOUND     c2173     1
 UP BOUND     c2174     1
 UP BOUND     c2175     1
 UP BOUND     c2176     10000
 UP BOUND     c2177     1
 UP BOUND     c2178     1
 UP BOUND     c2179     1
 UP BOUND     c2180     1
 UP BOUND     c2181     1
 UP BOUND     c2182     1
 UP BOUND     c2183     1
 UP BOUND     c2184     1
 UP BOUND     c2185     1
 UP BOUND     c2186     1
 UP BOUND     c2187     1
 UP BOUND     c2188     1
 UP BOUND     c2189     1
 UP BOUND     c2190     1
 UP BOUND     c2191     1
 UP BOUND     c2192     1
 UP BOUND     c2193     1
 UP BOUND     c2194     1
 UP BOUND     c2195     1
 UP BOUND     c2196     1
 UP BOUND     c2197     1
 UP BOUND     c2198     1
 UP BOUND     c2199     1
 UP BOUND     c2200     1
 UP BOUND     c2201     1
 UP BOUND     c2202     1
 UP BOUND     c2203     1
 UP BOUND     c2204     1
 UP BOUND     c2205     1
 UP BOUND     c2206     1
 UP BOUND     c2207     1
 UP BOUND     c2208     1
 UP BOUND     c2209     1
 UP BOUND     c2210     1
 UP BOUND     c2211     1
 UP BOUND     c2212     1
 UP BOUND     c2213     1
 UP BOUND     c2214     1
 UP BOUND     c2215     1
 UP BOUND     c2216     1
 UP BOUND     c2217     1
 UP BOUND     c2218     10000
 UP BOUND     c2219     1
 UP BOUND     c2220     1
 UP BOUND     c2221     1
 UP BOUND     c2222     1
 UP BOUND     c2223     1
 UP BOUND     c2224     1
 UP BOUND     c2225     1
 UP BOUND     c2226     1
 UP BOUND     c2227     1
 UP BOUND     c2228     1
 UP BOUND     c2229     1
 UP BOUND     c2230     1
 UP BOUND     c2231     10000
 UP BOUND     c2232     1
 UP BOUND     c2233     1
 UP BOUND     c2234     1
 UP BOUND     c2235     1
 UP BOUND     c2236     1
 UP BOUND     c2237     1
 UP BOUND     c2238     1
 UP BOUND     c2239     10000
 UP BOUND     c2240     1
 UP BOUND     c2241     1
 UP BOUND     c2242     1
 UP BOUND     c2243     1
 UP BOUND     c2244     1
 UP BOUND     c2245     1
 UP BOUND     c2246     1
 UP BOUND     c2247     1
 UP BOUND     c2248     1
 UP BOUND     c2249     1
 UP BOUND     c2250     1
 UP BOUND     c2251     1
 UP BOUND     c2252     1
 UP BOUND     c2253     1
 UP BOUND     c2254     1
 UP BOUND     c2255     1
 UP BOUND     c2256     1
 UP BOUND     c2257     1
 UP BOUND     c2258     1
 UP BOUND     c2259     1
 UP BOUND     c2260     1
 UP BOUND     c2261     1
 UP BOUND     c2262     1
 UP BOUND     c2263     1
 UP BOUND     c2264     10000
 UP BOUND     c2265     1
 FX BOUND     c2266     0
 UP BOUND     c2267     1
 UP BOUND     c2268     1
 UP BOUND     c2269     1
 UP BOUND     c2270     10000
 UP BOUND     c2271     1
 UP BOUND     c2272     10000
 UP BOUND     c2273     1
 UP BOUND     c2274     1
 UP BOUND     c2275     1
 UP BOUND     c2276     10000
 UP BOUND     c2277     1
 UP BOUND     c2278     1
 UP BOUND     c2279     1
 UP BOUND     c2280     10000
 UP BOUND     c2281     1
 UP BOUND     c2282     1
 UP BOUND     c2283     1
 UP BOUND     c2284     1
 UP BOUND     c2285     1
 UP BOUND     c2286     1
 UP BOUND     c2287     1
 UP BOUND     c2288     1
 UP BOUND     c2289     1
 UP BOUND     c2290     1
 UP BOUND     c2291     1
 UP BOUND     c2292     1
 FX BOUND     c2293     0
 UP BOUND     c2294     1
 UP BOUND     c2295     1
 UP BOUND     c2296     1
 UP BOUND     c2297     1
 UP BOUND     c2298     1
 UP BOUND     c2299     1
 UP BOUND     c2300     1
 UP BOUND     c2301     1
 UP BOUND     c2302     1
 UP BOUND     c2303     1
 UP BOUND     c2304     1
 UP BOUND     c2305     1
 UP BOUND     c2306     1
 UP BOUND     c2307     10000
 UP BOUND     c2308     1
 UP BOUND     c2309     1
 UP BOUND     c2310     1
 UP BOUND     c2311     10000
 UP BOUND     c2312     1
 UP BOUND     c2313     1
 UP BOUND     c2314     1
 UP BOUND     c2315     1
 UP BOUND     c2316     1
 UP BOUND     c2317     1
 UP BOUND     c2318     1
 UP BOUND     c2319     1
 UP BOUND     c2320     1
 UP BOUND     c2321     1
 UP BOUND     c2322     1
 UP BOUND     c2323     1
 UP BOUND     c2324     1
 UP BOUND     c2325     1
 UP BOUND     c2326     1
 UP BOUND     c2327     1
 FX BOUND     c2328     0
 UP BOUND     c2329     1
 UP BOUND     c2330     1
 UP BOUND     c2331     1
 UP BOUND     c2332     1
 UP BOUND     c2333     1
 UP BOUND     c2334     1
 UP BOUND     c2335     10000
 UP BOUND     c2336     1
 UP BOUND     c2337     10000
 UP BOUND     c2338     1
 UP BOUND     c2339     1
 UP BOUND     c2340     1
 UP BOUND     c2341     1
 UP BOUND     c2342     1
 UP BOUND     c2343     1
 UP BOUND     c2344     1
 UP BOUND     c2345     1
 UP BOUND     c2346     1
 UP BOUND     c2347     1
 UP BOUND     c2348     1
 UP BOUND     c2349     1
 UP BOUND     c2350     1
 UP BOUND     c2351     1
 FX BOUND     c2352     1
 UP BOUND     c2353     1
 UP BOUND     c2354     1
 UP BOUND     c2355     1
 UP BOUND     c2356     1
 UP BOUND     c2357     1
 UP BOUND     c2358     1
 UP BOUND     c2359     1
 UP BOUND     c2360     1
 UP BOUND     c2361     1
 UP BOUND     c2362     1
 UP BOUND     c2363     1
 UP BOUND     c2364     1
 UP BOUND     c2365     1
 UP BOUND     c2366     1
 UP BOUND     c2367     1
 UP BOUND     c2368     1
 UP BOUND     c2369     1
 UP BOUND     c2370     10000
 UP BOUND     c2371     1
 UP BOUND     c2372     1
 UP BOUND     c2373     1
 UP BOUND     c2374     1
 UP BOUND     c2375     1
 UP BOUND     c2376     1
 UP BOUND     c2377     1
 UP BOUND     c2378     1
 UP BOUND     c2379     1
 UP BOUND     c2380     1
 UP BOUND     c2381     1
 UP BOUND     c2382     1
 UP BOUND     c2383     1
 UP BOUND     c2384     1
 UP BOUND     c2385     1
 UP BOUND     c2386     1
 UP BOUND     c2387     1
 UP BOUND     c2388     1
 UP BOUND     c2389     1
 UP BOUND     c2390     1
 UP BOUND     c2391     1
 UP BOUND     c2392     1
 UP BOUND     c2393     10000
 UP BOUND     c2394     1
 FX BOUND     c2395     0
 UP BOUND     c2396     1
 UP BOUND     c2397     10000
 UP BOUND     c2398     1
 FX BOUND     c2399     0
 UP BOUND     c2400     1
 UP BOUND     c2401     1
 UP BOUND     c2402     1
 UP BOUND     c2403     10000
 UP BOUND     c2404     1
 UP BOUND     c2405     1
 UP BOUND     c2406     1
 UP BOUND     c2407     1
 UP BOUND     c2408     1
 UP BOUND     c2409     10000
 UP BOUND     c2410     1
 UP BOUND     c2411     10000
 UP BOUND     c2412     1
 FX BOUND     c2413     0
 FX BOUND     c2414     0
 UP BOUND     c2415     1
 UP BOUND     c2416     1
 UP BOUND     c2417     10000
 UP BOUND     c2418     1
 UP BOUND     c2419     10000
 UP BOUND     c2420     1
 UP BOUND     c2421     1
 UP BOUND     c2422     1
 UP BOUND     c2423     1
 UP BOUND     c2424     1
 UP BOUND     c2425     1
 UP BOUND     c2426     10000
 UP BOUND     c2427     1
 UP BOUND     c2428     1
 UP BOUND     c2429     1
 UP BOUND     c2430     10000
 UP BOUND     c2431     1
 UP BOUND     c2432     10000
 UP BOUND     c2433     1
 UP BOUND     c2434     1
 UP BOUND     c2435     10000
 UP BOUND     c2436     1
 UP BOUND     c2437     1
 UP BOUND     c2438     1
 FX BOUND     c2439     0
 UP BOUND     c2440     1
 UP BOUND     c2441     1
 UP BOUND     c2442     1
 UP BOUND     c2443     1
 UP BOUND     c2444     10000
 UP BOUND     c2445     1
 UP BOUND     c2446     1
 UP BOUND     c2447     10000
 UP BOUND     c2448     1
 UP BOUND     c2449     1
 UP BOUND     c2450     1
 UP BOUND     c2451     1
 UP BOUND     c2452     1
 FX BOUND     c2453     0
 FX BOUND     c2454     0
 UP BOUND     c2455     1
 UP BOUND     c2456     1
 UP BOUND     c2457     1
 UP BOUND     c2458     1
 UP BOUND     c2459     1
 UP BOUND     c2460     1
 UP BOUND     c2461     1
 UP BOUND     c2462     10000
 UP BOUND     c2463     1
 UP BOUND     c2464     1
 UP BOUND     c2465     1
 UP BOUND     c2466     1
 UP BOUND     c2467     1
 UP BOUND     c2468     1
 FX BOUND     c2469     0
 UP BOUND     c2470     10000
 UP BOUND     c2471     1
 UP BOUND     c2472     1
 UP BOUND     c2473     10000
 UP BOUND     c2474     1
 UP BOUND     c2475     1
 UP BOUND     c2476     1
 UP BOUND     c2477     1
 UP BOUND     c2478     1
 UP BOUND     c2479     1
 UP BOUND     c2480     1
 UP BOUND     c2481     1
 UP BOUND     c2482     1
 UP BOUND     c2483     1
 UP BOUND     c2484     10000
 UP BOUND     c2485     1
 UP BOUND     c2486     1
 UP BOUND     c2487     1
 UP BOUND     c2488     1
 UP BOUND     c2489     1
 UP BOUND     c2490     1
 UP BOUND     c2491     1
 UP BOUND     c2492     1
 FX BOUND     c2493     0
 UP BOUND     c2494     1
 UP BOUND     c2495     1
 UP BOUND     c2496     10000
 UP BOUND     c2497     1
 UP BOUND     c2498     1
 UP BOUND     c2499     1
 UP BOUND     c2500     1
 UP BOUND     c2501     1
 UP BOUND     c2502     1
 UP BOUND     c2503     10000
 UP BOUND     c2504     1
 UP BOUND     c2505     1
 UP BOUND     c2506     1
 FX BOUND     c2507     0
 UP BOUND     c2508     10000
 UP BOUND     c2509     1
 UP BOUND     c2510     1
 UP BOUND     c2511     1
 UP BOUND     c2512     1
 UP BOUND     c2513     10000
 UP BOUND     c2514     1
 UP BOUND     c2515     1
 UP BOUND     c2516     1
 FX BOUND     c2517     0
 UP BOUND     c2518     1
 UP BOUND     c2519     1
 UP BOUND     c2520     1
 UP BOUND     c2521     10000
 UP BOUND     c2522     1
 UP BOUND     c2523     1
 UP BOUND     c2524     10000
 UP BOUND     c2525     1
 FX BOUND     c2526     0
 UP BOUND     c2527     1
 UP BOUND     c2528     1
 UP BOUND     c2529     1
 UP BOUND     c2530     1
 UP BOUND     c2531     1
 UP BOUND     c2532     1
 UP BOUND     c2533     1
 UP BOUND     c2534     1
 UP BOUND     c2535     1
 UP BOUND     c2536     10000
 UP BOUND     c2537     1
 UP BOUND     c2538     1
 FX BOUND     c2539     0
 UP BOUND     c2540     1
 UP BOUND     c2541     1
 UP BOUND     c2542     1
 UP BOUND     c2543     1
 UP BOUND     c2544     1
 UP BOUND     c2545     1
 UP BOUND     c2546     1
 UP BOUND     c2547     1
 UP BOUND     c2548     1
 UP BOUND     c2549     1
 UP BOUND     c2550     1
 UP BOUND     c2551     1
 UP BOUND     c2552     1
 UP BOUND     c2553     10000
 UP BOUND     c2554     1
 UP BOUND     c2555     1
 UP BOUND     c2556     1
 UP BOUND     c2557     1
 UP BOUND     c2558     1
 UP BOUND     c2559     1
 UP BOUND     c2560     10000
 UP BOUND     c2561     1
 UP BOUND     c2562     1
 UP BOUND     c2563     10000
 UP BOUND     c2564     1
 UP BOUND     c2565     1
 UP BOUND     c2566     1
 UP BOUND     c2567     1
 UP BOUND     c2568     10000
 UP BOUND     c2569     1
 UP BOUND     c2570     1
 UP BOUND     c2571     1
 UP BOUND     c2572     1
 UP BOUND     c2573     1
 UP BOUND     c2574     1
 UP BOUND     c2575     1
 UP BOUND     c2576     1
 UP BOUND     c2577     1
 UP BOUND     c2578     1
 UP BOUND     c2579     1
 UP BOUND     c2580     1
 UP BOUND     c2581     1
 FX BOUND     c2582     0
 UP BOUND     c2583     10000
 UP BOUND     c2584     1
 UP BOUND     c2585     1
 UP BOUND     c2586     1
 UP BOUND     c2587     1
 UP BOUND     c2588     1
 UP BOUND     c2589     1
 UP BOUND     c2590     1
 UP BOUND     c2591     1
 UP BOUND     c2592     1
 UP BOUND     c2593     10000
 UP BOUND     c2594     1
 UP BOUND     c2595     1
 UP BOUND     c2596     1
 UP BOUND     c2597     1
 UP BOUND     c2598     1
 UP BOUND     c2599     1
 UP BOUND     c2600     1
 UP BOUND     c2601     1
 UP BOUND     c2602     1
 UP BOUND     c2603     1
 UP BOUND     c2604     1
 UP BOUND     c2605     1
 UP BOUND     c2606     1
 FX BOUND     c2607     0
 UP BOUND     c2608     10000
 UP BOUND     c2609     1
 UP BOUND     c2610     1
 UP BOUND     c2611     10000
 UP BOUND     c2612     1
 UP BOUND     c2613     1
 UP BOUND     c2614     1
 UP BOUND     c2615     1
 UP BOUND     c2616     10000
 UP BOUND     c2617     1
 UP BOUND     c2618     1
 UP BOUND     c2619     10000
 UP BOUND     c2620     1
 FX BOUND     c2621     0
 UP BOUND     c2622     1
 UP BOUND     c2623     1
 UP BOUND     c2624     1
 UP BOUND     c2625     1
 UP BOUND     c2626     1
 UP BOUND     c2627     1
 UP BOUND     c2628     1
 UP BOUND     c2629     1
 UP BOUND     c2630     1
 UP BOUND     c2631     1
 UP BOUND     c2632     1
 UP BOUND     c2633     1
 UP BOUND     c2634     1
 UP BOUND     c2635     1
 UP BOUND     c2636     1
 UP BOUND     c2637     1
 UP BOUND     c2638     1
 UP BOUND     c2639     1
 UP BOUND     c2640     1
 UP BOUND     c2641     10000
 UP BOUND     c2642     1
 UP BOUND     c2643     1
 UP BOUND     c2644     1
 FX BOUND     c2645     0
 UP BOUND     c2646     1
 FX BOUND     c2647     0
 UP BOUND     c2648     1
 UP BOUND     c2649     1
 UP BOUND     c2650     1
 UP BOUND     c2651     1
 UP BOUND     c2652     1
 UP BOUND     c2653     1
 UP BOUND     c2654     1
 UP BOUND     c2655     1
 UP BOUND     c2656     1
 UP BOUND     c2657     1
 UP BOUND     c2658     1
 UP BOUND     c2659     1
 UP BOUND     c2660     1
 UP BOUND     c2661     1
 UP BOUND     c2662     10000
 UP BOUND     c2663     1
 UP BOUND     c2664     1
 UP BOUND     c2665     1
 UP BOUND     c2666     1
 UP BOUND     c2667     1
 UP BOUND     c2668     1
 UP BOUND     c2669     1
 UP BOUND     c2670     1
 UP BOUND     c2671     1
 UP BOUND     c2672     1
 UP BOUND     c2673     1
 UP BOUND     c2674     1
 UP BOUND     c2675     1
 UP BOUND     c2676     1
 UP BOUND     c2677     1
 UP BOUND     c2678     1
 UP BOUND     c2679     1
 UP BOUND     c2680     1
 UP BOUND     c2681     1
 UP BOUND     c2682     1
 UP BOUND     c2683     1
 UP BOUND     c2684     1
 UP BOUND     c2685     1
 UP BOUND     c2686     10000
 UP BOUND     c2687     1
 UP BOUND     c2688     1
 UP BOUND     c2689     1
 UP BOUND     c2690     10000
 UP BOUND     c2691     1
 UP BOUND     c2692     1
 UP BOUND     c2693     1
 UP BOUND     c2694     1
 UP BOUND     c2695     1
 UP BOUND     c2696     1
 UP BOUND     c2697     1
 UP BOUND     c2698     1
 UP BOUND     c2699     1
 UP BOUND     c2700     1
 UP BOUND     c2701     1
 UP BOUND     c2702     1
 UP BOUND     c2703     1
 UP BOUND     c2704     10000
 UP BOUND     c2705     1
 UP BOUND     c2706     1
 UP BOUND     c2707     1
 UP BOUND     c2708     1
 UP BOUND     c2709     1
 UP BOUND     c2710     1
 UP BOUND     c2711     1
 UP BOUND     c2712     1
 UP BOUND     c2713     1
 UP BOUND     c2714     1
 UP BOUND     c2715     1
 UP BOUND     c2716     1
 UP BOUND     c2717     1
 UP BOUND     c2718     1
 UP BOUND     c2719     1
 FX BOUND     c2720     0
 UP BOUND     c2721     1
 UP BOUND     c2722     1
 FX BOUND     c2723     0
 UP BOUND     c2724     1
 UP BOUND     c2725     1
 UP BOUND     c2726     1
 UP BOUND     c2727     10000
 UP BOUND     c2728     1
 UP BOUND     c2729     10000
 UP BOUND     c2730     1
 UP BOUND     c2731     1
 UP BOUND     c2732     1
 UP BOUND     c2733     1
 UP BOUND     c2734     10000
 UP BOUND     c2735     1
 UP BOUND     c2736     1
 UP BOUND     c2737     1
 UP BOUND     c2738     1
 UP BOUND     c2739     10000
 UP BOUND     c2740     1
 UP BOUND     c2741     1
 UP BOUND     c2742     1
 UP BOUND     c2743     1
 UP BOUND     c2744     1
 UP BOUND     c2745     1
 UP BOUND     c2746     1
 UP BOUND     c2747     1
 UP BOUND     c2748     1
 UP BOUND     c2749     1
 UP BOUND     c2750     1
 UP BOUND     c2751     1
 UP BOUND     c2752     1
 UP BOUND     c2753     1
 UP BOUND     c2754     1
 UP BOUND     c2755     1
 UP BOUND     c2756     1
 UP BOUND     c2757     1
 UP BOUND     c2758     1
 UP BOUND     c2759     1
 UP BOUND     c2760     1
 UP BOUND     c2761     1
 UP BOUND     c2762     1
 UP BOUND     c2763     1
 UP BOUND     c2764     1
 UP BOUND     c2765     10000
 UP BOUND     c2766     1
 UP BOUND     c2767     1
 UP BOUND     c2768     10000
 UP BOUND     c2769     1
 UP BOUND     c2770     1
 UP BOUND     c2771     1
 UP BOUND     c2772     10000
 UP BOUND     c2773     1
 UP BOUND     c2774     1
 UP BOUND     c2775     1
 UP BOUND     c2776     10000
 UP BOUND     c2777     1
 UP BOUND     c2778     1
 UP BOUND     c2779     1
 FX BOUND     c2780     0
 FX BOUND     c2781     0
 UP BOUND     c2782     1
 UP BOUND     c2783     1
 UP BOUND     c2784     1
 UP BOUND     c2785     10000
 UP BOUND     c2786     1
 UP BOUND     c2787     1
 UP BOUND     c2788     1
 FX BOUND     c2789     0
 UP BOUND     c2790     1
 UP BOUND     c2791     1
 UP BOUND     c2792     1
 UP BOUND     c2793     1
 UP BOUND     c2794     1
 UP BOUND     c2795     1
 UP BOUND     c2796     1
 UP BOUND     c2797     1
 UP BOUND     c2798     10000
 UP BOUND     c2799     1
 UP BOUND     c2800     1
 UP BOUND     c2801     1
 UP BOUND     c2802     1
 UP BOUND     c2803     10000
 UP BOUND     c2804     1
 UP BOUND     c2805     1
 UP BOUND     c2806     1
 UP BOUND     c2807     1
 UP BOUND     c2808     1
 UP BOUND     c2809     1
 UP BOUND     c2810     1
 UP BOUND     c2811     1
 UP BOUND     c2812     1
 UP BOUND     c2813     1
 UP BOUND     c2814     10000
 UP BOUND     c2815     1
 UP BOUND     c2816     1
 UP BOUND     c2817     10000
 UP BOUND     c2818     1
 UP BOUND     c2819     1
 UP BOUND     c2820     10000
 UP BOUND     c2821     1
 UP BOUND     c2822     1
 UP BOUND     c2823     1
 UP BOUND     c2824     1
 UP BOUND     c2825     1
 UP BOUND     c2826     10000
 UP BOUND     c2827     1
 UP BOUND     c2828     1
 UP BOUND     c2829     1
 FX BOUND     c2830     0
 FX BOUND     c2831     0
 UP BOUND     c2832     1
 UP BOUND     c2833     1
 UP BOUND     c2834     10000
 UP BOUND     c2835     1
 UP BOUND     c2836     10000
 UP BOUND     c2837     1
 UP BOUND     c2838     1
 UP BOUND     c2839     1
 UP BOUND     c2840     1
 UP BOUND     c2841     1
 UP BOUND     c2842     1
 UP BOUND     c2843     1
 UP BOUND     c2844     1
 UP BOUND     c2845     10000
 FX BOUND     c2846     0
 UP BOUND     c2847     10000
 UP BOUND     c2848     1
 FX BOUND     c2849     0
 UP BOUND     c2850     1
 FX BOUND     c2851     0
 UP BOUND     c2852     1
 FX BOUND     c2853     0
 FX BOUND     c2854     0
 FX BOUND     c2855     0
 UP BOUND     c2856     1
 FX BOUND     c2857     0
 UP BOUND     c2858     1
 UP BOUND     c2859     10000
 UP BOUND     c2860     1
 FX BOUND     c2861     0
 UP BOUND     c2862     1
 UP BOUND     c2863     10000
 UP BOUND     c2864     1
 FX BOUND     c2865     0
 UP BOUND     c2866     1
 UP BOUND     c2867     10000
 FX BOUND     c2868     0
 FX BOUND     c2869     0
 UP BOUND     c2870     1
 FX BOUND     c2871     0
 UP BOUND     c2872     1
 FX BOUND     c2873     0
 UP BOUND     c2874     1
 UP BOUND     c2875     10000
 FX BOUND     c2876     0
 UP BOUND     c2877     10000
 UP BOUND     c2878     1
 FX BOUND     c2879     0
 UP BOUND     c2880     1
 FX BOUND     c2881     0
 UP BOUND     c2882     1
 UP BOUND     c2883     10000
 UP BOUND     c2884     1
 FX BOUND     c2885     0
 FX BOUND     c2886     0
 FX BOUND     c2887     0
 FX BOUND     c2888     0
 FX BOUND     c2889     0
 UP BOUND     c2890     1
 UP BOUND     c2891     10000
 UP BOUND     c2892     1
 FX BOUND     c2893     0
 UP BOUND     c2894     1
 UP BOUND     c2895     10000
 FX BOUND     c2896     0
 FX BOUND     c2897     0
 UP BOUND     c2898     1
 UP BOUND     c2899     270
 FX BOUND     c2900     0
 UP BOUND     c2901     10000
 FX BOUND     c2902     0
 UP BOUND     c2903     10000
 FX BOUND     c2904     0
 UP BOUND     c2905     10000
 UP BOUND     c2906     1
 FX BOUND     c2907     0
 FX BOUND     c2908     0
 UP BOUND     c2909     10000
 UP BOUND     c2910     1
 UP BOUND     c2911     10000
 UP BOUND     c2912     1
 UP BOUND     c2913     10000
 UP BOUND     c2914     1
 UP BOUND     c2915     10000
 UP BOUND     c2916     1
 UP BOUND     c2917     10000
 UP BOUND     c2918     1
 UP BOUND     c2919     10000
 UP BOUND     c2920     1
 UP BOUND     c2921     10000
 UP BOUND     c2922     1
 UP BOUND     c2923     10000
 UP BOUND     c2924     1
 UP BOUND     c2925     10000
 UP BOUND     c2926     1
 UP BOUND     c2927     10000
 UP BOUND     c2928     1
 UP BOUND     c2929     10000
 UP BOUND     c2930     1
 UP BOUND     c2931     10000
 UP BOUND     c2932     1
 FX BOUND     c2933     0
 UP BOUND     c2934     1
 FX BOUND     c2935     0
 UP BOUND     c2936     1
 FX BOUND     c2937     0
 UP BOUND     c2938     1
 UP BOUND     c2939     10000
 UP BOUND     c2940     1
 UP BOUND     c2941     10000
 FX BOUND     c2942     0
 UP BOUND     c2943     10000
 UP BOUND     c2944     1
 UP BOUND     c2945     10000
 UP BOUND     c2946     1
 UP BOUND     c2947     10000
 UP BOUND     c2948     1
 UP BOUND     c2949     10000
 UP BOUND     c2950     1
 FX BOUND     c2951     0
 UP BOUND     c2952     1
 FX BOUND     c2953     0
 UP BOUND     c2954     1
 UP BOUND     c2955     10000
 UP BOUND     c2956     1
 UP BOUND     c2957     10000
 UP BOUND     c2958     1
 UP BOUND     c2959     10000
 UP BOUND     c2960     1
 UP BOUND     c2961     10000
 UP BOUND     c2962     1
 UP BOUND     c2963     10000
 UP BOUND     c2964     1
 UP BOUND     c2965     10000
 UP BOUND     c2966     1
 UP BOUND     c2967     10000
 UP BOUND     c2968     1
 UP BOUND     c2969     10000
 FX BOUND     c2970     0
 FX BOUND     c2971     0
 UP BOUND     c2972     1
 UP BOUND     c2973     10000
 UP BOUND     c2974     1
 UP BOUND     c2975     10000
 UP BOUND     c2976     1
 UP BOUND     c2977     10000
 UP BOUND     c2978     1
 UP BOUND     c2979     10000
 UP BOUND     c2980     1
 UP BOUND     c2981     10000
 UP BOUND     c2982     1
 UP BOUND     c2983     10000
 UP BOUND     c2984     1
 UP BOUND     c2985     10000
 FX BOUND     c2986     0
 UP BOUND     c2987     10000
 UP BOUND     c2988     1
 UP BOUND     c2989     10000
 UP BOUND     c2990     1
 UP BOUND     c2991     10000
 FX BOUND     c2992     0
 FX BOUND     c2993     0
 UP BOUND     c2994     1
 UP BOUND     c2995     10000
 UP BOUND     c2996     1
 UP BOUND     c2997     10000
 FX BOUND     c2998     0
 FX BOUND     c2999     0
 UP BOUND     c3000     1
 UP BOUND     c3001     10000
 UP BOUND     c3002     1
 UP BOUND     c3003     10000
 UP BOUND     c3004     1
 UP BOUND     c3005     10000
 FX BOUND     c3006     0
 FX BOUND     c3007     0
 FX BOUND     c3008     0
 FX BOUND     c3009     0
 UP BOUND     c3010     1
 UP BOUND     c3011     10000
 FX BOUND     c3012     0
 FX BOUND     c3013     0
 UP BOUND     c3014     1
 UP BOUND     c3015     10000
 UP BOUND     c3016     1
 UP BOUND     c3017     10000
 UP BOUND     c3018     1
 UP BOUND     c3019     10000
 UP BOUND     c3020     1
 UP BOUND     c3021     10000
 FX BOUND     c3022     0
 UP BOUND     c3023     10000
 FX BOUND     c3024     1
 UP BOUND     c3025     10000
 FX BOUND     c3026     0
 FX BOUND     c3027     0
 UP BOUND     c3028     1
 FX BOUND     c3029     0
 UP BOUND     c3030     1
 FX BOUND     c3031     0
 FX BOUND     c3032     0
 FX BOUND     c3033     0
 UP BOUND     c3034     1
 FX BOUND     c3035     0
 UP BOUND     c3036     1
 UP BOUND     c3037     10000
 UP BOUND     c3038     1
 UP BOUND     c3039     10000
 UP BOUND     c3040     1
 FX BOUND     c3041     0
 UP BOUND     c3042     1
 UP BOUND     c3043     10000
 FX BOUND     c3044     1
 UP BOUND     c3045     10000
 UP BOUND     c3046     1
 UP BOUND     c3047     10000
 UP BOUND     c3048     1
 FX BOUND     c3049     0
 UP BOUND     c3050     1
 FX BOUND     c3051     0
 FX BOUND     c3052     0
 FX BOUND     c3053     0
 FX BOUND     c3054     0
 FX BOUND     c3055     0
 UP BOUND     c3056     1
 FX BOUND     c3057     0
 UP BOUND     c3058     1
 UP BOUND     c3059     10000
 UP BOUND     c3060     1
 FX BOUND     c3061     0
 UP BOUND     c3062     1
 FX BOUND     c3063     0
 UP BOUND     c3064     1
 FX BOUND     c3065     0
 UP BOUND     c3066     1
 UP BOUND     c3067     10000
 FX BOUND     c3068     0
 UP BOUND     c3069     10000
 UP BOUND     c3070     1
 UP BOUND     c3071     10000
 UP BOUND     c3072     1
 UP BOUND     c3073     10000
 UP BOUND     c3074     1
 UP BOUND     c3075     10000
 UP BOUND     c3076     1
 FX BOUND     c3077     0
 UP BOUND     c3078     1
 FX BOUND     c3079     0
 UP BOUND     c3080     1
 UP BOUND     c3081     10000
 UP BOUND     c3082     1
 FX BOUND     c3083     0
 UP BOUND     c3084     1
 UP BOUND     c3085     10000
 UP BOUND     c3086     1
 UP BOUND     c3087     10000
 UP BOUND     c3088     1
 UP BOUND     c3089     10000
 UP BOUND     c3090     1
 FX BOUND     c3091     0
 UP BOUND     c3092     1
 UP BOUND     c3093     10000
 UP BOUND     c3094     1
 FX BOUND     c3095     0
 UP BOUND     c3096     1
 FX BOUND     c3097     0
 FX BOUND     c3098     0
 FX BOUND     c3099     0
 UP BOUND     c3100     1
 FX BOUND     c3101     0
 UP BOUND     c3102     1
 FX BOUND     c3103     0
 UP BOUND     c3104     1
 UP BOUND     c3105     10000
 FX BOUND     c3106     0
 FX BOUND     c3107     0
 FX BOUND     c3108     0
 FX BOUND     c3109     0
 UP BOUND     c3110     1
 UP BOUND     c3111     10000
 FX BOUND     c3112     0
 UP BOUND     c3113     10000
 FX BOUND     c3114     0
 FX BOUND     c3115     0
 UP BOUND     c3116     1
 FX BOUND     c3117     0
 UP BOUND     c3118     1
 UP BOUND     c3119     10000
 UP BOUND     c3120     1
 UP BOUND     c3121     10000
 UP BOUND     c3122     1
 FX BOUND     c3123     0
 UP BOUND     c3124     1
 FX BOUND     c3125     0
 UP BOUND     c3126     1
 UP BOUND     c3127     10000
 FX BOUND     c3128     0
 FX BOUND     c3129     0
 UP BOUND     c3130     1
 UP BOUND     c3131     10000
 UP BOUND     c3132     1
 FX BOUND     c3133     0
 UP BOUND     c3134     1
 FX BOUND     c3135     0
 UP BOUND     c3136     1
 FX BOUND     c3137     0
 UP BOUND     c3138     1
 UP BOUND     c3139     10000
 UP BOUND     c3140     1
 UP BOUND     c3141     10000
 UP BOUND     c3142     1
 UP BOUND     c3143     10000
 FX BOUND     c3144     0
 FX BOUND     c3145     0
 UP BOUND     c3146     1
 UP BOUND     c3147     10000
 FX BOUND     c3148     0
 FX BOUND     c3149     0
 UP BOUND     c3150     1
 UP BOUND     c3151     10000
 FX BOUND     c3152     0
 FX BOUND     c3153     0
 FX BOUND     c3154     0
 FX BOUND     c3155     0
 UP BOUND     c3156     1
 UP BOUND     c3157     10000
 FX BOUND     c3158     0
 FX BOUND     c3159     0
 UP BOUND     c3160     1
 UP BOUND     c3161     10000
 UP BOUND     c3162     1
 FX BOUND     c3163     0
 UP BOUND     c3164     1
 UP BOUND     c3165     10000
 UP BOUND     c3166     1
 FX BOUND     c3167     0
 UP BOUND     c3168     1
 UP BOUND     c3169     10000
 FX BOUND     c3170     0
 UP BOUND     c3171     10000
 UP BOUND     c3172     1
 UP BOUND     c3173     10000
 UP BOUND     c3174     1
 FX BOUND     c3175     0
 UP BOUND     c3176     1
 UP BOUND     c3177     10000
 FX BOUND     c3178     0
 FX BOUND     c3179     0
 UP BOUND     c3180     1
 UP BOUND     c3181     10000
 UP BOUND     c3182     1
 UP BOUND     c3183     10000
 UP BOUND     c3184     1
 UP BOUND     c3185     10000
 FX BOUND     c3186     1
 LO BOUND     c3187     21.9035
 UP BOUND     c3187     23.5092999999994
 UP BOUND     c3188     1
 UP BOUND     c3189     10000
 UP BOUND     c3190     1
 UP BOUND     c3191     10000
 UP BOUND     c3192     1
 UP BOUND     c3193     10000
 FX BOUND     c3194     0
 FX BOUND     c3195     0
 UP BOUND     c3196     1
 UP BOUND     c3197     10000
 UP BOUND     c3198     1
 UP BOUND     c3199     10000
 UP BOUND     c3200     1
 FX BOUND     c3201     0
 UP BOUND     c3202     1
 UP BOUND     c3203     10000
 UP BOUND     c3204     1
 UP BOUND     c3205     10000
 UP BOUND     c3206     1
 UP BOUND     c3207     10000
 FX BOUND     c3208     0
 UP BOUND     c3209     10000
 UP BOUND     c3210     1
 UP BOUND     c3211     10000
 UP BOUND     c3212     1
 UP BOUND     c3213     10000
 UP BOUND     c3214     1
 UP BOUND     c3215     10000
 UP BOUND     c3216     1
 UP BOUND     c3217     10000
 UP BOUND     c3218     1
 UP BOUND     c3219     10000
 UP BOUND     c3220     1
 FX BOUND     c3221     0
 UP BOUND     c3222     1
 UP BOUND     c3223     10000
 FX BOUND     c3224     0
 UP BOUND     c3225     10000
 UP BOUND     c3226     1
 UP BOUND     c3227     10000
 UP BOUND     c3228     1
 UP BOUND     c3229     10000
 UP BOUND     c3230     1
 UP BOUND     c3231     10000
 FX BOUND     c3232     0
 UP BOUND     c3233     10000
 UP BOUND     c3234     1
 UP BOUND     c3235     10000
 FX BOUND     c3236     0
 FX BOUND     c3237     0
 FX BOUND     c3238     0
 FX BOUND     c3239     0
 UP BOUND     c3240     1
 UP BOUND     c3241     10000
 UP BOUND     c3242     1
 UP BOUND     c3243     10000
 UP BOUND     c3244     1
 FX BOUND     c3245     0
 UP BOUND     c3246     1
 FX BOUND     c3247     0
 UP BOUND     c3248     1
 FX BOUND     c3249     0
 UP BOUND     c3250     1
 UP BOUND     c3251     10000
 UP BOUND     c3252     1
 UP BOUND     c3253     10000
 UP BOUND     c3254     1
 UP BOUND     c3255     10000
 UP BOUND     c3256     1
 UP BOUND     c3257     10000
 UP BOUND     c3258     1
 UP BOUND     c3259     10000
 FX BOUND     c3260     0
 FX BOUND     c3261     0
 UP BOUND     c3262     1
 UP BOUND     c3263     10000
 UP BOUND     c3264     1
 UP BOUND     c3265     10000
 UP BOUND     c3266     1
 UP BOUND     c3267     10000
 FX BOUND     c3268     0
 FX BOUND     c3269     0
 FX BOUND     c3270     0
 FX BOUND     c3271     0
 FX BOUND     c3272     0
 FX BOUND     c3273     0
 UP BOUND     c3274     1
 UP BOUND     c3275     10000
 UP BOUND     c3276     1
 UP BOUND     c3277     10000
 UP BOUND     c3278     1
 UP BOUND     c3279     10000
 FX BOUND     c3280     0
 FX BOUND     c3281     0
 FX BOUND     c3282     0
 UP BOUND     c3283     10000
 FX BOUND     c3284     0
 UP BOUND     c3285     10000
 UP BOUND     c3286     1
 FX BOUND     c3287     0
 UP BOUND     c3288     1
 FX BOUND     c3289     0
 UP BOUND     c3290     1
 UP BOUND     c3291     10000
 FX BOUND     c3292     0
 UP BOUND     c3293     10000
 UP BOUND     c3294     1
 FX BOUND     c3295     0
 FX BOUND     c3296     0
 UP BOUND     c3297     10000
 UP BOUND     c3298     1
 UP BOUND     c3299     10000
 UP BOUND     c3300     1
 FX BOUND     c3301     0
 UP BOUND     c3302     1
 UP BOUND     c3303     10000
 UP BOUND     c3304     1
 UP BOUND     c3305     10000
 UP BOUND     c3306     1
 FX BOUND     c3307     0
 UP BOUND     c3308     1
 UP BOUND     c3309     10000
 UP BOUND     c3310     1
 UP BOUND     c3311     10000
 UP BOUND     c3312     1
 UP BOUND     c3313     10000
 UP BOUND     c3314     1
 FX BOUND     c3315     0
 UP BOUND     c3316     1
 UP BOUND     c3317     10000
 UP BOUND     c3318     1
 UP BOUND     c3319     10000
 UP BOUND     c3320     1
 UP BOUND     c3321     10000
 UP BOUND     c3322     1
 UP BOUND     c3323     10000
 UP BOUND     c3324     1
 UP BOUND     c3325     10000
 UP BOUND     c3326     1
 FX BOUND     c3327     0
 FX BOUND     c3328     0
 UP BOUND     c3329     10000
 FX BOUND     c3330     0
 FX BOUND     c3331     0
 FX BOUND     c3332     0
 FX BOUND     c3333     0
 FX BOUND     c3334     0
 FX BOUND     c3335     0
 FX BOUND     c3336     0
 FX BOUND     c3337     0
 FX BOUND     c3338     0
 FX BOUND     c3339     0
 FX BOUND     c3340     0
 FX BOUND     c3341     0
 FX BOUND     c3342     0
 FX BOUND     c3343     0
 UP BOUND     c3344     1
 UP BOUND     c3345     10000
 FX BOUND     c3346     0
 UP BOUND     c3347     10000
 UP BOUND     c3348     1
 UP BOUND     c3349     10000
 UP BOUND     c3350     1
 UP BOUND     c3351     10000
 UP BOUND     c3352     1
 UP BOUND     c3353     10000
 UP BOUND     c3354     1
 UP BOUND     c3355     10000
 UP BOUND     c3356     1
 FX BOUND     c3357     0
 FX BOUND     c3358     0
 FX BOUND     c3359     0
 UP BOUND     c3360     1
 FX BOUND     c3361     0
 FX BOUND     c3362     0
 FX BOUND     c3363     0
 UP BOUND     c3364     1
 FX BOUND     c3365     0
 UP BOUND     c3366     1
 UP BOUND     c3367     10000
 UP BOUND     c3368     1
 UP BOUND     c3369     10000
 UP BOUND     c3370     1
 UP BOUND     c3371     10000
 UP BOUND     c3372     1
 UP BOUND     c3373     10000
 UP BOUND     c3374     1
 FX BOUND     c3375     0
 FX BOUND     c3376     0
 FX BOUND     c3377     0
 UP BOUND     c3378     1
 UP BOUND     c3379     287.388109
 FX BOUND     c3380     0
 FX BOUND     c3381     0
 UP BOUND     c3382     1
 FX BOUND     c3383     0
 UP BOUND     c3384     1
 UP BOUND     c3385     10000
 UP BOUND     c3386     1
 UP BOUND     c3387     10000
 FX BOUND     c3388     0
 UP BOUND     c3389     10000
 UP BOUND     c3390     1
 FX BOUND     c3391     0
 UP BOUND     c3392     1
 UP BOUND     c3393     10000
 UP BOUND     c3394     1
 FX BOUND     c3395     0
 UP BOUND     c3396     1
 FX BOUND     c3397     0
 FX BOUND     c3398     0
 UP BOUND     c3399     10000
 UP BOUND     c3400     1
 UP BOUND     c3401     10000
 UP BOUND     c3402     1
 UP BOUND     c3403     10000
 UP BOUND     c3404     1
 UP BOUND     c3405     10000
 UP BOUND     c3406     1
 UP BOUND     c3407     10000
 UP BOUND     c3408     1
 UP BOUND     c3409     10000
 UP BOUND     c3410     1
 UP BOUND     c3411     10000
 UP BOUND     c3412     1
 UP BOUND     c3413     10000
 UP BOUND     c3414     1
 UP BOUND     c3415     10000
 UP BOUND     c3416     1
 UP BOUND     c3417     10000
 UP BOUND     c3418     1
 UP BOUND     c3419     10000
 UP BOUND     c3420     1
 UP BOUND     c3421     10000
 UP BOUND     c3422     1
 UP BOUND     c3423     10000
 UP BOUND     c3424     1
 FX BOUND     c3425     0
 UP BOUND     c3426     1
 FX BOUND     c3427     0
 UP BOUND     c3428     1
 UP BOUND     c3429     10000
 UP BOUND     c3430     1
 UP BOUND     c3431     10000
 UP BOUND     c3432     1
 UP BOUND     c3433     10000
 FX BOUND     c3434     0
 UP BOUND     c3435     10000
 UP BOUND     c3436     1
 FX BOUND     c3437     0
 UP BOUND     c3438     1
 UP BOUND     c3439     10000
 UP BOUND     c3440     1
 UP BOUND     c3441     10000
 FX BOUND     c3442     0
 FX BOUND     c3443     0
 FX BOUND     c3444     0
 FX BOUND     c3445     0
 UP BOUND     c3446     1
 FX BOUND     c3447     0
 UP BOUND     c3448     1
 FX BOUND     c3449     0
 FX BOUND     c3450     0
 FX BOUND     c3451     0
 UP BOUND     c3452     1
 UP BOUND     c3453     10000
 UP BOUND     c3454     1
 UP BOUND     c3455     10000
 FX BOUND     c3456     0
 FX BOUND     c3457     0
 UP BOUND     c3458     1
 UP BOUND     c3459     10000
 UP BOUND     c3460     1
 FX BOUND     c3461     0
 UP BOUND     c3462     1
 UP BOUND     c3463     10000
 UP BOUND     c3464     1
 FX BOUND     c3465     0
 UP BOUND     c3466     1
 FX BOUND     c3467     0
 UP BOUND     c3468     1
 FX BOUND     c3469     0
 UP BOUND     c3470     1
 FX BOUND     c3471     0
 UP BOUND     c3472     1
 FX BOUND     c3473     0
 UP BOUND     c3474     1
 UP BOUND     c3475     10000
 UP BOUND     c3476     1
 FX BOUND     c3477     0
 UP BOUND     c3478     1
 UP BOUND     c3479     10000
 UP BOUND     c3480     1
 UP BOUND     c3481     10000
 UP BOUND     c3482     1
 UP BOUND     c3483     10000
 UP BOUND     c3484     1
 UP BOUND     c3485     10000
 UP BOUND     c3486     1
 UP BOUND     c3487     10000
 UP BOUND     c3488     1
 UP BOUND     c3489     10000
 UP BOUND     c3490     1
 FX BOUND     c3491     0
 UP BOUND     c3492     1
 UP BOUND     c3493     10000
 UP BOUND     c3494     1
 UP BOUND     c3495     10000
 UP BOUND     c3496     1
 UP BOUND     c3497     10000
 FX BOUND     c3498     0
 UP BOUND     c3499     10000
 UP BOUND     c3500     1
 UP BOUND     c3501     10000
 UP BOUND     c3502     1
 UP BOUND     c3503     10000
 UP BOUND     c3504     1
 UP BOUND     c3505     10000
 UP BOUND     c3506     1
 UP BOUND     c3507     10000
 UP BOUND     c3508     1
 UP BOUND     c3509     10000
 UP BOUND     c3510     1
 UP BOUND     c3511     10000
 UP BOUND     c3512     1
 UP BOUND     c3513     10000
 UP BOUND     c3514     1
 UP BOUND     c3515     10000
 UP BOUND     c3516     1
 UP BOUND     c3517     10000
 UP BOUND     c3518     1
 UP BOUND     c3519     10000
 UP BOUND     c3520     1
 UP BOUND     c3521     10000
 UP BOUND     c3522     1
 UP BOUND     c3523     10000
 UP BOUND     c3524     1
 UP BOUND     c3525     10000
 UP BOUND     c3526     1
 UP BOUND     c3527     10000
 UP BOUND     c3528     1
 UP BOUND     c3529     10000
 UP BOUND     c3530     1
 UP BOUND     c3531     10000
 FX BOUND     c3532     0
 FX BOUND     c3533     0
 UP BOUND     c3534     1
 FX BOUND     c3535     0
 UP BOUND     c3536     1
 UP BOUND     c3537     10000
 UP BOUND     c3538     1
 UP BOUND     c3539     10000
 UP BOUND     c3540     1
 UP BOUND     c3541     10000
 FX BOUND     c3542     0
 UP BOUND     c3543     10000
 UP BOUND     c3544     1
 UP BOUND     c3545     10000
 UP BOUND     c3546     1
 UP BOUND     c3547     10000
 UP BOUND     c3548     1
 FX BOUND     c3549     0
 UP BOUND     c3550     1
 UP BOUND     c3551     10000
 UP BOUND     c3552     1
 UP BOUND     c3553     10000
 UP BOUND     c3554     1
 UP BOUND     c3555     10000
 UP BOUND     c3556     1
 UP BOUND     c3557     10000
 UP BOUND     c3558     1
 FX BOUND     c3559     0
 UP BOUND     c3560     1
 FX BOUND     c3561     0
 UP BOUND     c3562     1
 UP BOUND     c3563     10000
 UP BOUND     c3564     1
 UP BOUND     c3565     10000
 UP BOUND     c3566     1
 FX BOUND     c3567     0
 FX BOUND     c3568     0
 FX BOUND     c3569     0
 FX BOUND     c3570     0
 UP BOUND     c3571     10000
 FX BOUND     c3572     0
 FX BOUND     c3573     0
 UP BOUND     c3574     1
 UP BOUND     c3575     10000
 UP BOUND     c3576     1
 UP BOUND     c3577     10000
 UP BOUND     c3578     1
 FX BOUND     c3579     0
 UP BOUND     c3580     1
 UP BOUND     c3581     10000
 UP BOUND     c3582     1
 UP BOUND     c3583     10000
 UP BOUND     c3584     1
 UP BOUND     c3585     10000
 UP BOUND     c3586     1
 UP BOUND     c3587     10000
 UP BOUND     c3588     1
 FX BOUND     c3589     0
 UP BOUND     c3590     1
 UP BOUND     c3591     10000
 UP BOUND     c3592     1
 UP BOUND     c3593     10000
 UP BOUND     c3594     1
 UP BOUND     c3595     10000
 UP BOUND     c3596     1
 UP BOUND     c3597     10000
 UP BOUND     c3598     1
 UP BOUND     c3599     10000
 UP BOUND     c3600     1
 UP BOUND     c3601     10000
 UP BOUND     c3602     1
 FX BOUND     c3603     0
 FX BOUND     c3604     0
 FX BOUND     c3605     0
 FX BOUND     c3606     0
 FX BOUND     c3607     0
 UP BOUND     c3608     1
 UP BOUND     c3609     10000
 UP BOUND     c3610     1
 UP BOUND     c3611     10000
 UP BOUND     c3612     1
 FX BOUND     c3613     0
 UP BOUND     c3614     1
 UP BOUND     c3615     10000
 UP BOUND     c3616     1
 FX BOUND     c3617     0
 FX BOUND     c3618     0
 FX BOUND     c3619     0
 UP BOUND     c3620     1
 UP BOUND     c3621     10000
 UP BOUND     c3622     1
 FX BOUND     c3623     0
 UP BOUND     c3624     1
 UP BOUND     c3625     10000
 UP BOUND     c3626     1
 UP BOUND     c3627     10000
 UP BOUND     c3628     1
 UP BOUND     c3629     10000
 FX BOUND     c3630     0
 FX BOUND     c3631     0
 UP BOUND     c3632     1
 UP BOUND     c3633     10000
 FX BOUND     c3634     0
 FX BOUND     c3635     0
 UP BOUND     c3636     1
 UP BOUND     c3637     10000
 UP BOUND     c3638     1
 UP BOUND     c3639     10000
 UP BOUND     c3640     1
 UP BOUND     c3641     10000
 UP BOUND     c3642     1
 UP BOUND     c3643     10000
 UP BOUND     c3644     1
 UP BOUND     c3645     10000
 UP BOUND     c3646     1
 UP BOUND     c3647     10000
 UP BOUND     c3648     1
 UP BOUND     c3649     10000
 UP BOUND     c3650     1
 UP BOUND     c3651     10000
 UP BOUND     c3652     1
 UP BOUND     c3653     10000
 UP BOUND     c3654     1
 UP BOUND     c3655     10000
 UP BOUND     c3656     1
 UP BOUND     c3657     10000
 UP BOUND     c3658     1
 UP BOUND     c3659     10000
 UP BOUND     c3660     1
 FX BOUND     c3661     0
 UP BOUND     c3662     1
 UP BOUND     c3663     10000
 UP BOUND     c3664     1
 UP BOUND     c3665     10000
 UP BOUND     c3666     1
 UP BOUND     c3667     10000
 UP BOUND     c3668     1
 UP BOUND     c3669     135
 UP BOUND     c3670     1
 UP BOUND     c3671     10000
 UP BOUND     c3672     1
 UP BOUND     c3673     10000
 UP BOUND     c3674     1
 UP BOUND     c3675     192.215948
 UP BOUND     c3676     1
 UP BOUND     c3677     10000
 UP BOUND     c3678     1
 UP BOUND     c3679     10000
 UP BOUND     c3680     1
 UP BOUND     c3681     10000
 UP BOUND     c3682     1
 UP BOUND     c3683     10000
 UP BOUND     c3684     1
 FX BOUND     c3685     0
 UP BOUND     c3686     1
 UP BOUND     c3687     10000
 UP BOUND     c3688     1
 UP BOUND     c3689     10000
 FX BOUND     c3690     0
 FX BOUND     c3691     0
 FX BOUND     c3692     0
 UP BOUND     c3693     10000
 UP BOUND     c3694     1
 UP BOUND     c3695     10000
 UP BOUND     c3696     1
 UP BOUND     c3697     10000
 UP BOUND     c3698     1
 UP BOUND     c3699     10000
 UP BOUND     c3700     1
 UP BOUND     c3701     10000
 UP BOUND     c3702     1
 UP BOUND     c3703     10000
 UP BOUND     c3704     1
 UP BOUND     c3705     10000
 UP BOUND     c3706     1
 UP BOUND     c3707     10000
 UP BOUND     c3708     1
 UP BOUND     c3709     10000
 UP BOUND     c3710     1
 UP BOUND     c3711     10000
 UP BOUND     c3712     1
 UP BOUND     c3713     10000
 UP BOUND     c3714     1
 UP BOUND     c3715     10000
 UP BOUND     c3716     1
 UP BOUND     c3717     10000
 UP BOUND     c3718     1
 UP BOUND     c3719     10000
 UP BOUND     c3720     1
 UP BOUND     c3721     10000
 UP BOUND     c3722     1
 UP BOUND     c3723     10000
 UP BOUND     c3724     1
 UP BOUND     c3725     10000
 UP BOUND     c3726     1
 UP BOUND     c3727     10000
 UP BOUND     c3728     1
 UP BOUND     c3729     10000
 UP BOUND     c3730     1
 UP BOUND     c3731     10000
 UP BOUND     c3732     1
 UP BOUND     c3733     10000
 UP BOUND     c3734     1
 FX BOUND     c3735     0
 UP BOUND     c3736     1
 UP BOUND     c3737     10000
 UP BOUND     c3738     1
 UP BOUND     c3739     10000
 FX BOUND     c3740     0
 FX BOUND     c3741     0
 UP BOUND     c3742     1
 UP BOUND     c3743     10000
 UP BOUND     c3744     1
 UP BOUND     c3745     10000
 UP BOUND     c3746     1
 UP BOUND     c3747     10000
 FX BOUND     c3748     0
 FX BOUND     c3749     0
 UP BOUND     c3750     1
 FX BOUND     c3751     0
 UP BOUND     c3752     1
 UP BOUND     c3753     10000
 UP BOUND     c3754     1
 FX BOUND     c3755     0
 FX BOUND     c3756     0
 FX BOUND     c3757     0
 FX BOUND     c3758     1
 UP BOUND     c3759     490.3911
 UP BOUND     c3760     1
 UP BOUND     c3761     10000
 UP BOUND     c3762     1
 UP BOUND     c3763     10000
 UP BOUND     c3764     1
 UP BOUND     c3765     10000
 UP BOUND     c3766     1
 UP BOUND     c3767     10000
 UP BOUND     c3768     1
 UP BOUND     c3769     10000
 UP BOUND     c3770     1
 UP BOUND     c3771     10000
 UP BOUND     c3772     1
 UP BOUND     c3773     10000
 UP BOUND     c3774     1
 UP BOUND     c3775     10000
 UP BOUND     c3776     1
 UP BOUND     c3777     10000
 UP BOUND     c3778     1
 UP BOUND     c3779     10000
 UP BOUND     c3780     1
 UP BOUND     c3781     10000
 UP BOUND     c3782     1
 UP BOUND     c3783     10000
 UP BOUND     c3784     1
 UP BOUND     c3785     10000
 UP BOUND     c3786     1
 UP BOUND     c3787     10000
 UP BOUND     c3788     1
 UP BOUND     c3789     10000
 UP BOUND     c3790     1
 FX BOUND     c3791     0
 UP BOUND     c3792     1
 UP BOUND     c3793     10000
 UP BOUND     c3794     1
 UP BOUND     c3795     10000
 UP BOUND     c3796     1
 UP BOUND     c3797     10000
 UP BOUND     c3798     1
 UP BOUND     c3799     10000
 FX BOUND     c3800     0
 FX BOUND     c3801     0
 UP BOUND     c3802     1
 UP BOUND     c3803     10000
 UP BOUND     c3804     1
 UP BOUND     c3805     10000
 FX BOUND     c3806     0
 FX BOUND     c3807     0
 UP BOUND     c3808     1
 UP BOUND     c3809     10000
 UP BOUND     c3810     1
 UP BOUND     c3811     10000
 UP BOUND     c3812     1
 UP BOUND     c3813     10000
 UP BOUND     c3814     1
 UP BOUND     c3815     10000
 UP BOUND     c3816     1
 FX BOUND     c3817     0
 UP BOUND     c3818     1
 UP BOUND     c3819     10000
 UP BOUND     c3820     1
 UP BOUND     c3821     10000
 UP BOUND     c3822     1
 UP BOUND     c3823     10000
 UP BOUND     c3824     1
 UP BOUND     c3825     10000
 UP BOUND     c3826     1
 UP BOUND     c3827     10000
 UP BOUND     c3828     1
 FX BOUND     c3829     0
 UP BOUND     c3830     1
 UP BOUND     c3831     10000
 UP BOUND     c3832     1
 UP BOUND     c3833     10000
 UP BOUND     c3834     1
 UP BOUND     c3835     10000
 UP BOUND     c3836     1
 UP BOUND     c3837     10000
 UP BOUND     c3838     1
 FX BOUND     c3839     0
 UP BOUND     c3840     1
 UP BOUND     c3841     10000
 UP BOUND     c3842     1
 UP BOUND     c3843     10000
 UP BOUND     c3844     1
 UP BOUND     c3845     10000
 UP BOUND     c3846     1
 UP BOUND     c3847     10000
 UP BOUND     c3848     1
 UP BOUND     c3849     10000
 FX BOUND     c3850     0
 FX BOUND     c3851     0
 UP BOUND     c3852     1
 UP BOUND     c3853     10000
 UP BOUND     c3854     1
 UP BOUND     c3855     10000
 UP BOUND     c3856     10000
 UP BOUND     c3857     10000
 UP BOUND     c3858     10000
 UP BOUND     c3859     10000
 UP BOUND     c3860     10000
 UP BOUND     c3861     10000
 UP BOUND     c3862     10000
 UP BOUND     c3863     10000
 UP BOUND     c3864     10000
 UP BOUND     c3865     10000
 UP BOUND     c3866     274.609493999997
 UP BOUND     c3867     10000
 UP BOUND     c3868     10000
 UP BOUND     c3869     10000
 UP BOUND     c3870     10000
 UP BOUND     c3871     10000
 UP BOUND     c3872     10000
 UP BOUND     c3873     10000
 UP BOUND     c3874     10000
 FX BOUND     c3875     0
 FX BOUND     c3876     0
 UP BOUND     c3877     10000
 UP BOUND     c3878     10000
 UP BOUND     c3879     10000
 UP BOUND     c3880     10000
 UP BOUND     c3881     10000
 UP BOUND     c3882     10000
 FX BOUND     c3883     0
 UP BOUND     c3884     10000
 FX BOUND     c3885     0
 UP BOUND     c3886     10000
 UP BOUND     c3887     10000
 UP BOUND     c3888     10000
 UP BOUND     c3889     10000
 UP BOUND     c3890     10000
 UP BOUND     c3891     10000
 UP BOUND     c3892     10000
 UP BOUND     c3893     10000
 UP BOUND     c3894     10000
 FX BOUND     c3895     0
 UP BOUND     c3896     10000
 UP BOUND     c3897     10000
 FX BOUND     c3898     0
 UP BOUND     c3899     10000
 UP BOUND     c3900     10000
 FX BOUND     c3901     0
 UP BOUND     c3902     10000
 UP BOUND     c3903     10000
 UP BOUND     c3904     10000
 UP BOUND     c3905     10000
 UP BOUND     c3906     10000
 UP BOUND     c3907     10000
 UP BOUND     c3908     10000
 UP BOUND     c3909     10000
 UP BOUND     c3910     10000
 UP BOUND     c3911     10000
 UP BOUND     c3912     10000
 UP BOUND     c3913     10000
 UP BOUND     c3914     10000
 UP BOUND     c3915     10000
 FX BOUND     c3916     0
 UP BOUND     c3917     10000
 UP BOUND     c3918     10000
 UP BOUND     c3919     10000
 UP BOUND     c3920     10000
 UP BOUND     c3921     10000
 FX BOUND     c3922     0
 UP BOUND     c3923     10000
 FX BOUND     c3924     0
 FX BOUND     c3925     0
 UP BOUND     c3926     10000
 UP BOUND     c3927     10000
 UP BOUND     c3928     10000
 UP BOUND     c3929     10000
 UP BOUND     c3930     10000
 UP BOUND     c3931     10000
 UP BOUND     c3932     10000
 UP BOUND     c3933     10000
 UP BOUND     c3934     10000
 UP BOUND     c3935     10000
 UP BOUND     c3936     10000
 UP BOUND     c3937     10000
 UP BOUND     c3938     10000
 UP BOUND     c3939     10000
 UP BOUND     c3940     10000
 UP BOUND     c3941     10000
 FX BOUND     c3942     0
 UP BOUND     c3943     10000
 UP BOUND     c3944     10000
 UP BOUND     c3945     10000
 UP BOUND     c3946     10000
 FX BOUND     c3947     0
 UP BOUND     c3948     10000
 UP BOUND     c3949     10000
 FX BOUND     c3950     0
 FX BOUND     c3951     0
 UP BOUND     c3952     10000
 UP BOUND     c3953     10000
 UP BOUND     c3954     10000
 UP BOUND     c3955     10000
 UP BOUND     c3956     10000
 UP BOUND     c3957     10000
 UP BOUND     c3958     10000
 UP BOUND     c3959     10000
 UP BOUND     c3960     10000
 UP BOUND     c3961     10000
 UP BOUND     c3962     10000
 UP BOUND     c3963     10000
 UP BOUND     c3964     10000
 UP BOUND     c3965     10000
 UP BOUND     c3966     10000
 FX BOUND     c3967     0
 UP BOUND     c3968     10000
 UP BOUND     c3969     10000
 FX BOUND     c3970     0
 UP BOUND     c3971     10000
 UP BOUND     c3972     10000
 UP BOUND     c3973     10000
 UP BOUND     c3974     10000
 UP BOUND     c3975     10000
 UP BOUND     c3976     10000
 UP BOUND     c3977     10000
 UP BOUND     c3978     10000
 UP BOUND     c3979     10000
 FX BOUND     c3980     0
 UP BOUND     c3981     10000
 UP BOUND     c3982     10000
 UP BOUND     c3983     10000
 UP BOUND     c3984     10000
 UP BOUND     c3985     10000
 FX BOUND     c3986     0
 UP BOUND     c3987     10000
 FX BOUND     c3988     0
 UP BOUND     c3989     10000
 UP BOUND     c3990     10000
 UP BOUND     c3991     10000
 UP BOUND     c3992     10000
 UP BOUND     c3993     10000
 UP BOUND     c3994     10000
 UP BOUND     c3995     10000
 UP BOUND     c3996     10000
 UP BOUND     c3997     10000
 UP BOUND     c3998     10000
 FX BOUND     c3999     0
 UP BOUND     c4000     10000
 UP BOUND     c4001     10000
 FX BOUND     c4002     0
 UP BOUND     c4003     10000
 UP BOUND     c4004     10000
 FX BOUND     c4005     0
 UP BOUND     c4006     10000
 FX BOUND     c4007     0
 UP BOUND     c4008     10000
 FX BOUND     c4009     0
 UP BOUND     c4010     10000
 UP BOUND     c4011     10000
 FX BOUND     c4012     0
 FX BOUND     c4013     0
 UP BOUND     c4014     10000
 UP BOUND     c4015     270
 FX BOUND     c4016     0
 FX BOUND     c4017     0
 FX BOUND     c4018     0
 UP BOUND     c4019     10000
 FX BOUND     c4020     0
 UP BOUND     c4021     10000
 FX BOUND     c4022     0
 UP BOUND     c4023     10000
 UP BOUND     c4024     10000
 UP BOUND     c4025     10000
 UP BOUND     c4026     10000
 UP BOUND     c4027     10000
 UP BOUND     c4028     10000
 UP BOUND     c4029     10000
 UP BOUND     c4030     10000
 UP BOUND     c4031     10000
 FX BOUND     c4032     0
 FX BOUND     c4033     0
 FX BOUND     c4034     0
 UP BOUND     c4035     10000
 UP BOUND     c4036     10000
 UP BOUND     c4037     10000
 UP BOUND     c4038     10000
 UP BOUND     c4039     10000
 UP BOUND     c4040     10000
 UP BOUND     c4041     10000
 FX BOUND     c4042     0
 UP BOUND     c4043     10000
 UP BOUND     c4044     10000
 UP BOUND     c4045     10000
 UP BOUND     c4046     10000
 UP BOUND     c4047     10000
 UP BOUND     c4048     10000
 UP BOUND     c4049     10000
 UP BOUND     c4050     10000
 UP BOUND     c4051     10000
 UP BOUND     c4052     10000
 UP BOUND     c4053     10000
 UP BOUND     c4054     10000
 UP BOUND     c4055     10000
 UP BOUND     c4056     10000
 FX BOUND     c4057     0
 UP BOUND     c4058     10000
 UP BOUND     c4059     10000
 UP BOUND     c4060     10000
 UP BOUND     c4061     10000
 UP BOUND     c4062     10000
 FX BOUND     c4063     0
 FX BOUND     c4064     0
 FX BOUND     c4065     0
 UP BOUND     c4066     10000
 UP BOUND     c4067     10000
 FX BOUND     c4068     0
 UP BOUND     c4069     10000
 FX BOUND     c4070     0
 FX BOUND     c4071     0
 UP BOUND     c4072     10000
 UP BOUND     c4073     10000
 FX BOUND     c4074     0
 FX BOUND     c4075     0
 UP BOUND     c4076     10000
 FX BOUND     c4077     0
 UP BOUND     c4078     10000
 UP BOUND     c4079     10000
 UP BOUND     c4080     10000
 FX BOUND     c4081     0
 UP BOUND     c4082     10000
 UP BOUND     c4083     10000
 FX BOUND     c4084     0
 UP BOUND     c4085     10000
 UP BOUND     c4086     10000
 UP BOUND     c4087     10000
 FX BOUND     c4088     0
 UP BOUND     c4089     10000
 UP BOUND     c4090     10000
 UP BOUND     c4091     10000
 UP BOUND     c4092     10000
 FX BOUND     c4093     0
 UP BOUND     c4094     10000
 UP BOUND     c4095     10000
 FX BOUND     c4096     0
 UP BOUND     c4097     10000
 UP BOUND     c4098     10000
 UP BOUND     c4099     10000
 FX BOUND     c4100     0
 FX BOUND     c4101     0
 UP BOUND     c4102     10000
 FX BOUND     c4103     0
 UP BOUND     c4104     10000
 UP BOUND     c4105     10000
 FX BOUND     c4106     0
 UP BOUND     c4107     10000
 UP BOUND     c4108     10000
 FX BOUND     c4109     0
 FX BOUND     c4110     0
 UP BOUND     c4111     10000
 FX BOUND     c4112     0
 UP BOUND     c4113     10000
 UP BOUND     c4114     10000
 UP BOUND     c4115     10000
 FX BOUND     c4116     0
 FX BOUND     c4117     0
 FX BOUND     c4118     0
 UP BOUND     c4119     10000
 UP BOUND     c4120     10000
 FX BOUND     c4121     0
 FX BOUND     c4122     0
 UP BOUND     c4123     10000
 UP BOUND     c4124     10000
 FX BOUND     c4125     0
 FX BOUND     c4126     0
 FX BOUND     c4127     0
 FX BOUND     c4128     0
 UP BOUND     c4129     10000
 UP BOUND     c4130     10000
 FX BOUND     c4131     0
 UP BOUND     c4132     10000
 UP BOUND     c4133     10000
 UP BOUND     c4134     10000
 FX BOUND     c4135     0
 FX BOUND     c4136     0
 UP BOUND     c4137     10000
 UP BOUND     c4138     10000
 UP BOUND     c4139     10000
 UP BOUND     c4140     10000
 FX BOUND     c4141     0
 UP BOUND     c4142     10000
 FX BOUND     c4143     0
 FX BOUND     c4144     0
 UP BOUND     c4145     10000
 UP BOUND     c4146     10000
 UP BOUND     c4147     10000
 UP BOUND     c4148     10000
 UP BOUND     c4149     10000
 UP BOUND     c4150     10000
 UP BOUND     c4151     10000
 FX BOUND     c4152     0
 UP BOUND     c4153     10000
 UP BOUND     c4154     10000
 FX BOUND     c4155     0
 UP BOUND     c4156     10000
 UP BOUND     c4157     10000
 FX BOUND     c4158     0
 FX BOUND     c4159     0
 FX BOUND     c4160     0
 UP BOUND     c4161     10000
 UP BOUND     c4162     10000
 UP BOUND     c4163     10000
 UP BOUND     c4164     10000
 UP BOUND     c4165     10000
 UP BOUND     c4166     10000
 UP BOUND     c4167     10000
 UP BOUND     c4168     10000
 UP BOUND     c4169     10000
 UP BOUND     c4170     10000
 UP BOUND     c4171     10000
 FX BOUND     c4172     0
 UP BOUND     c4173     10000
 UP BOUND     c4174     10000
 UP BOUND     c4175     10000
 UP BOUND     c4176     10000
 FX BOUND     c4177     0
 UP BOUND     c4178     10000
 UP BOUND     c4179     10000
 UP BOUND     c4180     10000
 UP BOUND     c4181     10000
 FX BOUND     c4182     0
 UP BOUND     c4183     10000
 UP BOUND     c4184     10000
 UP BOUND     c4185     10000
 FX BOUND     c4186     0
 UP BOUND     c4187     10000
 FX BOUND     c4188     0
 UP BOUND     c4189     10000
 FX BOUND     c4190     0
 UP BOUND     c4191     10000
 UP BOUND     c4192     10000
 UP BOUND     c4193     10000
 UP BOUND     c4194     10000
 UP BOUND     c4195     10000
 UP BOUND     c4196     10000
 UP BOUND     c4197     10000
 UP BOUND     c4198     10000
 FX BOUND     c4199     0
 FX BOUND     c4200     0
 UP BOUND     c4201     10000
 UP BOUND     c4202     10000
 UP BOUND     c4203     10000
 UP BOUND     c4204     10000
 UP BOUND     c4205     10000
 UP BOUND     c4206     10000
 FX BOUND     c4207     0
 UP BOUND     c4208     10000
 FX BOUND     c4209     0
 UP BOUND     c4210     10000
 UP BOUND     c4211     10000
 UP BOUND     c4212     10000
 UP BOUND     c4213     10000
 FX BOUND     c4214     0
 FX BOUND     c4215     0
 UP BOUND     c4216     10000
 UP BOUND     c4217     10000
 UP BOUND     c4218     10000
 UP BOUND     c4219     10000
 UP BOUND     c4220     10000
 UP BOUND     c4221     10000
 UP BOUND     c4222     10000
 UP BOUND     c4223     10000
 UP BOUND     c4224     10000
 FX BOUND     c4225     0
 UP BOUND     c4226     10000
 UP BOUND     c4227     10000
 FX BOUND     c4228     0
 UP BOUND     c4229     10000
 FX BOUND     c4230     0
 FX BOUND     c4231     0
 UP BOUND     c4232     10000
 FX BOUND     c4233     0
 FX BOUND     c4234     0
 FX BOUND     c4235     0
 UP BOUND     c4236     10000
 FX BOUND     c4237     0
 UP BOUND     c4238     10000
 FX BOUND     c4239     0
 UP BOUND     c4240     10000
 UP BOUND     c4241     10000
 UP BOUND     c4242     10000
 UP BOUND     c4243     10000
 UP BOUND     c4244     10000
 UP BOUND     c4245     10000
 UP BOUND     c4246     10000
 UP BOUND     c4247     10000
 UP BOUND     c4248     10000
 UP BOUND     c4249     10000
 UP BOUND     c4250     10000
 UP BOUND     c4251     10000
 UP BOUND     c4252     10000
 UP BOUND     c4253     10000
 FX BOUND     c4254     0
 UP BOUND     c4255     270
 UP BOUND     c4256     10000
 UP BOUND     c4257     10000
 FX BOUND     c4258     0
 FX BOUND     c4259     0
 UP BOUND     c4260     10000
 UP BOUND     c4261     10000
 UP BOUND     c4262     10000
 FX BOUND     c4263     0
 UP BOUND     c4264     10000
 UP BOUND     c4265     10000
 UP BOUND     c4266     10000
 UP BOUND     c4267     10000
 UP BOUND     c4268     10000
 UP BOUND     c4269     10000
 UP BOUND     c4270     10000
 UP BOUND     c4271     10000
 FX BOUND     c4272     0
 UP BOUND     c4273     10000
 FX BOUND     c4274     0
 UP BOUND     c4275     10000
 FX BOUND     c4276     0
 UP BOUND     c4277     10000
 UP BOUND     c4278     10000
 UP BOUND     c4279     10000
 UP BOUND     c4280     10000
 FX BOUND     c4281     0
 FX BOUND     c4282     0
 UP BOUND     c4283     10000
 UP BOUND     c4284     10000
 FX BOUND     c4285     0
 FX BOUND     c4286     0
 UP BOUND     c4287     10000
 UP BOUND     c4288     10000
 FX BOUND     c4289     0
 UP BOUND     c4290     10000
 FX BOUND     c4291     0
 FX BOUND     c4292     0
 FX BOUND     c4293     0
 UP BOUND     c4294     10000
 FX BOUND     c4295     0
 FX BOUND     c4296     0
 UP BOUND     c4297     10000
 UP BOUND     c4298     10000
 FX BOUND     c4299     0
 UP BOUND     c4300     10000
 UP BOUND     c4301     10000
 FX BOUND     c4302     0
 UP BOUND     c4303     10000
 UP BOUND     c4304     10000
 UP BOUND     c4305     10000
 UP BOUND     c4306     10000
 UP BOUND     c4307     10000
 UP BOUND     c4308     10000
 UP BOUND     c4309     10000
 UP BOUND     c4310     10000
 UP BOUND     c4311     10000
 UP BOUND     c4312     10000
 UP BOUND     c4313     10000
 UP BOUND     c4314     10000
 UP BOUND     c4315     10000
 UP BOUND     c4316     10000
 UP BOUND     c4317     10000
 UP BOUND     c4318     10000
 FX BOUND     c4319     0
 UP BOUND     c4320     10000
 UP BOUND     c4321     10000
 UP BOUND     c4322     10000
 UP BOUND     c4323     10000
 UP BOUND     c4324     10000
 UP BOUND     c4325     10000
 UP BOUND     c4326     10000
 FX BOUND     c4327     0
 UP BOUND     c4328     10000
 UP BOUND     c4329     10000
 UP BOUND     c4330     10000
 FX BOUND     c4331     0
 UP BOUND     c4332     10000
 UP BOUND     c4333     10000
 UP BOUND     c4334     10000
 UP BOUND     c4335     10000
 UP BOUND     c4336     10000
 UP BOUND     c4337     10000
 UP BOUND     c4338     10000
 FX BOUND     c4339     0
 UP BOUND     c4340     10000
 UP BOUND     c4341     10000
 UP BOUND     c4342     10000
 UP BOUND     c4343     10000
 UP BOUND     c4344     10000
 UP BOUND     c4345     10000
 UP BOUND     c4346     10000
 FX BOUND     c4347     0
 UP BOUND     c4348     10000
 UP BOUND     c4349     10000
 FX BOUND     c4350     0
 FX BOUND     c4351     0
 UP BOUND     c4352     10000
 UP BOUND     c4353     10000
 FX BOUND     c4354     0
 UP BOUND     c4355     10000
 FX BOUND     c4356     0
 UP BOUND     c4357     10000
 UP BOUND     c4358     10000
 UP BOUND     c4359     10000
 UP BOUND     c4360     10000
 FX BOUND     c4361     0
 UP BOUND     c4362     10000
 UP BOUND     c4363     10000
 UP BOUND     c4364     10000
 UP BOUND     c4365     10000
 UP BOUND     c4366     10000
 UP BOUND     c4367     10000
 UP BOUND     c4368     10000
 UP BOUND     c4369     10000
 UP BOUND     c4370     10000
 FX BOUND     c4371     0
 UP BOUND     c4372     10000
 UP BOUND     c4373     10000
 UP BOUND     c4374     10000
 UP BOUND     c4375     10000
 UP BOUND     c4376     10000
 UP BOUND     c4377     10000
 FX BOUND     c4378     0
 FX BOUND     c4379     0
 FX BOUND     c4380     0
 UP BOUND     c4381     10000
 UP BOUND     c4382     10000
 UP BOUND     c4383     10000
 UP BOUND     c4384     10000
 UP BOUND     c4385     10000
 UP BOUND     c4386     10000
 UP BOUND     c4387     10000
 UP BOUND     c4388     10000
 UP BOUND     c4389     10000
 UP BOUND     c4390     10000
 UP BOUND     c4391     10000
 UP BOUND     c4392     10000
 UP BOUND     c4393     10000
 UP BOUND     c4394     10000
 UP BOUND     c4395     10000
 UP BOUND     c4396     10000
 UP BOUND     c4397     10000
 UP BOUND     c4398     10000
 UP BOUND     c4399     10000
 UP BOUND     c4400     135
 UP BOUND     c4401     10000
 UP BOUND     c4402     10000
 UP BOUND     c4403     77.7840519999983
 UP BOUND     c4404     10000
 FX BOUND     c4405     0
 UP BOUND     c4406     10000
 UP BOUND     c4407     10000
 UP BOUND     c4408     10000
 UP BOUND     c4409     10000
 UP BOUND     c4410     10000
 UP BOUND     c4411     10000
 UP BOUND     c4412     10000
 FX BOUND     c4413     0
 UP BOUND     c4414     10000
 UP BOUND     c4415     10000
 UP BOUND     c4416     10000
 UP BOUND     c4417     10000
 UP BOUND     c4418     10000
 UP BOUND     c4419     10000
 UP BOUND     c4420     10000
 FX BOUND     c4421     0
 UP BOUND     c4422     10000
 UP BOUND     c4423     10000
 UP BOUND     c4424     10000
 FX BOUND     c4425     0
 UP BOUND     c4426     10000
 UP BOUND     c4427     10000
 UP BOUND     c4428     10000
 UP BOUND     c4429     10000
 UP BOUND     c4430     10000
 FX BOUND     c4431     0
 UP BOUND     c4432     10000
 UP BOUND     c4433     10000
 UP BOUND     c4434     10000
 UP BOUND     c4435     10000
 UP BOUND     c4436     10000
 UP BOUND     c4437     10000
 UP BOUND     c4438     10000
 UP BOUND     c4439     10000
 UP BOUND     c4440     10000
 UP BOUND     c4441     10000
 UP BOUND     c4442     10000
 UP BOUND     c4443     10000
 UP BOUND     c4444     10000
 FX BOUND     c4445     0
 UP BOUND     c4446     10000
 UP BOUND     c4447     10000
 UP BOUND     c4448     10000
 UP BOUND     c4449     10000
 UP BOUND     c4450     10000
 UP BOUND     c4451     10000
 UP BOUND     c4452     10000
 UP BOUND     c4453     10000
 UP BOUND     c4454     10000
 UP BOUND     c4455     10000
 UP BOUND     c4456     10000
 FX BOUND     c4457     0
 UP BOUND     c4458     10000
 UP BOUND     c4459     10000
 FX BOUND     c4460     0
 UP BOUND     c4461     10000
 UP BOUND     c4462     10000
 UP BOUND     c4463     10000
 UP BOUND     c4464     10000
 UP BOUND     c4465     10000
 UP BOUND     c4466     10000
 UP BOUND     c4467     10000
 UP BOUND     c4468     10000
 FX BOUND     c4469     0
 UP BOUND     c4470     10000
 UP BOUND     c4471     10000
 UP BOUND     c4472     10000
 UP BOUND     c4473     10000
 UP BOUND     c4474     10000
 UP BOUND     c4475     10000
 UP BOUND     c4476     10000
 UP BOUND     c4477     10000
 UP BOUND     c4478     10000
 UP BOUND     c4479     10000
 FX BOUND     c4480     0
 UP BOUND     c4481     10000
 UP BOUND     c4482     10000
 UP BOUND     c4483     10000
 UP BOUND     c4484     10000
 UP BOUND     c4485     10000
 UP BOUND     c4486     10000
 UP BOUND     c4487     10000
 UP BOUND     c4488     10000
 FX BOUND     c4489     0
 FX BOUND     c4490     0
 UP BOUND     c4491     10000
 UP BOUND     c4492     10000
 UP BOUND     c4493     10000
 FX BOUND     c4494     1631.6367
 FX BOUND     c4495     142.7782
 FX BOUND     c4496     0
 FX BOUND     c4497     0
 FX BOUND     c4498     0
 FX BOUND     c4499     0
 FX BOUND     c4500     241.9
 FX BOUND     c4501     25
 FX BOUND     c4502     329.4425
 FX BOUND     c4503     569.399287
 LO BOUND     c4504     1853.93762
 UP BOUND     c4504     2703.70812
 FX BOUND     c4505     0
 FX BOUND     c4506     0
 UP BOUND     c4507     1019.9821
 LO BOUND     c4508     55.5
 UP BOUND     c4508     239.0367
 FX BOUND     c4509     0
 FX BOUND     c4510     0
 FX BOUND     c4511     0
 FX BOUND     c4512     0
 FX BOUND     c4513     0
 FX BOUND     c4514     0
 FX BOUND     c4515     68.9
 FX BOUND     c4516     0
 FX BOUND     c4517     0
 FX BOUND     c4518     2623.0372
 FX BOUND     c4519     179.1035
 FX BOUND     c4520     465.62
 FX BOUND     c4521     804.4362
ENDATA
